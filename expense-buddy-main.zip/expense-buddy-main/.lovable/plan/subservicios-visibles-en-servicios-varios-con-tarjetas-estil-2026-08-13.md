# Subservicios visibles en Servicios Varios, con tarjetas estilo portada

## Qué pasa hoy

El servicio "Servicios Varios" ahora tiene número contable `1130204` como código, pero la página del servicio decide mostrar los subservicios comparando el código con el texto `varios`. Al no coincidir, todo el bloque de subservicios (y sus estadísticas y buscador) queda oculto. Eso es lo que hace que "no aparezcan".

## Qué se hace

1. Detectar "Servicios Varios" de forma robusta: por nombre del servicio (normalizado, sin acentos/mayúsculas) o por código legado `varios`, en lugar de depender del código contable. Así sigue funcionando si mañana cambia el número contable.

2. Rediseñar el bloque de subservicios con el mismo look de la pantalla de inicio (Administración / Afiliados / Proveedores):
   - Una grilla de tarjetas (3 por fila en escritorio, 2 en tablet, 1 en móvil) con borde superior de color institucional.
   - Cada tarjeta: ícono + título del subservicio, una línea de descripción y un botón ancho abajo.
   - Botones: "Gestionar círculos", "Gestionar cumpleaños", "Gestionar colectas", "Gestionar comida a dto.", "Gestionar más servicios".
   - Los cinco subservicios siempre visibles, dentro de Servicios Varios.

3. Quitar el botón "Gestionar" duplicado del bloque de estadísticas por subservicio, para no repetir la misma acción dos veces en la página.

## Detalles técnicos

- `src/routes/_authenticated/admin/servicio.$codigo.tsx`: reemplazar `const esVarios = codigo === "varios"` por una detección basada en `svc?.nombre` normalizado (`servicios varios`) con fallback al código; reemplazar el `div`/borde simple del bloque de subservicios por `Card` + `CardHeader`/`CardDescription`/`CardContent` con `border-t-4 border-t-primary` e íconos de `lucide-react`, replicando el patrón de `src/routes/index.tsx`.
- Sin cambios de base de datos ni de lógica de liquidaciones.
