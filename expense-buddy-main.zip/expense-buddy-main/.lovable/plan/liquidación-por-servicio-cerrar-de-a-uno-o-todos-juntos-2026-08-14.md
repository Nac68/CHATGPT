# Liquidación por servicio: cerrar de a uno o todos juntos

## Qué se agrega

En la sección **Liquidación** (período desde/hasta), debajo de los totales, un **listado con todos los servicios y subservicios** del período:

| Servicio / Subservicio | N° contable | Afiliados | Total a descontar | Estado | Acción |
|---|---|---|---|---|---|
| Farmacia | 1130501 | 82 | $ 1.240.300 | Pendiente | Cerrar |
| Círculos | 1130204 | 45 | $ 380.000 | Cerrado (14/08) | Reabrir |
| Comida a Dto. | … | 130 | $ 512.700 | Pendiente | Cerrar |

- Aparecen **todos** los servicios activos, incluso con total en $0 (se muestran deshabilitados para cerrar).
- Arriba del listado: **Total en pesos a liquidar del período**, más el total ya cerrado y el total pendiente, en tarjetas.
- Selección múltiple con casillas + botón **Cerrar seleccionados** y botón **Cerrar todo el período** (equivale a lo que hace hoy).
- Cerrar un servicio marca como liquidado solo lo de ese concepto; el resto queda pendiente y se puede cerrar después dentro del mismo período.
- Cada cierre queda registrado y se puede **reabrir** individualmente, liberando solo sus consumos.
- El Excel de descuentos se puede bajar del período completo (como hoy) o solo de los servicios cerrados de una tanda.

## Detalles técnicos

- Migración: agregar a `payroll_periods` una columna `concepto_key text` y `concepto_nombre text` (nulas = cierre total del período), para que un mismo rango pueda tener varios cierres parciales. Sin cambios en `payroll_period_items` / `payroll_consumed` (la unicidad de `source_key` ya evita doble cobro).
- `src/lib/payroll.server.ts`: `buildPayroll` ya devuelve `conceptos` con `total`/`afiliados` y `rows[].keys`; agregar el `conceptKey` a cada `source_key` registrado en la fila para poder filtrar por concepto al cerrar, y devolver por concepto los `keys` correspondientes.
- `src/lib/payroll.functions.ts`: `closePayroll` acepta `conceptos?: string[]`; cuando viene, inserta un período por tanda con solo los ítems y `payroll_consumed` de esos conceptos y guarda `concepto_key`. `listPayrollPeriods` devuelve los cierres parciales para pintar el estado del listado. `reopenPayroll` sin cambios (borra el período y libera sus keys por cascada de `payroll_consumed`; si no hay cascada, se borra explícitamente).
- `src/routes/_authenticated/admin/liquidacion.tsx`: nueva tarjeta "Servicios del período" con casillas, estado por concepto (cruzando `listPayrollPeriods` del mismo rango), acciones Cerrar / Cerrar seleccionados / Cerrar todo / Reabrir, y KPIs de total a liquidar / cerrado / pendiente.
