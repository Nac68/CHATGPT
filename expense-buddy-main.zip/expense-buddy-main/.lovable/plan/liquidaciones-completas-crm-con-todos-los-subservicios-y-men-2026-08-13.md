# Liquidaciones completas, CRM con todos los subservicios y menú reordenado

## 1. Buscador CRM: historial completo por afiliado

Hoy el historial de un afiliado en el Buscador CRM sólo trae consumos de proveedores/servicios y Comida a Dto. Se agregan los subservicios de Servicios Varios:

- Círculos: aporte mensual por mes activo del círculo.
- Cumpleaños: cuota del mes según el plan.
- Colectas: cuota del mes según la colecta (no cerradas).

Estos aportes se suman al resumen mensual ("por mes"), al desglose "por servicio" y a los totales (importe y a descontar), y se muestran en una nueva tabla "Servicios Varios" en la ficha del afiliado, con exportación a Excel igual que las demás.

## 2. Liquidaciones: todos los servicios

La liquidación por período ya incorpora servicios de proveedores, Comida a Dto., Círculos, Cumpleaños y Colectas. Se revisa y completa para que:

- Cada servicio activo genere su columna con su número contable, incluidos los que se cargan como "Descuentos Diversos".
- Ningún concepto quede fuera por falta de número contable (se muestra igual, con la cuenta vacía).
- El detalle por afiliado del Excel incluya una columna por cada servicio/subservicio con importe en el período.

## 3. Menú del panel

- Se elimina la sección "Consumos CRM" (y su página).
- Se agrega "Proveedores" como sección propia del menú principal.
- Del menú "Servicios" se quitan "Proveedores", "Colectas" y "Cumpleaños". Colectas y Cumpleaños siguen accesibles desde la ficha de Servicios Varios (tarjetas de producto).

## Detalles técnicos

- `src/lib/crm-search.server.ts` → `affiliateHistory`: leer `circle_members`/`circles`, `birthday_members`/`birthday_plans`, `collection_members`/`collections`, reutilizando `circleActivo` (circles.server), `cuotaIndex` (birthdays.server y collections.server) para expandir cuotas por mes; devolver nuevo array `varios` y sumarlo en `porMes`, `porServicio` y `totales`.
- `src/routes/_authenticated/admin/crm.tsx`: nueva tabla + hoja Excel para `varios`.
- `src/lib/payroll.server.ts`: verificar cobertura de conceptos y cuentas contables por servicio/producto.
- `src/routes/_authenticated/admin/route.tsx`: ajustar navegación; borrar `src/routes/_authenticated/admin/consumos.tsx`.
