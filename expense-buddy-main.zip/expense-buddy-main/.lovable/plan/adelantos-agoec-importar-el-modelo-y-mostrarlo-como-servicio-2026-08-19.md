# Adelantos AGOEC: importar el modelo y mostrarlo como servicio

## Qué encontré

- El archivo modelo (`Descripcion` fila 1, `Periodo` 201801 fila 2, títulos FECHA/LEGAJO/... fila 4) se lee bien: el lector detecta la fila de títulos y el período, y encuentra 300+ filas.
- Los legajos de muestra del modelo están en el padrón y la tabla de adelantos existe, pero **no tiene ni un registro guardado**: la importación nunca llegó a guardarse.
- El motivo es el flujo actual: al confirmar la previsualización, las filas sólo se cargan en la tabla de carga manual y hay que apretar además "Guardar". Con 300 filas eso se ve como "no pasó nada / no lo reconoce".
- El servicio `Adelantos` ya existe como servicio independiente en la base y no tiene productos. Sin embargo, al abrirlo desde el menú se usa la pantalla genérica de servicios, que siempre muestra formularios, métricas y secciones de productos/proveedores; por eso siguen apareciendo aunque Adelantos sea interno de AGOEC.
- El servidor de CRM ya arma las cuotas de adelantos como consumos con servicio `Adelantos`, origen `AGOEC` y opción de refinanciación. No aparecen porque todavía no hay adelantos guardados.

## Qué voy a cambiar

1. **Confirmar = guardar**. En la previsualización, el botón pasa a "Confirmar e importar": guarda directamente los adelantos en la base con el período elegido y refresca el listado, sin pasar por la tabla de carga manual.
2. **Legajos bien reconocidos**. Normalizar legajos numéricos y alfanuméricos como texto (sin `.0`, espacios invisibles ni diferencias de mayúsculas), cruzarlos contra el padrón y mostrar antes de confirmar cuáles no se reconocieron. Las filas válidas se guardan; las no reconocidas quedan detalladas para corregirlas, sin un error genérico que bloquee todo el archivo.
3. **Lectura más tolerante**. Aceptar el archivo aunque los títulos vengan con acentos, mayúsculas, espacios extra, celdas combinadas o alguna fila vacía antes de los títulos; aceptar también la primera hoja con otro nombre. Si no encuentra la fila de títulos, el mensaje dirá exactamente qué se esperaba.
4. **Feedback al elegir el archivo**. Mostrar el nombre del archivo y un estado "leyendo…" al instante, para que se vea que el archivo fue tomado.
5. **Adelantos es sólo AGOEC, sin productos**. Tanto el menú de Servicios como cualquier acceso a la ficha genérica de `Adelantos` abrirán directamente la pantalla específica de Adelantos. Esa pantalla sólo tendrá importación, carga manual y listado; no mostrará alta de productos, proveedores ni configuración de servicios.
6. **Adelantos visible en CRM como servicio**. Mantenerlo como servicio `Adelantos` (no como producto ni mezclado visualmente con otro servicio), con origen `AGOEC`, período, cuota y monto. Las filas quedarán seleccionables para refinanciar y aparecerán también en el resumen por servicio.
7. **Verificación real**. Probar el flujo completo en la app con el archivo modelo (importar → confirmar → listado → búsqueda de uno de sus legajos en CRM), y confirmar en la base que quedaron los registros con período 01/2018 y sus cuotas.

## Detalles técnicos

- `src/routes/_authenticated/admin/adelantos.tsx`: `confirmarImportacion` llama a `saveAdvances` con las filas de la previsualización en vez de sólo `setRows`; agregar estado de archivo/lectura; normalizar títulos y legajos; mostrar coincidencias y no reconocidos; quitar cualquier dependencia visual de productos o proveedores.
- `src/lib/advances.functions.ts`: normalizar los legajos antes del cruce; devolver `{ guardados, omitidos: [{legajo, motivo}] }` guardando los válidos, y hacer que el cliente muestre el detalle.
- `src/components/ImportPreview.tsx`: permitir `confirmLabel` "Confirmar e importar" y estado de carga (ya soportado vía `loading`).
- `src/routes/_authenticated/admin/route.tsx`: el ítem `Adelantos` del menú de Servicios enlaza a `/admin/adelantos`, no a la ficha genérica.
- `src/routes/_authenticated/admin/servicio.$codigo.tsx`: si el código corresponde a Adelantos, redirigir a la pantalla específica para que nunca se rendericen productos/proveedores.
- `src/lib/crm-search.server.ts` y `src/routes/_authenticated/admin/crm.tsx`: verificar y ajustar la clasificación para que cada cuota se presente explícitamente bajo el servicio `Adelantos`, con origen `AGOEC`, en detalle, resumen y refinanciación.
- Sin cambios de base de datos.
