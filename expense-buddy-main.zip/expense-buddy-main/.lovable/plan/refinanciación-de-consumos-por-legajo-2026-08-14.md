# Refinanciación de consumos por legajo

## Cómo se usa

1. En el **Buscador CRM**, al pedir todos los consumos de un legajo, la grilla de detalle unificado (todos los servicios y subservicios) gana una **casilla de selección** por fila.
2. Se marcan uno o varios consumos y se toca **Refinanciar seleccionados**. Se abre una ventana con:
   - Total elegido y el detalle de lo que se refinancia.
   - **Cantidad de cuotas** (1 a 60) y **período de inicio** (mes/año; por defecto el próximo).
   - Observación opcional.
   - Muestra el importe de cada cuota (total / cuotas).
3. Al confirmar: los consumos pasan a estado **Refinanciado** y dejan de descontarse por su concepto original; en su lugar se descuenta la cuota correspondiente bajo el concepto **Refinanciación** en cada período.
4. Nueva pantalla **Refinanciación** (tarjeta "Gestionar refinanciación" en Servicios Varios, como los otros subservicios) con:
   - KPIs: legajos refinanciando, total refinanciado, saldo pendiente, cuota del período actual.
   - Listado de todos los legajos con refinanciación: legajo, nombre, total, cuotas, importe de cuota, cuota actual (ej. 3/10), saldo pendiente, período de inicio/fin, estado (Activa / Finalizada).
   - Buscador por legajo o nombre, detalle de los consumos incluidos, descarga de Excel y opción de **anular** una refinanciación (los consumos vuelven a su cobro original si todavía no se liquidaron).

## Reglas

- Al refinanciar, el consumo original queda excluido de la liquidación futura; lo ya liquidado en períodos cerrados no se toca (sólo se refinancia el saldo no liquidado).
- Un consumo ya refinanciado no puede volver a seleccionarse (aparece con la etiqueta Refinanciado).
- La cuota del período se calcula igual que en Adelantos: total / cuotas, desde el período de inicio.

## Detalles técnicos

- **Migración**: tabla `refinanciaciones` (legajo, apellido_nombre, total, cuotas, periodo_mes, periodo_anio, observacion, estado, created_by, timestamps) y `refinanciacion_items` (refinanciacion_id, source_key, servicio, detalle, periodo, importe). GRANTs para `authenticated`/`service_role`, RLS: admin gestiona todo (`has_role(auth.uid(),'admin')`), el afiliado ve sólo su legajo (`current_legajo()`).
- `src/lib/crm-search.server.ts`: cada fila del `detalle` unificado expone un `source_key` estable equivalente al que usa la liquidación (`submission_item:<id>`, `daily_consumption:<id>`, `circle_member:<id>:<ym>`, etc.) más un flag `refinanciado` cruzando `refinanciacion_items`.
- `src/lib/refinance.functions.ts` + `refinance.server.ts`: `createRefinance` (valida keys, calcula total, inserta cabecera + ítems y marca los `source_key` como consumidos en `payroll_consumed` para que no se cobren por su concepto original), `listRefinances` (con plan de cuotas y saldo, reutilizando el helper de cuotas por período de `advances.server.ts`), `cancelRefinance` (borra la refinanciación y libera los `source_key` no liquidados).
- `src/lib/payroll.server.ts`: nuevo bloque que agrega el concepto `refinanciacion` ("Refinanciación") con `source_key` `refinanciacion:<id>:<YYYYMM>`, aportando la cuota del período; se suma también a la lista de conceptos siempre visibles.
- `src/routes/_authenticated/admin/crm.tsx`: columna de casillas en la grilla de detalle, barra de acción con total seleccionado y diálogo de refinanciación.
- `src/routes/_authenticated/admin/refinanciacion.tsx`: nueva ruta con KPIs, buscador, listado, detalle expandible y exportación a Excel; tarjeta de acceso en `servicio.$codigo.tsx` (Servicios Varios).
