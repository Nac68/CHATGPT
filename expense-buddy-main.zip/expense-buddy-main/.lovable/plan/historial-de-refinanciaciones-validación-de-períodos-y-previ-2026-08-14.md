# Historial de refinanciaciones, validación de períodos y previsualización de Excel

## 1. Historial de refinanciaciones

**Por legajo (Buscador CRM y pantalla Refinanciación)**
- Nueva sección "Historial de refinanciaciones" en la ficha del afiliado del Buscador CRM: una fila por plan con fecha de refinanciación, período inicial (mes/año), período final, cantidad de cuotas, importe de cuota, total refinanciado, saldo pendiente y estado (en curso / finalizada).
- Al expandir un plan se ven los consumos que lo componen (servicio, detalle, período original, importe).
- Descarga a Excel del historial del legajo.

**Por servicio**
- Nueva pestaña "Por servicio" en `/admin/refinanciacion`: agrupa los consumos refinanciados por servicio de origen (Farmacia, Supermercado, Comida a Dto., Círculos, Cumpleaños, Colectas, Adelantos, etc.) mostrando cantidad de planes, legajos alcanzados, total refinanciado y saldo pendiente de ese servicio.
- Filtro por servicio y por período de refinanciación, más exportación a Excel.

**En la ficha de cada afiliado (portal del afiliado)**
- El afiliado ve sus planes de refinanciación con cuotas, cuota del mes y saldo, sin poder modificarlos.

## 2. Proveedor externo se cobra el total; AGOEC refinancia

Ya está así en el cálculo: lo que se le paga al proveedor sale del total de su liquidación y no se toca cuando el consumo se refinancia; la refinanciación solo cambia **cómo se le descuenta al afiliado**. Lo que se agrega es dejarlo explícito y auditable:

- Aviso en el diálogo de refinanciación: "Al proveedor se le paga el total de la factura; AGOEC financia el consumo al afiliado en cuotas".
- En Informes contables, la refinanciación aparece como concepto propio del lado de descuentos a afiliados, y el pago al proveedor sigue figurando completo en el informe de transferencias.
- En el detalle de cada plan se indica el proveedor de origen de cada consumo, para poder cruzar "pagado al proveedor" contra "financiado al afiliado".

## 3. Validación obligatoria de Mes y Año en toda carga

Regla única para todas las cargas (manual y Excel): no se guarda nada si el período no es válido — mes entre 1 y 12, año entre 2000 y 2100, ambos presentes.

Pantallas afectadas: Adelantos, Círculos, Cumpleaños, Colectas, Más Servicios (carga administrativa), Liquidaciones de proveedor (Farmacia y resto) y Refinanciación.

- El botón de guardar queda deshabilitado mientras el período esté incompleto o fuera de rango, con el mensaje del error a la vista.
- Los selectores de mes/año se normalizan: mes como lista de meses y año como número validado (se aceptan formatos `YYYYMM`, `MM/YYYY` y `MM-YYYY` al importar).
- La validación se repite también del lado del servidor, para que ninguna carga entre con período inválido aunque se llame directo.

## 4. Previsualización antes de confirmar la importación

Cada importador de Excel pasa a un flujo de dos pasos:

1. **Leer y previsualizar**: se muestra un panel con lo detectado — Descripción, Período (mes/año, resaltado en rojo si falta o es inválido), cantidad de filas válidas, cuotas detectadas, total importado, legajos no encontrados en el padrón y filas descartadas con el motivo. Tabla con las primeras filas y buscador.
2. **Confirmar importación**: recién ahí se cargan los datos. También se puede cancelar y volver a elegir el archivo, o corregir el período a mano antes de confirmar.

Si el período no se pudo leer del Excel, la previsualización lo pide explícitamente y no permite confirmar hasta completarlo.

## Detalles técnicos

- `src/lib/refinance.functions.ts`: agregar `refinanceHistoryByLegajo` (planes + items + plan de cuotas del legajo) y `refinanceByService` (agregación por `refinanciacion_items.servicio`), ambas con `requireSupabaseAuth` + chequeo de rol admin; para el portal del afiliado, una lectura scopeada por `current_legajo()`.
- `src/lib/refinance.server.ts`: reutilizar `withPlan` para calcular cuota, cuotas restantes y saldo en las nuevas vistas.
- `src/lib/periodo.ts` (nuevo): helpers compartidos `parsePeriodo`, `periodoValido`, `formatPeriodo` y un `zPeriodo` de Zod, usados por las pantallas y por los validadores de las server functions de adelantos, círculos, cumpleaños, colectas, carga de servicios y liquidaciones.
- `src/components/ImportPreview.tsx` (nuevo): panel de previsualización reutilizable (encabezado detectado, período editable, KPIs, tabla con filas y motivos de descarte, botones Confirmar / Cancelar). Los importadores existentes dejan de guardar directo y pasan a poblar este componente.
- `src/routes/_authenticated/admin/refinanciacion.tsx`: pestañas "En curso", "Finalizadas" y "Por servicio", con exportación a Excel de cada vista.
- `src/routes/_authenticated/admin/crm.tsx`: nueva tarjeta de historial de refinanciaciones en la ficha del afiliado.
- Sin cambios de base de datos: `refinanciaciones` y `refinanciacion_items` ya guardan `created_at`, `periodo_mes`, `periodo_anio`, `cuotas`, `servicio` y `periodo` original.
