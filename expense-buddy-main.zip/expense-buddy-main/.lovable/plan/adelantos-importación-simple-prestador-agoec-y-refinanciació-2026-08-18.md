# Adelantos: importación simple, prestador AGOEC y refinanciación

## 1. Importación de Excel exactamente como el modelo

La importación (y la carga manual) usa el formato del archivo enviado:

- Fila 1: `Descripcion` = ADELANTOS
- Fila 2: `Periodo` = 201801 (se traduce a mes/año)
- Fila 4 (títulos): FECHA | LEGAJO | APELLIDO_Y_NOMBRE | MONTO_PEDIDO | CUOTAS | CUIL | BANCO | N°_DE_CUENTA | 1°_CBU | 2°_CBU | CONCEPTO | RESPONSABLE | ID

Ajustes:
- Aceptar legajos alfanuméricos y numéricos; el nombre se completa desde el padrón.
- Si el Excel no trae período, se pide en pantalla antes de confirmar (se mantiene la previsualización, pero simplificada: archivo, descripción, período, filas y descartadas).
- La descarga de Excel sale con el mismo formato, para reimportar sin cambios.

## 2. El adelanto lo presta siempre AGOEC

- Se elimina toda elección de proveedor/servicio en Adelantos: el prestador es fijo AGOEC.
- La pantalla Adelantos no muestra nada de "crear servicio" ni enlaces a configuración de servicios: sólo período, importar/exportar Excel, carga manual y el listado de adelantos.

## 3. Los adelantos entran en Refinanciación

- Al buscar un legajo en el Buscador CRM, además de los otros servicios aparecen las cuotas de adelanto como consumos seleccionables (servicio "Adelantos", período y cuota 1/N).
- Tildando esas filas se refinancia el adelanto igual que cualquier otro consumo: se elige cantidad de cuotas y período de inicio, y pasa a la pantalla Refinanciación.
- Lo refinanciado deja de cobrarse por el concepto "Adelantos" y se cobra sólo por el plan de refinanciación (sin doble descuento).
- En el historial de refinanciación por servicio aparece "Adelantos" como origen.

## Detalles técnicos

- `src/routes/_authenticated/admin/adelantos.tsx`: quitar cualquier referencia/enlace a configuración o creación de servicios; dejar el flujo en tres bloques (Datos del listado + Excel, carga manual, listado). Mantener `parsePeriodo`/`periodoError` y `ImportPreview`.
- `src/lib/crm-search.server.ts`: agregar el bloque de adelantos leyendo `adelantos` y expandiendo cuotas con `cuotaDelPeriodo` de `advances.server.ts`, con `source_key` `adelanto:{id}:{ym}` (mismo formato que usa `payroll.server.ts`), servicio "Adelantos", detalle `Adelanto cuota i/N`, e `importe = monto_pedido / cuotas`. Marcar `refinanciado` con el set existente de `refinanciacion_items`.
- `src/lib/refinance.functions.ts`: ninguna migración necesaria — los `source_key` de adelanto se guardan igual; verificar que el mapeo de servicio de origen reconozca el prefijo `adelanto:` para el historial por servicio.
- `payroll.server.ts` ya excluye los `source_key` refinanciados, por lo que el adelanto refinanciado no se descuenta doble.
- Sin cambios de base de datos.
