# Adelantos con cuotas y liquidación por período

## 1. Subservicio Adelantos (importación + carga manual)

Nueva pantalla de gestión de **Adelantos** (dentro del servicio Adelantos), con el mismo formato del Excel modelo:

Encabezado: `Descripcion` (ej. ADELANTOS) y `Periodo` (ej. 201801 = enero 2018, se traduce a mes/año).

Columnas de cada fila:

| FECHA | LEGAJO | APELLIDO_Y_NOMBRE | MONTO_PEDIDO | CUOTAS | CUIL | BANCO | N°_DE_CUENTA | 1°_CBU | 2°_CBU | CONCEPTO | RESPONSABLE | ID |

- Importar Excel con ese formato (acepta legajos alfanuméricos, ej. `te259`) y también **carga manual fila por fila** con los mismos campos.
- El nombre y apellido se completa automáticamente desde el padrón por legajo.
- Se guardan CUIL, banco, N° de cuenta y CBU en cada adelanto, y se ven/exportan en el detalle.
- Descarga del Excel en el mismo formato con el que se importa.
- Validaciones: legajo existente, monto > 0, cuotas ≥ 1, período obligatorio.

## 2. Cuotas: 1/N por período

Un adelanto de $1.000.000 en 5 cuotas descuenta $200.000 en cada uno de los 5 períodos, empezando por el período cargado. Misma regla para el resto de los servicios que se cargan en cuotas (supermercado, automotores, farmacia, etc.).

En la pantalla del adelanto se ve el plan de cuotas (cuota 1 de 5 → 06/2026, etc.) y cuánto queda por descontar.

## 3. Liquidación por período, no por fecha

- La liquidación deja de filtrar por la fecha del consumo: toma el **período (mes y año)** declarado en cada carga de servicio.
- Toda carga de servicio pasa a exigir mes y año de período (ya se pide en la carga de AGOEC y de proveedores; se vuelve obligatorio y visible en todas).
- En Liquidación, el selector pasa a ser **período (mes/año)** además del rango de fechas informativo; el listado de servicios, los totales y el Excel se calculan por período.
- Se mantiene el control de no volver a liquidar lo ya cerrado y los cierres por servicio.

## Detalles técnicos

- Migración: tabla `advances` (legajo, apellido_nombre, fecha, monto_pedido, cuotas, periodo_mes, periodo_anio, concepto, responsable, ref_id, cuil, banco, cuenta, cbu, cbu2, observacion) con GRANT + RLS (admin gestiona; el afiliado ve sólo sus filas vía `current_legajo()`), y trigger de `updated_at`. Se vincula al `service_products` "Adelanto".
- Nuevos `src/lib/advances.functions.ts` (CRUD + import bulk) y `advances.server.ts` (validación de legajos, armado del plan de cuotas: `cuotaIndex(periodo_inicio, cuotas, mes, anio)` igual que cumpleaños).
- `src/lib/payroll.server.ts`: en la sección de `submission_items` cambiar el filtro `inRange(fecha…)` por comparación de `periodo_mes`/`periodo_anio` de la submission contra el mes/año del período liquidado; prorratear por `cuotas` (importe_afiliado / cuotas por período, con índice de cuota según el período de carga) y `source_key` = `submission_item:{id}:{ym}`. Agregar bloque de Adelantos con `source_key` `advance:{id}:{ym}`, concepto `adelanto` con la cuenta contable del producto Adelanto.
- `src/routes/_authenticated/admin/liquidacion.tsx`: selector de mes/año como base del período; se mantiene desde/hasta para el rótulo. `previewPayroll`/`closePayroll` reciben `mes`/`anio`.
- Nueva ruta `src/routes/_authenticated/admin/adelantos.tsx` con importador XLSX, tabla editable, buscador/paginación y exportación; enlace "Gestionar Adelantos" desde el servicio Adelantos.
- `SubserviciosDetalle` y el buscador CRM suman los adelantos (detalle por afiliado y cuotas pendientes).
