# Refinanciación como servicio completo + CRM por servicio + períodos cerrados

## 1. Pantalla Refinanciación (servicio propio)

Hoy la pantalla lista planes por legajo con buscador básico y dos pestañas (vigentes / finalizadas), pero no muestra el detalle por servicio refinanciado ni estadísticas por servicio.

Se agrega:
- **Buscador ampliado**: por legajo, apellido y nombre, servicio refinanciado y período. Filtros por servicio (Farmacia, Supermercado, Automotores, Círculos, Cumpleaños, Colectas, Comida a Dto., Adelantos) y por estado (vigente / finalizada).
- **Listado de todos los legajos** con refinanciación, con paginación y cantidad por página (igual al listado de afiliados), ordenado por legajo.
- **Detalle por plan**: al expandir, tabla de los consumos incluidos con servicio, detalle, período original e importe; total del plan, cuotas, cuota del período, saldo.
- **Vista por servicio**: nueva pestaña "Por servicio" con una fila por servicio refinanciado (cantidad de planes, legajos, total refinanciado, saldo pendiente, cuota del período).
- **Estadísticas**: KPIs (total refinanciado, saldo, cuota del mes, legajos, planes activos/finalizados, promedio de cuotas) y gráficos: total refinanciado por servicio y evolución mensual de cuotas a descontar.
- **Excel**: exportar el listado filtrado, el detalle de ítems y el resumen por servicio.

## 2. Adelantos en cuotas = refinanciación

Un adelanto con más de una cuota pasa a formar parte de Refinanciación:
- Al guardar (Excel o manual) un adelanto con cuotas > 1, se crea automáticamente su plan de refinanciación (servicio "Adelantos", período inicial y cuotas del adelanto), sin duplicar el descuento: el adelanto se descuenta solo a través del plan.
- Los adelantos de 1 cuota siguen su curso normal.
- Los adelantos ya cargados con cuotas > 1 se incorporan con una migración de datos, para que aparezcan en la pantalla.
- En Refinanciación se distingue el origen: "Refinanciación de consumos" vs "Adelanto en cuotas".

## 3. CRM: refinanciar por cada servicio

En el detalle del legajo la grilla ya permite tildar consumos; se agrega:
- Selección y acción **"Refinanciar" por servicio** (botón por grupo de servicio, que selecciona los consumos pendientes de ese servicio).
- Agrupación visual por servicio con subtotal y total seleccionado por servicio.
- Al confirmar, cada grupo genera su plan con el servicio identificado (así queda el detalle por servicio en la pantalla de Refinanciación).

## 4. Consumos de períodos cerrados

- La grilla de consumos del CRM deja de mostrar los consumos cuyo período ya fue cerrado en liquidación (registrados en el cierre de período).
- Esos consumos pasan a una pestaña **"Históricos"** (solo lectura, sin posibilidad de refinanciar, con filtro por período y exportación a Excel).
- Los consumos de períodos cerrados no se pueden refinanciar (validación también en el servidor).

## Detalles técnicos

- `src/lib/refinance.functions.ts`: `listRefinances` devuelve además agregados por servicio y por período; `createRefinance` acepta `origen` ("consumo" | "adelanto") y valida que ningún `source_key` pertenezca a un período cerrado (`payroll_consumed` + `payroll_periods.estado`).
- `src/lib/refinance.server.ts`: helpers de agregación por servicio y serie mensual de cuotas.
- Migración: columna `origen` en `refinanciaciones` (default `consumo`) + backfill de adelantos con cuotas > 1 (crea plan e ítems por cuota). GRANTs y RLS existentes se mantienen.
- `src/lib/advances.functions.ts`: al guardar adelantos con cuotas > 1, crear el plan de refinanciación en la misma operación.
- `src/lib/crm-search.server.ts`: marcar cada fila con `periodo_cerrado` y separar `detalle` (abierto) de `historico` (cerrado); excluir del cálculo de seleccionables los cerrados.
- `src/routes/_authenticated/admin/refinanciacion.tsx`: pestañas Vigentes / Finalizadas / Por servicio, buscador y filtros, paginación, expansión de detalle, KPIs y gráficos (recharts).
- `src/routes/_authenticated/admin/crm.tsx`: agrupación por servicio con acción de refinanciar por grupo y pestaña Históricos.
