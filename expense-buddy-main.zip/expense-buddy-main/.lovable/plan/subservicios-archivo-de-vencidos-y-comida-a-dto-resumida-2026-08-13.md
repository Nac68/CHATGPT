# Subservicios: archivo de vencidos y Comida a Dto. resumida

## Qué cambia en Servicios Varios

1. **Dos pestañas en "Subservicios habilitados"**
   - **Vigentes**: subservicios cuyo período todavía no terminó (o no tiene fin).
   - **Vencidos (archivo)**: los que ya terminaron su período — cumpleaños con la última cuota pasada, colectas cerradas o con todas las cuotas cumplidas, círculos con período fin anterior al mes actual.
   - El buscador, el filtro por subservicio, la paginación y los botones de Excel (por registro y del listado) funcionan igual en ambas pestañas.
   - Los contadores por subservicio muestran el conteo de la pestaña activa.

2. **Comida a Dto. resumida**
   - En lugar de una fila por día, una sola fila "Comida a Dto." con el total: cantidad de días cargados, comensales/afiliados involucrados y el importe total a descontar.
   - Su botón de Excel exporta el resumen general por día (una fila por día con fecha, descripción, comensales, pagan e importe).
   - El detalle día por día se sigue viendo entrando a "Gestionar Comida a Dto." (sin cambios en esa pantalla).

## Reglas de vencimiento

- **Círculos**: vencido si `periodo_fin` (AAAAMM) es menor al mes actual.
- **Cumpleaños**: vencido si el mes de la última cuota (`periodo_inicio` + cantidad de cuotas − 1) ya pasó; si no hay período de inicio, se considera vigente.
- **Colectas**: vencida si está cerrada, o si `mes_inicio/anio_inicio` + `cuotas` − 1 ya pasó.
- **Comida a Dto.**: siempre vigente (es un servicio continuo).

## Detalle técnico

- Todo el cambio es de presentación y ocurre en `src/components/SubserviciosDetalle.tsx`:
  - Se agrega a `Row` un campo `vencido: boolean` y un estado de pestaña (`vigentes` | `vencidos`), aplicado antes del filtro de texto y la paginación.
  - Helpers locales para convertir AAAAMM y mes/año a índice de mes y comparar con el mes actual.
  - El bloque que recorre `comidaQ.data.dias` se reemplaza por una única fila agregada usando `kpis` (`dias`, `afiliados`, `total_a_descontar`), con un `exportComidaResumen()` que reemplaza a `exportComidaDia()`.
- Sin cambios de base de datos ni de funciones de servidor.
