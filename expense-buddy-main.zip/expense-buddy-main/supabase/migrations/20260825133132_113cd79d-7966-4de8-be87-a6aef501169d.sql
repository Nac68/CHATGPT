CREATE TABLE public.audit_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entidad text NOT NULL,
  entidad_id text,
  accion text NOT NULL,
  user_id uuid,
  user_email text,
  legajo text,
  nota text,
  valor_anterior jsonb,
  valor_nuevo jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.audit_events TO authenticated;
GRANT ALL ON public.audit_events TO service_role;

ALTER TABLE public.audit_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins pueden ver la auditoria"
ON public.audit_events FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE INDEX audit_events_entidad_idx ON public.audit_events (entidad, entidad_id, created_at DESC);
CREATE INDEX audit_events_created_at_idx ON public.audit_events (created_at DESC);