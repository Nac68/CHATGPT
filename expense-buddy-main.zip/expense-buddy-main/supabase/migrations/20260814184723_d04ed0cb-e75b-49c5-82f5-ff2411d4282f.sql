CREATE TABLE public.adelantos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legajo text NOT NULL,
  apellido_nombre text,
  fecha date,
  monto_pedido numeric NOT NULL DEFAULT 0,
  cuotas integer NOT NULL DEFAULT 1,
  periodo_mes integer NOT NULL,
  periodo_anio integer NOT NULL,
  concepto text NOT NULL DEFAULT 'ADELANTO',
  responsable text,
  ref_id text,
  cuil text,
  banco text,
  cuenta text,
  cbu text,
  cbu2 text,
  observacion text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.adelantos TO authenticated;
GRANT ALL ON public.adelantos TO service_role;

ALTER TABLE public.adelantos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins gestionan adelantos" ON public.adelantos
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Afiliados ven sus adelantos" ON public.adelantos
  FOR SELECT TO authenticated
  USING (legajo = public.current_legajo());

CREATE TRIGGER adelantos_updated_at BEFORE UPDATE ON public.adelantos
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE INDEX adelantos_periodo_idx ON public.adelantos (periodo_anio, periodo_mes);
CREATE INDEX adelantos_legajo_idx ON public.adelantos (legajo);