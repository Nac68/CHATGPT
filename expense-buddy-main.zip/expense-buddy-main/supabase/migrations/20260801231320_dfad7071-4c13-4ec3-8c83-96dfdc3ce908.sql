CREATE TABLE public.circles (
  id uuid primary key default gen_random_uuid(),
  service_id uuid references public.services(id) on delete cascade,
  product_id uuid references public.service_products(id) on delete cascade,
  nombre text not null,
  fecha_inicio date,
  fecha_fin date,
  importe numeric not null default 0,
  observacion text,
  created_at timestamptz not null default now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.circles TO authenticated;
GRANT ALL ON public.circles TO service_role;
ALTER TABLE public.circles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admins manage circles" ON public.circles FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.circle_members (
  id uuid primary key default gen_random_uuid(),
  circle_id uuid not null references public.circles(id) on delete cascade,
  legajo text not null,
  apellido_nombre text,
  importe_mensual numeric not null default 0,
  mes_cobro int,
  anio_cobro int,
  observacion text,
  created_at timestamptz not null default now()
);
CREATE INDEX circle_members_circle_idx ON public.circle_members(circle_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.circle_members TO authenticated;
GRANT ALL ON public.circle_members TO service_role;
ALTER TABLE public.circle_members ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admins manage circle members" ON public.circle_members FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));