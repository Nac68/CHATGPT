CREATE TABLE public.affiliate_pin_status (
  user_id uuid NOT NULL PRIMARY KEY,
  legajo text,
  must_change_pin boolean NOT NULL DEFAULT false,
  pin_changed_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT ALL ON public.affiliate_pin_status TO service_role;

ALTER TABLE public.affiliate_pin_status ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Sin acceso directo desde el cliente"
  ON public.affiliate_pin_status FOR SELECT
  TO authenticated
  USING (false);

CREATE TRIGGER affiliate_pin_status_updated_at
  BEFORE UPDATE ON public.affiliate_pin_status
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();