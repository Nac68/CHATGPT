CREATE TABLE public.provider_prestaciones (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  provider_id uuid NOT NULL REFERENCES public.providers(id) ON DELETE CASCADE,
  nombre text NOT NULL,
  comision_pct numeric NOT NULL DEFAULT 0,
  activo boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.provider_prestaciones TO authenticated;
GRANT ALL ON public.provider_prestaciones TO service_role;

ALTER TABLE public.provider_prestaciones ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins administran prestaciones"
ON public.provider_prestaciones FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Proveedor ve sus prestaciones"
ON public.provider_prestaciones FOR SELECT TO authenticated
USING (public.owns_provider(provider_id));

CREATE UNIQUE INDEX provider_prestaciones_uniq ON public.provider_prestaciones (provider_id, lower(nombre));
CREATE INDEX provider_prestaciones_provider_idx ON public.provider_prestaciones (provider_id);

CREATE TRIGGER provider_prestaciones_updated_at
BEFORE UPDATE ON public.provider_prestaciones
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

ALTER TABLE public.submission_items
  ADD COLUMN prestacion text,
  ADD COLUMN comision_pct numeric NOT NULL DEFAULT 0,
  ADD COLUMN comision_monto numeric NOT NULL DEFAULT 0,
  ADD COLUMN neto_proveedor numeric,
  ADD COLUMN cuotas_importes jsonb;

ALTER TABLE public.provider_submissions
  ADD COLUMN total_comision numeric NOT NULL DEFAULT 0,
  ADD COLUMN total_neto numeric NOT NULL DEFAULT 0,
  ADD COLUMN factura text;