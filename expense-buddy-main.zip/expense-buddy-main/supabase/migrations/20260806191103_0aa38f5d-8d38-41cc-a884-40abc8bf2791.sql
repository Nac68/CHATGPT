ALTER TABLE public.circles
  ADD COLUMN IF NOT EXISTS numero text,
  ADD COLUMN IF NOT EXISTS periodo_inicio integer,
  ADD COLUMN IF NOT EXISTS periodo_fin integer;

ALTER TABLE public.circle_members
  ADD COLUMN IF NOT EXISTS fecha_cobro date;

CREATE INDEX IF NOT EXISTS circles_numero_idx ON public.circles (numero);