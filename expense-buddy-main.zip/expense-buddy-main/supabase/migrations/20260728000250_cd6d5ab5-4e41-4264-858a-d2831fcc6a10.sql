CREATE TYPE public.app_role AS ENUM ('admin', 'afiliado');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  legajo integer,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own roles readable" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role) $$;

CREATE OR REPLACE FUNCTION public.current_legajo()
RETURNS integer LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT legajo FROM public.user_roles WHERE user_id = auth.uid() AND role = 'afiliado' LIMIT 1 $$;

CREATE TABLE public.affiliates (
  legajo integer PRIMARY KEY,
  apellido_nombre text NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.affiliates TO authenticated;
GRANT ALL ON public.affiliates TO service_role;
ALTER TABLE public.affiliates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "affiliates readable by authenticated" ON public.affiliates FOR SELECT TO authenticated USING (true);

CREATE TABLE public.daily_forms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  fecha date NOT NULL UNIQUE,
  descripcion_comida text,
  observacion text,
  importe numeric(14,2),
  foto_url text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.daily_forms TO authenticated;
GRANT ALL ON public.daily_forms TO service_role;
ALTER TABLE public.daily_forms ENABLE ROW LEVEL SECURITY;
CREATE POLICY "daily_forms admin all" ON public.daily_forms FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "daily_forms afiliado read" ON public.daily_forms FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'afiliado'));

CREATE TABLE public.daily_consumptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  daily_form_id uuid NOT NULL REFERENCES public.daily_forms(id) ON DELETE CASCADE,
  legajo integer NOT NULL REFERENCES public.affiliates(legajo) ON DELETE CASCADE,
  desayuno boolean NOT NULL DEFAULT false,
  almuerzo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (daily_form_id, legajo)
);
CREATE INDEX ON public.daily_consumptions (legajo);
CREATE INDEX ON public.daily_consumptions (daily_form_id);
GRANT SELECT ON public.daily_consumptions TO authenticated;
GRANT ALL ON public.daily_consumptions TO service_role;
ALTER TABLE public.daily_consumptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "consumptions admin all" ON public.daily_consumptions FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "consumptions afiliado own" ON public.daily_consumptions FOR SELECT TO authenticated
  USING (legajo = public.current_legajo());

CREATE TABLE public.monthly_settlements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  anio integer NOT NULL,
  mes integer NOT NULL CHECK (mes BETWEEN 1 AND 12),
  importe_total numeric(14,2) NOT NULL,
  total_consumos integer NOT NULL,
  importe_por_consumo numeric(14,4) NOT NULL,
  generado_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (anio, mes)
);
GRANT SELECT ON public.monthly_settlements TO authenticated;
GRANT ALL ON public.monthly_settlements TO service_role;
ALTER TABLE public.monthly_settlements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "settlements read all authenticated" ON public.monthly_settlements FOR SELECT TO authenticated USING (true);
CREATE POLICY "settlements admin write" ON public.monthly_settlements FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.set_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;
CREATE TRIGGER daily_forms_updated_at BEFORE UPDATE ON public.daily_forms
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();