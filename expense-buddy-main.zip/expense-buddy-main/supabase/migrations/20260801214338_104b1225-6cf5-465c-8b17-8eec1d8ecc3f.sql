-- Productos habilitados por servicio
CREATE TABLE IF NOT EXISTS public.service_products (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  service_id UUID NOT NULL REFERENCES public.services(id) ON DELETE CASCADE,
  nombre TEXT NOT NULL,
  codigo TEXT,
  descripcion TEXT,
  tipo TEXT NOT NULL DEFAULT 'agoec',
  activo BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.service_products TO authenticated;
GRANT ALL ON public.service_products TO service_role;
ALTER TABLE public.service_products ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "service_products_admin_all" ON public.service_products;
CREATE POLICY "service_products_admin_all" ON public.service_products FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
DROP POLICY IF EXISTS "service_products_read" ON public.service_products;
CREATE POLICY "service_products_read" ON public.service_products FOR SELECT TO authenticated USING (true);

ALTER TABLE public.providers ADD COLUMN IF NOT EXISTS product_id UUID REFERENCES public.service_products(id) ON DELETE SET NULL;

-- Producto Comida a Dto. dentro de Servicios Varios
INSERT INTO public.service_products (service_id, nombre, codigo, descripcion, tipo)
SELECT id, 'Comida a Dto.', 'comida-dto', 'Servicio de comida diaria provisto por AGOEC', 'agoec'
FROM public.services WHERE codigo = 'varios'
AND NOT EXISTS (SELECT 1 FROM public.service_products p WHERE p.codigo = 'comida-dto');

-- Autorización manual de usuarios registrados
CREATE TABLE IF NOT EXISTS public.user_accounts (
  user_id UUID NOT NULL PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT,
  autorizado BOOLEAN NOT NULL DEFAULT false,
  clave_temporal TEXT,
  nota TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_accounts TO authenticated;
GRANT ALL ON public.user_accounts TO service_role;
ALTER TABLE public.user_accounts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "user_accounts_admin_all" ON public.user_accounts;
CREATE POLICY "user_accounts_admin_all" ON public.user_accounts FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));