CREATE POLICY "daily-photos admin read" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'daily-photos' AND public.has_role(auth.uid(), 'admin'));
CREATE POLICY "daily-photos admin insert" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'daily-photos' AND public.has_role(auth.uid(), 'admin'));
CREATE POLICY "daily-photos admin update" ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'daily-photos' AND public.has_role(auth.uid(), 'admin'));
CREATE POLICY "daily-photos admin delete" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'daily-photos' AND public.has_role(auth.uid(), 'admin'));