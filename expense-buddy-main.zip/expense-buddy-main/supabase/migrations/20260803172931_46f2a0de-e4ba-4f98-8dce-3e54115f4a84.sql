CREATE TABLE public.collections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id uuid REFERENCES public.services(id) ON DELETE SET NULL,
  product_id uuid REFERENCES public.service_products(id) ON DELETE SET NULL,
  nombre text NOT NULL,
  motivo text,
  beneficiario_legajo text,
  beneficiario_nombre text,
  fecha date,
  importe_objetivo numeric NOT NULL DEFAULT 0,
  cuotas integer NOT NULL DEFAULT 1,
  mes_inicio integer,
  anio_inicio integer,
  cerrada boolean NOT NULL DEFAULT false,
  observacion text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.collection_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  collection_id uuid NOT NULL REFERENCES public.collections(id) ON DELETE CASCADE,
  legajo text NOT NULL,
  apellido_nombre text,
  importe_total numeric NOT NULL DEFAULT 0,
  cuotas integer NOT NULL DEFAULT 1,
  importe_cuota numeric NOT NULL DEFAULT 0,
  observacion text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX collection_members_collection_id_idx ON public.collection_members(collection_id);
CREATE INDEX collection_members_legajo_idx ON public.collection_members(legajo);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.collections TO authenticated;
GRANT ALL ON public.collections TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.collection_members TO authenticated;
GRANT ALL ON public.collection_members TO service_role;

ALTER TABLE public.collections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.collection_members ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage collections" ON public.collections FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins manage collection members" ON public.collection_members FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Afiliados ven sus aportes" ON public.collection_members FOR SELECT TO authenticated
  USING (legajo = public.current_legajo());

CREATE TRIGGER collections_updated_at BEFORE UPDATE ON public.collections
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();