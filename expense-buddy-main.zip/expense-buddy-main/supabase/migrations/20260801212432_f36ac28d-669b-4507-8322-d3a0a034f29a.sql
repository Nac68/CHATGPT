ALTER TABLE public.providers
  ADD COLUMN IF NOT EXISTS tipo text NOT NULL DEFAULT 'externo';

ALTER TABLE public.providers
  DROP CONSTRAINT IF EXISTS providers_tipo_check;

ALTER TABLE public.providers
  ADD CONSTRAINT providers_tipo_check CHECK (tipo IN ('externo','interno','agoec'));

UPDATE public.providers SET tipo = 'interno' WHERE interno IS TRUE AND tipo = 'externo';