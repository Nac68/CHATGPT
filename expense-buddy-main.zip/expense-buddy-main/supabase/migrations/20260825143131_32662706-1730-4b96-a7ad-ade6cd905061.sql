-- 1) Períodos de Adelantos (entidad mínima con estados y snapshot inmutable)
CREATE TABLE public.advance_periods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  periodo_mes integer NOT NULL CHECK (periodo_mes BETWEEN 1 AND 12),
  periodo_anio integer NOT NULL CHECK (periodo_anio BETWEEN 2000 AND 2100),
  descripcion text NOT NULL DEFAULT 'ADELANTOS',
  estado text NOT NULL DEFAULT 'abierto' CHECK (estado IN ('abierto','revisado','cerrado')),
  snapshot jsonb,
  total_solicitado numeric NOT NULL DEFAULT 0,
  total_cuotas_adelantos numeric NOT NULL DEFAULT 0,
  total_cuotas_refinanciacion numeric NOT NULL DEFAULT 0,
  total_general numeric NOT NULL DEFAULT 0,
  total_adelantos integer NOT NULL DEFAULT 0,
  total_legajos integer NOT NULL DEFAULT 0,
  cerrado_at timestamptz,
  cerrado_por uuid,
  reabierto_at timestamptz,
  reabierto_por uuid,
  reaperturas integer NOT NULL DEFAULT 0,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (periodo_mes, periodo_anio)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.advance_periods TO authenticated;
GRANT ALL ON public.advance_periods TO service_role;

ALTER TABLE public.advance_periods ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins gestionan periodos de adelantos"
ON public.advance_periods FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER advance_periods_updated_at
BEFORE UPDATE ON public.advance_periods
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Una sola apertura a la vez
CREATE UNIQUE INDEX advance_periods_una_abierta
ON public.advance_periods ((estado)) WHERE estado = 'abierto';

-- 2) Refinanciación consolidada (columnas aditivas, nada se transforma)
ALTER TABLE public.refinanciaciones
  ADD COLUMN IF NOT EXISTS cuotas_efectivas integer,
  ADD COLUMN IF NOT EXISTS reemplaza_a uuid REFERENCES public.refinanciaciones(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS reemplazada_por uuid REFERENCES public.refinanciaciones(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS saldo_incorporado numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS cuotas_cobradas integer,
  ADD COLUMN IF NOT EXISTS consolidada_at timestamptz,
  ADD COLUMN IF NOT EXISTS consolidada_por uuid;

CREATE INDEX IF NOT EXISTS refinanciaciones_legajo_estado_idx
ON public.refinanciaciones (legajo, estado);