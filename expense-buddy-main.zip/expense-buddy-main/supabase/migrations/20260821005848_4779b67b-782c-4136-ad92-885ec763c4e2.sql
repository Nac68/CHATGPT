ALTER TABLE public.refinanciaciones
  ADD COLUMN IF NOT EXISTS origen TEXT NOT NULL DEFAULT 'consumo';

CREATE INDEX IF NOT EXISTS refinanciaciones_legajo_idx ON public.refinanciaciones (legajo);
CREATE INDEX IF NOT EXISTS refinanciacion_items_source_key_idx ON public.refinanciacion_items (source_key);