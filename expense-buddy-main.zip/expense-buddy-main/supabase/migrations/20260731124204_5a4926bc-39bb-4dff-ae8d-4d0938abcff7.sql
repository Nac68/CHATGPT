ALTER TABLE public.daily_consumptions DROP CONSTRAINT IF EXISTS daily_consumptions_daily_form_id_legajo_key;

CREATE TABLE public.settlements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  fechas date[] NOT NULL DEFAULT '{}',
  desde date,
  hasta date,
  total_consumos integer NOT NULL DEFAULT 0,
  total_afiliados integer NOT NULL DEFAULT 0,
  importe_total numeric NOT NULL DEFAULT 0,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.settlements TO authenticated;
GRANT ALL ON public.settlements TO service_role;
ALTER TABLE public.settlements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage settlements" ON public.settlements FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.settlement_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  settlement_id uuid NOT NULL REFERENCES public.settlements(id) ON DELETE CASCADE,
  legajo text NOT NULL,
  apellido_nombre text NOT NULL,
  desayunos integer NOT NULL DEFAULT 0,
  almuerzos integer NOT NULL DEFAULT 0,
  consumos integer NOT NULL DEFAULT 0,
  importe numeric NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.settlement_items TO authenticated;
GRANT ALL ON public.settlement_items TO service_role;
ALTER TABLE public.settlement_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage settlement items" ON public.settlement_items FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Afiliados ven su detalle" ON public.settlement_items FOR SELECT TO authenticated
  USING (legajo = public.current_legajo());

CREATE INDEX idx_settlement_items_settlement ON public.settlement_items(settlement_id);

CREATE TRIGGER settlements_set_updated_at BEFORE UPDATE ON public.settlements
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();