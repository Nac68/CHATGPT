
DROP POLICY IF EXISTS "affiliates readable by authenticated" ON public.affiliates;

CREATE POLICY "affiliates admin full access"
  ON public.affiliates FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "affiliates own row readable"
  ON public.affiliates FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR legajo = public.current_legajo());
