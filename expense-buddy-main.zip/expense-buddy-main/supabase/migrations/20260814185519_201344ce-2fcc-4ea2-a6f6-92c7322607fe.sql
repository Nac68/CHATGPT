CREATE TABLE public.refinanciaciones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legajo text NOT NULL,
  apellido_nombre text,
  total numeric NOT NULL DEFAULT 0,
  cuotas integer NOT NULL DEFAULT 1,
  periodo_mes integer NOT NULL,
  periodo_anio integer NOT NULL,
  observacion text,
  estado text NOT NULL DEFAULT 'activa',
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.refinanciacion_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  refinanciacion_id uuid NOT NULL REFERENCES public.refinanciaciones(id) ON DELETE CASCADE,
  source_key text NOT NULL,
  servicio text,
  detalle text,
  periodo text,
  importe numeric NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (source_key)
);

CREATE INDEX refinanciaciones_legajo_idx ON public.refinanciaciones (legajo);
CREATE INDEX refinanciacion_items_ref_idx ON public.refinanciacion_items (refinanciacion_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.refinanciaciones TO authenticated;
GRANT ALL ON public.refinanciaciones TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.refinanciacion_items TO authenticated;
GRANT ALL ON public.refinanciacion_items TO service_role;

ALTER TABLE public.refinanciaciones ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.refinanciacion_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins gestionan refinanciaciones" ON public.refinanciaciones
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Afiliados ven sus refinanciaciones" ON public.refinanciaciones
  FOR SELECT TO authenticated
  USING (legajo = public.current_legajo());

CREATE POLICY "Admins gestionan items de refinanciacion" ON public.refinanciacion_items
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Afiliados ven items de sus refinanciaciones" ON public.refinanciacion_items
  FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.refinanciaciones r
    WHERE r.id = refinanciacion_id AND r.legajo = public.current_legajo()
  ));

CREATE TRIGGER refinanciaciones_updated_at
  BEFORE UPDATE ON public.refinanciaciones
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();