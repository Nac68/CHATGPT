ALTER TABLE public.providers ADD COLUMN IF NOT EXISTS cuenta_contable text;
CREATE INDEX IF NOT EXISTS providers_cuenta_contable_idx ON public.providers (cuenta_contable);