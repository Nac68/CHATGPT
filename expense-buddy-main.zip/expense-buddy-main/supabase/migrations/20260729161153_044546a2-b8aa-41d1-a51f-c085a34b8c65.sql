REVOKE EXECUTE ON FUNCTION public.current_legajo() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.current_legajo() TO authenticated, service_role;