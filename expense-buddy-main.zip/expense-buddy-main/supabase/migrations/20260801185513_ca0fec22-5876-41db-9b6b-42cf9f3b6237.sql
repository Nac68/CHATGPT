-- 1) Nuevo rol
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'proveedor';

-- 2) Trigger de updated_at (idempotente)
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- 3) SERVICIOS
CREATE TABLE public.services (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  nombre text NOT NULL,
  codigo text NOT NULL UNIQUE,
  descripcion text,
  activo boolean NOT NULL DEFAULT true,
  campos_requeridos jsonb NOT NULL DEFAULT '["fecha","legajo","detalle","importe","cuotas"]'::jsonb,
  usa_receta boolean NOT NULL DEFAULT false,
  subsidio_receta_pct numeric NOT NULL DEFAULT 0,
  permite_cuotas boolean NOT NULL DEFAULT true,
  permite_cumpleanos boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.services TO authenticated;
GRANT ALL ON public.services TO service_role;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
CREATE POLICY "services_read_auth" ON public.services FOR SELECT TO authenticated USING (true);
CREATE POLICY "services_admin_all" ON public.services FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER services_updated_at BEFORE UPDATE ON public.services
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 4) PROVEEDORES
CREATE TABLE public.providers (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  service_id uuid NOT NULL REFERENCES public.services(id) ON DELETE RESTRICT,
  nombre text NOT NULL,
  cuit text,
  email text,
  interno boolean NOT NULL DEFAULT false,
  habilitado boolean NOT NULL DEFAULT true,
  banco text,
  cbu text,
  alias text,
  titular text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX providers_service_idx ON public.providers(service_id);
CREATE INDEX providers_user_idx ON public.providers(user_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.providers TO authenticated;
GRANT ALL ON public.providers TO service_role;
ALTER TABLE public.providers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "providers_admin_all" ON public.providers FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "providers_self_read" ON public.providers FOR SELECT TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "providers_self_update" ON public.providers FOR UPDATE TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE TRIGGER providers_updated_at BEFORE UPDATE ON public.providers
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Helper: el usuario actual es dueño del proveedor
CREATE OR REPLACE FUNCTION public.owns_provider(_provider_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.providers p
    WHERE p.id = _provider_id AND p.user_id = auth.uid()
  )
$$;

-- 5) LIQUIDACIONES DE PROVEEDORES
CREATE TABLE public.provider_submissions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  provider_id uuid NOT NULL REFERENCES public.providers(id) ON DELETE CASCADE,
  service_id uuid NOT NULL REFERENCES public.services(id) ON DELETE RESTRICT,
  nombre text NOT NULL,
  periodo_mes int NOT NULL,
  periodo_anio int NOT NULL,
  estado text NOT NULL DEFAULT 'enviada',
  total_importe numeric NOT NULL DEFAULT 0,
  total_subsidio numeric NOT NULL DEFAULT 0,
  total_a_pagar numeric NOT NULL DEFAULT 0,
  total_items int NOT NULL DEFAULT 0,
  total_afiliados int NOT NULL DEFAULT 0,
  observacion text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX provider_submissions_provider_idx ON public.provider_submissions(provider_id);
CREATE INDEX provider_submissions_periodo_idx ON public.provider_submissions(periodo_anio, periodo_mes);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.provider_submissions TO authenticated;
GRANT ALL ON public.provider_submissions TO service_role;
ALTER TABLE public.provider_submissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "psub_admin_all" ON public.provider_submissions FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "psub_self_read" ON public.provider_submissions FOR SELECT TO authenticated
  USING (public.owns_provider(provider_id));
CREATE POLICY "psub_self_insert" ON public.provider_submissions FOR INSERT TO authenticated
  WITH CHECK (public.owns_provider(provider_id));
CREATE POLICY "psub_self_update" ON public.provider_submissions FOR UPDATE TO authenticated
  USING (public.owns_provider(provider_id) AND estado = 'enviada')
  WITH CHECK (public.owns_provider(provider_id));
CREATE POLICY "psub_self_delete" ON public.provider_submissions FOR DELETE TO authenticated
  USING (public.owns_provider(provider_id) AND estado = 'enviada');
CREATE TRIGGER provider_submissions_updated_at BEFORE UPDATE ON public.provider_submissions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 6) DETALLE
CREATE TABLE public.submission_items (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  submission_id uuid NOT NULL REFERENCES public.provider_submissions(id) ON DELETE CASCADE,
  provider_id uuid NOT NULL REFERENCES public.providers(id) ON DELETE CASCADE,
  service_id uuid NOT NULL REFERENCES public.services(id) ON DELETE RESTRICT,
  legajo text NOT NULL,
  fecha date,
  detalle text,
  comprobante text,
  importe numeric NOT NULL DEFAULT 0,
  cuotas int NOT NULL DEFAULT 1,
  con_receta boolean NOT NULL DEFAULT false,
  es_cumpleanos boolean NOT NULL DEFAULT false,
  subsidio numeric NOT NULL DEFAULT 0,
  importe_afiliado numeric NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX submission_items_submission_idx ON public.submission_items(submission_id);
CREATE INDEX submission_items_legajo_idx ON public.submission_items(legajo);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.submission_items TO authenticated;
GRANT ALL ON public.submission_items TO service_role;
ALTER TABLE public.submission_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "sitems_admin_all" ON public.submission_items FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "sitems_self_read" ON public.submission_items FOR SELECT TO authenticated
  USING (public.owns_provider(provider_id));
CREATE POLICY "sitems_self_insert" ON public.submission_items FOR INSERT TO authenticated
  WITH CHECK (public.owns_provider(provider_id));
CREATE POLICY "sitems_self_delete" ON public.submission_items FOR DELETE TO authenticated
  USING (public.owns_provider(provider_id));
CREATE POLICY "sitems_afiliado_read" ON public.submission_items FOR SELECT TO authenticated
  USING (legajo = public.current_legajo());

-- 7) MENSAJES
CREATE TABLE public.provider_messages (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  provider_id uuid NOT NULL REFERENCES public.providers(id) ON DELETE CASCADE,
  autor_user_id uuid,
  desde_admin boolean NOT NULL DEFAULT false,
  asunto text,
  mensaje text NOT NULL,
  leido boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX provider_messages_provider_idx ON public.provider_messages(provider_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.provider_messages TO authenticated;
GRANT ALL ON public.provider_messages TO service_role;
ALTER TABLE public.provider_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pmsg_admin_all" ON public.provider_messages FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "pmsg_self_read" ON public.provider_messages FOR SELECT TO authenticated
  USING (public.owns_provider(provider_id));
CREATE POLICY "pmsg_self_insert" ON public.provider_messages FOR INSERT TO authenticated
  WITH CHECK (public.owns_provider(provider_id) AND desde_admin = false);

-- 8) Servicios iniciales
INSERT INTO public.services (nombre, codigo, descripcion, usa_receta, subsidio_receta_pct, permite_cuotas, permite_cumpleanos, campos_requeridos) VALUES
  ('Servicios Varios', 'varios', 'Incluye Comida a Descuento (servicio interno de AGOEC) y otros servicios varios.', false, 0, true, true, '["fecha","legajo","detalle","importe","cuotas"]'::jsonb),
  ('Farmacia', 'farmacia', 'Consumos de farmacia. Los productos con receta reciben subsidio.', true, 15, true, false, '["fecha","legajo","detalle","comprobante","importe","cuotas","con_receta"]'::jsonb),
  ('Supermercado', 'supermercado', 'Consumos en supermercados adheridos.', false, 0, true, false, '["fecha","legajo","detalle","comprobante","importe","cuotas"]'::jsonb),
  ('Automotores', 'automotores', 'Repuestos, service y afines.', false, 0, true, false, '["fecha","legajo","detalle","comprobante","importe","cuotas"]'::jsonb),
  ('Indumentaria', 'indumentaria', 'Indumentaria y calzado.', false, 0, true, false, '["fecha","legajo","detalle","comprobante","importe","cuotas"]'::jsonb),
  ('Adelantos', 'adelantos', 'Adelantos de haberes.', false, 0, true, false, '["fecha","legajo","detalle","importe","cuotas"]'::jsonb);