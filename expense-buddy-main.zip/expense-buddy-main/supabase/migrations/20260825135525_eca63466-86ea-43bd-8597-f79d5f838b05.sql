CREATE TABLE public.settlement_days (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  settlement_id uuid NOT NULL REFERENCES public.settlements(id) ON DELETE CASCADE,
  daily_form_id uuid NOT NULL REFERENCES public.daily_forms(id) ON DELETE CASCADE,
  fecha date NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (settlement_id, daily_form_id)
);

CREATE INDEX settlement_days_daily_form_id_idx ON public.settlement_days (daily_form_id);
CREATE INDEX settlement_days_settlement_id_idx ON public.settlement_days (settlement_id);

GRANT SELECT ON public.settlement_days TO authenticated;
GRANT ALL ON public.settlement_days TO service_role;

ALTER TABLE public.settlement_days ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view settlement days"
ON public.settlement_days
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Backfill: vincular cada liquidación existente con los formularios de sus fechas
INSERT INTO public.settlement_days (settlement_id, daily_form_id, fecha)
SELECT s.id, f.id, f.fecha
FROM public.settlements s
JOIN public.daily_forms f ON f.fecha = ANY (s.fechas)
ON CONFLICT (settlement_id, daily_form_id) DO NOTHING;