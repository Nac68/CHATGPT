-- Drop policies that reference legajo
DROP POLICY IF EXISTS "consumptions afiliado own" ON public.daily_consumptions;

-- Drop FKs / PKs
ALTER TABLE public.daily_consumptions DROP CONSTRAINT IF EXISTS daily_consumptions_legajo_fkey;
ALTER TABLE public.affiliates DROP CONSTRAINT IF EXISTS affiliates_pkey;

-- Change types to text
ALTER TABLE public.affiliates ALTER COLUMN legajo TYPE text USING legajo::text;
ALTER TABLE public.daily_consumptions ALTER COLUMN legajo TYPE text USING legajo::text;
ALTER TABLE public.user_roles ALTER COLUMN legajo TYPE text USING legajo::text;

-- Restore PK + FK
ALTER TABLE public.affiliates ADD CONSTRAINT affiliates_pkey PRIMARY KEY (legajo);
ALTER TABLE public.daily_consumptions
  ADD CONSTRAINT daily_consumptions_legajo_fkey
  FOREIGN KEY (legajo) REFERENCES public.affiliates(legajo) ON DELETE CASCADE;

-- New per-row fields
ALTER TABLE public.daily_consumptions
  ADD COLUMN IF NOT EXISTS observacion text,
  ADD COLUMN IF NOT EXISTS importe numeric(12,2);

-- Recreate function (return text)
DROP FUNCTION IF EXISTS public.current_legajo();
CREATE OR REPLACE FUNCTION public.current_legajo()
RETURNS text
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT legajo::text
  FROM public.user_roles
  WHERE user_id = auth.uid() AND role = 'afiliado'
  LIMIT 1
$$;

-- Recreate the afiliado policy on daily_consumptions
CREATE POLICY "consumptions afiliado own"
ON public.daily_consumptions
FOR SELECT
TO authenticated
USING (legajo = public.current_legajo());