CREATE TABLE public.birthday_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id uuid REFERENCES public.services(id) ON DELETE SET NULL,
  product_id uuid REFERENCES public.service_products(id) ON DELETE SET NULL,
  nombre text NOT NULL,
  importe_total numeric NOT NULL DEFAULT 0,
  periodo_inicio integer,
  periodo_fin integer,
  observacion text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.birthday_plans TO authenticated;
GRANT ALL ON public.birthday_plans TO service_role;
ALTER TABLE public.birthday_plans ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage birthday plans" ON public.birthday_plans FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER birthday_plans_updated_at BEFORE UPDATE ON public.birthday_plans
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.birthday_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id uuid NOT NULL REFERENCES public.birthday_plans(id) ON DELETE CASCADE,
  legajo text NOT NULL,
  apellido_nombre text,
  fecha_cobro date,
  cuotas jsonb NOT NULL DEFAULT '[]'::jsonb,
  total numeric NOT NULL DEFAULT 0,
  observacion text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.birthday_members TO authenticated;
GRANT ALL ON public.birthday_members TO service_role;
ALTER TABLE public.birthday_members ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage birthday members" ON public.birthday_members FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE INDEX birthday_members_plan_idx ON public.birthday_members(plan_id);