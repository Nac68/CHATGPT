ALTER TABLE public.services ADD COLUMN IF NOT EXISTS cuenta_contable text;
ALTER TABLE public.service_products ADD COLUMN IF NOT EXISTS cuenta_contable text;
CREATE INDEX IF NOT EXISTS idx_services_cuenta_contable ON public.services (cuenta_contable);
CREATE INDEX IF NOT EXISTS idx_service_products_cuenta_contable ON public.service_products (cuenta_contable);