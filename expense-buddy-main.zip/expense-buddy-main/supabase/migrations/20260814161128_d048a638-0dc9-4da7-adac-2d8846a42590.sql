ALTER TABLE public.payroll_periods
  ADD COLUMN IF NOT EXISTS concepto_key text,
  ADD COLUMN IF NOT EXISTS concepto_nombre text;