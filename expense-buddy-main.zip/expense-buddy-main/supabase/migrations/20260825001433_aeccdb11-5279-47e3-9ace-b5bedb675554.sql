ALTER TABLE public.settlements
  ADD COLUMN IF NOT EXISTS periodo_mes integer,
  ADD COLUMN IF NOT EXISTS periodo_anio integer,
  ADD COLUMN IF NOT EXISTS estado text NOT NULL DEFAULT 'borrador',
  ADD COLUMN IF NOT EXISTS importe_cargado numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS diferencia numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS dias_sin_importe integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS snapshot jsonb,
  ADD COLUMN IF NOT EXISTS revisada_at timestamptz,
  ADD COLUMN IF NOT EXISTS revisada_por uuid,
  ADD COLUMN IF NOT EXISTS cerrada_at timestamptz,
  ADD COLUMN IF NOT EXISTS cerrada_por uuid,
  ADD COLUMN IF NOT EXISTS exportada_at timestamptz,
  ADD COLUMN IF NOT EXISTS exportada_por uuid,
  ADD COLUMN IF NOT EXISTS reabierta_at timestamptz,
  ADD COLUMN IF NOT EXISTS reabierta_por uuid,
  ADD COLUMN IF NOT EXISTS reaperturas integer NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS public.settlement_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  settlement_id uuid NOT NULL REFERENCES public.settlements(id) ON DELETE CASCADE,
  accion text NOT NULL,
  user_id uuid,
  user_email text,
  nota text,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.settlement_events TO authenticated;
GRANT ALL ON public.settlement_events TO service_role;

ALTER TABLE public.settlement_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Admins manage settlement events" ON public.settlement_events;
CREATE POLICY "Admins manage settlement events"
ON public.settlement_events
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE INDEX IF NOT EXISTS settlement_events_settlement_idx ON public.settlement_events(settlement_id, created_at DESC);
CREATE INDEX IF NOT EXISTS settlements_periodo_idx ON public.settlements(periodo_anio, periodo_mes);