CREATE TABLE public.payroll_periods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  desde date NOT NULL,
  hasta date NOT NULL,
  estado text NOT NULL DEFAULT 'abierto',
  total_descuento numeric NOT NULL DEFAULT 0,
  total_afiliados integer NOT NULL DEFAULT 0,
  cerrado_at timestamptz,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.payroll_periods TO authenticated;
GRANT ALL ON public.payroll_periods TO service_role;
ALTER TABLE public.payroll_periods ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage payroll periods" ON public.payroll_periods FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER payroll_periods_updated_at BEFORE UPDATE ON public.payroll_periods
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.payroll_period_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  period_id uuid NOT NULL REFERENCES public.payroll_periods(id) ON DELETE CASCADE,
  legajo text NOT NULL,
  apellido_nombre text,
  servicio text NOT NULL,
  cuenta_contable text,
  importe numeric NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX payroll_period_items_period_idx ON public.payroll_period_items(period_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.payroll_period_items TO authenticated;
GRANT ALL ON public.payroll_period_items TO service_role;
ALTER TABLE public.payroll_period_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage payroll period items" ON public.payroll_period_items FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.payroll_consumed (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  period_id uuid NOT NULL REFERENCES public.payroll_periods(id) ON DELETE CASCADE,
  source_key text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX payroll_consumed_period_idx ON public.payroll_consumed(period_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.payroll_consumed TO authenticated;
GRANT ALL ON public.payroll_consumed TO service_role;
ALTER TABLE public.payroll_consumed ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage payroll consumed" ON public.payroll_consumed FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));