CREATE TABLE public.pagos_adelantados (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ref_key text NOT NULL UNIQUE,
  tipo text NOT NULL,
  legajo text,
  detalle text,
  importe numeric NOT NULL DEFAULT 0,
  pagado_mes integer,
  pagado_anio integer,
  nota text,
  pagado_por uuid,
  pagado_por_email text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.pagos_adelantados TO authenticated;
GRANT ALL ON public.pagos_adelantados TO service_role;
ALTER TABLE public.pagos_adelantados ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins gestionan pagos adelantados" ON public.pagos_adelantados
FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));