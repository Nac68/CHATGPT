<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->
- Pagos adelantados a beneficiarios (círculos/cumpleaños/colectas) se guardan en `pagos_adelantados` por ref_key estable (tipo:padre_id[:legajo]); solo excluyen el egreso del tablero, nunca el descuento — los integrantes se reinsertan al guardar, así que no usar ids de fila.
