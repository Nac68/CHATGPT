import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getMyStats } from "@/lib/stats.functions";
import { changeMyPin } from "@/lib/auth-affiliate.functions";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Legend,
} from "recharts";
import { UtensilsCrossed, LogOut } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useAffiliateNames } from "@/hooks/use-affiliate-names";
import { ForcePinChangeGate } from "@/components/ForcePinChangeGate";
import { BackButton } from "@/components/BackButton";


export const Route = createFileRoute("/_authenticated/mis-consumos")({
  component: MisConsumos,
});

function MisConsumos() {
  const fn = useServerFn(getMyStats);
  const change = useServerFn(changeMyPin);
  const [pinActual, setPinActual] = useState("");
  const [pinNuevo, setPinNuevo] = useState("");
  const [showPin, setShowPin] = useState(false);
  const { data, isLoading } = useQuery({
    queryKey: ["my-stats"],
    queryFn: () => fn({ data: undefined as any }),
  });
  const nombres = useAffiliateNames(data?.legajo ? [String(data.legajo)] : []);


  const currencyFmt = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });

  async function handleChangePin(e: React.FormEvent) {
    e.preventDefault();
    try {
      await change({ data: { currentPin: pinActual, newPin: pinNuevo } });
      toast.success("PIN actualizado");
      setPinActual("");
      setPinNuevo("");
      setShowPin(false);
    } catch (err: any) {
      toast.error(err?.message ?? "Error");
    }
  }

  const currentMonthKey = (() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
  })();
  const current = data?.months.find((m) => m.mes === currentMonthKey);

  return (
    <ForcePinChangeGate>
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/mis-consumos" className="flex items-center gap-2 font-semibold">
            <UtensilsCrossed className="h-5 w-5 text-primary" />
            Mis consumos
          </Link>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => setShowPin((s) => !s)}>
              Cambiar PIN
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={async () => {
                await supabase.auth.signOut();
                window.location.href = "/";
              }}
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>
      <main className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        <BackButton fallback="/mis-consumos" />
        {isLoading || !data ? (
          <div>Cargando...</div>
        ) : (
          <>
            <div>
              <h1 className="text-2xl font-bold">
                Hola, {nombres[String(data.legajo).toUpperCase()] ?? `legajo ${data.legajo}`}
              </h1>
              <p className="text-xs text-muted-foreground">Legajo {data.legajo}</p>

              <p className="text-sm text-muted-foreground">
                Acá podés ver tus consumos del mes en curso y meses anteriores.
              </p>
            </div>

            {showPin && (
              <Card>
                <CardHeader>
                  <CardTitle>Cambiar PIN</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleChangePin} className="grid gap-3 md:grid-cols-3 items-end">
                    <div className="space-y-2">
                      <Label>PIN actual</Label>
                      <Input
                        type="password"
                        value={pinActual}
                        onChange={(e) => setPinActual(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>PIN nuevo</Label>
                      <Input
                        type="password"
                        value={pinNuevo}
                        onChange={(e) => setPinNuevo(e.target.value)}
                        minLength={4}
                        required
                      />
                    </div>
                    <Button type="submit">Actualizar</Button>
                  </form>
                </CardContent>
              </Card>
            )}

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Stat label="Consumos este mes" value={String(current?.consumos ?? 0)} />
              <Stat label="Desayunos" value={String(current?.desayunos ?? 0)} />
              <Stat label="Almuerzos" value={String(current?.almuerzos ?? 0)} />
              <Stat
                label="A pagar (estimado)"
                value={
                  current?.importe_a_pagar != null
                    ? currencyFmt.format(current.importe_a_pagar)
                    : "Pendiente liquidación"
                }
              />
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Consumos por mes</CardTitle>
              </CardHeader>
              <CardContent>
                {data.months.length === 0 ? (
                  <div className="text-sm text-muted-foreground">Todavía no tenés consumos.</div>
                ) : (
                  <ResponsiveContainer width="100%" height={260}>
                    <BarChart data={[...data.months].reverse()}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="mes" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="desayunos" stackId="a" fill="#f59e0b" />
                      <Bar dataKey="almuerzos" stackId="a" fill="#0ea5e9" />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Historial por mes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="text-left border-b">
                      <tr>
                        <th className="py-2 pr-2">Mes</th>
                        <th className="py-2 pr-2 text-center">Desayunos</th>
                        <th className="py-2 pr-2 text-center">Almuerzos</th>
                        <th className="py-2 pr-2 text-center">Consumos</th>
                        <th className="py-2 pr-2 text-right">Importe</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.months.map((m) => (
                        <tr key={m.mes} className="border-b">
                          <td className="py-2 pr-2 font-mono">{m.mes}</td>
                          <td className="py-2 pr-2 text-center">{m.desayunos}</td>
                          <td className="py-2 pr-2 text-center">{m.almuerzos}</td>
                          <td className="py-2 pr-2 text-center">{m.consumos}</td>
                          <td className="py-2 pr-2 text-right">
                            {m.importe_a_pagar != null
                              ? currencyFmt.format(m.importe_a_pagar)
                              : "—"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Detalle de días</CardTitle>
              </CardHeader>
              <CardContent>
                {data.days.length === 0 ? (
                  <div className="text-sm text-muted-foreground">Sin consumos aún.</div>
                ) : (
                  <div className="divide-y">
                    {data.days.slice(0, 60).map((d) => (
                      <div key={d.fecha} className="py-2 flex justify-between text-sm">
                        <div>
                          <div className="font-semibold">{d.fecha}</div>
                          {d.descripcion && (
                            <div className="text-xs text-muted-foreground">{d.descripcion}</div>
                          )}
                          {d.observacion && (
                            <div className="text-xs italic text-muted-foreground">Obs: {d.observacion}</div>
                          )}
                        </div>
                        <div className="flex gap-3 items-center">
                          {d.desayuno && <span className="text-amber-600">Desayuno</span>}
                          {d.almuerzo && <span className="text-sky-600">Almuerzo</span>}
                          {d.importe > 0 && (
                            <span className="font-mono">{currencyFmt.format(d.importe)}</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        )}
      </main>
    </div>
    </ForcePinChangeGate>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="text-xs uppercase text-muted-foreground">{label}</div>
        <div className="text-lg font-bold mt-1">{value}</div>
      </CardContent>
    </Card>
  );
}
