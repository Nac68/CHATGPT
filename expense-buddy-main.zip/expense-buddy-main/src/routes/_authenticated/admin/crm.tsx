import { createFileRoute } from "@tanstack/react-router";
import { Fragment, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { crmSearch, crmAffiliateHistory, crmProviderHistory } from "@/lib/crm-search.functions";
import { createRefinance, previewRefinance, refinanceHistoryByLegajo } from "@/lib/refinance.functions";
import { formatPeriodo, periodoError } from "@/lib/periodo";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ChevronDown, ChevronRight, Download, Loader2, Search, User, Building2, CreditCard } from "lucide-react";
import * as XLSX from "xlsx";
import { compareLegajo } from "@/lib/legajo";
import { toast } from "sonner";
import { CrmPeriodoConsolidado } from "@/components/CrmPeriodoConsolidado";



export const Route = createFileRoute("/_authenticated/admin/crm")({
  component: CrmBuscador,
  head: () => ({
    meta: [
      { title: "Buscador CRM: afiliados y proveedores · AGOEC" },
      {
        name: "description",
        content:
          "Buscá por legajo o nombre de afiliado, o por número contable o nombre de proveedor, y mirá consumos, liquidaciones y pagos.",
      },
      { property: "og:title", content: "Buscador CRM: afiliados y proveedores · AGOEC" },
      {
        property: "og:description",
        content: "Historial de consumos del afiliado y de liquidaciones y pagos de cada proveedor.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const currency = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });

const ESTADO_CLASS: Record<string, string> = {
  enviada: "bg-secondary text-secondary-foreground",
  revisada: "bg-secondary text-secondary-foreground",
  aprobada: "bg-primary/15 text-primary",
  pagada: "bg-primary text-primary-foreground",
  rechazada: "bg-destructive/15 text-destructive",
};

function Kpi({ t, v }: { t: string; v: string }) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-xs font-medium text-muted-foreground">{t}</CardTitle>
      </CardHeader>
      <CardContent className="text-xl font-bold">{v}</CardContent>
    </Card>
  );
}

function ComidasPorPeriodo({ comidas }: { comidas: any[] }) {
  const [abiertos, setAbiertos] = useState<Set<string>>(() => new Set());

  const grupos = useMemo(() => {
    const map = new Map<
      string,
      { key: string; mes: number; anio: number; dias: any[]; total: number; desayunos: number; almuerzos: number; noPaga: number }
    >();
    for (const c of comidas) {
      const key = String(c.fecha ?? "").slice(0, 7) || "—";
      const g = map.get(key) ?? {
        key,
        mes: 0,
        anio: 0,
        dias: [] as any[],
        total: 0,
        desayunos: 0,
        almuerzos: 0,
        noPaga: 0,
      };
      g.dias.push(c);
      g.total += c.no_paga ? 0 : c.importe;
      if (c.desayuno) g.desayunos += 1;
      if (c.almuerzo) g.almuerzos += 1;
      if (c.no_paga) g.noPaga += 1;
      map.set(key, g);
    }
    return Array.from(map.values()).sort((a, b) => b.key.localeCompare(a.key));
  }, [comidas]);

  const toggle = (key: string) =>
    setAbiertos((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });

  return (
    <div>
      <h3 className="mb-2 text-sm font-semibold">Comida a Dto.</h3>
      {!grupos.length ? (
        <p className="text-sm text-muted-foreground">Sin presencias registradas.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-left text-muted-foreground">
              <tr className="border-b">
                <th className="py-2 pr-3"></th>
                <th className="py-2 pr-3">Período</th>
                <th className="py-2 pr-3">Días</th>
                <th className="py-2 pr-3">Desayunos</th>
                <th className="py-2 pr-3">Almuerzos</th>
                <th className="py-2 pr-3">No paga</th>
                <th className="py-2">Total</th>
              </tr>
            </thead>
            <tbody>
              {grupos.map((g) => {
                const abierto = abiertos.has(g.key);
                return (
                  <Fragment key={g.key}>
                    <tr
                      className="cursor-pointer border-b last:border-0 hover:bg-muted/60"
                      onClick={() => toggle(g.key)}
                    >
                      <td className="py-2 pr-1 text-muted-foreground">
                        {abierto ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                      </td>
                      <td className="py-2 pr-3 font-medium">
                        {g.key !== "—"
                          ? formatPeriodo(Number(g.key.slice(5, 7)), Number(g.key.slice(0, 4)))
                          : "Sin fecha"}
                      </td>
                      <td className="py-2 pr-3">{g.dias.length}</td>
                      <td className="py-2 pr-3">{g.desayunos || "—"}</td>
                      <td className="py-2 pr-3">{g.almuerzos || "—"}</td>
                      <td className={`py-2 pr-3 ${g.noPaga ? "text-destructive" : "text-muted-foreground"}`}>
                        {g.noPaga || "—"}
                      </td>
                      <td className="py-2 font-medium">{currency.format(g.total)}</td>
                    </tr>
                    {abierto && (
                      <tr className="border-b last:border-0">
                        <td colSpan={7} className="bg-muted/40 py-3 pl-8 pr-3">
                          <table className="w-full text-xs">
                            <thead className="text-left text-muted-foreground">
                              <tr className="border-b">
                                <th className="py-1.5 pr-3">Fecha</th>
                                <th className="py-1.5 pr-3">Comida</th>
                                <th className="py-1.5 pr-3">Desayuno</th>
                                <th className="py-1.5 pr-3">Almuerzo</th>
                                <th className="py-1.5 pr-3">Observación</th>
                                <th className="py-1.5">Importe</th>
                              </tr>
                            </thead>
                            <tbody>
                              {g.dias.map((c: any) => (
                                <tr key={c.id} className={`border-b last:border-0 ${c.no_paga ? "text-destructive" : ""}`}>
                                  <td className="py-1.5 pr-3">{c.fecha ?? "—"}</td>
                                  <td className="py-1.5 pr-3">{c.descripcion ?? "—"}</td>
                                  <td className="py-1.5 pr-3">{c.desayuno ? "SI" : "—"}</td>
                                  <td className="py-1.5 pr-3">{c.almuerzo ? "SI" : "—"}</td>
                                  <td className="py-1.5 pr-3">{c.observacion ?? (c.no_paga ? "No paga" : "—")}</td>
                                  <td className="py-1.5">{currency.format(c.no_paga ? 0 : c.importe)}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </td>
                      </tr>
                    )}
                  </Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function CrmBuscador() {
  const search = useServerFn(crmSearch);
  const affHist = useServerFn(crmAffiliateHistory);
  const provHist = useServerFn(crmProviderHistory);

  const [texto, setTexto] = useState("");
  const [q, setQ] = useState("");
  const [legajo, setLegajo] = useState<string | null>(null);
  const [providerId, setProviderId] = useState<string | null>(null);

  const { data: res, isFetching } = useQuery({
    queryKey: ["crm-search", q],
    queryFn: () => search({ data: { q } }),
    enabled: q.trim().length >= 1,
  });

  const { data: aff, isFetching: loadingAff } = useQuery({
    queryKey: ["crm-aff", legajo],
    queryFn: () => affHist({ data: { legajo: legajo! } }),
    enabled: !!legajo,
  });

  const { data: prov, isFetching: loadingProv } = useQuery({
    queryKey: ["crm-prov", providerId],
    queryFn: () => provHist({ data: { provider_id: providerId! } }),
    enabled: !!providerId,
  });

  function exportarAfiliado() {
    if (!aff) return;
    try {
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(
        wb,
        XLSX.utils.json_to_sheet(
          aff.consumos.map((c: any) => ({
            Fecha: c.fecha ?? "",
            Período: c.periodo,
            Servicio: c.servicio,
            Proveedor: c.proveedor,
            "Cuenta contable": c.cuenta_contable ?? "",
            Detalle: c.detalle ?? "",
            Comprobante: c.comprobante ?? "",
            Cuotas: c.cuotas,
            Importe: c.importe,
            Subsidio: c.subsidio,
            "A descontar": c.importe_afiliado,
            Estado: c.estado,
          })),
        ),
        "Consumos",
      );
      XLSX.utils.book_append_sheet(
        wb,
        XLSX.utils.json_to_sheet(
          aff.comidas.map((c: any) => ({
            Fecha: c.fecha ?? "",
            Comida: c.descripcion ?? "",
            Desayuno: c.desayuno ? "SI" : "",
            Almuerzo: c.almuerzo ? "SI" : "",
            "No paga": c.no_paga ? "SI" : "",
            Observación: c.observacion ?? "",
            Importe: c.importe,
          })),
        ),
        "Comida a Dto",
      );
      XLSX.utils.book_append_sheet(
        wb,
        XLSX.utils.json_to_sheet(
          (aff.varios ?? []).map((v: any) => ({
            Período: v.periodo,
            Subservicio: v.subservicio,
            Detalle: v.detalle,
            Cuota: v.cuota ?? "",
            Importe: v.importe,
          })),
        ),
        "Servicios Varios",
      );
      XLSX.utils.book_append_sheet(
        wb,
        XLSX.utils.json_to_sheet(
          (aff.adelantos ?? []).map((v: any) => ({
            Período: v.periodo,
            Servicio: "Adelantos",
            Origen: "AGOEC",
            Detalle: v.detalle,
            Cuota: v.cuota ?? "",
            Importe: v.importe,
          })),
        ),
        "Adelantos",
      );
      XLSX.utils.book_append_sheet(
        wb,
        XLSX.utils.json_to_sheet(
          ((aff as any).detalle ?? []).map((d: any) => ({
            Período: d.periodo,
            Fecha: d.fecha ?? "",
            Servicio: d.servicio,
            "Proveedor / Origen": d.origen ?? "",
            Detalle: d.detalle ?? "",
            Importe: d.importe,
            Subsidio: d.subsidio,
            "A descontar": d.a_descontar,
            Estado: d.estado ?? "",
          })),
        ),
        "Detalle completo",
      );
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(aff.porMes), "Por mes");

      XLSX.writeFile(wb, `afiliado-${aff.legajo}.xlsx`);
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo exportar");
    }
  }

  function exportarProveedor() {
    if (!prov) return;
    try {
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(
        wb,
        XLSX.utils.json_to_sheet(
          prov.liquidaciones.map((l: any) => ({
            Período: l.periodo,
            Liquidación: l.nombre,
            Estado: l.estado,
            Ítems: l.total_items,
            Afiliados: l.total_afiliados,
            Facturado: l.total_importe,
            Subsidios: l.total_subsidio,
            "A pagar": l.total_a_pagar,
          })),
        ),
        "Liquidaciones",
      );
      XLSX.writeFile(wb, `proveedor-${prov.proveedor.nombre.replace(/[^\w\s-]/g, "")}.xlsx`);
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo exportar");
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Buscador CRM</h1>
        <p className="text-sm text-muted-foreground">
          Buscá por legajo o nombre de afiliado, o por número contable o nombre de proveedor.
        </p>
      </div>

      <Card>
        <CardContent className="pt-6">
          <form
            className="flex flex-wrap gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              setLegajo(null);
              setProviderId(null);
              setQ(texto);
            }}
          >
            <Input
              className="max-w-sm"
              placeholder="Legajo, nombre del afiliado, 001/002/003 o proveedor…"
              value={texto}
              onChange={(e) => setTexto(e.target.value)}
            />
            <Button type="submit">
              {isFetching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />} Buscar
            </Button>
          </form>
        </CardContent>
      </Card>

      {q.trim() && (
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <User className="h-4 w-4 text-primary" /> Afiliados ({res?.affiliates.length ?? 0})
              </CardTitle>
              <CardDescription>Elegí un afiliado para ver su historial de consumos.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-1">
              {!res?.affiliates.length ? (
                <p className="text-sm text-muted-foreground">Sin resultados.</p>
              ) : (
                [...res.affiliates]
                  .sort((a: any, b: any) => compareLegajo(a.legajo, b.legajo))
                  .map((a: any) => (
                    <button
                      key={a.legajo}
                      onClick={() => {
                        setProviderId(null);
                        setLegajo(a.legajo);
                      }}
                      className={`flex w-full items-center justify-between rounded-md px-2 py-1.5 text-left text-sm hover:bg-muted ${
                        legajo === a.legajo ? "bg-muted" : ""
                      }`}
                    >
                      <span>
                        <span className="font-mono">{a.legajo}</span> · {a.apellido_nombre}
                      </span>
                      <span className="text-xs text-muted-foreground">{a.sector ?? ""}</span>
                    </button>
                  ))
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Building2 className="h-4 w-4 text-primary" /> Proveedores ({res?.providers.length ?? 0})
              </CardTitle>
              <CardDescription>Elegí un proveedor para ver liquidaciones y pagos.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-1">
              {!res?.providers.length ? (
                <p className="text-sm text-muted-foreground">Sin resultados.</p>
              ) : (
                res.providers.map((p: any) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      setLegajo(null);
                      setProviderId(p.id);
                    }}
                    className={`flex w-full items-center justify-between rounded-md px-2 py-1.5 text-left text-sm hover:bg-muted ${
                      providerId === p.id ? "bg-muted" : ""
                    }`}
                  >
                    <span>
                      <span className="font-mono">{p.cuenta_contable ?? "sin cuenta"}</span> · {p.nombre}
                    </span>
                    <span className="text-xs text-muted-foreground">{p.servicio ?? ""}</span>
                  </button>
                ))
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {legajo && (
        <Card>
          <CardHeader className="flex-row items-start justify-between gap-3">
            <div>
              <CardTitle className="text-base">
                {aff?.afiliado?.apellido_nombre ?? "Afiliado"} · <span className="font-mono">{legajo}</span>
              </CardTitle>
              <CardDescription>
                {aff?.afiliado?.sector ? `Sector ${aff.afiliado.sector} · ` : ""}Historial completo de consumos
              </CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={exportarAfiliado} disabled={!aff}>
              <Download className="h-4 w-4" /> Excel
            </Button>
          </CardHeader>
          <CardContent className="space-y-5">
            {loadingAff ? (
              <p className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" /> Cargando…
              </p>
            ) : (
              <>
                <CrmPeriodoConsolidado legajo={legajo} modo="actual" />

                <DetalleTodos rows={aff?.detalle ?? []} legajo={legajo} />

                <CrmPeriodoConsolidado legajo={legajo} modo="historico" />

                <Historicos rows={(aff as any)?.historico ?? []} />

                <HistorialRefinanciaciones legajo={legajo} />

                <div className="grid gap-4 sm:grid-cols-4">
                  <Kpi t="Consumos" v={String(aff?.totales.items ?? 0)} />
                  <Kpi t="Total consumido" v={currency.format(aff?.totales.importe ?? 0)} />
                  <Kpi t="Subsidios AGOEC" v={currency.format(aff?.totales.subsidio ?? 0)} />
                  <Kpi t="A descontar" v={currency.format(aff?.totales.a_descontar ?? 0)} />
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <h3 className="mb-2 text-sm font-semibold">Por mes</h3>
                    <table className="w-full text-sm">
                      <thead className="text-left text-muted-foreground">
                        <tr className="border-b">
                          <th className="py-1.5 pr-3">Período</th>
                          <th className="py-1.5 pr-3">Ítems</th>
                          <th className="py-1.5 pr-3">Consumido</th>
                          <th className="py-1.5">A descontar</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(aff?.porMes ?? []).map((m: any) => (
                          <tr key={m.periodo} className="border-b last:border-0">
                            <td className="py-1.5 pr-3">{m.periodo}</td>
                            <td className="py-1.5 pr-3">{m.consumos}</td>
                            <td className="py-1.5 pr-3">{currency.format(m.importe)}</td>
                            <td className="py-1.5 font-medium">{currency.format(m.a_descontar)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div>
                    <h3 className="mb-2 text-sm font-semibold">Por servicio</h3>
                    <table className="w-full text-sm">
                      <thead className="text-left text-muted-foreground">
                        <tr className="border-b">
                          <th className="py-1.5 pr-3">Servicio</th>
                          <th className="py-1.5">A descontar</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(aff?.porServicio ?? []).map((s: any) => (
                          <tr key={s.servicio} className="border-b last:border-0">
                            <td className="py-1.5 pr-3">{s.servicio}</td>
                            <td className="py-1.5 font-medium">{currency.format(s.total)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>



                <div>
                  <h3 className="mb-2 text-sm font-semibold">Consumos en servicios y proveedores</h3>
                  {!aff?.consumos.length ? (
                    <p className="text-sm text-muted-foreground">Sin consumos cargados.</p>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="text-left text-muted-foreground">
                          <tr className="border-b">
                            <th className="py-2 pr-3">Fecha</th>
                            <th className="py-2 pr-3">Período</th>
                            <th className="py-2 pr-3">Servicio</th>
                            <th className="py-2 pr-3">Proveedor</th>
                            <th className="py-2 pr-3">Detalle</th>
                            <th className="py-2 pr-3">Importe</th>
                            <th className="py-2 pr-3">Subsidio</th>
                            <th className="py-2 pr-3">A descontar</th>
                            <th className="py-2 pr-3">Estado</th>
                          </tr>
                        </thead>
                        <tbody>
                          {aff.consumos.map((c: any) => (
                            <tr key={c.id} className="border-b last:border-0">
                              <td className="py-1.5 pr-3">{c.fecha ?? "—"}</td>
                              <td className="py-1.5 pr-3">{c.periodo}</td>
                              <td className="py-1.5 pr-3">{c.servicio}</td>
                              <td className="py-1.5 pr-3">{c.proveedor}</td>
                              <td className="py-1.5 pr-3">{c.detalle ?? "—"}</td>
                              <td className="py-1.5 pr-3">{currency.format(c.importe)}</td>
                              <td className="py-1.5 pr-3">{currency.format(c.subsidio)}</td>
                              <td className="py-1.5 pr-3 font-medium">{currency.format(c.importe_afiliado)}</td>
                              <td className="py-1.5 pr-3">
                                <span
                                  className={`rounded px-2 py-0.5 text-xs capitalize ${ESTADO_CLASS[c.estado] ?? "bg-muted"}`}
                                >
                                  {c.estado}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                <ComidasPorPeriodo comidas={aff?.comidas ?? []} />

                <div>
                  <h3 className="mb-2 text-sm font-semibold">Servicios Varios (Círculos, Cumpleaños, Colectas)</h3>
                  {!aff?.varios?.length ? (
                    <p className="text-sm text-muted-foreground">Sin aportes registrados.</p>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="text-left text-muted-foreground">
                          <tr className="border-b">
                            <th className="py-2 pr-3">Período</th>
                            <th className="py-2 pr-3">Subservicio</th>
                            <th className="py-2 pr-3">Detalle</th>
                            <th className="py-2 pr-3">Cuota</th>
                            <th className="py-2 pr-3">A descontar</th>
                          </tr>
                        </thead>
                        <tbody>
                          {aff.varios.map((v: any) => (
                            <tr key={v.id} className="border-b last:border-0">
                              <td className="py-1.5 pr-3">{v.periodo}</td>
                              <td className="py-1.5 pr-3">{v.subservicio}</td>
                              <td className="py-1.5 pr-3">{v.detalle}</td>
                              <td className="py-1.5 pr-3">{v.cuota ?? "—"}</td>
                              <td className="py-1.5 pr-3 font-medium">{currency.format(v.importe)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                <div>
                  <h3 className="mb-2 text-sm font-semibold">Adelantos · servicio interno AGOEC</h3>
                  {!aff?.adelantos?.length ? (
                    <p className="text-sm text-muted-foreground">Sin adelantos registrados.</p>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="text-left text-muted-foreground">
                          <tr className="border-b">
                            <th className="py-2 pr-3">Período</th>
                            <th className="py-2 pr-3">Servicio</th>
                            <th className="py-2 pr-3">Origen</th>
                            <th className="py-2 pr-3">Detalle</th>
                            <th className="py-2 pr-3">Cuota</th>
                            <th className="py-2 pr-3">A descontar</th>
                          </tr>
                        </thead>
                        <tbody>
                          {aff.adelantos.map((v: any) => (
                            <tr key={v.id} className="border-b last:border-0">
                              <td className="py-1.5 pr-3">{v.periodo}</td>
                              <td className="py-1.5 pr-3">Adelantos</td>
                              <td className="py-1.5 pr-3">AGOEC</td>
                              <td className="py-1.5 pr-3">{v.detalle}</td>
                              <td className="py-1.5 pr-3">{v.cuota ?? "—"}</td>
                              <td className="py-1.5 pr-3 font-medium">{currency.format(v.importe)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

              </>
            )}
          </CardContent>
        </Card>
      )}

      {providerId && (
        <Card>
          <CardHeader className="flex-row items-start justify-between gap-3">
            <div>
              <CardTitle className="text-base">
                {prov?.proveedor.nombre ?? "Proveedor"}{" "}
                <span className="font-mono text-sm text-muted-foreground">
                  {prov?.proveedor.cuenta_contable ?? "sin cuenta contable"}
                </span>
              </CardTitle>
              <CardDescription>
                {prov?.proveedor.servicio ?? "—"} · {prov?.proveedor.tipo ?? "—"} · CUIT{" "}
                {prov?.proveedor.cuit ?? "—"} · {prov?.proveedor.cbu ?? prov?.proveedor.alias ?? "sin datos de cobro"}
              </CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={exportarProveedor} disabled={!prov}>
              <Download className="h-4 w-4" /> Excel
            </Button>
          </CardHeader>
          <CardContent className="space-y-5">
            {loadingProv ? (
              <p className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" /> Cargando…
              </p>
            ) : (
              <>
                <div className="grid gap-4 sm:grid-cols-4">
                  <Kpi t="Liquidaciones" v={String(prov?.totales.liquidaciones ?? 0)} />
                  <Kpi t="Facturado" v={currency.format(prov?.totales.facturado ?? 0)} />
                  <Kpi t="Pagado" v={currency.format(prov?.totales.pagado ?? 0)} />
                  <Kpi t="Pendiente de pago" v={currency.format(prov?.totales.pendiente ?? 0)} />
                </div>

                {!prov?.liquidaciones.length ? (
                  <p className="text-sm text-muted-foreground">Este proveedor todavía no presentó liquidaciones.</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="text-left text-muted-foreground">
                        <tr className="border-b">
                          <th className="py-2 pr-3">Período</th>
                          <th className="py-2 pr-3">Liquidación</th>
                          <th className="py-2 pr-3">Ítems</th>
                          <th className="py-2 pr-3">Afiliados</th>
                          <th className="py-2 pr-3">Facturado</th>
                          <th className="py-2 pr-3">Subsidios</th>
                          <th className="py-2 pr-3">A pagar</th>
                          <th className="py-2 pr-3">Estado</th>
                        </tr>
                      </thead>
                      <tbody>
                        {prov.liquidaciones.map((l: any) => (
                          <tr key={l.id} className="border-b last:border-0">
                            <td className="py-1.5 pr-3">{l.periodo}</td>
                            <td className="py-1.5 pr-3">{l.nombre}</td>
                            <td className="py-1.5 pr-3">{l.total_items}</td>
                            <td className="py-1.5 pr-3">{l.total_afiliados}</td>
                            <td className="py-1.5 pr-3">{currency.format(l.total_importe)}</td>
                            <td className="py-1.5 pr-3">{currency.format(l.total_subsidio)}</td>
                            <td className="py-1.5 pr-3 font-medium">{currency.format(l.total_a_pagar)}</td>
                            <td className="py-1.5 pr-3">
                              <span
                                className={`rounded px-2 py-0.5 text-xs capitalize ${ESTADO_CLASS[l.estado] ?? "bg-muted"}`}
                              >
                                {l.estado}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

/** Detalle unificado de TODOS los servicios y subservicios del afiliado. */
function DetalleTodos({ rows, legajo }: { rows: any[]; legajo: string }) {
  const [q, setQ] = useState("");
  const [srv, setSrv] = useState("todos");
  const [page, setPage] = useState(1);
  const [sel, setSel] = useState<Record<string, boolean>>({});
  const [open, setOpen] = useState(false);
  const size = 20;

  const servicios = Array.from(new Set(rows.map((r) => r.servicio))).sort();
  const t = q.trim().toLowerCase();
  const filtradas = rows.filter(
    (r) =>
      (srv === "todos" || r.servicio === srv) &&
      (!t ||
        String(r.servicio).toLowerCase().includes(t) ||
        String(r.detalle ?? "").toLowerCase().includes(t) ||
        String(r.origen ?? "").toLowerCase().includes(t) ||
        String(r.periodo ?? "").includes(t)),
  );
  const totalPages = Math.max(1, Math.ceil(filtradas.length / size));
  const pageSafe = Math.min(page, totalPages);
  const visibles = filtradas.slice((pageSafe - 1) * size, pageSafe * size);
  const totalDesc = filtradas.reduce((a, r) => a + Number(r.a_descontar ?? 0), 0);

  const seleccionables = filtradas.filter((r) => !r.refinanciado && Number(r.a_descontar) > 0);
  const seleccionadas = rows.filter((r) => sel[r.source_key]);
  const totalSel = seleccionadas.reduce((a, r) => a + Number(r.a_descontar ?? 0), 0);
  const allVisiblesSel =
    visibles.filter((r) => !r.refinanciado && Number(r.a_descontar) > 0).length > 0 &&
    visibles
      .filter((r) => !r.refinanciado && Number(r.a_descontar) > 0)
      .every((r) => sel[r.source_key]);

  return (
    <div>
      <h3 className="mb-2 text-sm font-semibold">Detalle completo por servicio</h3>
      <div className="mb-3 flex flex-wrap gap-2">
        <Input
          className="max-w-xs"
          placeholder="Filtrar por servicio, detalle o período…"
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setPage(1);
          }}
        />
        <select
          className="h-9 rounded-md border bg-background px-2 text-sm"
          value={srv}
          onChange={(e) => {
            setSrv(e.target.value);
            setPage(1);
          }}
        >
          <option value="todos">Todos los servicios</option>
          {servicios.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        <span className="self-center text-xs text-muted-foreground">
          {filtradas.length} movimientos · a descontar {currency.format(totalDesc)}
        </span>
        <div className="ml-auto flex items-center gap-2">
          {seleccionables.length > 0 && (
            <Button
              size="sm"
              variant="outline"
              onClick={() =>
                setSel((prev) => {
                  const next = { ...prev };
                  const marcarTodo = seleccionables.some((r) => !next[r.source_key]);
                  for (const r of seleccionables) next[r.source_key] = marcarTodo;
                  return next;
                })
              }
            >
              {seleccionables.every((r) => sel[r.source_key]) ? "Quitar selección" : "Seleccionar filtrados"}
            </Button>
          )}
          <Button size="sm" disabled={!seleccionadas.length} onClick={() => setOpen(true)}>
            <CreditCard className="mr-2 h-4 w-4" />
            Refinanciar {seleccionadas.length ? `(${seleccionadas.length})` : ""}
          </Button>
        </div>
      </div>
      <div className="mb-3 flex flex-wrap gap-2">
        {servicios.map((sv) => {
          const delServicio = rows.filter(
            (r) => r.servicio === sv && !r.refinanciado && Number(r.a_descontar) > 0,
          );
          const todosSel = delServicio.length > 0 && delServicio.every((r) => sel[r.source_key]);
          const totalSv = delServicio.reduce((a, r) => a + Number(r.a_descontar ?? 0), 0);
          return (
            <div key={sv} className="flex items-center gap-1 rounded-md border px-2 py-1">
              <Button
                size="sm"
                variant={todosSel ? "default" : "ghost"}
                disabled={!delServicio.length}
                onClick={() =>
                  setSel((prev) => {
                    const next = { ...prev };
                    for (const r of delServicio) next[r.source_key] = !todosSel;
                    return next;
                  })
                }
              >
                {todosSel ? "Quitar" : "Marcar"} {sv} ({delServicio.length}) · {currency.format(totalSv)}
              </Button>
              <Button
                size="sm"
                variant="outline"
                disabled={!delServicio.length}
                onClick={() => {
                  const next: Record<string, boolean> = {};
                  for (const r of delServicio) next[r.source_key] = true;
                  setSel(next);
                  setOpen(true);
                }}
              >
                <CreditCard className="mr-1 h-3.5 w-3.5" />
                Refinanciar solo este servicio
              </Button>
            </div>
          );
        })}
      </div>

      {seleccionadas.length > 0 && (
        <p className="mb-3 rounded-md border bg-muted/40 px-3 py-2 text-xs">
          {seleccionadas.length} consumos seleccionados · total a refinanciar{" "}
          <strong>{currency.format(totalSel)}</strong>
        </p>
      )}
      {!filtradas.length ? (
        <p className="text-sm text-muted-foreground">Sin movimientos registrados.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-left text-muted-foreground">
              <tr className="border-b">
                <th className="py-2 pr-3">
                  <Checkbox
                    checked={allVisiblesSel}
                    onCheckedChange={(v) =>
                      setSel((prev) => {
                        const next = { ...prev };
                        for (const r of visibles) {
                          if (r.refinanciado || Number(r.a_descontar) <= 0) continue;
                          next[r.source_key] = Boolean(v);
                        }
                        return next;
                      })
                    }
                    aria-label="Seleccionar página"
                  />
                </th>
                <th className="py-2 pr-3">Período</th>
                <th className="py-2 pr-3">Fecha</th>
                <th className="py-2 pr-3">Servicio</th>
                <th className="py-2 pr-3">Proveedor / Origen</th>
                <th className="py-2 pr-3">Detalle</th>
                <th className="py-2 pr-3">Importe</th>
                <th className="py-2 pr-3">Subsidio</th>
                <th className="py-2 pr-3">A descontar</th>
                <th className="py-2 pr-3">Estado</th>
              </tr>
            </thead>
            <tbody>
              {visibles.map((r) => (
                <tr key={r.id} className="border-b last:border-0">
                  <td className="py-1.5 pr-3">
                    <Checkbox
                      checked={Boolean(sel[r.source_key])}
                      disabled={r.refinanciado || Number(r.a_descontar) <= 0}
                      onCheckedChange={(v) =>
                        setSel((prev) => ({ ...prev, [r.source_key]: Boolean(v) }))
                      }
                      aria-label={`Seleccionar ${r.servicio}`}
                    />
                  </td>
                  <td className="py-1.5 pr-3">{r.periodo}</td>
                  <td className="py-1.5 pr-3">{r.fecha ?? "—"}</td>
                  <td className="py-1.5 pr-3">{r.servicio}</td>
                  <td className="py-1.5 pr-3">{r.origen ?? "—"}</td>
                  <td className="py-1.5 pr-3">{r.detalle ?? "—"}</td>
                  <td className="py-1.5 pr-3">{currency.format(r.importe)}</td>
                  <td className="py-1.5 pr-3">{currency.format(r.subsidio)}</td>
                  <td className="py-1.5 pr-3 font-medium">{currency.format(r.a_descontar)}</td>
                  <td className="py-1.5 pr-3 capitalize">
                    {r.refinanciado ? (
                      <Badge variant="secondary">Refinanciado</Badge>
                    ) : (
                      (r.estado ?? "—")
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {filtradas.length > size && (
        <div className="mt-2 flex items-center justify-between gap-2">
          <p className="text-xs text-muted-foreground">
            Página {pageSafe} de {totalPages}
          </p>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" disabled={pageSafe <= 1} onClick={() => setPage(pageSafe - 1)}>
              Anterior
            </Button>
            <Button
              size="sm"
              variant="outline"
              disabled={pageSafe >= totalPages}
              onClick={() => setPage(pageSafe + 1)}
            >
              Siguiente
            </Button>
          </div>
        </div>
      )}
      <RefinanciarDialog
        open={open}
        onOpenChange={setOpen}
        legajo={legajo}
        items={seleccionadas}
        onDone={() => setSel({})}
      />
    </div>
  );
}

/** Diálogo para armar el plan de cuotas de los consumos seleccionados. */
function RefinanciarDialog({
  open,
  onOpenChange,
  legajo,
  items,
  onDone,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  legajo: string;
  items: any[];
  onDone: () => void;
}) {
  const hoy = new Date();
  const [cuotas, setCuotas] = useState(3);
  const [mes, setMes] = useState(hoy.getMonth() + 2 > 12 ? 1 : hoy.getMonth() + 2);
  const [anio, setAnio] = useState(hoy.getMonth() + 2 > 12 ? hoy.getFullYear() + 1 : hoy.getFullYear());
  const [obs, setObs] = useState("");
  const [saving, setSaving] = useState(false);
  const crear = useServerFn(createRefinance);
  const qc = useQueryClient();

  const total = items.reduce((a, r) => a + Number(r.a_descontar ?? 0), 0);
  const cuotasSafe = Math.max(1, Math.min(60, Number(cuotas) || 1));

  const porServicio = useMemo(() => {
    const map = new Map<string, { servicio: string; cant: number; total: number }>();
    for (const r of items) {
      const sv = String(r.servicio ?? "Sin servicio");
      const g = map.get(sv) ?? { servicio: sv, cant: 0, total: 0 };
      g.cant += 1;
      g.total += Number(r.a_descontar ?? 0);
      map.set(sv, g);
    }
    return Array.from(map.values()).sort((a, b) => b.total - a.total);
  }, [items]);

  const previewFn = useServerFn(previewRefinance);
  const errPeriodo = periodoError(mes, anio);
  const prevQ = useQuery({
    queryKey: ["refi-preview", legajo, total, cuotasSafe, mes, anio],
    enabled: open && total > 0 && !errPeriodo,
    queryFn: () =>
      previewFn({
        data: {
          legajo,
          nuevos: total,
          cuotas: cuotasSafe,
          periodo_mes: Number(mes),
          periodo_anio: Number(anio),
        },
      }),
  });
  const anterior: any = prevQ.data?.anterior ?? null;
  const pv: any = prevQ.data?.preview ?? null;
  const conflicto: any[] = prevQ.data?.conflicto ?? [];
  const plan: any[] = pv?.plan ?? [];




  const submit = async () => {
    setSaving(true);
    try {
      await crear({
        data: {
          legajo,
          cuotas: cuotasSafe,
          periodo_mes: Number(mes),
          periodo_anio: Number(anio),
          observacion: obs.trim() || null,
          items: items.map((r) => ({
            source_key: String(r.source_key),
            servicio: String(r.servicio ?? ""),
            detalle: String(r.detalle ?? ""),
            periodo: String(r.periodo ?? ""),
            importe: Number(r.a_descontar ?? 0),
          })),
        },
      });
      toast.success(
        anterior
          ? `Plan consolidado: ${pv?.cuotas ?? cuotasSafe} cuotas de ${currency.format(pv?.importe_cuota ?? total / cuotasSafe)} (saldo anterior + nuevos importes)`
          : `Refinanciación creada: ${pv?.cuotas ?? cuotasSafe} cuotas de ${currency.format(pv?.importe_cuota ?? total / cuotasSafe)}`,
      );
      onOpenChange(false);
      onDone();
      await qc.invalidateQueries();
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo refinanciar");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Refinanciar consumos</DialogTitle>
          <DialogDescription>
            Legajo {legajo} · {items.length} consumos · total {currency.format(total)}. Los consumos dejan de
            cobrarse por su servicio original y se descuentan en cuotas.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-3">
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label htmlFor="ref-cuotas">Cuotas</Label>
              <Input
                id="ref-cuotas"
                type="number"
                min={1}
                max={60}
                value={cuotas}
                onChange={(e) => setCuotas(Number(e.target.value))}
              />
            </div>
            <div>
              <Label htmlFor="ref-mes">Mes inicio</Label>
              <Input
                id="ref-mes"
                type="number"
                min={1}
                max={12}
                value={mes}
                onChange={(e) => setMes(Number(e.target.value))}
              />
            </div>
            <div>
              <Label htmlFor="ref-anio">Año inicio</Label>
              <Input
                id="ref-anio"
                type="number"
                min={2000}
                max={2100}
                value={anio}
                onChange={(e) => setAnio(Number(e.target.value))}
              />
            </div>
          </div>
          <div>
            <Label htmlFor="ref-obs">Observación</Label>
            <Input id="ref-obs" value={obs} onChange={(e) => setObs(e.target.value)} placeholder="Opcional" />
          </div>
          {errPeriodo ? (
            <p className="rounded-md border border-destructive bg-destructive/5 px-3 py-2 text-sm text-destructive">
              {errPeriodo}
            </p>
          ) : conflicto.length ? (
            <p className="rounded-md border border-destructive bg-destructive/5 px-3 py-2 text-sm text-destructive">
              El legajo tiene {conflicto.length} refinanciaciones activas a la vez. No se consolida
              automáticamente para no perder datos: revisá los planes en Refinanciación y dejá uno solo activo.
            </p>
          ) : (
            <div className="rounded-md border bg-muted/40 px-3 py-2 text-sm space-y-1">
              {anterior ? (
                <>
                  <p className="text-xs text-muted-foreground">
                    Ya existe una refinanciación activa: se consolida en un único plan.
                  </p>
                  <p>
                    Saldo pendiente anterior <strong>{currency.format(anterior.saldo)}</strong> (
                    {anterior.cuotas_cobradas}/{anterior.cuotas} cuotas ya cobradas se conservan) + nuevos
                    importes <strong>{currency.format(total)}</strong> ={" "}
                    <strong>capital consolidado {currency.format(pv?.capital ?? total)}</strong>
                  </p>
                </>
              ) : (
                <p className="text-xs text-muted-foreground">
                  El legajo no tiene refinanciación activa: se crea el primer plan.
                </p>
              )}
              <p>
                {pv?.cuotas ?? cuotasSafe} cuotas de{" "}
                <strong>{currency.format(pv?.importe_cuota ?? total / cuotasSafe)}</strong> desde{" "}
                {pv?.periodo_label ?? formatPeriodo(mes, anio)}
                {pv?.periodo_fin_label ? ` hasta ${pv.periodo_fin_label}` : ""}
              </p>
            </div>
          )}

          <div className="rounded-md border p-2">
            <p className="mb-1 text-xs font-semibold text-muted-foreground">Servicios a refinanciar</p>
            <table className="w-full text-xs">
              <tbody>
                {porServicio.map((s) => (
                  <tr key={s.servicio}>
                    <td className="py-0.5 pr-2">{s.servicio}</td>
                    <td className="py-0.5 pr-2 text-muted-foreground">{s.cant} consumos</td>
                    <td className="py-0.5 text-right font-medium">{currency.format(s.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="max-h-40 overflow-y-auto rounded-md border">
            <table className="w-full text-xs">
              <thead className="sticky top-0 bg-muted text-left text-muted-foreground">
                <tr>
                  <th className="px-2 py-1">Cuota</th>
                  <th className="px-2 py-1">Período</th>
                  <th className="px-2 py-1">Importe</th>
                  <th className="px-2 py-1 text-right">Saldo restante</th>
                </tr>
              </thead>
              <tbody>
                {plan.map((c) => (
                  <tr key={c.n} className="border-t">
                    <td className="px-2 py-1">
                      {c.n}/{cuotasSafe}
                    </td>
                    <td className="px-2 py-1">{c.periodo}</td>
                    <td className="px-2 py-1">{currency.format(c.importe)}</td>
                    <td className="px-2 py-1 text-right">{currency.format(c.saldo)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="rounded-md border border-primary/40 bg-primary/5 px-3 py-2 text-xs text-muted-foreground">
            Al proveedor se le paga el total de la factura; AGOEC financia el consumo al afiliado en cuotas.
          </p>

        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button
            onClick={submit}
            disabled={saving || !items.length || total <= 0 || !!errPeriodo || !!conflicto.length}
          >
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Confirmar refinanciación
          </Button>

        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}


function HistorialRefinanciaciones({ legajo }: { legajo: string }) {
  const fn = useServerFn(refinanceHistoryByLegajo);
  const [abierta, setAbierta] = useState<string | null>(null);
  const { data, isLoading } = useQuery({
    queryKey: ["refin-hist", legajo],
    queryFn: () => fn({ data: { legajo } }),
    enabled: !!legajo,
  });

  const planes = (data?.planes ?? []) as any[];

  const exportar = () => {
    if (!planes.length) return toast.error("Sin refinanciaciones para exportar");
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        planes.map((p) => ({
          "Refinanciado el": String(p.created_at ?? "").slice(0, 10),
          "Período inicial": p.periodo_label,
          "Período final": p.periodo_fin_label,
          Cuotas: p.cuotas,
          "Importe cuota": p.importe_cuota,
          "Total refinanciado": p.total,
          Saldo: p.saldo,
          Estado: p.finalizada ? "Finalizada" : "En curso",
          Consumos: (p.items ?? []).length,
          Observación: p.observacion ?? "",
        })),
      ),
      "Planes",
    );
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        planes.flatMap((p) =>
          (p.items ?? []).map((i: any) => ({
            "Refinanciado el": String(p.created_at ?? "").slice(0, 10),
            "Período inicial": p.periodo_label,
            Cuotas: p.cuotas,
            Servicio: i.servicio ?? "",
            Detalle: i.detalle ?? "",
            "Período original": i.periodo ?? "",
            Importe: Number(i.importe ?? 0),
          })),
        ),
      ),
      "Consumos",
    );
    XLSX.writeFile(wb, `refinanciaciones-${legajo}.xlsx`);
  };

  return (
    <div>
      <div className="mb-2 flex items-center justify-between gap-2">
        <h3 className="text-sm font-semibold">Historial de refinanciaciones</h3>
        <Button variant="outline" size="sm" onClick={exportar} disabled={!planes.length}>
          <Download className="h-4 w-4" /> Excel
        </Button>
      </div>
      {isLoading ? (
        <p className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Cargando…
        </p>
      ) : !planes.length ? (
        <p className="text-sm text-muted-foreground">Este legajo no tiene consumos refinanciados.</p>
      ) : (
        <>
          <div className="mb-2 grid gap-4 sm:grid-cols-4">
            <Kpi t="Planes" v={String(data?.resumen.planes ?? 0)} />
            <Kpi t="En curso" v={String(data?.resumen.en_curso ?? 0)} />
            <Kpi t="Total refinanciado" v={currency.format(data?.resumen.total ?? 0)} />
            <Kpi t="Saldo pendiente" v={currency.format(data?.resumen.saldo ?? 0)} />
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground">
                <tr className="border-b">
                  <th className="py-2 pr-3">Refinanciado el</th>
                  <th className="py-2 pr-3">Período inicial</th>
                  <th className="py-2 pr-3">Período final</th>
                  <th className="py-2 pr-3">Cuotas</th>
                  <th className="py-2 pr-3">Importe cuota</th>
                  <th className="py-2 pr-3">Total</th>
                  <th className="py-2 pr-3">Saldo</th>
                  <th className="py-2 pr-3">Estado</th>
                  <th className="py-2 pr-3"></th>
                </tr>
              </thead>
              <tbody>
                {planes.map((p) => (
                  <Fragment key={p.id}>
                    <tr className="border-b last:border-0">
                      <td className="py-1.5 pr-3">{String(p.created_at ?? "").slice(0, 10)}</td>
                      <td className="py-1.5 pr-3">{p.periodo_label}</td>
                      <td className="py-1.5 pr-3">{p.periodo_fin_label}</td>
                      <td className="py-1.5 pr-3">{p.cuotas}</td>
                      <td className="py-1.5 pr-3">{currency.format(p.importe_cuota)}</td>
                      <td className="py-1.5 pr-3">{currency.format(p.total)}</td>
                      <td className="py-1.5 pr-3 font-medium">{currency.format(p.saldo)}</td>
                      <td className="py-1.5 pr-3">
                        {p.finalizada ? (
                          <Badge variant="secondary">Finalizada</Badge>
                        ) : (
                          <Badge>
                            Cuota {p.cuota_actual ?? "—"}/{p.cuotas}
                          </Badge>
                        )}
                      </td>
                      <td className="py-1.5 pr-3 text-right">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setAbierta(abierta === p.id ? null : p.id)}
                        >
                          {abierta === p.id ? "Ocultar" : `Ver ${(p.items ?? []).length} consumos`}
                        </Button>
                      </td>
                    </tr>
                    {abierta === p.id && (
                      <tr className="border-b bg-muted/30">
                        <td colSpan={9} className="p-3">
                          <table className="w-full text-xs">
                            <thead className="text-left text-muted-foreground">
                              <tr>
                                <th className="pb-1 pr-3">Servicio</th>
                                <th className="pb-1 pr-3">Detalle</th>
                                <th className="pb-1 pr-3">Período original</th>
                                <th className="pb-1 pr-3">Importe</th>
                              </tr>
                            </thead>
                            <tbody>
                              {(p.items ?? []).map((i: any) => (
                                <tr key={i.id}>
                                  <td className="py-1 pr-3">{i.servicio ?? "—"}</td>
                                  <td className="py-1 pr-3">{i.detalle ?? "—"}</td>
                                  <td className="py-1 pr-3">{i.periodo ?? "—"}</td>
                                  <td className="py-1 pr-3">{currency.format(Number(i.importe ?? 0))}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </td>
                      </tr>
                    )}
                  </Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

/** Consumos de períodos ya liquidados: solo lectura, no se refinancian. */
function Historicos({ rows }: { rows: any[] }) {
  const [q, setQ] = useState("");
  const [mes, setMes] = useState("todos");
  const [anio, setAnio] = useState("todos");
  const [tipo, setTipo] = useState("todos");
  const [page, setPage] = useState(1);
  const size = 20;

  const anios = useMemo(
    () =>
      Array.from(new Set(rows.map((r) => String(r.periodo ?? "").slice(0, 4)).filter(Boolean)))
        .sort()
        .reverse(),
    [rows],
  );

  const esAdelanto = (r: any) => String(r.servicio ?? "").toLowerCase().includes("adelanto");

  const t = q.trim().toLowerCase();
  const filtradas = rows.filter((r) => {
    const p = String(r.periodo ?? "");
    return (
      (anio === "todos" || p.slice(0, 4) === anio) &&
      (mes === "todos" || p.slice(5, 7) === mes) &&
      (tipo === "todos" || (tipo === "adelanto" ? esAdelanto(r) : !esAdelanto(r))) &&
      (!t ||
        String(r.legajo ?? "").toLowerCase().includes(t) ||
        String(r.servicio).toLowerCase().includes(t) ||
        String(r.detalle ?? "").toLowerCase().includes(t) ||
        p.includes(t))
    );
  });

  const totalPages = Math.max(1, Math.ceil(filtradas.length / size));
  const pageSafe = Math.min(page, totalPages);
  const visibles = filtradas.slice((pageSafe - 1) * size, pageSafe * size);
  const total = filtradas.reduce((a, r) => a + Number(r.a_descontar ?? 0), 0);

  return (
    <div>
      <h3 className="mb-2 text-sm font-semibold">Históricos · períodos ya liquidados</h3>
      <p className="mb-3 text-xs text-muted-foreground">
        Estos consumos ya se descontaron en una liquidación cerrada, por eso no aparecen en el detalle
        vigente y no pueden refinanciarse.
      </p>
      <div className="mb-3 flex flex-wrap gap-2">
        <Input
          className="max-w-xs"
          placeholder="Filtrar por legajo, servicio o detalle…"
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setPage(1);
          }}
        />
        <select
          className="h-9 rounded-md border bg-background px-2 text-sm"
          value={mes}
          onChange={(e) => {
            setMes(e.target.value);
            setPage(1);
          }}
        >
          <option value="todos">Todos los meses</option>
          {Array.from({ length: 12 }, (_, i) => String(i + 1).padStart(2, "0")).map((m) => (
            <option key={m} value={m}>
              Mes {m}
            </option>
          ))}
        </select>
        <select
          className="h-9 rounded-md border bg-background px-2 text-sm"
          value={anio}
          onChange={(e) => {
            setAnio(e.target.value);
            setPage(1);
          }}
        >
          <option value="todos">Todos los años</option>
          {anios.map((a) => (
            <option key={a} value={a}>
              {a}
            </option>
          ))}
        </select>
        <select
          className="h-9 rounded-md border bg-background px-2 text-sm"
          value={tipo}
          onChange={(e) => {
            setTipo(e.target.value);
            setPage(1);
          }}
        >
          <option value="todos">Todo origen</option>
          <option value="consumo">Consumos</option>
          <option value="adelanto">Adelantos</option>
        </select>
        <span className="self-center text-xs text-muted-foreground">
          {filtradas.length} movimientos · descontado {currency.format(total)}
        </span>

      </div>
      {!filtradas.length ? (
        <p className="text-sm text-muted-foreground">Sin consumos en períodos cerrados.</p>
      ) : (
        <>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground">
                <tr className="border-b">
                  <th className="py-2 pr-3">Período</th>
                  <th className="py-2 pr-3">Servicio</th>
                  <th className="py-2 pr-3">Origen</th>
                  <th className="py-2 pr-3">Detalle</th>
                  <th className="py-2 pr-3">Importe</th>
                  <th className="py-2 pr-3">Descontado</th>
                </tr>
              </thead>
              <tbody>
                {visibles.map((r) => (
                  <tr key={r.id} className="border-b last:border-0">
                    <td className="py-1.5 pr-3">{r.periodo}</td>
                    <td className="py-1.5 pr-3">{r.servicio}</td>
                    <td className="py-1.5 pr-3">{r.origen ?? "—"}</td>
                    <td className="py-1.5 pr-3">{r.detalle ?? "—"}</td>
                    <td className="py-1.5 pr-3">{currency.format(Number(r.importe ?? 0))}</td>
                    <td className="py-1.5 pr-3">{currency.format(Number(r.a_descontar ?? 0))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {totalPages > 1 && (
            <div className="mt-3 flex items-center gap-2">
              <Button size="sm" variant="outline" disabled={pageSafe <= 1} onClick={() => setPage(pageSafe - 1)}>
                Anterior
              </Button>
              <span className="text-xs text-muted-foreground">
                Página {pageSafe} de {totalPages}
              </span>
              <Button
                size="sm"
                variant="outline"
                disabled={pageSafe >= totalPages}
                onClick={() => setPage(pageSafe + 1)}
              >
                Siguiente
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
