import { usePeriodoVigente } from "@/hooks/use-periodo-vigente";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  adminDeleteSubmissionItem,
  adminParseProviderPhoto,
  adminPreviewLiquidation,
  adminProviderLiquidations,
  adminSubmitLiquidation,
} from "@/lib/crm.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Camera, Download, Loader2, Plus, Trash2, Upload } from "lucide-react";
import * as XLSX from "xlsx";
import { toast } from "sonner";
import { compareLegajo } from "@/lib/legajo";
import { useAffiliateNames } from "@/hooks/use-affiliate-names";


export const Route = createFileRoute("/_authenticated/admin/proveedor/$id/liquidaciones")({
  component: ProveedorLiquidaciones,
  head: () => ({
    meta: [
      { title: "Liquidaciones del proveedor · AGOEC" },
      {
        name: "description",
        content:
          "Ver y cargar las liquidaciones de un proveedor por Excel o foto, con el subsidio por receta aplicado al afiliado.",
      },
      { property: "og:title", content: "Liquidaciones del proveedor · AGOEC" },
      {
        property: "og:description",
        content: "Carga administrativa de liquidaciones por proveedor con subsidios y cuotas.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const money = (n: number) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" }).format(Number(n) || 0);

type Row = {
  uid: string;
  legajo: string;
  fecha: string;
  detalle: string;
  comprobante: string;
  importe: string;
  /** A/C Afiliado: importe ya con el descuento de obra social. Vacío = 100%. */
  ac_afiliado: string;
  cuotas: string;
  con_receta: boolean;
  es_cumpleanos: boolean;
};

const uid = () => Math.random().toString(36).slice(2);
const emptyRow = (): Row => ({
  uid: uid(),
  legajo: "",
  fecha: new Date().toISOString().slice(0, 10),
  detalle: "",
  comprobante: "",
  importe: "",
  ac_afiliado: "",
  cuotas: "1",
  con_receta: false,
  es_cumpleanos: false,
});

const pick = (obj: any, keys: string[]) => {
  const entries = Object.entries(obj).map(([k, v]) => [String(k).toLowerCase().trim(), v] as const);
  for (const key of keys) {
    const hit = entries.find(([k]) => k === key || k.includes(key));
    if (hit && hit[1] != null && String(hit[1]).trim() !== "") return String(hit[1]).trim();
  }
  return "";
};

const toDate = (v: string) => {
  if (!v) return "";
  if (/^\d{4}-\d{2}-\d{2}/.test(v)) return v.slice(0, 10);
  const m = v.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})/);
  if (m) {
    const y = m[3].length === 2 ? `20${m[3]}` : m[3];
    return `${y}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}`;
  }
  const n = Number(v);
  if (Number.isFinite(n) && n > 20000 && n < 60000) {
    return new Date(Math.round((n - 25569) * 86400 * 1000)).toISOString().slice(0, 10);
  }
  return "";
};

const toNumber = (v: string) => {
  if (!v) return 0;
  const s = v.replace(/[^\d,.-]/g, "");
  const norm =
    s.includes(",") && s.lastIndexOf(",") > s.lastIndexOf(".")
      ? s.replace(/\./g, "").replace(",", ".")
      : s.replace(/,/g, "");
  return Number(norm) || 0;
};

const truthy = (v: string) => /^(si|sí|s|yes|y|true|1|x|c\/receta|con receta)$/i.test(v.trim());

// Tipo de compra en el Excel de farmacias: 1 = con receta, 2 = sin receta.
const recetaFromTipo = (v: string) => {
  const s = v.trim().toLowerCase();
  if (!s) return null;
  if (s.startsWith("1") || s.includes("con receta")) return true;
  if (s.startsWith("2") || s.includes("sin receta")) return false;
  return null;
};


function ProveedorLiquidaciones() {
  const { id } = Route.useParams();
  const qc = useQueryClient();
  const load = useServerFn(adminProviderLiquidations);
  const previewFn = useServerFn(adminPreviewLiquidation);
  const submitFn = useServerFn(adminSubmitLiquidation);
  const ocr = useServerFn(adminParseProviderPhoto);
  const deleteItemFn = useServerFn(adminDeleteSubmissionItem);

  const hoy = new Date();
  const [nombre, setNombre] = useState("");
  const [mes, setMes] = useState(String(hoy.getMonth() + 1));
  const [anio, setAnio] = useState(String(hoy.getFullYear()));
  // Período administrativo que se está mirando (por defecto, el vigente).
  const [verPeriodo, setVerPeriodo] = useState(
    `${hoy.getFullYear()}-${String(hoy.getMonth() + 1).padStart(2, "0")}`,
  );
  usePeriodoVigente((p) => {
    setMes(String(p.mes));
    setAnio(String(p.anio));
    setVerPeriodo(`${p.anio}-${String(p.mes).padStart(2, "0")}`);
  });
  const [observacion, setObservacion] = useState("");
  const [rows, setRows] = useState<Row[]>([emptyRow()]);
  const [busy, setBusy] = useState<string | null>(null);
  const [prev, setPrev] = useState<any>(null);
  const excelRef = useRef<HTMLInputElement>(null);
  const photoRef = useRef<HTMLInputElement>(null);

  const verMes = Number(verPeriodo.slice(5, 7));
  const verAnio = Number(verPeriodo.slice(0, 4));

  const { data, isLoading, error } = useQuery({
    queryKey: ["admin-provider-liq", id, verPeriodo],
    queryFn: () =>
      load({ data: { provider_id: id, periodo_mes: verMes, periodo_anio: verAnio } }),
  });


  const prov: any = data?.provider;
  const svc: any = prov?.services;
  const usaReceta = !!svc?.usa_receta;
  const pct = Number(svc?.subsidio_receta_pct ?? 0);
  const usaCumple = !!svc?.permite_cumpleanos;

  const items = useMemo(
    () =>
      rows
        .filter((r) => r.legajo.trim())
        .map((r) => ({
          legajo: r.legajo.trim().toUpperCase(),
          fecha: r.fecha || null,
          detalle: r.detalle || null,
          comprobante: r.comprobante || null,
          importe: toNumber(r.importe),
          base_afiliado: r.ac_afiliado.trim() ? toNumber(r.ac_afiliado) : null,
          cuotas: Math.max(1, Number(r.cuotas) || 1),
          con_receta: r.con_receta,
          es_cumpleanos: r.es_cumpleanos,
        })),
    [rows],
  );

  const nombresPadron = useAffiliateNames(rows.map((r) => r.legajo));

  const totales = useMemo(() => {
    let total = 0;
    let subsidio = 0;
    let afiliado = 0;
    for (const i of items) {
      total += i.importe;
      const base = i.base_afiliado == null ? i.importe : i.base_afiliado;
      const sr = usaReceta && i.con_receta && pct > 0 ? (i.importe * pct) / 100 : 0;
      const exento = usaCumple && i.es_cumpleanos;
      subsidio += exento ? i.importe : sr;
      afiliado += exento ? 0 : Math.max(0, base - sr);
    }
    return { total, subsidio, afiliado, items: items.length };
  }, [items, usaReceta, usaCumple, pct]);

  function setRow(key: string, patch: Partial<Row>) {
    setRows((rs) => rs.map((r) => (r.uid === key ? { ...r, ...patch } : r)));
  }

  function addRows(nuevas: Omit<Row, "uid">[]) {
    setRows((rs) => {
      const kept = rs.filter((r) => r.legajo.trim());
      return [...kept, ...nuevas.map((r) => ({ ...r, uid: uid() }))].sort((a, b) =>
        compareLegajo(a.legajo, b.legajo),
      );
    });
  }

  async function onExcel(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy("excel");
    try {
      const wb = XLSX.read(await file.arrayBuffer(), { type: "array" });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const aoa = XLSX.utils.sheet_to_json<any[]>(sheet, { header: 1, defval: "", raw: false });

      // El modelo de farmacias tiene un encabezado (Proveedor / Fecha / Periodo)
      // antes de la fila de títulos del listado: la buscamos por la columna "Legajo".
      const headIdx = aoa.findIndex((fila) =>
        (fila ?? []).some((c) => /legajo/i.test(String(c ?? ""))),
      );
      const head = headIdx > 0 ? aoa.slice(0, headIdx) : [];
      const cols = (aoa[headIdx] ?? []).map((c) => String(c ?? "").toLowerCase().trim());
      const json = (headIdx < 0 ? [] : aoa.slice(headIdx + 1)).map((fila) => {
        const obj: Record<string, any> = {};
        cols.forEach((c, i) => {
          if (c) obj[c] = fila?.[i] ?? "";
        });
        return obj;
      });

      // Datos del encabezado: nombre del proveedor y período liquidado.
      const flat = head.flat().map((c) => String(c ?? "").trim());
      const labelValue = (re: RegExp) => {
        const i = flat.findIndex((c) => re.test(c));
        return i >= 0 ? (flat[i + 1] ?? "") : "";
      };
      const periodo = toDate(labelValue(/^periodo/i));
      if (periodo) {
        setMes(String(Number(periodo.slice(5, 7))));
        setAnio(periodo.slice(0, 4));
      }
      const provNombre = labelValue(/^proveedor/i);
      if (!nombre.trim()) {
        const per = periodo ? ` ${periodo.slice(0, 7)}` : "";
        setNombre(`${provNombre || prov?.nombre || "Liquidación"}${per}`.trim());
      }

      const parsed = json
        .map((r) => {
          const tipo = recetaFromTipo(pick(r, ["tipo_compra", "tipo compra", "tipo", "codigo"]));
          return {
            legajo: pick(r, ["legajo", "leg"]).toUpperCase(),
            fecha: toDate(pick(r, ["fecha_compra", "fecha compra", "fecha", "dia", "día"])),
            detalle: pick(r, [
              "observacion",
              "observación",
              "detalle",
              "descripcion",
              "descripción",
              "producto",
              "concepto",
            ]),
            comprobante: pick(r, ["ticket", "comprobante", "compr", "factura", "nro"]),
            importe: pick(r, ["100%", "importe 100", "importe", "total", "monto", "precio"]),
            ac_afiliado: pick(r, [
              "a/c_afiliado",
              "a/c afiliado",
              "a cargo afiliado",
              "afiliado",
            ]),
            cuotas: pick(r, ["cuotas", "cuota"]) || "1",
            con_receta: tipo ?? truthy(pick(r, ["receta", "con receta"])),
            es_cumpleanos: truthy(pick(r, ["cumple", "cumpleaños", "cumpleanos"])),
          };
        })
        .filter((r) => r.legajo);
      if (!parsed.length) toast.error("No se detectaron filas con legajo");
      else {
        addRows(parsed);
        toast.success(`${parsed.length} filas importadas`);
      }
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo leer el Excel");
    } finally {
      setBusy(null);
      if (excelRef.current) excelRef.current.value = "";
    }
  }

  function modeloExcel() {
    const per = `${anio}-${String(Number(mes) || 1).padStart(2, "0")}-01`;
    const aoa = [
      ["Proveedor", prov?.cuenta_contable ?? "", prov?.nombre ?? "", "", "", "", "", ""],
      ["Fecha", per, "Periodo", per, "", "", "", ""],
      [],
      [
        "Fecha_Compra",
        "Legajo",
        "Apellido_y_Nombre",
        "Ticket",
        "100%_en_$",
        "A/C_Afiliado",
        "Tipo_Compra",
        "Observacion",
      ],
      [per, "1512", "", "TK000001", 10000, 6000, 1, "CON RECETA"],
      [per, "1513", "", "TK000002", 5000, 5000, 2, "SIN RECETA"],
    ];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(aoa), "Hoja1");
    XLSX.writeFile(wb, `modelo_farmacia_${(prov?.nombre ?? "proveedor").replace(/\W+/g, "-")}.xlsx`);
  }

  async function onPhoto(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy("foto");
    try {
      const base64 = await new Promise<string>((res, rej) => {
        const fr = new FileReader();
        fr.onload = () => res(String(fr.result));
        fr.onerror = rej;
        fr.readAsDataURL(file);
      });
      const out = await ocr({ data: { provider_id: id, base64 } });
      if (!out.items.length) toast.error("La IA no detectó filas en la foto");
      else {
        addRows(
          out.items.map((i: any) => ({
            legajo: i.legajo,
            fecha: i.fecha ?? "",
            detalle: i.detalle ?? "",
            comprobante: i.comprobante ?? "",
            importe: String(i.importe ?? ""),
            ac_afiliado: "",
            cuotas: String(i.cuotas ?? 1),
            con_receta: i.con_receta,
            es_cumpleanos: i.es_cumpleanos,
          })),
        );
        toast.success(`${out.items.length} filas leídas de la foto`);
      }
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo leer la foto");
    } finally {
      setBusy(null);
      if (photoRef.current) photoRef.current.value = "";
    }
  }


  async function validar() {
    if (!items.length) return toast.error("Cargá al menos una fila");
    setBusy("preview");
    try {
      const out = await previewFn({ data: { provider_id: id, items } });
      setPrev(out);
      const malos = out.rows.filter((r: any) => !r.valido).length;
      if (malos) toast.warning(`${malos} legajos no están en el padrón`);
      else toast.success("Todos los legajos existen en el padrón");
    } catch (e: any) {
      toast.error(e?.message ?? "Error al validar");
    } finally {
      setBusy(null);
    }
  }

  async function guardar() {
    if (!items.length) return toast.error("Cargá al menos una fila");
    if (nombre.trim().length < 2) return toast.error("Ponele un nombre a la liquidación");
    setBusy("submit");
    try {
      await submitFn({
        data: {
          provider_id: id,
          nombre: nombre.trim(),
          periodo_mes: Number(mes),
          periodo_anio: Number(anio),
          observacion: observacion || null,
          items,
        },
      });
      toast.success("Liquidación cargada");
      setRows([emptyRow()]);
      setPrev(null);
      setNombre("");
      setObservacion("");
      qc.invalidateQueries({ queryKey: ["admin-provider-liq", id] });
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo guardar");
    } finally {
      setBusy(null);
    }
  }

  const filaExcel = (i: any) => ({
    Periodo: i.periodo ?? "",
    Carga: i.submission_nombre ?? "",
    Estado: i.submission_estado ?? "",
    Fecha: i.fecha ?? "",
    Legajo: i.legajo,
    "Apellido y Nombre": i.apellido_nombre ?? "",
    Detalle: i.detalle ?? "",
    Comprobante: i.comprobante ?? "",
    Receta: i.con_receta ? "Sí" : "No",
    Cuotas: i.cuotas,
    "Importe (se paga al proveedor)": Number(Number(i.importe).toFixed(2)),
    "Subsidio AGOEC": Number(Number(i.subsidio ?? 0).toFixed(2)),
    "A descontar al afiliado": Number(Number(i.importe_afiliado ?? 0).toFixed(2)),
  });

  const slug = (prov?.nombre ?? "proveedor").replace(/\W+/g, "-");

  function exportarHistorico() {
    const list = data?.itemsTodos ?? [];
    if (!list.length) return toast.error("Sin datos para exportar");
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(list.map(filaExcel)), "Consumos");
    XLSX.writeFile(wb, `liquidaciones_${slug}.xlsx`);
  }

  /** Excel del período seleccionado: cargas, detalle, rechazadas aparte y los mismos totales de pantalla. */
  function exportarPeriodo() {
    const per = `${String(verMes).padStart(2, "0")}-${verAnio}`;
    const subs = data?.submissions ?? [];
    const rech = data?.submissionsRechazadas ?? [];
    const its = data?.items ?? [];
    const itsR = data?.itemsRechazados ?? [];
    if (!subs.length && !rech.length) return toast.error("El período no tiene cargas");

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet([
        { Concepto: "Proveedor", Valor: prov?.nombre ?? "" },
        { Concepto: "Período", Valor: `${String(verMes).padStart(2, "0")}/${verAnio}` },
        { Concepto: "Cargas del período", Valor: t.cargas ?? 0 },
        { Concepto: "Pendientes", Valor: t.pendientes ?? 0 },
        { Concepto: "Aprobadas", Valor: t.aprobadas ?? 0 },
        { Concepto: "Rechazadas (no se pagan)", Valor: t.rechazadas ?? 0 },
        { Concepto: "Afiliados", Valor: t.afiliados ?? 0 },
        {
          Concepto: "Total a pagar al proveedor",
          Valor: Number(Number(t.total_importe ?? 0).toFixed(2)),
        },
        { Concepto: "Subsidio AGOEC", Valor: Number(Number(t.total_subsidio ?? 0).toFixed(2)) },
        {
          Concepto: "A descontar a afiliados",
          Valor: Number(Number(t.total_afiliado ?? 0).toFixed(2)),
        },
        {
          Concepto: "Importe rechazado (excluido)",
          Valor: Number(Number(t.total_rechazado ?? 0).toFixed(2)),
        },
      ]),
      "Resumen",
    );
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        subs.map((s: any) => ({
          Periodo: `${String(s.periodo_mes).padStart(2, "0")}/${s.periodo_anio}`,
          Carga: s.nombre,
          Estado: s.estado,
          Items: s.total_items,
          "Se paga al proveedor": Number(Number(s.total_a_pagar ?? 0).toFixed(2)),
          Subsidio: Number(Number(s.total_subsidio ?? 0).toFixed(2)),
        })),
      ),
      "Cargas",
    );
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(its.length ? its.map(filaExcel) : [{ Aviso: "Sin consumos" }]),
      "Detalle",
    );
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        itsR.length ? itsR.map(filaExcel) : [{ Aviso: "Sin cargas rechazadas" }],
      ),
      "Rechazadas",
    );
    XLSX.writeFile(wb, `periodo_${per}_${slug}.xlsx`);
  }

  async function borrarConsumo(item: any) {
    if (
      !window.confirm(
        `¿Borrar el consumo del legajo ${item.legajo} por ${money(item.importe)}? Esta acción no se puede deshacer.`,
      )
    )
      return;
    setBusy(`del-${item.id}`);
    try {
      await deleteItemFn({ data: { item_id: item.id } });
      toast.success("Consumo borrado");
      qc.invalidateQueries({ queryKey: ["admin-provider-liq", id] });
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo borrar el consumo");
    } finally {
      setBusy(null);
    }
  }


  if (isLoading) return <p className="text-sm text-muted-foreground">Cargando…</p>;
  if (error) return <p className="text-sm text-destructive">{(error as any)?.message}</p>;

  const t: any = data?.totales ?? {};

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">{prov?.nombre}</h1>
          <p className="text-sm text-muted-foreground">
            {svc?.nombre} · {prov?.email || "sin email"}
            {usaReceta
              ? ` · Con receta: el afiliado paga ${100 - pct}% (subsidio ${pct}%). Al proveedor se le paga el 100%.`
              : ""}
          </p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            <Badge variant={prov?.habilitado ? "default" : "secondary"}>
              {prov?.habilitado ? "Habilitado" : "Deshabilitado"}
            </Badge>
            <Badge variant="outline">CUIT {prov?.cuit || "—"}</Badge>
            <Badge variant="outline">
              {prov?.banco || "sin banco"} · {prov?.cbu || prov?.alias || "sin CBU"}
            </Badge>
          </div>
        </div>
        <div className="flex flex-wrap items-end gap-2">
          <div className="space-y-1">
            <Label className="text-xs">Período</Label>
            <select
              className="h-9 rounded-md border border-input bg-background px-2 text-sm"
              value={verPeriodo}
              onChange={(e) => setVerPeriodo(e.target.value)}
            >
              {Array.from(
                new Set([
                  `${hoy.getFullYear()}-${String(hoy.getMonth() + 1).padStart(2, "0")}`,
                  verPeriodo,
                  ...(data?.periodos ?? []).map(
                    (p: any) => `${p.anio}-${String(p.mes).padStart(2, "0")}`,
                  ),
                ]),
              )
                .sort()
                .reverse()
                .map((k) => (
                  <option key={k} value={k}>
                    {k.slice(5, 7)}/{k.slice(0, 4)}
                  </option>
                ))}
            </select>
          </div>
          <Button asChild variant="outline" size="sm">
            <Link to="/admin/servicio/$codigo" params={{ codigo: svc?.codigo ?? "" }}>
              Volver al servicio
            </Link>
          </Button>
          <Button size="sm" onClick={exportarPeriodo}>
            <Download className="h-4 w-4 mr-1" /> Excel del período
          </Button>
          <Button variant="secondary" size="sm" onClick={exportarHistorico}>
            <Download className="h-4 w-4 mr-1" /> Excel histórico
          </Button>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
        {[
          { l: `Cargas ${String(verMes).padStart(2, "0")}/${verAnio}`, v: String(t.cargas ?? 0) },
          { l: "Pendientes", v: String(t.pendientes ?? 0) },
          { l: "Aprobadas", v: String(t.aprobadas ?? 0) },
          { l: "Afiliados", v: String(t.afiliados ?? 0) },
          { l: "Total a pagar al proveedor", v: money(t.total_importe ?? 0) },
          { l: "A descontar a afiliados", v: money(t.total_afiliado ?? 0) },
        ].map((x) => (
          <Card key={x.l}>
            <CardContent className="pt-5">
              <p className="text-xs text-muted-foreground">{x.l}</p>
              <p className="text-lg font-semibold">{x.v}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Nueva liquidación</CardTitle>
          <CardDescription>
            {usaReceta
              ? `Formato farmacia: Fecha_Compra, Legajo, Apellido_y_Nombre, Ticket, 100%_en_$, A/C_Afiliado, Tipo_Compra (1 = con receta, 2 = sin receta) y Observación. Al proveedor se le paga el 100%; el afiliado paga el A/C Afiliado menos el ${pct}% de subsidio cuando hay receta.`
              : "Subí un Excel o una foto con fecha, legajo, descripción, importe y comprobante. También podés agregar filas a mano."}

          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-4">
            <div className="space-y-2 sm:col-span-2">
              <Label>Nombre de la liquidación</Label>
              <Input
                placeholder="Ej: Consumos julio 2026"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Mes</Label>
              <Input inputMode="numeric" value={mes} onChange={(e) => setMes(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Año</Label>
              <Input inputMode="numeric" value={anio} onChange={(e) => setAnio(e.target.value)} />
            </div>
            <div className="space-y-2 sm:col-span-4">
              <Label>Observaciones</Label>
              <Textarea
                rows={2}
                value={observacion}
                onChange={(e) => setObservacion(e.target.value)}
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <input
              ref={excelRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              className="hidden"
              onChange={onExcel}
            />
            <input
              ref={photoRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={onPhoto}
            />
            <Button
              variant="outline"
              size="sm"
              onClick={() => excelRef.current?.click()}
              disabled={!!busy}
            >
              {busy === "excel" ? (
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
              ) : (
                <Upload className="h-4 w-4 mr-1" />
              )}
              Importar Excel
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => photoRef.current?.click()}
              disabled={!!busy}
            >
              {busy === "foto" ? (
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
              ) : (
                <Camera className="h-4 w-4 mr-1" />
              )}
              Leer foto con IA
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setRows((r) => [...r, emptyRow()])}
            >
              <Plus className="h-4 w-4 mr-1" /> Agregar fila
            </Button>
            {usaReceta && (
              <Button variant="ghost" size="sm" onClick={modeloExcel}>
                <Download className="h-4 w-4 mr-1" /> Modelo Excel
              </Button>
            )}
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b text-left text-muted-foreground">
                <tr>
                  <th className="py-2 pr-2">Fecha</th>
                  <th className="py-2 pr-2">Legajo</th>
                  <th className="py-2 pr-2">Afiliado</th>
                  <th className="py-2 pr-2">{usaReceta ? "Observación" : "Descripción"}</th>

                  <th className="py-2 pr-2">{usaReceta ? "Ticket" : "Comprobante"}</th>
                  <th className="py-2 pr-2">{usaReceta ? "100% en $" : "Importe"}</th>
                  {usaReceta && <th className="py-2 pr-2">A/C Afiliado</th>}
                  <th className="py-2 pr-2">Cuotas</th>
                  {usaReceta && <th className="py-2 pr-2">Tipo compra</th>}
                  {usaReceta && <th className="py-2 pr-2 text-right">Paga el afiliado</th>}
                  {usaCumple && <th className="py-2 pr-2">Cumple</th>}

                  <th className="py-2" />
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.uid} className="border-b last:border-0">
                    <td className="py-1 pr-2">
                      <Input
                        type="date"
                        className="h-8 w-36"
                        value={r.fecha}
                        onChange={(e) => setRow(r.uid, { fecha: e.target.value })}
                      />
                    </td>
                    <td className="py-1 pr-2">
                      <Input
                        className="h-8 w-24 font-mono"
                        value={r.legajo}
                        onChange={(e) => setRow(r.uid, { legajo: e.target.value.toUpperCase() })}
                      />
                    </td>
                    <td className="py-1 pr-2 min-w-48 text-xs">
                      {!r.legajo.trim() ? (
                        <span className="text-muted-foreground">—</span>
                      ) : nombresPadron[r.legajo.trim().toUpperCase()] === undefined ? (
                        <span className="text-muted-foreground">buscando…</span>
                      ) : nombresPadron[r.legajo.trim().toUpperCase()] ? (
                        <span className="font-medium">
                          {nombresPadron[r.legajo.trim().toUpperCase()]}
                        </span>
                      ) : (
                        <span className="text-destructive">no está en el padrón</span>
                      )}
                    </td>

                    <td className="py-1 pr-2">
                      <Input
                        className="h-8 min-w-48"
                        value={r.detalle}
                        onChange={(e) => setRow(r.uid, { detalle: e.target.value })}
                      />
                    </td>
                    <td className="py-1 pr-2">
                      <Input
                        className="h-8 w-28"
                        value={r.comprobante}
                        onChange={(e) => setRow(r.uid, { comprobante: e.target.value })}
                      />
                    </td>
                    <td className="py-1 pr-2">
                      <Input
                        className="h-8 w-28"
                        inputMode="decimal"
                        value={r.importe}
                        onChange={(e) => setRow(r.uid, { importe: e.target.value })}
                      />
                    </td>
                    {usaReceta && (
                      <td className="py-1 pr-2">
                        <Input
                          className="h-8 w-28"
                          inputMode="decimal"
                          placeholder="= 100%"
                          value={r.ac_afiliado}
                          onChange={(e) => setRow(r.uid, { ac_afiliado: e.target.value })}
                        />
                      </td>
                    )}
                    <td className="py-1 pr-2">
                      <Input
                        className="h-8 w-16"
                        inputMode="numeric"
                        value={r.cuotas}
                        onChange={(e) => setRow(r.uid, { cuotas: e.target.value })}
                      />
                    </td>
                    {usaReceta && (
                      <td className="py-1 pr-2">
                        <select
                          className="h-8 w-36 rounded-md border border-input bg-background px-2 text-sm"
                          value={r.con_receta ? "1" : "2"}
                          onChange={(e) => setRow(r.uid, { con_receta: e.target.value === "1" })}
                        >
                          <option value="1">1 · Con receta</option>
                          <option value="2">2 · Sin receta</option>
                        </select>
                      </td>
                    )}
                    {usaReceta && (
                      <td className="py-1 pr-2 text-right whitespace-nowrap">
                        {(() => {
                          const imp = toNumber(r.importe);
                          const base = r.ac_afiliado.trim() ? toNumber(r.ac_afiliado) : imp;
                          const sub = r.con_receta && pct > 0 ? (imp * pct) / 100 : 0;
                          const exento = usaCumple && r.es_cumpleanos;
                          return (
                            <span className="font-medium">
                              {money(exento ? 0 : Math.max(0, base - sub))}
                            </span>
                          );
                        })()}
                      </td>
                    )}

                    {usaCumple && (
                      <td className="py-1 pr-2">
                        <Checkbox
                          checked={r.es_cumpleanos}
                          onCheckedChange={(v) => setRow(r.uid, { es_cumpleanos: !!v })}
                        />
                      </td>
                    )}
                    <td className="py-1 text-right">
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => setRows((rs) => rs.filter((x) => x.uid !== r.uid))}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="grid gap-3 sm:grid-cols-4">
            {[
              { l: "Ítems", v: String(totales.items) },
              { l: "Total a pagar al proveedor", v: money(totales.total) },
              { l: "Subsidio AGOEC", v: money(totales.subsidio) },
              { l: "A descontar a afiliados", v: money(totales.afiliado) },
            ].map((x) => (
              <div key={x.l} className="rounded-md bg-muted/50 px-3 py-2">
                <p className="text-[11px] text-muted-foreground">{x.l}</p>
                <p className="font-medium">{x.v}</p>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={validar} disabled={!!busy}>
              {busy === "preview" ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : null}
              Validar legajos
            </Button>
            <Button onClick={guardar} disabled={!!busy}>
              {busy === "submit" ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : null}
              Guardar liquidación
            </Button>
          </div>

          {prev && (
            <div className="overflow-x-auto rounded border">
              <table className="w-full text-sm">
                <thead className="border-b bg-muted text-left">
                  <tr>
                    <th className="p-2">Legajo</th>
                    <th className="p-2">Afiliado</th>
                    <th className="p-2 text-right">Importe</th>
                    <th className="p-2 text-right">Subsidio</th>
                    <th className="p-2 text-right">Paga el afiliado</th>
                  </tr>
                </thead>
                <tbody>
                  {prev.rows.map((r: any, i: number) => (
                    <tr key={i} className="border-b last:border-0">
                      <td className="p-2 font-mono">{r.legajo}</td>
                      <td className={`p-2 ${r.valido ? "" : "text-destructive"}`}>
                        {r.apellido_nombre ?? "no está en el padrón"}
                      </td>
                      <td className="p-2 text-right">{money(r.importe)}</td>
                      <td className="p-2 text-right">{money(r.subsidio)}</td>
                      <td className="p-2 text-right">{money(r.importe_afiliado)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            Liquidaciones del período {String(verMes).padStart(2, "0")}/{verAnio}
          </CardTitle>
          <CardDescription>
            Sólo las cargas válidas del período elegido. Las rechazadas se muestran aparte y no se
            pagan ni se descuentan.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!(data?.submissions ?? []).length ? (
            <p className="text-sm text-muted-foreground">
              El período seleccionado no tiene cargas.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b text-left text-muted-foreground">
                  <tr>
                    <th className="py-2 pr-2">Período</th>
                    <th className="py-2 pr-2">Nombre</th>
                    <th className="py-2 pr-2">Estado</th>
                    <th className="py-2 pr-2 text-center">Ítems</th>
                    <th className="py-2 pr-2 text-right">Se paga al proveedor</th>
                    <th className="py-2 pr-2 text-right">Subsidio</th>
                  </tr>
                </thead>
                <tbody>
                  {(data?.submissions ?? []).map((s: any) => (
                    <tr key={s.id} className="border-b last:border-0">
                      <td className="py-2 pr-2 font-mono">
                        {String(s.periodo_mes).padStart(2, "0")}/{s.periodo_anio}
                      </td>
                      <td className="py-2 pr-2">{s.nombre}</td>
                      <td className="py-2 pr-2">
                        <Badge
                          variant={
                            s.estado === "aprobada" || s.estado === "pagada" ? "default" : "outline"
                          }
                        >
                          {s.estado}
                        </Badge>
                      </td>
                      <td className="py-2 pr-2 text-center">{s.total_items}</td>
                      <td className="py-2 pr-2 text-right">{money(s.total_a_pagar)}</td>
                      <td className="py-2 pr-2 text-right">{money(s.total_subsidio)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            Consumos del período {String(verMes).padStart(2, "0")}/{verAnio}
          </CardTitle>
          <CardDescription>
            Podés borrar un consumo cargado por error mientras no esté pagado ni liquidado.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!(data?.items ?? []).length ? (
            <p className="text-sm text-muted-foreground">Sin consumos en este período.</p>
          ) : (
            <div className="max-h-[480px] overflow-auto">
              <table className="w-full text-sm">
                <thead className="sticky top-0 border-b bg-card text-left text-muted-foreground">
                  <tr>
                    <th className="py-2 pr-2">Fecha</th>
                    <th className="py-2 pr-2">Legajo</th>
                    <th className="py-2 pr-2">Afiliado</th>
                    <th className="py-2 pr-2">Detalle</th>
                    <th className="py-2 pr-2">Carga</th>
                    <th className="py-2 pr-2 text-center">Receta</th>
                    <th className="py-2 pr-2 text-right">Importe</th>
                    <th className="py-2 pr-2 text-right">Paga el afiliado</th>
                    <th className="py-2" />
                  </tr>
                </thead>
                <tbody>
                  {(data?.items ?? []).map((i: any) => (
                    <tr key={i.id} className="border-b last:border-0">
                      <td className="py-2 pr-2 font-mono">{i.fecha ?? "—"}</td>
                      <td className="py-2 pr-2 font-mono">{i.legajo}</td>
                      <td className="py-2 pr-2">{i.apellido_nombre ?? "—"}</td>
                      <td className="py-2 pr-2">{i.detalle ?? "—"}</td>
                      <td className="py-2 pr-2 text-xs text-muted-foreground">
                        {i.submission_nombre ?? "—"} · {i.submission_estado ?? "—"}
                      </td>
                      <td className="py-2 pr-2 text-center">{i.con_receta ? "Sí" : "No"}</td>
                      <td className="py-2 pr-2 text-right">{money(i.importe)}</td>
                      <td className="py-2 pr-2 text-right">{money(i.importe_afiliado)}</td>
                      <td className="py-2 text-right">
                        <Button
                          size="icon"
                          variant="ghost"
                          disabled={busy === `del-${i.id}`}
                          onClick={() => borrarConsumo(i)}
                          title="Borrar consumo cargado por error"
                        >
                          {busy === `del-${i.id}` ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Trash2 className="h-4 w-4 text-destructive" />
                          )}
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {!!(data?.submissionsRechazadas ?? []).length && (
        <Card className="border-destructive/40">
          <CardHeader>
            <CardTitle className="text-base">
              Cargas rechazadas del período {String(verMes).padStart(2, "0")}/{verAnio}
            </CardTitle>
            <CardDescription>
              Excluidas del total a pagar y de los descuentos a afiliados. Importe rechazado:{" "}
              {money(t.total_rechazado ?? 0)}.
            </CardDescription>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b text-left text-muted-foreground">
                <tr>
                  <th className="py-2 pr-2">Nombre</th>
                  <th className="py-2 pr-2 text-center">Ítems</th>
                  <th className="py-2 pr-2 text-right">Importe rechazado</th>
                  <th className="py-2 pr-2">Observación</th>
                </tr>
              </thead>
              <tbody>
                {(data?.submissionsRechazadas ?? []).map((s: any) => (
                  <tr key={s.id} className="border-b last:border-0">
                    <td className="py-2 pr-2">{s.nombre}</td>
                    <td className="py-2 pr-2 text-center">{s.total_items}</td>
                    <td className="py-2 pr-2 text-right">{money(s.total_importe)}</td>
                    <td className="py-2 pr-2 text-xs text-muted-foreground">
                      {s.observacion ?? "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Histórico de liquidaciones</CardTitle>
          <CardDescription>
            Todos los períodos del proveedor. Elegí un período arriba para ver su detalle.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!(data?.submissionsTodas ?? []).length ? (
            <p className="text-sm text-muted-foreground">Todavía no hay liquidaciones.</p>
          ) : (
            <div className="max-h-80 overflow-auto">
              <table className="w-full text-sm">
                <thead className="sticky top-0 border-b bg-card text-left text-muted-foreground">
                  <tr>
                    <th className="py-2 pr-2">Período</th>
                    <th className="py-2 pr-2">Nombre</th>
                    <th className="py-2 pr-2">Estado</th>
                    <th className="py-2 pr-2 text-center">Ítems</th>
                    <th className="py-2 pr-2 text-right">Se paga al proveedor</th>
                  </tr>
                </thead>
                <tbody>
                  {(data?.submissionsTodas ?? []).map((s: any) => (
                    <tr key={s.id} className="border-b last:border-0">
                      <td className="py-2 pr-2 font-mono">
                        {String(s.periodo_mes).padStart(2, "0")}/{s.periodo_anio}
                      </td>
                      <td className="py-2 pr-2">{s.nombre}</td>
                      <td className="py-2 pr-2">
                        <Badge variant="outline">{s.estado}</Badge>
                      </td>
                      <td className="py-2 pr-2 text-center">{s.total_items}</td>
                      <td className="py-2 pr-2 text-right">{money(s.total_a_pagar)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

    </div>
  );
}
