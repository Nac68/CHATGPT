import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import * as XLSX from "xlsx";
import { toast } from "sonner";
import {
  listCircles,
  saveCircle,
  deleteCircle,
  circlesSettlement,
} from "@/lib/circles.functions";
import { ocrCirclePhoto } from "@/lib/ocr.functions";
import { useAffiliateNames } from "@/hooks/use-affiliate-names";
import { compareLegajo } from "@/lib/legajo";
import { parsePeriodo, periodoNumero } from "@/lib/periodo";
import { ImportPreview, type ImportPreviewData } from "@/components/ImportPreview";
import { IntegrantesDialog } from "@/components/IntegrantesDialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Plus,
  Trash2,
  Upload,
  Camera,
  Download,
  CircleDollarSign,
  Search,
  FileSpreadsheet,
  Pencil,
} from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/circulo")({
  validateSearch: (s: Record<string, unknown>): { product_id?: string; service_id?: string } => ({
    product_id: typeof s.product_id === "string" ? s.product_id : undefined,
    service_id: typeof s.service_id === "string" ? s.service_id : undefined,
  }),
  component: CirculoAdmin,
  head: () => ({
    meta: [
      { title: "Círculos · AGOEC" },
      {
        name: "description",
        content:
          "Gestioná los círculos de AGOEC: número, descripción, períodos, importe total e integrantes con su cuota mensual y el mes en que cobran el pozo.",
      },
      { property: "og:title", content: "Círculos · AGOEC" },
      {
        property: "og:description",
        content: "Alta manual, por Excel o por foto de los círculos, con liquidación mensual.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

type Row = {
  uid: string;
  legajo: string;
  importe: string;
  fecha_cobro: string;
  observacion: string;
};

const uid = () => Math.random().toString(36).slice(2);
const emptyRow = (): Row => ({
  uid: uid(),
  legajo: "",
  importe: "",
  fecha_cobro: "",
  observacion: "",
});

const MESES = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre",
];

const money = (n: number) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" }).format(Number(n) || 0);

const toNumber = (v: string | number) => {
  const s = String(v ?? "").replace(/[^\d,.-]/g, "");
  const norm =
    s.includes(",") && s.lastIndexOf(",") > s.lastIndexOf(".")
      ? s.replace(/\./g, "").replace(",", ".")
      : s.replace(/,/g, "");
  return Number(norm) || 0;
};

const norm = (v: unknown) =>
  String(v ?? "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();

/** Convierte celdas de Excel (fecha serial, texto o Date) a YYYY-MM-DD. */
function toISODate(v: unknown): string {
  if (v == null || v === "") return "";
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  if (typeof v === "number") {
    const d = XLSX.SSF?.parse_date_code?.(v);
    if (d) return `${d.y}-${String(d.m).padStart(2, "0")}-${String(d.d).padStart(2, "0")}`;
    return "";
  }
  const s = String(v).trim();
  let m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  m = /^(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})/.exec(s);
  if (m) {
    const y = m[3].length === 2 ? `20${m[3]}` : m[3];
    return `${y}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}`;
  }
  return "";
}

const periodoOk = (v: string) => !!parsePeriodo(v);
const periodoNorm = (v: string) => {
  const p = parsePeriodo(v);
  return p ? String(periodoNumero(p.mes, p.anio)) : "";
};
const fmtPeriodo = (p: number | null | undefined) => {
  if (!p) return "—";
  const s = String(p);
  return `${s.slice(4, 6)}/${s.slice(0, 4)}`;
};

function CirculoAdmin() {
  const { product_id, service_id } = Route.useSearch();
  const qc = useQueryClient();
  const load = useServerFn(listCircles);
  const save = useServerFn(saveCircle);
  const del = useServerFn(deleteCircle);
  const ocr = useServerFn(ocrCirclePhoto);
  const liquidar = useServerFn(circlesSettlement);

  const hoy = new Date();
  const [editId, setEditId] = useState<string | undefined>();
  const [numero, setNumero] = useState("");
  const [nombre, setNombre] = useState("");
  const [periodoInicio, setPeriodoInicio] = useState("");
  const [periodoFin, setPeriodoFin] = useState("");
  const [importe, setImporte] = useState("");
  const [observacion, setObservacion] = useState("");
  const [rows, setRows] = useState<Row[]>([emptyRow()]);
  const [busy, setBusy] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [mes, setMes] = useState(hoy.getMonth() + 1);
  const [anio, setAnio] = useState(hoy.getFullYear());
  const [preview, setPreview] = useState<(ImportPreviewData & { _rows?: Omit<Row, "uid">[] }) | null>(null);
  const excelRef = useRef<HTMLInputElement>(null);
  const photoRef = useRef<HTMLInputElement>(null);

  const { data, isLoading, error } = useQuery({
    queryKey: ["circles", product_id ?? "all"],
    queryFn: () => load({ data: product_id ? { product_id } : {} }),
  });

  const settlement = useQuery({
    queryKey: ["circles-settlement", product_id ?? "all", mes, anio],
    queryFn: () => liquidar({ data: { mes, anio, ...(product_id ? { product_id } : {}) } }),
  });

  const nombres = useAffiliateNames(rows.map((r) => r.legajo));

  const members = useMemo(
    () =>
      rows
        .filter((r) => r.legajo.trim())
        .map((r) => ({
          legajo: r.legajo.trim().toUpperCase(),
          importe_mensual: toNumber(r.importe),
          fecha_cobro: r.fecha_cobro || null,
          observacion: r.observacion || null,
        })),
    [rows],
  );

  const totalCargado = members.reduce((a, m) => a + m.importe_mensual, 0);
  const integrantesUnicos = new Set(members.map((m) => m.legajo)).size;

  const circulos = useMemo(() => {
    const list = data?.circles ?? [];
    const t = norm(q);
    if (!t) return list;
    return list.filter(
      (c: any) =>
        norm(c.numero).includes(t) ||
        norm(c.nombre).includes(t) ||
        (c.members ?? []).some(
          (m: any) => norm(m.legajo).includes(t) || norm(m.apellido_nombre).includes(t),
        ),
    );
  }, [data, q]);

  function setRow(key: string, patch: Partial<Row>) {
    setRows((rs) => rs.map((r) => (r.uid === key ? { ...r, ...patch } : r)));
  }

  function addRows(nuevas: Omit<Row, "uid">[]) {
    setRows((rs) => {
      const kept = rs.filter((r) => r.legajo.trim());
      return [...kept, ...nuevas.map((r) => ({ ...r, uid: uid() }))].sort((a, b) =>
        compareLegajo(a.legajo, b.legajo),
      );
    });
  }

  function resetForm() {
    setEditId(undefined);
    setNumero("");
    setNombre("");
    setPeriodoInicio("");
    setPeriodoFin("");
    setImporte("");
    setObservacion("");
    setRows([emptyRow()]);
  }

  /** Lee el modelo oficial: encabezado en las primeras filas + grilla de integrantes. */
  async function onExcel(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy("excel");
    try {
      const wb = XLSX.read(await file.arrayBuffer(), { type: "array", cellDates: true });
      const grid = XLSX.utils.sheet_to_json<any[]>(wb.Sheets[wb.SheetNames[0]], {
        header: 1,
        defval: "",
        raw: false,
      });

      let head = -1;
      for (let i = 0; i < Math.min(grid.length, 40); i++) {
        const cells = (grid[i] ?? []).map(norm);
        if (cells.some((c) => c === "legajo") && cells.some((c) => c.startsWith("importe"))) {
          head = i;
          break;
        }
      }

      // Encabezado del círculo (pares etiqueta/valor arriba de la grilla)
      const meta: Record<string, string> = {};
      for (let i = 0; i < (head < 0 ? Math.min(grid.length, 10) : head); i++) {
        const cells = grid[i] ?? [];
        for (let c = 0; c < cells.length - 1; c++) {
          const k = norm(cells[c]);
          if (k) meta[k] = String(cells[c + 1] ?? "").trim();
        }
      }
      const nro = meta["circulo_numero"] ?? meta["circulo numero"] ?? meta["numero"] ?? "";
      const desc = meta["descripcion"] ?? "";
      const pIni = (meta["periodo_inicio"] ?? meta["periodo inicio"] ?? "").replace(/\D/g, "");
      const pFin = (meta["periodo_fin"] ?? meta["periodo fin"] ?? "").replace(/\D/g, "");
      const total = meta["total general"] ?? meta["total_general"] ?? meta["total"] ?? "";

      if (nro) setNumero(nro);
      if (desc || nro) setNombre(desc || `Círculo ${nro}`);
      if (periodoOk(pIni)) setPeriodoInicio(periodoNorm(pIni));
      if (periodoOk(pFin)) setPeriodoFin(periodoNorm(pFin));
      if (total) setImporte(String(toNumber(total)));

      if (head < 0) throw new Error("No encontré la fila de títulos (Legajo / Importe)");

      const cols = (grid[head] ?? []).map(norm);
      const iLeg = cols.findIndex((c) => c.includes("legajo"));
      const iImp = cols.findIndex((c) => c.startsWith("importe") || c.includes("cuota"));
      const iFec = cols.findIndex((c) => c.includes("fecha"));
      const iObs = cols.findIndex((c) => c.includes("observ"));

      const parsed: Omit<Row, "uid">[] = [];
      for (let i = head + 1; i < grid.length; i++) {
        const r = grid[i] ?? [];
        const legajo = String(r[iLeg] ?? "").trim().toUpperCase();
        if (!legajo) continue;
        parsed.push({
          legajo,
          importe: iImp >= 0 ? String(toNumber(r[iImp])) : "",
          fecha_cobro: iFec >= 0 ? toISODate(r[iFec]) : "",
          observacion: iObs >= 0 ? String(r[iObs] ?? "").trim() : "",
        });
      }

      if (!parsed.length) toast.error("No se detectaron filas con legajo");
      else {
        setPreview({
          archivo: file.name,
          descripcion: desc || nro ? `${desc || `Círculo ${nro}`}` : "",
          filas: parsed.map((r) => ({
            legajo: r.legajo,
            detalle: r.observacion,
            importe: Number(r.importe) || 0,
            cuotas: 1,
          })),
          _rows: parsed,
        } as any);
        if (!periodoOk(pIni))
          toast.warning("No se pudo leer el período inicial: completalo antes de confirmar");
      }
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo leer el Excel");
    } finally {
      setBusy(null);
      if (excelRef.current) excelRef.current.value = "";
    }
  }

  async function onPhoto(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy("foto");
    try {
      const base64 = await new Promise<string>((res, rej) => {
        const fr = new FileReader();
        fr.onload = () => res(String(fr.result));
        fr.onerror = rej;
        fr.readAsDataURL(file);
      });
      const out = await ocr({ data: { base64 } });
      if (!out.integrantes?.length) toast.error("La IA no detectó integrantes en la foto");
      else {
        addRows(
          out.integrantes.map((i: any) => {
            const m = Number(i.mes_cobro) || 0;
            const a = Number(i.anio_cobro) || anio;
            return {
              legajo: String(i.legajo ?? "").toUpperCase(),
              importe: String(i.importe_mensual ?? ""),
              fecha_cobro: m ? `${a}-${String(m).padStart(2, "0")}-01` : "",
              observacion: i.observacion ?? "",
            };
          }),
        );
        toast.success(`${out.integrantes.length} integrantes leídos de la foto`);
      }
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo leer la foto");
    } finally {
      setBusy(null);
      if (photoRef.current) photoRef.current.value = "";
    }
  }

  function descargarPlantilla() {
    const aoa: any[][] = [
      ["Circulo_Numero", "", "Descripcion", ""],
      ["Periodo_Inicio", "", "Periodo_Fin", ""],
      ["Total General", "", "", ""],
      ["", "", "", ""],
      ["Legajo", "Nombre_y_Apellido", "Importe", "Fecha_Cobro", "Observaciones"],
      ["", "", "", "", ""],
    ];
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [{ wch: 16 }, { wch: 34 }, { wch: 14 }, { wch: 16 }, { wch: 28 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Hoja1");
    XLSX.writeFile(wb, "MODELO_CIRCULO.xlsx");
  }

  function exportarCirculo(c: any) {
    const ms = c.members ?? [];
    const aoa: any[][] = [
      ["Circulo_Numero", c.numero ?? "", "Descripcion", c.nombre ?? ""],
      ["Periodo_Inicio", c.periodo_inicio ?? "", "Periodo_Fin", c.periodo_fin ?? ""],
      ["Total General", Number(c.importe ?? 0), "", ""],
      ["", "", "", ""],
      ["Legajo", "Nombre_y_Apellido", "Importe", "Fecha_Cobro", "Observaciones"],
      ...ms.map((m: any) => [
        m.legajo,
        m.apellido_nombre ?? "",
        Number(m.importe_mensual ?? 0),
        m.fecha_cobro ?? "",
        m.observacion ?? "",
      ]),
      ["", "", "", "", ""],
      [
        "",
        "",
        Math.round(ms.reduce((a: number, m: any) => a + (Number(m.importe_mensual) || 0), 0) * 100) /
          100,
        "",
        "",
      ],
    ];
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [{ wch: 16 }, { wch: 34 }, { wch: 14 }, { wch: 16 }, { wch: 28 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Hoja1");
    XLSX.writeFile(wb, `CIRCULO_${c.numero ?? c.nombre}.xlsx`);
  }

  function exportarLiquidacion() {
    const s = settlement.data;
    if (!s) return;
    const wb = XLSX.utils.book_new();
    const desc = XLSX.utils.json_to_sheet(
      s.rows.map((r: any) => ({
        Legajo: r.legajo,
        Nombre_y_Apellido: r.apellido_nombre ?? "",
        Circulos: r.circulos.map((c: any) => c.numero ?? c.nombre).join(" / "),
        Importe: r.importe,
      })),
    );
    XLSX.utils.book_append_sheet(wb, desc, "Descuentos");
    const pagos = XLSX.utils.json_to_sheet(
      s.cobradores.map((r: any) => ({
        Circulo: r.numero ?? "",
        Descripcion: r.circulo,
        Legajo: r.legajo,
        Nombre_y_Apellido: r.apellido_nombre ?? "",
        Importe_a_pagar: r.importe,
      })),
    );
    XLSX.utils.book_append_sheet(wb, pagos, "Cobran");
    XLSX.writeFile(wb, `LIQUIDACION_CIRCULOS_${anio}${String(mes).padStart(2, "0")}.xlsx`);
  }

  async function guardar(e: React.FormEvent) {
    e.preventDefault();
    if (nombre.trim().length < 2) return toast.error("Ponele una descripción al círculo");
    if (!members.length) return toast.error("Cargá al menos un integrante");
    if (!periodoOk(periodoInicio))
      return toast.error("Indicá el período inicial (mes y año) del círculo, ej. 202601");
    setBusy("save");
    try {
      await save({
        data: {
          ...(editId ? { id: editId } : {}),
          product_id: product_id ?? null,
          service_id: service_id ?? null,
          numero: numero.trim() || null,
          nombre: nombre.trim(),
          periodo_inicio: Number(periodoNorm(periodoInicio)),
          periodo_fin: periodoOk(periodoFin) ? Number(periodoNorm(periodoFin)) : null,
          importe: toNumber(importe) || totalCargado,
          observacion: observacion || null,
          members,
        } as any,
      });
      toast.success(editId ? "Círculo actualizado" : "Círculo creado");
      resetForm();
      qc.invalidateQueries({ queryKey: ["circles", product_id ?? "all"] });
      qc.invalidateQueries({ queryKey: ["circles-settlement"] });
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo guardar");
    } finally {
      setBusy(null);
    }
  }

  function editar(c: any) {
    setEditId(c.id);
    setNumero(c.numero ?? "");
    setNombre(c.nombre ?? "");
    setPeriodoInicio(c.periodo_inicio ? String(c.periodo_inicio) : "");
    setPeriodoFin(c.periodo_fin ? String(c.periodo_fin) : "");
    setImporte(String(c.importe ?? ""));
    setObservacion(c.observacion ?? "");
    setRows(
      (c.members ?? []).length
        ? c.members.map((m: any) => ({
            uid: uid(),
            legajo: m.legajo,
            importe: String(m.importe_mensual ?? ""),
            fecha_cobro: m.fecha_cobro ?? "",
            observacion: m.observacion ?? "",
          }))
        : [emptyRow()],
    );
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function borrar(id: string) {
    try {
      await del({ data: { id } });
      toast.success("Círculo eliminado");
      qc.invalidateQueries({ queryKey: ["circles", product_id ?? "all"] });
      qc.invalidateQueries({ queryKey: ["circles-settlement"] });
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo eliminar");
    }
  }

  const pIni = parsePeriodo(periodoInicio);

  return (
    <div className="space-y-6">
      {preview && (
        <ImportPreview
          data={preview}
          mes={pIni?.mes ?? 0}
          anio={pIni?.anio ?? 0}
          onMes={(m) =>
            setPeriodoInicio(String(periodoNumero(m, pIni?.anio || new Date().getFullYear())))
          }
          onAnio={(a) =>
            setPeriodoInicio(String(periodoNumero(pIni?.mes || new Date().getMonth() + 1, a)))
          }
          onConfirm={() => {
            addRows(preview._rows ?? []);
            toast.success(`${(preview._rows ?? []).length} cuotas importadas`);
            setPreview(null);
          }}
          onCancel={() => setPreview(null)}
        />
      )}
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-bold">
            <CircleDollarSign className="h-6 w-6 text-primary" /> Círculos
          </h1>
          <p className="text-sm text-muted-foreground">
            Servicios Varios · cada círculo tiene su número, períodos, importe total e integrantes.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={descargarPlantilla}>
            <FileSpreadsheet className="mr-2 h-4 w-4" /> Modelo Excel
          </Button>
          <Button variant="outline" size="sm" asChild>
            <Link to="/admin/servicios">Volver a servicios</Link>
          </Button>
        </div>
      </header>

      <Card>
        <CardHeader>
          <CardTitle>{editId ? "Editar círculo" : "Nuevo círculo"}</CardTitle>
          <CardDescription>
            Cargalo a mano, importá el Excel del círculo o saná una foto de la planilla.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={guardar} className="space-y-5">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <div className="space-y-1.5">
                <Label>N° de círculo</Label>
                <Input value={numero} onChange={(e) => setNumero(e.target.value)} placeholder="169" />
              </div>
              <div className="space-y-1.5 lg:col-span-2">
                <Label>Descripción</Label>
                <Input
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                  placeholder="169 CIRCULO COLEGIALES - entregó el delegado…"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Período inicio (AAAAMM)</Label>
                <Input
                  value={periodoInicio}
                  onChange={(e) => setPeriodoInicio(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  placeholder="201802"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Período fin (AAAAMM)</Label>
                <Input
                  value={periodoFin}
                  onChange={(e) => setPeriodoFin(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  placeholder="201811"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Total general</Label>
                <Input
                  value={importe}
                  onChange={(e) => setImporte(e.target.value)}
                  placeholder="180000"
                />
              </div>
              <div className="space-y-1.5 lg:col-span-3">
                <Label>Observaciones</Label>
                <Input value={observacion} onChange={(e) => setObservacion(e.target.value)} />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                disabled={busy === "excel"}
                onClick={() => excelRef.current?.click()}
              >
                <Upload className="mr-2 h-4 w-4" />
                {busy === "excel" ? "Leyendo…" : "Importar Excel"}
              </Button>
              <input
                ref={excelRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={onExcel}
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                disabled={busy === "foto"}
                onClick={() => photoRef.current?.click()}
              >
                <Camera className="mr-2 h-4 w-4" />
                {busy === "foto" ? "Analizando…" : "Cargar por foto"}
              </Button>
              <input
                ref={photoRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={onPhoto}
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setRows((rs) => [...rs, emptyRow()])}
              >
                <Plus className="mr-2 h-4 w-4" /> Agregar fila
              </Button>
              <div className="ml-auto flex gap-2 text-sm">
                <Badge variant="secondary">{integrantesUnicos} integrantes</Badge>
                <Badge variant="secondary">{members.length} cuotas</Badge>
                <Badge>{money(totalCargado)} cargado</Badge>
              </div>
            </div>

            <div className="overflow-x-auto rounded-md border">
              <table className="w-full text-sm">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="p-2 text-left">Legajo</th>
                    <th className="p-2 text-left">Nombre y Apellido</th>
                    <th className="p-2 text-left">Importe</th>
                    <th className="p-2 text-left">Fecha de cobro</th>
                    <th className="p-2 text-left">Observación</th>
                    <th className="p-2" />
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => {
                    const nom = nombres[r.legajo.trim().toUpperCase()];
                    return (
                      <tr key={r.uid} className="border-t">
                        <td className="p-1.5">
                          <Input
                            className="h-9 w-28"
                            value={r.legajo}
                            onChange={(e) => setRow(r.uid, { legajo: e.target.value.toUpperCase() })}
                          />
                        </td>
                        <td className="p-1.5">
                          <span
                            className={
                              nom ? "text-foreground" : "text-destructive/80 text-xs"
                            }
                          >
                            {r.legajo.trim() ? (nom ?? "Legajo no encontrado") : "—"}
                          </span>
                        </td>
                        <td className="p-1.5">
                          <Input
                            className="h-9 w-28"
                            value={r.importe}
                            onChange={(e) => setRow(r.uid, { importe: e.target.value })}
                          />
                        </td>
                        <td className="p-1.5">
                          <Input
                            type="date"
                            className="h-9 w-40"
                            value={r.fecha_cobro}
                            onChange={(e) => setRow(r.uid, { fecha_cobro: e.target.value })}
                          />
                        </td>
                        <td className="p-1.5">
                          <Input
                            className="h-9"
                            value={r.observacion}
                            onChange={(e) => setRow(r.uid, { observacion: e.target.value })}
                          />
                        </td>
                        <td className="p-1.5 text-right">
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() =>
                              setRows((rs) =>
                                rs.length > 1 ? rs.filter((x) => x.uid !== r.uid) : [emptyRow()],
                              )
                            }
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="flex gap-2">
              <Button type="submit" disabled={busy === "save"}>
                {busy === "save" ? "Guardando…" : editId ? "Guardar cambios" : "Crear círculo"}
              </Button>
              {editId && (
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancelar
                </Button>
              )}
            </div>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row flex-wrap items-end justify-between gap-3">
          <div>
            <CardTitle>Liquidación mensual</CardTitle>
            <CardDescription>
              Descuento por afiliado de todos los círculos vigentes y pozo a pagar a quien cobra.
            </CardDescription>
          </div>
          <div className="flex items-end gap-2">
            <div className="space-y-1.5">
              <Label>Mes</Label>
              <select
                className="h-9 rounded-md border bg-background px-2 text-sm"
                value={mes}
                onChange={(e) => setMes(Number(e.target.value))}
              >
                {MESES.map((m, i) => (
                  <option key={m} value={i + 1}>
                    {m}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-1.5">
              <Label>Año</Label>
              <Input
                className="h-9 w-24"
                value={anio}
                onChange={(e) => setAnio(Number(e.target.value.replace(/\D/g, "")) || anio)}
              />
            </div>
            <Button variant="outline" size="sm" onClick={exportarLiquidacion}>
              <Download className="mr-2 h-4 w-4" /> Excel
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {settlement.isLoading ? (
            <p className="text-sm text-muted-foreground">Calculando…</p>
          ) : settlement.data ? (
            <>
              <div className="grid gap-3 sm:grid-cols-4">
                <Kpi label="Círculos vigentes" value={String(settlement.data.circulos)} />
                <Kpi label="Aportantes" value={String(settlement.data.aportantes)} />
                <Kpi label="Total a descontar" value={money(settlement.data.total)} />
                <Kpi label="Total a pagar" value={money(settlement.data.total_a_pagar)} />
              </div>

              {settlement.data.cobradores.length > 0 && (
                <div className="rounded-md border p-3">
                  <p className="mb-2 text-sm font-medium">Cobran este mes</p>
                  <ul className="space-y-1 text-sm">
                    {settlement.data.cobradores.map((c: any, i: number) => (
                      <li key={i} className="flex justify-between gap-2">
                        <span>
                          {c.legajo} · {c.apellido_nombre ?? "—"}{" "}
                          <span className="text-muted-foreground">
                            (Círculo {c.numero ?? c.circulo})
                          </span>
                        </span>
                        <span className="font-medium">{money(c.importe)}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="max-h-80 overflow-auto rounded-md border">
                <table className="w-full text-sm">
                  <thead className="sticky top-0 bg-muted/50">
                    <tr>
                      <th className="p-2 text-left">Legajo</th>
                      <th className="p-2 text-left">Afiliado</th>
                      <th className="p-2 text-left">Círculos</th>
                      <th className="p-2 text-right">Descuento</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[...settlement.data.rows]
                      .sort((a: any, b: any) => compareLegajo(a.legajo, b.legajo))
                      .map((r: any) => (
                        <tr key={r.legajo} className="border-t">
                          <td className="p-2 font-mono">{r.legajo}</td>
                          <td className="p-2">{r.apellido_nombre ?? "—"}</td>
                          <td className="p-2 text-muted-foreground">
                            {r.circulos.map((c: any) => c.numero ?? c.nombre).join(" / ")}
                          </td>
                          <td className="p-2 text-right font-medium">{money(r.importe)}</td>
                        </tr>
                      ))}
                    {!settlement.data.rows.length && (
                      <tr>
                        <td colSpan={4} className="p-4 text-center text-muted-foreground">
                          No hay círculos vigentes en este período.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </>
          ) : null}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row flex-wrap items-end justify-between gap-3">
          <div>
            <CardTitle>Círculos cargados</CardTitle>
            <CardDescription>{data?.circles?.length ?? 0} en total</CardDescription>
          </div>
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              className="w-64 pl-8"
              placeholder="Buscar por número, nombre o legajo"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {isLoading && <p className="text-sm text-muted-foreground">Cargando…</p>}
          {error && <p className="text-sm text-destructive">{(error as Error).message}</p>}
          {circulos.map((c: any) => (
            <div key={c.id} className="rounded-md border p-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-medium">
                    {c.numero ? <Badge className="mr-2">N° {c.numero}</Badge> : null}
                    {c.nombre}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {fmtPeriodo(c.periodo_inicio)} → {fmtPeriodo(c.periodo_fin)} ·{" "}
                    {c.integrantes} integrantes · {c.cuotas} cuotas · Total{" "}
                    {money(Number(c.importe ?? 0))}
                  </p>
                </div>
                <div className="flex gap-1">
                  <IntegrantesDialog
                    titulo={`Integrantes · ${c.numero ? `N° ${c.numero} ` : ""}${c.nombre}`}
                    descripcion="Afiliados a los que se les descuenta la cuota mensual de este círculo."
                    detalleLabel="Cobra"
                    importeLabel="Cuota mensual"
                    rows={(c.members ?? []).map((m: any) => ({
                      legajo: String(m.legajo),
                      nombre: m.apellido_nombre,
                      detalle: m.fecha_cobro
                        ? m.fecha_cobro
                        : m.mes_cobro
                          ? `${String(m.mes_cobro).padStart(2, "0")}/${m.anio_cobro ?? ""}`
                          : "",
                      importe: Number(m.importe_mensual ?? 0),
                      observacion: m.observacion,
                      adelanto:
                        m.fecha_cobro || m.mes_cobro
                          ? {
                              refKey: `circulo:${c.id}:${String(m.legajo)}`,
                              tipo: "Círculo",
                              detalle: c.numero ? `Círculo ${c.numero} - ${c.nombre}` : c.nombre,
                              importe: (c.members ?? []).reduce(
                                (a: number, x: any) => a + (Number(x.importe_mensual) || 0),
                                0,
                              ),
                            }
                          : undefined,
                    }))}
                  />
                  <Button variant="outline" size="sm" onClick={() => exportarCirculo(c)}>
                    <Download className="mr-2 h-4 w-4" /> Excel
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => editar(c)}>
                    <Pencil className="mr-2 h-4 w-4" /> Editar
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => borrar(c.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
              <Separator className="my-2" />
              <p className="text-xs text-muted-foreground">
                Aporte mensual del círculo: {money(Number(c.total_mensual ?? 0))}
              </p>
            </div>
          ))}
          {!isLoading && !circulos.length && (
            <p className="text-sm text-muted-foreground">No hay círculos que coincidan.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function Kpi({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="text-lg font-semibold">{value}</p>
    </div>
  );
}
