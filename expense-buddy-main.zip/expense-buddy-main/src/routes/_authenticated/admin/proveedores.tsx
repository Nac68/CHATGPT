import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listProviders, createProvider, updateProvider, deleteProvider, listServices } from "@/lib/crm.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { ImportProvidersCard } from "@/components/ImportProvidersCard";
import { Trash2, KeyRound } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/proveedores")({
  component: Proveedores,
  head: () => ({
    meta: [
      { title: "Proveedores habilitados · AGOEC" },
      { name: "description", content: "Tesorería habilita proveedores internos y externos por servicio y les da acceso al portal." },
      { property: "og:title", content: "Proveedores habilitados · AGOEC" },
      { property: "og:description", content: "Gestión de proveedores por servicio, habilitación y accesos." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

function Proveedores() {
  const list = useServerFn(listProviders);
  const services = useServerFn(listServices);
  const create = useServerFn(createProvider);
  const update = useServerFn(updateProvider);
  const del = useServerFn(deleteProvider);
  const qc = useQueryClient();

  const [form, setForm] = useState({
    nombre: "",
    service_id: "",
    email: "",
    password: "",
    cuit: "",
    cuenta_contable: "",
    tipo: "externo" as "externo" | "interno" | "agoec",
  });

  const [saving, setSaving] = useState(false);
  const [filtro, setFiltro] = useState("");

  const { data: provs } = useQuery({ queryKey: ["providers"], queryFn: () => list({ data: undefined as any }) });
  const { data: svcs } = useQuery({ queryKey: ["services"], queryFn: () => services({ data: undefined as any }) });

  const filtrados = useMemo(() => {
    const q = filtro.trim().toLowerCase();
    if (!q) return provs ?? [];
    return (provs ?? []).filter(
      (p: any) =>
        p.nombre.toLowerCase().includes(q) ||
        (p.email ?? "").toLowerCase().includes(q) ||
        (p.services?.nombre ?? "").toLowerCase().includes(q),
    );
  }, [provs, filtro]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.service_id) return toast.error("Elegí el servicio");
    setSaving(true);
    try {
      await create({
        data: {
          nombre: form.nombre,
          service_id: form.service_id,
          email: form.email.trim().toLowerCase(),
          password: form.password,
          cuit: form.cuit || null,
          cuenta_contable: form.cuenta_contable || null,
          tipo: form.tipo,
        },
      });
      toast.success("Proveedor creado y habilitado");
      setForm({ nombre: "", service_id: "", email: "", password: "", cuit: "", cuenta_contable: "", tipo: "externo" });

      qc.invalidateQueries({ queryKey: ["providers"] });
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo crear");
    } finally {
      setSaving(false);
    }
  }

  async function change(id: string, patch: any) {
    try {
      await update({ data: { id, ...patch } });
      qc.invalidateQueries({ queryKey: ["providers"] });
      toast.success("Proveedor actualizado");
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo actualizar");
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Proveedores</h1>
        <p className="text-sm text-muted-foreground">
          Tesorería habilita proveedores internos (afiliados de AGOEC) y externos por servicio.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Nuevo proveedor</CardTitle>
          <CardDescription>Se crea el acceso al portal con el email y la contraseña indicados.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="p-nombre">Nombre / Razón social</Label>
              <Input
                id="p-nombre"
                value={form.nombre}
                onChange={(e) => setForm({ ...form, nombre: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-servicio">Servicio</Label>
              <select
                id="p-servicio"
                className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={form.service_id}
                onChange={(e) => setForm({ ...form, service_id: e.target.value })}
              >
                <option value="">Elegí un servicio…</option>
                {(svcs ?? []).map((s: any) => (
                  <option key={s.id} value={s.id}>
                    {s.nombre}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-email">Email de acceso</Label>
              <Input
                id="p-email"
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-pass">Contraseña inicial</Label>
              <Input
                id="p-pass"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                minLength={6}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-cuit">CUIT</Label>
              <Input id="p-cuit" value={form.cuit} onChange={(e) => setForm({ ...form, cuit: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-cta">Número contable (xxx/xxx/xxx)</Label>
              <Input
                id="p-cta"
                placeholder="001/002/003"
                value={form.cuenta_contable}
                onChange={(e) => setForm({ ...form, cuenta_contable: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="p-tipo">Tipo de prestador</Label>
              <select
                id="p-tipo"
                className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={form.tipo}
                onChange={(e) => setForm({ ...form, tipo: e.target.value as any })}
              >
                <option value="externo">Externo</option>
                <option value="interno">Interno (afiliado de AGOEC)</option>
                <option value="agoec">De AGOEC (carga el administrador)</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <Button type="submit" disabled={saving}>
                {saving ? "Creando…" : "Crear proveedor"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <ImportProvidersCard services={svcs ?? []} />

      <Card>
        <CardHeader className="flex-row items-center justify-between gap-3">
          <CardTitle className="text-base">Proveedores ({filtrados.length})</CardTitle>
          <Input
            className="max-w-xs"
            placeholder="Buscar…"
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
        </CardHeader>
        <CardContent>
          {!filtrados.length ? (
            <p className="text-sm text-muted-foreground">No hay proveedores cargados.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr className="border-b">
                    <th className="py-2 pr-3">Proveedor</th>
                    <th className="py-2 pr-3">N° contable</th>

                    <th className="py-2 pr-3">Servicio</th>
                    <th className="py-2 pr-3">Email</th>
                    <th className="py-2 pr-3">Tipo</th>
                    <th className="py-2 pr-3">Datos de cobro</th>
                    <th className="py-2 pr-3">Habilitado</th>
                    <th className="py-2" />
                  </tr>
                </thead>
                <tbody>
                  {filtrados.map((p: any) => (
                    <tr key={p.id} className="border-b last:border-0">
                      <td className="py-2 pr-3 font-medium">{p.nombre}</td>
                      <td className="py-2 pr-3">
                        <Input
                          className="h-8 w-28 font-mono text-xs"
                          placeholder="001/002/003"
                          defaultValue={p.cuenta_contable ?? ""}
                          onBlur={(e) => {
                            const v = e.target.value.trim();
                            if (v === (p.cuenta_contable ?? "")) return;
                            change(p.id, { cuenta_contable: v || null });
                          }}
                        />
                      </td>

                      <td className="py-2 pr-3">
                        <select
                          className="h-8 rounded-md border border-input bg-background px-2 text-xs"
                          value={p.service_id}
                          onChange={(e) => change(p.id, { service_id: e.target.value })}
                        >
                          {(svcs ?? []).map((s: any) => (
                            <option key={s.id} value={s.id}>
                              {s.nombre}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="py-2 pr-3">{p.email}</td>
                      <td className="py-2 pr-3">
                        <select
                          className="h-8 rounded-md border border-input bg-background px-2 text-xs"
                          value={p.tipo ?? (p.interno ? "interno" : "externo")}
                          onChange={(e) => change(p.id, { tipo: e.target.value })}
                        >
                          <option value="externo">Externo</option>
                          <option value="interno">Interno</option>
                          <option value="agoec">De AGOEC</option>
                        </select>
                      </td>
                      <td className="py-2 pr-3 text-xs text-muted-foreground">
                        {p.cbu || p.alias ? `${p.banco ?? ""} ${p.cbu ?? p.alias}` : "Sin datos"}
                      </td>
                      <td className="py-2 pr-3">
                        <Checkbox
                          checked={p.habilitado}
                          onCheckedChange={(v) => change(p.id, { habilitado: !!v })}
                        />
                      </td>
                      <td className="py-2 text-right whitespace-nowrap">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            const np = window.prompt(`Nueva contraseña para ${p.nombre}`);
                            if (np && np.length >= 6) change(p.id, { newPassword: np });
                            else if (np) toast.error("Mínimo 6 caracteres");
                          }}
                        >
                          <KeyRound className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={async () => {
                            if (!window.confirm(`¿Eliminar ${p.nombre}?`)) return;
                            try {
                              await del({ data: { id: p.id } });
                              qc.invalidateQueries({ queryKey: ["providers"] });
                              toast.success("Proveedor eliminado");
                            } catch (e: any) {
                              toast.error(e?.message ?? "No se pudo eliminar");
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
