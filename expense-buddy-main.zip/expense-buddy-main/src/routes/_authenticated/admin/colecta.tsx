import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import * as XLSX from "xlsx";
import { toast } from "sonner";
import {
  listCollections,
  saveCollection,
  deleteCollection,
  collectionsSettlement,
} from "@/lib/collections.functions";
import { useAffiliateNames } from "@/hooks/use-affiliate-names";
import { compareLegajo } from "@/lib/legajo";
import { parsePeriodo, periodoError } from "@/lib/periodo";
import { ImportPreview, type ImportPreviewData } from "@/components/ImportPreview";
import { IntegrantesDialog } from "@/components/IntegrantesDialog";
import { AdelantoToggle } from "@/components/AdelantoToggle";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Trash2, Upload, Download, HeartHandshake } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/colecta")({
  validateSearch: (s: Record<string, unknown>): { product_id?: string; service_id?: string } => ({
    product_id: typeof s.product_id === "string" ? s.product_id : undefined,
    service_id: typeof s.service_id === "string" ? s.service_id : undefined,
  }),
  component: ColectaAdmin,
  head: () => ({
    meta: [
      { title: "Colectas · AGOEC" },
      {
        name: "description",
        content:
          "Cargá colectas de AGOEC con beneficiario editable, cuotas opcionales y liquidación de descuentos por afiliado.",
      },
      { property: "og:title", content: "Colectas · AGOEC" },
      {
        property: "og:description",
        content: "Alta manual o por Excel de colectas, cuotas y liquidación mensual por afiliado.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

type Row = {
  uid: string;
  legajo: string;
  importe_total: string;
  cuotas: string;
  observacion: string;
};

const uid = () => Math.random().toString(36).slice(2);
const emptyRow = (cuotas = "1"): Row => ({
  uid: uid(),
  legajo: "",
  importe_total: "",
  cuotas,
  observacion: "",
});

const MESES = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre",
];

const money = (n: number) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" }).format(Number(n) || 0);

const toNumber = (v: string) => {
  const s = String(v ?? "").replace(/[^\d,.-]/g, "");
  const norm =
    s.includes(",") && s.lastIndexOf(",") > s.lastIndexOf(".")
      ? s.replace(/\./g, "").replace(",", ".")
      : s.replace(/,/g, "");
  return Number(norm) || 0;
};

const pick = (r: any, keys: string[]) => {
  for (const k of Object.keys(r)) {
    const norm = k
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .trim();
    if (keys.some((x) => norm === x || norm.includes(x))) return String(r[k] ?? "").trim();
  }
  return "";
};

function ColectaAdmin() {
  const { product_id, service_id } = Route.useSearch();
  const qc = useQueryClient();
  const load = useServerFn(listCollections);
  const save = useServerFn(saveCollection);
  const del = useServerFn(deleteCollection);
  const settle = useServerFn(collectionsSettlement);

  const hoy = new Date();
  const [editId, setEditId] = useState<string | undefined>();
  const [nombre, setNombre] = useState("");
  const [motivo, setMotivo] = useState("");
  const [benLegajo, setBenLegajo] = useState("");
  const [benNombre, setBenNombre] = useState("");
  const [fecha, setFecha] = useState("");
  const [objetivo, setObjetivo] = useState("");
  const [cuotas, setCuotas] = useState("1");
  const [preview, setPreview] = useState<(ImportPreviewData & { _rows?: Omit<Row, "uid">[] }) | null>(null);
  const [mesInicio, setMesInicio] = useState(String(hoy.getMonth() + 1));
  const [anioInicio, setAnioInicio] = useState(String(hoy.getFullYear()));
  const [cerrada, setCerrada] = useState(false);
  const [observacion, setObservacion] = useState("");
  const [rows, setRows] = useState<Row[]>([emptyRow()]);
  const [busy, setBusy] = useState<string | null>(null);
  const excelRef = useRef<HTMLInputElement>(null);

  const [liqMes, setLiqMes] = useState(String(hoy.getMonth() + 1));
  const [liqAnio, setLiqAnio] = useState(String(hoy.getFullYear()));

  const key = ["collections", product_id ?? "all"] as const;
  const { data, isLoading, error } = useQuery({
    queryKey: key,
    queryFn: () => load({ data: product_id ? { product_id } : {} }),
  });

  const nombres = useAffiliateNames([...rows.map((r) => r.legajo), benLegajo]);

  const liq = useQuery({
    queryKey: ["collections-settlement", liqMes, liqAnio, product_id ?? "all"],
    queryFn: () =>
      settle({
        data: {
          mes: Number(liqMes),
          anio: Number(liqAnio),
          ...(product_id ? { product_id } : {}),
        } as any,
      }),
  });

  const members = useMemo(
    () =>
      rows
        .filter((r) => r.legajo.trim())
        .map((r) => ({
          legajo: r.legajo.trim().toUpperCase(),
          importe_total: toNumber(r.importe_total),
          cuotas: Math.max(1, Number(r.cuotas) || Number(cuotas) || 1),
          observacion: r.observacion || null,
        })),
    [rows, cuotas],
  );

  const totalAportes = members.reduce((a, m) => a + m.importe_total, 0);
  const totalCuotaMes = members.reduce((a, m) => a + m.importe_total / m.cuotas, 0);

  function setRow(k: string, patch: Partial<Row>) {
    setRows((rs) => rs.map((r) => (r.uid === k ? { ...r, ...patch } : r)));
  }

  function addRows(nuevas: Omit<Row, "uid">[]) {
    setRows((rs) => {
      const kept = rs.filter((r) => r.legajo.trim());
      return [...kept, ...nuevas.map((r) => ({ ...r, uid: uid() }))].sort((a, b) =>
        compareLegajo(a.legajo, b.legajo),
      );
    });
  }

  function resetForm() {
    setEditId(undefined);
    setNombre("");
    setMotivo("");
    setBenLegajo("");
    setBenNombre("");
    setFecha("");
    setObjetivo("");
    setCuotas("1");
    setMesInicio(String(hoy.getMonth() + 1));
    setAnioInicio(String(hoy.getFullYear()));
    setCerrada(false);
    setObservacion("");
    setRows([emptyRow()]);
  }

  async function onExcel(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy("excel");
    try {
      const wb = XLSX.read(await file.arrayBuffer(), { type: "array" });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const aoa = XLSX.utils.sheet_to_json<any[]>(sheet, { header: 1, defval: "" });
      const txt = (v: any) => String(v ?? "").trim();
      const norm = (v: any) =>
        txt(v)
          .toLowerCase()
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "");

      // Encabezado del modelo AGOEC (Descripción / Periodo Desde-Hasta / Beneficiario)
      let desde = "";
      let hasta = "";
      let headerIdx = -1;
      aoa.forEach((row, i) => {
        for (let c = 0; c < row.length; c++) {
          const k = norm(row[c]);
          const v = txt(row[c + 1]);
          if (k === "descripcion" && v) setNombre(v);
          else if (k.startsWith("periodo desde") && v) desde = v;
          else if (k.startsWith("periodo hasta") && v) hasta = v;
          else if (k.startsWith("legajo benef") && v) setBenLegajo(v.toUpperCase());
          else if (k.startsWith("nombre benef") && v) setBenNombre(v);
          else if (k === "legajo" && norm(row[c + 1]).includes("nombre")) headerIdx = i;
        }
      });

      const per = (s: string) => parsePeriodo(s);
      const d = per(desde);
      const h = per(hasta);
      if (d) {
        setMesInicio(String(d.mes));
        setAnioInicio(String(d.anio));
      }
      const nCuotas = d && h ? Math.max(1, (h.anio - d.anio) * 12 + (h.mes - d.mes) + 1) : null;
      if (nCuotas) setCuotas(String(nCuotas));

      let parsed: Omit<Row, "uid">[] = [];
      if (headerIdx >= 0) {
        for (let i = headerIdx + 1; i < aoa.length; i++) {
          const row = aoa[i];
          const legajo = txt(row[0]).toUpperCase();
          const nombreFila = txt(row[1]);
          if (!legajo || !nombreFila) continue;
          parsed.push({
            legajo,
            importe_total: txt(row[2]),
            cuotas: String(nCuotas ?? cuotas),
            observacion: txt(row[3]),
          });
        }
      } else {
        const json = XLSX.utils.sheet_to_json<any>(sheet, { defval: "" });
        parsed = json
          .map((r) => ({
            legajo: pick(r, ["legajo", "leg"]).toUpperCase(),
            importe_total: pick(r, ["importe", "aporte", "monto", "total"]),
            cuotas: pick(r, ["cuota"]) || cuotas,
            observacion: pick(r, ["observacion", "obs", "nota"]),
          }))
          .filter((r) => r.legajo);
      }

      if (!parsed.length) toast.error("No se detectaron filas con legajo");
      else {
        setPreview({
          archivo: file.name,
          filas: parsed.map((r) => ({
            legajo: r.legajo,
            detalle: r.observacion,
            importe: Number(String(r.importe_total).replace(/[^\d,.-]/g, "").replace(",", ".")) || 0,
            cuotas: Number(r.cuotas) || 1,
          })),
          _rows: parsed,
        });
        if (!d) toast.warning("No pude leer el período: completalo antes de confirmar");
      }
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo leer el Excel");
    } finally {
      setBusy(null);
      if (excelRef.current) excelRef.current.value = "";
    }
  }

  /** Genera la planilla con el formato oficial de colectas de AGOEC. */
  function sheetModelo(c: {
    nombre: string;
    benLegajo: string;
    benNombre: string;
    mesInicio: string;
    anioInicio: string;
    cuotas: string;
    members: { legajo: string; nombre: string; importe: number; observacion?: string }[];
  }) {
    const per = (mes: number, anio: number) => `${anio}${String(mes).padStart(2, "0")}`;
    const m0 = Number(c.mesInicio) || 1;
    const a0 = Number(c.anioInicio) || new Date().getFullYear();
    const n = Math.max(1, Number(c.cuotas) || 1);
    const fin = new Date(a0, m0 - 1 + (n - 1), 1);
    const aoa: any[][] = [
      ["Descripción", c.nombre, "", ""],
      ["Periodo Desde", per(m0, a0), "Periodo Hasta", per(fin.getMonth() + 1, fin.getFullYear())],
      ["Legajo Beneficiario", c.benLegajo, "Nombre Beneficiario", c.benNombre],
      ["", "", "", ""],
      ["Legajo", "Nombre_y_Apellido", "Importe_Descontar", ""],
      ...c.members.map((m) => [m.legajo, m.nombre, m.importe, m.observacion ?? ""]),
      ["", "", "", ""],
      ["", "", c.members.reduce((a, m) => a + (Number(m.importe) || 0), 0), ""],
    ];
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [{ wch: 20 }, { wch: 28 }, { wch: 20 }, { wch: 22 }];
    return ws;
  }

  function descargarPlantilla() {
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      sheetModelo({
        nombre: nombre || "COLECTA REGALO EJEMPLO",
        benLegajo: benLegajo || "1684",
        benNombre: benNombre || nombres[benLegajo.trim().toUpperCase()] || "APELLIDO NOMBRE",
        mesInicio,
        anioInicio,
        cuotas,
        members: members.length
          ? members.map((m) => ({
              legajo: m.legajo,
              nombre: nombres[m.legajo] ?? "",
              importe: m.importe_total,
              observacion: m.observacion ?? "",
            }))
          : [
              { legajo: "1224", nombre: "GARCIA HERNAN PABLO", importe: 1500 },
              { legajo: "827", nombre: "TORTORELLI CECILIA", importe: 1000 },
            ],
      }),
      "Hoja1",
    );
    XLSX.writeFile(wb, "modelo_colecta.xlsx");
  }


  async function guardar(e: React.FormEvent) {
    e.preventDefault();
    if (nombre.trim().length < 2) return toast.error("Ponele un nombre a la colecta");
    if (!members.length) return toast.error("Cargá al menos un aportante");
    const errP = periodoError(Number(mesInicio), Number(anioInicio));
    if (errP) return toast.error(errP);
    setBusy("save");
    try {
      await save({
        data: {
          ...(editId ? { id: editId } : {}),
          product_id: product_id ?? null,
          service_id: service_id ?? null,
          nombre: nombre.trim(),
          motivo: motivo || null,
          beneficiario_legajo: benLegajo.trim() || null,
          beneficiario_nombre:
            benNombre.trim() || (benLegajo ? (nombres[benLegajo.trim().toUpperCase()] ?? null) : null),
          fecha: fecha || null,
          importe_objetivo: toNumber(objetivo),
          cuotas: Math.max(1, Number(cuotas) || 1),
          mes_inicio: Number(mesInicio),
          anio_inicio: Number(anioInicio),
          cerrada,
          observacion: observacion || null,
          members,
        } as any,
      });
      toast.success(editId ? "Colecta actualizada" : "Colecta creada");
      resetForm();
      qc.invalidateQueries({ queryKey: ["collections"] });
      qc.invalidateQueries({ queryKey: ["collections-settlement"] });
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo guardar");
    } finally {
      setBusy(null);
    }
  }

  function editar(c: any) {
    setEditId(c.id);
    setNombre(c.nombre ?? "");
    setMotivo(c.motivo ?? "");
    setBenLegajo(c.beneficiario_legajo ?? "");
    setBenNombre(c.beneficiario_nombre ?? "");
    setFecha(c.fecha ?? "");
    setObjetivo(String(c.importe_objetivo ?? ""));
    setCuotas(String(c.cuotas ?? 1));
    setMesInicio(c.mes_inicio ? String(c.mes_inicio) : "");
    setAnioInicio(c.anio_inicio ? String(c.anio_inicio) : "");
    setCerrada(!!c.cerrada);
    setObservacion(c.observacion ?? "");
    setRows(
      (c.members ?? []).length
        ? c.members.map((m: any) => ({
            uid: uid(),
            legajo: m.legajo,
            importe_total: String(m.importe_total ?? ""),
            cuotas: String(m.cuotas ?? 1),
            observacion: m.observacion ?? "",
          }))
        : [emptyRow()],
    );
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function borrar(id: string) {
    try {
      await del({ data: { id } });
      toast.success("Colecta eliminada");
      qc.invalidateQueries({ queryKey: ["collections"] });
      qc.invalidateQueries({ queryKey: ["collections-settlement"] });
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo eliminar");
    }
  }

  function exportarColecta(c: any) {
    const wb = XLSX.utils.book_new();
    const ms = [...(c.members ?? [])].sort((a: any, b: any) => compareLegajo(a.legajo, b.legajo));
    XLSX.utils.book_append_sheet(
      wb,
      sheetModelo({
        nombre: c.nombre ?? "",
        benLegajo: c.beneficiario_legajo ?? "",
        benNombre: c.beneficiario_nombre ?? "",
        mesInicio: String(c.mes_inicio ?? new Date().getMonth() + 1),
        anioInicio: String(c.anio_inicio ?? new Date().getFullYear()),
        cuotas: String(c.cuotas ?? 1),
        members: ms.map((m: any) => ({
          legajo: m.legajo,
          nombre: m.apellido_nombre ?? "",
          importe: Number(Number(m.importe_cuota ?? m.importe_total ?? 0).toFixed(2)),
          observacion: m.observacion ?? "",
        })),
      }),
      "Hoja1",
    );
    XLSX.writeFile(wb, `colecta_${String(c.nombre ?? "").replace(/\W+/g, "-")}.xlsx`);
  }


  function exportarLiquidacion() {
    const d: any = liq.data;
    if (!d?.rows?.length) return toast.error("No hay descuentos para ese período");
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet([
        ...[...d.rows]
          .sort((a: any, b: any) => compareLegajo(a.legajo, b.legajo))
          .map((r: any) => ({
            Legajo: r.legajo,
            "Apellido y Nombre": r.apellido_nombre ?? "",
            Colectas: r.colectas.map((x: any) => `${x.nombre} (cuota ${x.cuota})`).join(" | "),
            "Importe a descontar": Number(Number(r.importe).toFixed(2)),
          })),
        { Legajo: "TOTAL", "Apellido y Nombre": "", Colectas: "", "Importe a descontar": Number(Number(d.total).toFixed(2)) },
      ]),
      "Descuentos",
    );
    XLSX.writeFile(wb, `colectas_liquidacion_${liqAnio}-${String(liqMes).padStart(2, "0")}.xlsx`);
  }

  const d: any = liq.data;

  return (
    <div className="space-y-6">
      {preview && (
        <ImportPreview
          data={preview}
          mes={Number(mesInicio) || 0}
          anio={Number(anioInicio) || 0}
          onMes={(m) => setMesInicio(String(m))}
          onAnio={(a) => setAnioInicio(String(a))}
          onConfirm={() => {
            addRows(preview._rows ?? []);
            toast.success(`${(preview._rows ?? []).length} aportantes importados`);
            setPreview(null);
          }}
          onCancel={() => setPreview(null)}
        />
      )}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <HeartHandshake className="h-6 w-6 text-primary" /> Colectas
          </h1>
          <p className="text-sm text-muted-foreground">
            Cargá la colecta con su beneficiario (editable), definí si se descuenta en una o varias
            cuotas y generá la liquidación por afiliado y el total.
          </p>
        </div>
        <div className="flex gap-2">
          <Button asChild variant="outline" size="sm">
            <Link to="/admin/proveedores">Prestadores</Link>
          </Button>
          <Button asChild variant="outline" size="sm">
            <Link to="/admin/servicios">Volver a servicios</Link>
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{editId ? "Editar colecta" : "Nueva colecta"}</CardTitle>
          <CardDescription>
            Carga manual o importando un Excel con legajo, importe, cuotas y observaciones.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={guardar} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="conombre">Nombre de la colecta</Label>
                <Input
                  id="conombre"
                  required
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                  placeholder="Colecta solidaria Agosto"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cofecha">Fecha</Label>
                <Input
                  id="cofecha"
                  type="date"
                  value={fecha}
                  onChange={(e) => setFecha(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="coobj">Importe objetivo</Label>
                <Input
                  id="coobj"
                  inputMode="decimal"
                  value={objetivo}
                  onChange={(e) => setObjetivo(e.target.value)}
                  placeholder="0,00"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cobenl">Beneficiario · legajo</Label>
                <Input
                  id="cobenl"
                  value={benLegajo}
                  onChange={(e) => setBenLegajo(e.target.value.toUpperCase())}
                  placeholder="Ej. 2887"
                />
              </div>
              <div className="space-y-2 lg:col-span-2">
                <Label htmlFor="cobenn">Beneficiario · nombre (editable)</Label>
                <Input
                  id="cobenn"
                  value={benNombre || (nombres[benLegajo.trim().toUpperCase()] ?? "")}
                  onChange={(e) => setBenNombre(e.target.value)}
                  placeholder="Se completa con el legajo y podés editarlo"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cocuo">Cuotas (opcional)</Label>
                <Input
                  id="cocuo"
                  type="number"
                  min={1}
                  max={60}
                  value={cuotas}
                  onChange={(e) => setCuotas(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="comes">Mes de inicio del descuento</Label>
                <select
                  id="comes"
                  className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                  value={mesInicio}
                  onChange={(e) => setMesInicio(e.target.value)}
                >
                  <option value="">—</option>
                  {MESES.map((m, i) => (
                    <option key={m} value={i + 1}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="coanio">Año de inicio</Label>
                <Input
                  id="coanio"
                  type="number"
                  value={anioInicio}
                  onChange={(e) => setAnioInicio(e.target.value)}
                />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="comotivo">Motivo</Label>
                <Input
                  id="comotivo"
                  value={motivo}
                  onChange={(e) => setMotivo(e.target.value)}
                  placeholder="Ej. ayuda por enfermedad"
                />
              </div>
              <div className="space-y-2 sm:col-span-2 lg:col-span-3">
                <Label htmlFor="coobs">Observaciones</Label>
                <Input
                  id="coobs"
                  value={observacion}
                  onChange={(e) => setObservacion(e.target.value)}
                />
              </div>
              <label className="flex items-center gap-2 text-sm sm:col-span-2">
                <Checkbox checked={cerrada} onCheckedChange={(v) => setCerrada(!!v)} />
                Colecta cerrada (no genera descuentos)
              </label>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setRows((rs) => [...rs, emptyRow(cuotas)])}>
                <Plus className="h-4 w-4 mr-1" /> Agregar aportante
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                disabled={busy === "excel"}
                onClick={() => excelRef.current?.click()}
              >
                <Upload className="h-4 w-4 mr-1" /> {busy === "excel" ? "Leyendo…" : "Importar Excel"}
              </Button>
              <input
                ref={excelRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={onExcel}
              />
              <Button type="button" variant="outline" size="sm" onClick={descargarPlantilla}>
                <Download className="h-4 w-4 mr-1" /> Modelo Excel
              </Button>

              <Badge variant="outline">{members.length} aportantes</Badge>
              <Badge variant="outline">Aportes: {money(totalAportes)}</Badge>
              <Badge variant="outline">Descuento mensual: {money(totalCuotaMes)}</Badge>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr className="border-b">
                    <th className="py-2 pr-3">Legajo</th>
                    <th className="py-2 pr-3">Apellido y Nombre</th>
                    <th className="py-2 pr-3">Aporte total</th>
                    <th className="py-2 pr-3">Cuotas</th>
                    <th className="py-2 pr-3">Importe por cuota</th>
                    <th className="py-2 pr-3">Observaciones</th>
                    <th className="py-2" />
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => {
                    const cuo = Math.max(1, Number(r.cuotas) || Number(cuotas) || 1);
                    return (
                      <tr key={r.uid} className="border-b last:border-0">
                        <td className="py-2 pr-3">
                          <Input
                            className="h-8 w-24"
                            value={r.legajo}
                            onChange={(e) => setRow(r.uid, { legajo: e.target.value.toUpperCase() })}
                          />
                        </td>
                        <td className="py-2 pr-3 text-muted-foreground">
                          {nombres[r.legajo.trim().toUpperCase()] ?? "—"}
                        </td>
                        <td className="py-2 pr-3">
                          <Input
                            className="h-8 w-28"
                            inputMode="decimal"
                            value={r.importe_total}
                            onChange={(e) => setRow(r.uid, { importe_total: e.target.value })}
                          />
                        </td>
                        <td className="py-2 pr-3">
                          <Input
                            className="h-8 w-16"
                            type="number"
                            min={1}
                            value={r.cuotas}
                            onChange={(e) => setRow(r.uid, { cuotas: e.target.value })}
                          />
                        </td>
                        <td className="py-2 pr-3 font-medium">
                          {money(toNumber(r.importe_total) / cuo)}
                        </td>
                        <td className="py-2 pr-3">
                          <Input
                            className="h-8"
                            value={r.observacion}
                            onChange={(e) => setRow(r.uid, { observacion: e.target.value })}
                          />
                        </td>
                        <td className="py-2">
                          <Button
                            type="button"
                            size="icon"
                            variant="ghost"
                            onClick={() => setRows((rs) => rs.filter((x) => x.uid !== r.uid))}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="flex gap-2">
              <Button type="submit" disabled={busy === "save"}>
                {busy === "save" ? "Guardando…" : editId ? "Guardar colecta" : "Crear colecta"}
              </Button>
              {editId && (
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancelar
                </Button>
              )}
            </div>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex-row flex-wrap items-end justify-between gap-3">
          <div>
            <CardTitle className="text-base">Liquidación de colectas</CardTitle>
            <CardDescription>
              Descuento que corresponde a cada afiliado en el período elegido, y el total.
            </CardDescription>
          </div>
          <div className="flex flex-wrap items-end gap-2">
            <select
              className="h-9 rounded-md border border-input bg-background px-2 text-sm"
              value={liqMes}
              onChange={(e) => setLiqMes(e.target.value)}
            >
              {MESES.map((m, i) => (
                <option key={m} value={i + 1}>
                  {m}
                </option>
              ))}
            </select>
            <Input
              className="h-9 w-24"
              type="number"
              value={liqAnio}
              onChange={(e) => setLiqAnio(e.target.value)}
            />
            <Button size="sm" variant="outline" onClick={exportarLiquidacion}>
              <Download className="h-4 w-4 mr-1" /> Excel
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-3">
            {[
              { l: "Colectas activas", v: d?.colectas ?? 0 },
              { l: "Afiliados con descuento", v: d?.aportantes ?? 0 },
              { l: "Total a descontar", v: money(d?.total ?? 0) },
            ].map((k) => (
              <div key={k.l} className="rounded-md bg-muted/50 px-3 py-2">
                <p className="text-[11px] text-muted-foreground">{k.l}</p>
                <p className="font-semibold">{k.v}</p>
              </div>
            ))}
          </div>
          {!d?.rows?.length ? (
            <p className="text-sm text-muted-foreground">
              Sin descuentos de colectas para {MESES[Number(liqMes) - 1]} {liqAnio}.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr className="border-b">
                    <th className="py-2 pr-3">Legajo</th>
                    <th className="py-2 pr-3">Apellido y Nombre</th>
                    <th className="py-2 pr-3">Colectas / cuota</th>
                    <th className="py-2 pr-3 text-right">A descontar</th>
                  </tr>
                </thead>
                <tbody>
                  {[...d.rows]
                    .sort((a: any, b: any) => compareLegajo(a.legajo, b.legajo))
                    .map((r: any) => (
                      <tr key={r.legajo} className="border-b last:border-0">
                        <td className="py-2 pr-3 font-mono">{r.legajo}</td>
                        <td className="py-2 pr-3">{r.apellido_nombre ?? "—"}</td>
                        <td className="py-2 pr-3 text-muted-foreground">
                          {r.colectas.map((x: any) => `${x.nombre} (${x.cuota})`).join(" · ")}
                        </td>
                        <td className="py-2 pr-3 text-right font-medium">{money(r.importe)}</td>
                      </tr>
                    ))}
                  <tr className="font-semibold">
                    <td className="py-2 pr-3" colSpan={3}>
                      Total
                    </td>
                    <td className="py-2 pr-3 text-right">{money(d.total)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Colectas cargadas</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {isLoading ? (
            <p className="text-sm text-muted-foreground">Cargando…</p>
          ) : error ? (
            <p className="text-sm text-destructive">{(error as any)?.message}</p>
          ) : !data?.collections?.length ? (
            <p className="text-sm text-muted-foreground">Todavía no hay colectas.</p>
          ) : (
            data.collections.map((c: any) => (
              <div key={c.id} className="rounded-lg border p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="font-semibold">{c.nombre}</p>
                    <p className="text-xs text-muted-foreground">
                      Beneficiario: {c.beneficiario_nombre || "—"}
                      {c.beneficiario_legajo ? ` (${c.beneficiario_legajo})` : ""}
                      {c.motivo ? ` · ${c.motivo}` : ""}
                    </p>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      <Badge variant={c.cerrada ? "secondary" : "default"}>
                        {c.cerrada ? "Cerrada" : "Activa"}
                      </Badge>
                      <Badge variant="outline">{c.cuotas} cuota(s)</Badge>
                      {c.mes_inicio && (
                        <Badge variant="outline">
                          Desde {MESES[c.mes_inicio - 1]} {c.anio_inicio}
                        </Badge>
                      )}
                      <Badge variant="outline">{c.aportantes} aportantes</Badge>
                      <Badge variant="outline">Aportes {money(c.total_aportes)}</Badge>
                      <Badge variant="outline">Cuota mensual {money(c.total_cuota_mes)}</Badge>
                      {Number(c.importe_objetivo) > 0 && (
                        <Badge variant="outline">Objetivo {money(c.importe_objetivo)}</Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <IntegrantesDialog
                      titulo={`Aportantes · ${c.nombre}`}
                      descripcion="Afiliados a los que se les descuenta esta colecta."
                      label="Ver aportantes"
                      detalleLabel="Aporte total / cuotas"
                      importeLabel="Cuota mensual"
                      rows={(c.members ?? []).map((m: any) => {
                        const n = Math.max(1, Number(m.cuotas ?? c.cuotas ?? 1));
                        const tot = Number(m.importe_total ?? 0);
                        return {
                          legajo: String(m.legajo),
                          nombre: m.apellido_nombre,
                          detalle: `${money(tot)} en ${n} cuota(s)`,
                          importe: Number(m.importe_cuota ?? 0) || tot / n,
                          observacion: m.observacion,
                        };
                      })}
                    />
                    {(c.beneficiario_legajo || c.beneficiario_nombre) && (
                      <div className="flex items-center px-2">
                        <AdelantoToggle
                          refKey={`colecta:${c.id}`}
                          tipo="Colecta"
                          legajo={c.beneficiario_legajo}
                          detalle={c.nombre}
                          importe={Number(c.importe_objetivo) || Number(c.total_cuota_mes) || 0}
                          label="Beneficiario ya cobró"
                        />
                      </div>
                    )}
                    <Button size="sm" variant="outline" onClick={() => exportarColecta(c)}>
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => editar(c)}>
                      Editar
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => borrar(c.id)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}
