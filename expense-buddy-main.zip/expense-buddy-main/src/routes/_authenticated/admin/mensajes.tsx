import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listAllMessages, replyProviderMessage } from "@/lib/crm.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/mensajes")({
  component: MensajesAdmin,
  head: () => ({
    meta: [
      { title: "Mensajes de proveedores · AGOEC" },
      { name: "description", content: "Bandeja de consultas de los proveedores de AGOEC con respuesta directa desde administración." },
      { property: "og:title", content: "Mensajes de proveedores · AGOEC" },
      { property: "og:description", content: "Respondé las consultas que envían los proveedores desde su portal." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

function MensajesAdmin() {
  const list = useServerFn(listAllMessages);
  const reply = useServerFn(replyProviderMessage);
  const qc = useQueryClient();
  const [texto, setTexto] = useState<Record<string, string>>({});

  const { data } = useQuery({ queryKey: ["all-messages"], queryFn: () => list({ data: undefined as any }) });

  const grupos = useMemo(() => {
    const map = new Map<string, { nombre: string; servicio: string; mensajes: any[] }>();
    for (const m of data ?? []) {
      const key = m.provider_id;
      if (!map.has(key))
        map.set(key, {
          nombre: m.providers?.nombre ?? "Proveedor",
          servicio: m.providers?.services?.nombre ?? "—",
          mensajes: [],
        });
      map.get(key)!.mensajes.push(m);
    }
    return Array.from(map.entries());
  }, [data]);

  async function responder(providerId: string) {
    const mensaje = (texto[providerId] ?? "").trim();
    if (mensaje.length < 2) return toast.error("Escribí la respuesta");
    try {
      await reply({ data: { provider_id: providerId, asunto: null, mensaje } });
      setTexto({ ...texto, [providerId]: "" });
      qc.invalidateQueries({ queryKey: ["all-messages"] });
      toast.success("Respuesta enviada");
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo enviar");
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Mensajes de proveedores</h1>
        <p className="text-sm text-muted-foreground">Consultas recibidas desde el portal de proveedores.</p>
      </div>

      {!grupos.length ? (
        <Card>
          <CardContent className="py-8 text-sm text-muted-foreground">No hay mensajes todavía.</CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {grupos.map(([providerId, g]) => (
            <Card key={providerId}>
              <CardHeader>
                <CardTitle className="text-base">{g.nombre}</CardTitle>
                <CardDescription>{g.servicio}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="max-h-72 space-y-2 overflow-y-auto">
                  {g.mensajes
                    .slice()
                    .reverse()
                    .map((m: any) => (
                      <div
                        key={m.id}
                        className={`rounded-lg border p-3 text-sm ${m.desde_admin ? "bg-secondary" : "bg-card"}`}
                      >
                        <p className="text-xs text-muted-foreground">
                          {m.desde_admin ? "Administración" : g.nombre} ·{" "}
                          {new Date(m.created_at).toLocaleString("es-AR")}
                        </p>
                        {m.asunto && <p className="mt-1 font-medium">{m.asunto}</p>}
                        <p className="mt-1 whitespace-pre-wrap">{m.mensaje}</p>
                      </div>
                    ))}
                </div>
                <Textarea
                  rows={3}
                  placeholder="Escribí la respuesta…"
                  value={texto[providerId] ?? ""}
                  onChange={(e) => setTexto({ ...texto, [providerId]: e.target.value })}
                />
                <Button size="sm" onClick={() => responder(providerId)}>
                  Responder
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
