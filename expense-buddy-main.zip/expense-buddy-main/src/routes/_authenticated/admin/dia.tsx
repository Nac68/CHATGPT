import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listAffiliates } from "@/lib/affiliates.functions";
import {
  getDailyFormByDate,
  saveDailyForm,
  uploadDailyPhoto,
} from "@/lib/daily-forms.functions";
import { ocrDailyPhoto } from "@/lib/ocr.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Loader2, Plus, Trash2, Upload, Wand2, Download } from "lucide-react";
import * as XLSX from "xlsx";
import { compareLegajo } from "@/lib/legajo";

export const Route = createFileRoute("/_authenticated/admin/dia")({
  validateSearch: (s: Record<string, unknown>): { fecha?: string } => ({
    fecha: typeof s.fecha === "string" ? s.fecha : undefined,
  }),
  component: DiaForm,
});

type Row = {
  uid: string;
  legajo: string;
  apellido_nombre: string;
  desayuno: boolean;
  almuerzo: boolean;
  no_paga: boolean;
  observacion: string;
};

function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

const normalize = (s: string) => s.trim().toUpperCase().replace(/\s+/g, "");
const newUid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

function DiaForm() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const [fecha, setFecha] = useState(search.fecha ?? today());
  const [descripcion, setDescripcion] = useState("Comida a Dto.");
  const [observacion, setObservacion] = useState("");
  const [importe, setImporte] = useState<string>("");
  const [rows, setRows] = useState<Row[]>([]);
  const [legajoInput, setLegajoInput] = useState("");
  const [saving, setSaving] = useState(false);
  const [ocrLoading, setOcrLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [fotoPath, setFotoPath] = useState<string | null>(null);
  const [esCumple, setEsCumple] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const listAff = useServerFn(listAffiliates);
  const getByDate = useServerFn(getDailyFormByDate);
  const save = useServerFn(saveDailyForm);
  const upload = useServerFn(uploadDailyPhoto);
  const ocr = useServerFn(ocrDailyPhoto);

  const { data: affiliates } = useQuery({
    queryKey: ["affiliates"],
    queryFn: () => listAff({ data: undefined as any }),
  });

  const affByLegajo = useMemo(() => {
    const m = new Map<string, string>();
    (affiliates ?? []).forEach((a: any) => m.set(String(a.legajo), a.apellido_nombre));
    return m;
  }, [affiliates]);

  useEffect(() => {
    (async () => {
      const res = await getByDate({ data: { fecha } });
      if (res.form) {
        setDescripcion(res.form.descripcion_comida ?? "Comida a Dto.");
        setObservacion(res.form.observacion ?? "");
        setImporte(res.form.importe != null ? String(res.form.importe) : "");
        setFotoPath(res.form.foto_url ?? null);
        setEsCumple(Boolean((res.form as any).es_cumpleanos));
        setRows(
          (res.consumos ?? []).map((c: any) => ({
            uid: newUid(),
            legajo: String(c.legajo),
            apellido_nombre: affByLegajo.get(String(c.legajo)) ?? String(c.legajo),
            desayuno: c.desayuno,
            almuerzo: c.almuerzo,
            no_paga: Boolean(c.no_paga),
            observacion: c.observacion ?? "",
          })).sort((a: Row, b: Row) => compareLegajo(a.legajo, b.legajo)),
        );
      } else {
        setRows([]);
        setImporte("");
        setObservacion("");
        setFotoPath(null);
        setEsCumple(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fecha, affiliates]);

  function addLegajo() {
    const n = normalize(legajoInput);
    if (!n) return toast.error("Legajo inválido");
    const name = affByLegajo.get(n);
    if (!name) return toast.error(`Legajo ${n} no está en la lista de afiliados`);
    setRows((r) => [
      ...r,
      {
        uid: newUid(),
        legajo: n,
        apellido_nombre: name,
        desayuno: false,
        almuerzo: true,
        no_paga: false,
        observacion: "",
      },
    ]);
    setLegajoInput("");
  }

  function updateRow(uid: string, patch: Partial<Row>) {
    setRows((r) => r.map((x) => (x.uid === uid ? { ...x, ...patch } : x)));
  }

  function removeRow(uid: string) {
    setRows((r) => r.filter((x) => x.uid !== uid));
  }

  async function fileToBase64(f: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(String(r.result));
      r.onerror = reject;
      r.readAsDataURL(f);
    });
  }

  async function onPhoto(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    setUploading(true);
    try {
      const b64 = await fileToBase64(f);
      const { path } = await upload({ data: { fecha, base64: b64 } });
      setFotoPath(path);
      setOcrLoading(true);
      try {
        const { consumos } = await ocr({ data: { base64: b64 } });
        const merged = new Map<string, Row>();
        const extras: Row[] = [];
        rows.forEach((r) => {
          if (merged.has(r.legajo)) extras.push(r);
          else merged.set(r.legajo, r);
        });
        let ignorados = 0;
        for (const c of consumos) {
          const legajo = normalize(String(c.legajo));
          const name = affByLegajo.get(legajo);
          if (!name) {
            ignorados++;
            continue;
          }
          const cur = merged.get(legajo);
          merged.set(legajo, {
            uid: cur?.uid ?? newUid(),
            legajo,
            apellido_nombre: name,
            desayuno: c.desayuno || cur?.desayuno || false,
            almuerzo: c.almuerzo || cur?.almuerzo || false,
            no_paga: cur?.no_paga ?? false,
            observacion: c.observacion ?? cur?.observacion ?? "",
          });
        }
        setRows(
          [...Array.from(merged.values()), ...extras].sort((a, b) =>
            compareLegajo(a.legajo, b.legajo),
          ),
        );
        toast.success(
          `IA detectó ${consumos.length} consumos${ignorados ? ` (${ignorados} sin legajo en la base)` : ""}. Podés seguir agregando manualmente.`,
        );
      } catch (err: any) {
        toast.error(err?.message ?? "No se pudo leer la foto");
      } finally {
        setOcrLoading(false);
      }
    } catch (err: any) {
      toast.error(err?.message ?? "Error al subir la foto");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  useEffect(() => {
    if (/cumplea/i.test(descripcion + " " + observacion)) setEsCumple(true);
  }, [descripcion, observacion]);

  const sortedRows = useMemo(
    () => [...rows].sort((a, b) => compareLegajo(a.legajo, b.legajo)),
    [rows],
  );
  const importeNum = importe.trim() === "" ? null : Number(importe);
  const comensales = rows.filter((r) => r.desayuno || r.almuerzo).length;
  const porAfiliado =
    importeNum != null && Number.isFinite(importeNum) && comensales > 0
      ? importeNum / comensales
      : null;
  const noPagan = rows.filter((r) => (r.desayuno || r.almuerzo) && r.no_paga).length;
  const currencyFmt = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });
  const cobroDe = (r: Row) =>
    porAfiliado != null && (r.desayuno || r.almuerzo) && !r.no_paga && !esCumple
      ? porAfiliado
      : null;
  const totalACobrar =
    porAfiliado != null && !esCumple
      ? Math.round(porAfiliado * (comensales - noPagan) * 100) / 100
      : 0;

  async function handleSave() {
    setSaving(true);
    try {
      if (importe.trim() !== "" && (!Number.isFinite(importeNum) || importeNum! < 0)) {
        throw new Error("Importe inválido");
      }
      await save({
        data: {
          fecha,
          descripcion_comida: descripcion || null,
          observacion: observacion || null,
          importe: importeNum,
          foto_url: fotoPath,
          es_cumpleanos: esCumple,
          consumos: rows.map((r) => ({
            legajo: r.legajo,
            desayuno: r.desayuno,
            almuerzo: r.almuerzo,
            no_paga: r.no_paga,
            observacion: r.observacion || null,
          })),
        },
      });
      toast.success("Formulario guardado");
      navigate({ to: "/admin/dias" });
    } catch (err: any) {
      toast.error(err?.message ?? "Error al guardar");
    } finally {
      setSaving(false);
    }
  }

  function exportDayXLSX() {
    if (rows.length === 0) return toast.error("No hay filas para exportar");
    const data = sortedRows.map((r) => ({
      Legajo: r.legajo,
      "Apellido y Nombre": r.apellido_nombre,
      Desayuno: r.desayuno ? "X" : "",
      Almuerzo: r.almuerzo ? "X" : "",
      Observaciones: r.observacion || "",
      "No paga": r.no_paga ? "X" : "",
      Importe: cobroDe(r) != null ? Number(cobroDe(r)!.toFixed(2)) : 0,
    }));
    const totales = {
      Legajo: "",
      "Apellido y Nombre": "TOTAL",
      Desayuno: rows.filter((r) => r.desayuno).length,
      Almuerzo: rows.filter((r) => r.almuerzo).length,
      Observaciones: `${comensales} comensales`,
      "No paga": rows.filter((r) => r.no_paga).length,
      Importe: esCumple ? 0 : totalACobrar,
    };
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet([
      {
        Legajo: "Fecha",
        "Apellido y Nombre": fecha,
        Desayuno: "",
        Almuerzo: "",
        Observaciones: esCumple ? `${descripcion} (cumpleaños - no se cobra)` : descripcion,
        "No paga": "",
        Importe: "",
      },
      {},
      ...data,
      totales,
    ]);
    XLSX.utils.book_append_sheet(wb, ws, fecha);
    XLSX.writeFile(wb, `comida_${fecha}.xlsx`);
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Formulario diario</h1>
        <p className="text-sm text-muted-foreground">
          Cargá el consumo del día. Subí la foto para que la IA marque los tildes o cargalos a mano.
          Al escribir el importe, el sistema lo divide entre los comensales.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Encabezado</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="fecha">Fecha</Label>
            <Input id="fecha" type="date" value={fecha} onChange={(e) => setFecha(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="desc">Descripción</Label>
            <Input id="desc" value={descripcion} onChange={(e) => setDescripcion(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="importe">Importe total del día</Label>
            <Input
              id="importe"
              type="number"
              step="0.01"
              value={importe}
              onChange={(e) => setImporte(e.target.value)}
              placeholder="0.00"
            />
            <div className="text-xs text-muted-foreground">
              {comensales} comensales →{" "}
              {porAfiliado != null ? (
                <span className="font-semibold text-foreground">
                  {currencyFmt.format(porAfiliado)} por afiliado
                </span>
              ) : (
                "cargá importe y tildes"
              )}
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="obs">Comida servida</Label>
            <Textarea
              id="obs"
              value={observacion}
              onChange={(e) => setObservacion(e.target.value)}
              placeholder="Ej: Milanesa con puré..."
              rows={2}
            />
          </div>

          <label className="md:col-span-2 flex items-start gap-2 rounded border p-3 cursor-pointer">
            <Checkbox checked={esCumple} onCheckedChange={(v) => setEsCumple(Boolean(v))} />
            <span className="text-sm">
              <span className="font-medium">Es cumpleaños (día sin cargo)</span>
              <span className="block text-xs text-muted-foreground">
                No se le cobra a ningún afiliado y no suma al total del mes.
              </span>
            </span>
          </label>

          <div className="md:col-span-2 grid gap-3 sm:grid-cols-3">
            <div className="rounded border p-3">
              <div className="text-xs text-muted-foreground">Afiliados que comieron</div>
              <div className="text-2xl font-bold">{comensales}</div>
            </div>
            <div className="rounded border p-3">
              <div className="text-xs text-muted-foreground">No pagan</div>
              <div className="text-2xl font-bold text-destructive">{noPagan}</div>
            </div>
            <div className="rounded border p-3">
              <div className="text-xs text-muted-foreground">Total a cobrar</div>
              <div className="text-2xl font-bold">
                {esCumple ? "Sin cargo" : currencyFmt.format(totalACobrar)}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>


      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Foto del formulario firmado</CardTitle>
          {fotoPath && <span className="text-xs text-muted-foreground truncate max-w-xs">Subida</span>}
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2 items-center">
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              capture="environment"
              className="hidden"
              onChange={onPhoto}
            />
            <Button
              type="button"
              variant="secondary"
              onClick={() => fileRef.current?.click()}
              disabled={uploading || ocrLoading}
            >
              {uploading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Upload className="h-4 w-4 mr-1" />}
              Subir foto (leer con IA)
            </Button>
            {ocrLoading && (
              <span className="text-sm text-muted-foreground inline-flex items-center gap-1">
                <Wand2 className="h-4 w-4 animate-pulse" /> Leyendo tildes...
              </span>
            )}
            <span className="text-xs text-muted-foreground">
              Podés seguir agregando afiliados manualmente después de la foto.
            </span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Consumos ({rows.length})</CardTitle>
          <Button type="button" variant="outline" size="sm" onClick={exportDayXLSX}>
            <Download className="h-4 w-4 mr-1" /> Descargar Excel del día
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Legajo (letras y/o números)"
              value={legajoInput}
              onChange={(e) => setLegajoInput(e.target.value.toUpperCase())}
              onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addLegajo())}
            />
            <Button type="button" onClick={addLegajo}>
              <Plus className="h-4 w-4 mr-1" />
              Agregar
            </Button>
          </div>
          {legajoInput && affByLegajo.get(normalize(legajoInput)) && (
            <div className="text-xs text-muted-foreground">
              → {affByLegajo.get(normalize(legajoInput))}
            </div>
          )}

          <div className="rounded border overflow-x-auto">
            <div className="grid grid-cols-[80px_1fr_60px_60px_70px_1fr_110px_40px] bg-muted text-xs uppercase font-semibold px-2 py-2 min-w-[720px]">
              <div>Legajo</div>
              <div>Apellido y Nombre</div>
              <div className="text-center">Des.</div>
              <div className="text-center">Alm.</div>
              <div className="text-center text-destructive">No paga</div>
              <div>Observaciones</div>
              <div className="text-right">Importe</div>
              <div></div>
            </div>
            {rows.length === 0 ? (
              <div className="p-6 text-center text-sm text-muted-foreground">
                Sin consumos. Agregá un legajo o subí la foto del formulario.
              </div>
            ) : (
              sortedRows.map((r) => (
                <div
                  key={r.uid}
                  className={(r.no_paga ? "text-destructive " : "") + "grid grid-cols-[80px_1fr_60px_60px_70px_1fr_110px_40px] px-2 py-2 items-center border-t text-sm min-w-[780px]"}
                >
                  <div className="font-mono">{r.legajo}</div>
                  <div className="truncate pr-2">{r.apellido_nombre}</div>
                  <div className="flex justify-center">
                    <Checkbox
                      checked={r.desayuno}
                      onCheckedChange={(v) => updateRow(r.uid, { desayuno: Boolean(v) })}
                    />
                  </div>
                  <div className="flex justify-center">
                    <Checkbox
                      checked={r.almuerzo}
                      onCheckedChange={(v) => updateRow(r.uid, { almuerzo: Boolean(v) })}
                    />
                  </div>
                  <div className="flex justify-center">
                    <Checkbox
                      checked={r.no_paga}
                      onCheckedChange={(v) => updateRow(r.uid, { no_paga: Boolean(v) })}
                      className="data-[state=checked]:bg-destructive data-[state=checked]:border-destructive"
                    />
                  </div>
                  <div className="pr-2">
                    <Input
                      value={r.observacion}
                      onChange={(e) => updateRow(r.uid, { observacion: e.target.value })}
                      placeholder="—"
                      className="h-8"
                    />
                  </div>
                  <div className="text-right font-mono text-xs">
                    {cobroDe(r) != null ? (
                      currencyFmt.format(cobroDe(r)!)
                    ) : (
                      <span className={r.no_paga ? "text-destructive font-semibold" : ""}>
                        {r.no_paga ? "No paga" : "—"}
                      </span>
                    )}
                  </div>
                  <div className="flex justify-end">
                    <Button size="icon" variant="ghost" onClick={() => removeRow(r.uid)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-2">
        <Button onClick={handleSave} disabled={saving}>
          {saving ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
          Guardar formulario
        </Button>
      </div>
    </div>
  );
}
