import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listDailyForms } from "@/lib/daily-forms.functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/admin/dias")({
  component: DiasList,
});

function DiasList() {
  const fn = useServerFn(listDailyForms);
  const { data, isLoading } = useQuery({
    queryKey: ["daily-forms"],
    queryFn: () => fn({ data: {} as any }),
  });

  const currencyFmt = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Formularios diarios</h1>
          <p className="text-sm text-muted-foreground">Historial de fichas cargadas.</p>
        </div>
        <Button asChild>
          <Link to="/admin/dia">Nuevo día</Link>
        </Button>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Últimos formularios</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div>Cargando...</div>
          ) : (data ?? []).length === 0 ? (
            <div className="text-sm text-muted-foreground">Todavía no hay formularios.</div>
          ) : (
            <div className="divide-y">
              {(data ?? []).map((f: any) => (
                <Link
                  key={f.id}
                  to="/admin/dia"
                  search={{ fecha: f.fecha }}
                  className="flex items-center justify-between py-3 hover:bg-accent/40 px-2 rounded"
                >
                  <div>
                    <div className="font-semibold">{f.fecha}</div>
                    <div className="text-xs text-muted-foreground truncate max-w-xs">
                      {f.descripcion_comida ?? "—"}
                    </div>
                  </div>
                  <div className="text-sm">
                    {f.importe != null ? currencyFmt.format(f.importe) : "—"}
                  </div>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
