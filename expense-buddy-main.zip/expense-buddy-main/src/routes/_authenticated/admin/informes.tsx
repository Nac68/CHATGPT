import { usePeriodoVigente } from "@/hooks/use-periodo-vigente";
import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import * as XLSX from "xlsx";
import { toast } from "sonner";
import {
  accountingReport,
  listAccountingCodes,
  setCuentaContable,
} from "@/lib/reports.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Download, FileSpreadsheet, Hash } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/informes")({
  component: Informes,
  head: () => ({
    meta: [
      { title: "Informes contables · AGOEC" },
      {
        name: "description",
        content:
          "Liquidación a proveedores para transferencia y liquidación de descuentos afiliado por afiliado, con número contable por servicio y producto.",
      },
      { property: "og:title", content: "Informes contables · AGOEC" },
      {
        property: "og:description",
        content: "Informes de transferencias a proveedores y descuentos por afiliado, con números contables.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const money = (n: number) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" }).format(Number(n) || 0);

function Informes() {
  const reportFn = useServerFn(accountingReport);
  const codesFn = useServerFn(listAccountingCodes);
  const saveFn = useServerFn(setCuentaContable);
  const qc = useQueryClient();
  const hoy = new Date();
  const [mes, setMes] = useState(hoy.getMonth() + 1);
  const [anio, setAnio] = useState(hoy.getFullYear());
  const [serviceId, setServiceId] = useState<string>("all");
  usePeriodoVigente((p) => { setMes(p.mes); setAnio(p.anio); });

  const { data, isLoading, error } = useQuery({
    queryKey: ["informe-contable", mes, anio, serviceId],
    queryFn: () =>
      reportFn({
        data: { mes, anio, service_id: serviceId === "all" ? null : serviceId, incluir_comida: true },
      }),
  });
  const { data: codes } = useQuery({ queryKey: ["cuentas-contables"], queryFn: () => codesFn({}) });

  const save = useMutation({
    mutationFn: (v: { tipo: "service" | "product" | "provider"; id: string; cuenta_contable: string }) =>
      saveFn({ data: v }),
    onSuccess: () => {
      toast.success("Número contable guardado");
      qc.invalidateQueries({ queryKey: ["cuentas-contables"] });
      qc.invalidateQueries({ queryKey: ["informe-contable"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "No se pudo guardar"),
  });

  const k: any = data?.kpis ?? {};
  const cols: string[] = data?.columnasServicio ?? [];

  const anios = useMemo(
    () => Array.from({ length: 6 }, (_, i) => hoy.getFullYear() - 3 + i),
    [hoy],
  );

  function bajarProveedores() {
    const rows = (data?.proveedores ?? []).map((p: any) => ({
      "Cta. servicio": p.cuenta_contable_servicio ?? "",
      Servicio: p.servicio,
      "Cta. proveedor": p.cuenta_contable ?? "",
      Proveedor: p.proveedor,
      Tipo: p.tipo,
      CUIT: p.cuit ?? "",
      Titular: p.titular ?? "",
      Banco: p.banco ?? "",
      CBU: p.cbu ?? "",
      Alias: p.alias ?? "",
      Consumos: p.items,
      Afiliados: p.afiliados,
      "Con receta": p.con_receta,
      "Sin receta": p.sin_receta,
      "Subsidio AGOEC": p.subsidio_agoec,
      "Descuento afiliados": p.descuento_afiliados,
      "A TRANSFERIR": p.a_transferir,
    }));
    if (!rows.length) return toast.error("No hay datos para el período");
    rows.push({
      "Cta. servicio": "",
      Servicio: "TOTAL",
      "Cta. proveedor": "",
      Proveedor: "",
      Tipo: "",
      CUIT: "",
      Titular: "",
      Banco: "",
      CBU: "",
      Alias: "",
      Consumos: rows.reduce((a: number, r: any) => a + r.Consumos, 0),
      Afiliados: 0,
      "Con receta": rows.reduce((a: number, r: any) => a + r["Con receta"], 0),
      "Sin receta": rows.reduce((a: number, r: any) => a + r["Sin receta"], 0),
      "Subsidio AGOEC": rows.reduce((a: number, r: any) => a + r["Subsidio AGOEC"], 0),
      "Descuento afiliados": rows.reduce((a: number, r: any) => a + r["Descuento afiliados"], 0),
      "A TRANSFERIR": rows.reduce((a: number, r: any) => a + r["A TRANSFERIR"], 0),
    } as any);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), "Transferencias");
    XLSX.writeFile(wb, `liquidacion-proveedores-${anio}-${String(mes).padStart(2, "0")}.xlsx`);
  }

  function bajarAfiliados() {
    const rows = (data?.afiliados ?? []).map((r: any) => {
      const base: any = { Legajo: r.legajo, "Apellido y nombre": r.apellido_nombre ?? "" };
      for (const c of cols) base[c] = r.por_servicio[c] ?? 0;
      base["TOTAL A DESCONTAR"] = r.total_descuento;
      return base;
    });
    if (!rows.length) return toast.error("No hay datos para el período");
    const total: any = { Legajo: "TOTAL", "Apellido y nombre": "" };
    for (const c of cols) total[c] = rows.reduce((a: number, r: any) => a + (r[c] ?? 0), 0);
    total["TOTAL A DESCONTAR"] = rows.reduce(
      (a: number, r: any) => a + r["TOTAL A DESCONTAR"],
      0,
    );
    rows.push(total);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), "Descuentos");
    XLSX.writeFile(wb, `liquidacion-afiliados-${anio}-${String(mes).padStart(2, "0")}.xlsx`);
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Informes contables</h1>
        <p className="text-sm text-muted-foreground">
          Liquidación a proveedores para transferencia y liquidación de descuentos afiliado por
          afiliado. Cada servicio, producto y proveedor lleva su número contable editable.
        </p>
      </div>

      <Card>
        <CardContent className="pt-6 flex flex-wrap items-end gap-3">
          <div>
            <Label>Mes</Label>
            <Select value={String(mes)} onValueChange={(v) => setMes(Number(v))}>
              <SelectTrigger className="w-28">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
                  <SelectItem key={m} value={String(m)}>
                    {String(m).padStart(2, "0")}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Año</Label>
            <Select value={String(anio)} onValueChange={(v) => setAnio(Number(v))}>
              <SelectTrigger className="w-28">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {anios.map((a) => (
                  <SelectItem key={a} value={String(a)}>
                    {a}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Servicio</Label>
            <Select value={serviceId} onValueChange={setServiceId}>
              <SelectTrigger className="w-56">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los servicios</SelectItem>
                {(data?.services ?? codes?.services ?? []).map((s: any) => (
                  <SelectItem key={s.id} value={s.id}>
                    {s.nombre}
                    {s.cuenta_contable ? ` · ${s.cuenta_contable}` : ""}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-3 sm:grid-cols-4">
        {[
          ["A transferir a proveedores", money(k.a_transferir ?? 0)],
          ["Subsidio AGOEC", money(k.subsidio_agoec ?? 0)],
          ["A descontar a afiliados", money(k.descuento_afiliados ?? 0)],
          ["Afiliados alcanzados", String(k.afiliados ?? 0)],
        ].map(([t, v]) => (
          <Card key={t as string}>
            <CardHeader className="pb-2">
              <CardDescription>{t}</CardDescription>
              <CardTitle className="text-xl">{v}</CardTitle>
            </CardHeader>
          </Card>
        ))}
      </div>

      {error ? <p className="text-sm text-destructive">{(error as any).message}</p> : null}

      <Tabs defaultValue="proveedores">
        <TabsList>
          <TabsTrigger value="proveedores">Proveedores (transferencia)</TabsTrigger>
          <TabsTrigger value="afiliados">Afiliados (descuentos)</TabsTrigger>
          <TabsTrigger value="cuentas">Números contables</TabsTrigger>
        </TabsList>

        <TabsContent value="proveedores" className="space-y-3">
          <div className="flex justify-end">
            <Button onClick={bajarProveedores} size="sm">
              <Download className="h-4 w-4 mr-2" /> Excel transferencias
            </Button>
          </div>
          <Card>
            <CardContent className="overflow-x-auto pt-6">
              <table className="w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr>
                    <th className="py-2 pr-3">Cta.</th>
                    <th className="py-2 pr-3">Proveedor</th>
                    <th className="py-2 pr-3">Servicio</th>
                    <th className="py-2 pr-3">CBU / Alias</th>
                    <th className="py-2 pr-3 text-right">Con receta</th>
                    <th className="py-2 pr-3 text-right">Sin receta</th>
                    <th className="py-2 pr-3 text-right">Subsidio</th>
                    <th className="py-2 pr-3 text-right">A transferir</th>
                  </tr>
                </thead>
                <tbody>
                  {(data?.proveedores ?? []).map((p: any) => (
                    <tr key={p.provider_id} className="border-t">
                      <td className="py-2 pr-3 font-mono text-xs">{p.cuenta_contable ?? "—"}</td>
                      <td className="py-2 pr-3 font-medium">
                        {p.proveedor} <Badge variant="outline">{p.tipo}</Badge>
                      </td>
                      <td className="py-2 pr-3">{p.servicio}</td>
                      <td className="py-2 pr-3 text-xs">{p.cbu ?? p.alias ?? "—"}</td>
                      <td className="py-2 pr-3 text-right">{money(p.con_receta)}</td>
                      <td className="py-2 pr-3 text-right">{money(p.sin_receta)}</td>
                      <td className="py-2 pr-3 text-right">{money(p.subsidio_agoec)}</td>
                      <td className="py-2 pr-3 text-right font-semibold">{money(p.a_transferir)}</td>
                    </tr>
                  ))}
                  {!isLoading && !(data?.proveedores ?? []).length ? (
                    <tr>
                      <td colSpan={8} className="py-6 text-center text-muted-foreground">
                        Sin liquidaciones cargadas en este período.
                      </td>
                    </tr>
                  ) : null}
                </tbody>
              </table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="afiliados" className="space-y-3">
          <div className="flex justify-end">
            <Button onClick={bajarAfiliados} size="sm">
              <FileSpreadsheet className="h-4 w-4 mr-2" /> Excel descuentos
            </Button>
          </div>
          <Card>
            <CardContent className="overflow-x-auto pt-6">
              <table className="w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr>
                    <th className="py-2 pr-3">Legajo</th>
                    <th className="py-2 pr-3">Apellido y nombre</th>
                    {cols.map((c) => (
                      <th key={c} className="py-2 pr-3 text-right">
                        {c}
                      </th>
                    ))}
                    <th className="py-2 pr-3 text-right">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {(data?.afiliados ?? []).map((r: any) => (
                    <tr key={r.legajo} className="border-t">
                      <td className="py-2 pr-3 font-mono">{r.legajo}</td>
                      <td className="py-2 pr-3">{r.apellido_nombre ?? "—"}</td>
                      {cols.map((c) => (
                        <td key={c} className="py-2 pr-3 text-right">
                          {r.por_servicio[c] ? money(r.por_servicio[c]) : "—"}
                        </td>
                      ))}
                      <td className="py-2 pr-3 text-right font-semibold">
                        {money(r.total_descuento)}
                      </td>
                    </tr>
                  ))}
                  {!isLoading && !(data?.afiliados ?? []).length ? (
                    <tr>
                      <td colSpan={cols.length + 3} className="py-6 text-center text-muted-foreground">
                        Sin consumos en este período.
                      </td>
                    </tr>
                  ) : null}
                </tbody>
              </table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cuentas" className="space-y-4">
          {(["services", "products", "providers"] as const).map((grupo) => (
            <CuentasCard
              key={grupo}
              grupo={grupo}
              rows={((codes as any)?.[grupo] ?? []) as any[]}
              onSave={(id, cuenta_contable) =>
                save.mutate({
                  tipo:
                    grupo === "services" ? "service" : grupo === "products" ? "product" : "provider",
                  id,
                  cuenta_contable,
                })
              }
            />
          ))}
        </TabsContent>

      </Tabs>
    </div>
  );
}

function CuentasCard({
  grupo,
  rows,
  onSave,
}: {
  grupo: "services" | "products" | "providers";
  rows: any[];
  onSave: (id: string, cuenta_contable: string) => void;
}) {
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [q, setQ] = useState("");

  const filtered = useMemo(
    () =>
      rows.filter((r) =>
        `${r.nombre ?? ""} ${r.cuenta_contable ?? ""}`.toLowerCase().includes(q.trim().toLowerCase()),
      ),
    [rows, q],
  );
  const pages = Math.max(1, Math.ceil(filtered.length / perPage));
  const current = Math.min(page, pages);
  const slice = filtered.slice((current - 1) * perPage, current * perPage);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <Hash className="h-4 w-4" />
          {grupo === "services" ? "Servicios" : grupo === "products" ? "Productos" : "Proveedores"}
          <Badge variant="secondary">{filtered.length}</Badge>
        </CardTitle>
        <CardDescription>
          Cargá el número contable a mano; se guarda al salir del campo y se puede editar.
        </CardDescription>
        <div className="flex flex-wrap items-end gap-3 pt-2">
          <Input
            className="w-64"
            placeholder="Buscar por nombre o número"
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setPage(1);
            }}
          />
          <Select
            value={String(perPage)}
            onValueChange={(v) => {
              setPerPage(Number(v));
              setPage(1);
            }}
          >
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {[10, 25, 50, 100].map((n) => (
                <SelectItem key={n} value={String(n)}>
                  {n} por pág.
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        {!slice.length ? (
          <p className="text-sm text-muted-foreground">Sin resultados.</p>
        ) : (
          slice.map((row: any) => (
            <div key={row.id} className="flex items-center gap-3">
              <span className="flex-1 text-sm">{row.nombre}</span>
              <Input
                className="w-40 font-mono"
                defaultValue={row.cuenta_contable ?? ""}
                placeholder="xxx/xxx/xxx"
                onBlur={(e) => {
                  const v = e.target.value.trim();
                  if (v !== (row.cuenta_contable ?? "")) onSave(row.id, v);
                }}
              />
            </div>
          ))
        )}
        <div className="flex items-center justify-between pt-2 text-sm">
          <span className="text-muted-foreground">
            Página {current} de {pages}
          </span>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={current <= 1}
              onClick={() => setPage(current - 1)}
            >
              Anterior
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={current >= pages}
              onClick={() => setPage(current + 1)}
            >
              Siguiente
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
