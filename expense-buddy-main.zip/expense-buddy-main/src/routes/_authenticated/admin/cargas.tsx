import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { setSubmissionEstado, getSubmission } from "@/lib/crm.functions";
import { getCargasPanel, getCargasPeriodos } from "@/lib/cargas-panel.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Download, Loader2, AlertCircle } from "lucide-react";
import * as XLSX from "xlsx";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/cargas")({
  component: Cargas,
  head: () => ({
    meta: [
      { title: "Liquidaciones de proveedores · AGOEC" },
      { name: "description", content: "Bandeja de liquidaciones enviadas por los proveedores: revisión, aprobación y pago." },
      { property: "og:title", content: "Liquidaciones de proveedores · AGOEC" },
      { property: "og:description", content: "Revisá, aprobá y marcá como pagadas las liquidaciones de cada proveedor." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const MESES = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
const currency = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });
const ESTADOS = ["enviada", "revisada", "aprobada", "pagada", "rechazada"] as const;
const rojo = "bg-destructive/10";

function Cargas() {
  const panelFn = useServerFn(getCargasPanel);
  const periodosFn = useServerFn(getCargasPeriodos);
  const setEstado = useServerFn(setSubmissionEstado);
  const detail = useServerFn(getSubmission);
  const qc = useQueryClient();

  const [filtro, setFiltro] = useState("");
  const [openProv, setOpenProv] = useState<{
    key: string;
    ids: string[];
    nombre: string;
    servicio: string;
    detalle: any[];
  } | null>(null);

  const [openCuota, setOpenCuota] = useState<string | null>(null);
  const [histKey, setHistKey] = useState("");
  // Estado de las líneas de cuotas (no tienen carga de proveedor): se guarda en el navegador.
  const [cuotaEstados, setCuotaEstados] = useState<Record<string, string>>(() => {
    try {
      return JSON.parse(localStorage.getItem("cargas-cuota-estados") ?? "{}");
    } catch {
      return {};
    }
  });

  function cambiarEstadoCuota(key: string, estado: string) {
    setCuotaEstados((prev) => {
      const next = { ...prev, [key]: estado };
      try {
        localStorage.setItem("cargas-cuota-estados", JSON.stringify(next));
      } catch {}
      return next;
    });
    toast.success("Estado actualizado");
  }

  const { data: panel, isLoading } = useQuery({
    queryKey: ["cargas-panel", "vigente"],
    queryFn: () => panelFn({ data: {} }),
  });

  const { data: periodos } = useQuery({
    queryKey: ["cargas-periodos"],
    queryFn: () => periodosFn({ data: undefined as any }),
  });

  const histSel = useMemo(() => {
    if (!histKey) return null;
    const [a, m] = histKey.split("-").map(Number);
    return { mes: m, anio: a };
  }, [histKey]);

  const { data: hist, isFetching: histLoading } = useQuery({
    queryKey: ["cargas-panel", histKey],
    queryFn: () => panelFn({ data: { mes: histSel!.mes, anio: histSel!.anio } }),
    enabled: !!histSel,
  });

  const q = filtro.trim().toLowerCase();
  const matchProv = (r: any) =>
    !q || r.proveedor.toLowerCase().includes(q) || r.servicio.toLowerCase().includes(q) || (r.estado ?? "").includes(q);
  const matchCuota = (r: any) =>
    !q || r.concepto.toLowerCase().includes(q) || r.servicio.toLowerCase().includes(q);

  const provs = (panel?.proveedores ?? []).filter(matchProv);
  const cuotas = (panel?.cuotas ?? []).filter(matchCuota);

  const totales = useMemo(() => {
    const provTotal = provs.reduce((a, b: any) => a + Number(b.a_pagar ?? 0), 0);
    const provDto = provs.reduce((a, b: any) => a + Number(b.a_descontar ?? 0), 0);
    const cuotaTotal = cuotas.reduce((a, b: any) => a + Number(b.total ?? 0), 0);
    return {
      lineas: provs.length + cuotas.length,
      sinConsumo: provs.filter((p: any) => p.sin_consumo).length + cuotas.filter((c: any) => c.sin_consumo).length,
      provTotal,
      cuotaTotal: cuotaTotal + provDto,
    };
  }, [provs, cuotas]);

  const vigLbl = panel ? `${MESES[panel.mes - 1]} ${panel.anio}` : "…";

  async function cambiarEstado(ids: string[], estado: string) {
    if (!estado || !ids?.length) return;
    try {
      for (const id of ids) await setEstado({ data: { id, estado: estado as any } });
      qc.invalidateQueries({ queryKey: ["cargas-panel"] });
      toast.success(ids.length > 1 ? `Estado actualizado en ${ids.length} cargas` : "Estado actualizado");
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo actualizar");
    }
  }

  async function exportar(row: any, nombre: string) {
    if (!row.detalle?.length) return toast.error("No hay descuentos para exportar");
    try {
      const sheet = row.detalle.map((i: any) => ({
        Carga: i.carga ?? "",
        Fecha: i.fecha ?? "",
        Legajo: i.legajo,
        "Apellido y Nombre": i.apellido_nombre ?? "",
        Detalle: i.detalle ?? "",
        Importe: Number(i.importe),
        Cuota: i.cuota,
        Subsidio: Number(i.subsidio),
        "Descuento del período": Number(i.a_descontar),
      }));
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(sheet), "Liquidación");
      XLSX.writeFile(wb, `${nombre.replace(/[^\w\s-]/g, "")}.xlsx`);
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo exportar");
    }
  }

  async function exportarCuota(row: any, mes: number, anio: number) {
    if (!row.detalle?.length) return toast.error("No hay consumos para exportar");
    try {
      const ExcelJS = (await import("exceljs")).default;
      const wb = new ExcelJS.Workbook();
      const ws = wb.addWorksheet(row.concepto.slice(0, 28));

      const esColecta = row.key === "colectas";
      const destaca = row.key === "cumpleanos" || row.key === "circulos";
      const notaTitulo = row.key === "cumpleanos" ? "Agasajado del mes" : "Cobra este mes";

      const cols: { header: string; key: string; width: number }[] = [
        { header: row.key === "cumpleanos" ? "Cumpleaños" : "Grupo", key: "grupo", width: 34 },
      ];
      if (esColecta) cols.push({ header: "Beneficiario", key: "beneficiario", width: 32 });
      cols.push(
        { header: "Legajo", key: "legajo", width: 12 },
        { header: "Apellido y Nombre", key: "nombre", width: 32 },
        { header: "Cuota", key: "cuota", width: 10 },
        { header: "A descontar", key: "importe", width: 16 },
      );
      if (destaca) cols.push({ header: notaTitulo, key: "nota", width: 26 });
      ws.columns = cols;

      ws.getRow(1).font = { name: "Arial", bold: true };
      ws.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFE6E6E6" } };

      for (const d of row.detalle) {
        const r = ws.addRow({
          grupo: d.grupo,
          beneficiario: d.beneficiario ?? "",
          legajo: d.legajo,
          nombre: d.apellido_nombre ?? "",
          cuota: d.cuota,
          importe: Number(d.importe) || 0,
          nota: d.destacado ? (d.nota ?? "SI") : "",
        });
        r.font = { name: "Arial" };
        r.getCell("importe").numFmt = '$#,##0.00;($#,##0.00);-';
        if (destaca && d.destacado) {
          r.eachCell((cell) => {
            cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFFFF2A8" } };
            cell.font = { name: "Arial", bold: true };
          });
        }
      }

      const total = ws.addRow({ grupo: "TOTAL", importe: row.detalle.reduce((a: number, d: any) => a + (Number(d.importe) || 0), 0) });
      total.font = { name: "Arial", bold: true };
      total.getCell("importe").numFmt = '$#,##0.00;($#,##0.00);-';

      const buf = await wb.xlsx.writeBuffer();
      const url = URL.createObjectURL(new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }));
      const a = document.createElement("a");
      a.href = url;
      a.download = `${row.concepto.replace(/[^\w\s-]/g, "")}_${MESES[mes - 1]}_${anio}.xlsx`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo exportar");
    }
  }


  function tablaPanel(data: any, editable: boolean) {
    const p = (data?.proveedores ?? []).filter(matchProv);
    const c = (data?.cuotas ?? []).filter(matchCuota);
    return (
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-muted-foreground">
            <tr className="border-b">
              <th className="py-2 pr-3">Servicio</th>
              <th className="py-2 pr-3">Proveedor / Concepto</th>
              <th className="py-2 pr-3">Ítems</th>
              <th className="py-2 pr-3">Afiliados</th>
              <th className="py-2 pr-3">A descontar / pagar</th>
              <th className="py-2 pr-3">Estado</th>
              <th className="py-2" />
            </tr>
          </thead>
          <tbody>
            {c.map((row: any) => (
              <tr key={row.key} className={`border-b last:border-0 ${row.sin_consumo ? rojo : ""}`}>
                <td className="py-2 pr-3">{row.servicio}</td>
                <td className="py-2 pr-3 font-medium">{row.concepto}</td>
                <td className="py-2 pr-3">{row.detalle.length}</td>
                <td className="py-2 pr-3">{row.afiliados}</td>
                <td className="py-2 pr-3 font-medium">{currency.format(Number(row.total))}</td>
                <td className="py-2 pr-3 text-xs">
                  {row.sin_consumo ? (
                    <span className="flex items-center gap-1 text-destructive">
                      <AlertCircle className="h-3.5 w-3.5" /> Sin cuotas en el período
                    </span>
                  ) : editable ? (
                    <select
                      className="h-8 rounded-md border border-input bg-background px-2 text-xs capitalize"
                      value={cuotaEstados[`${data.anio}-${data.mes}:${row.key}`] ?? "enviada"}
                      onChange={(e) => cambiarEstadoCuota(`${data.anio}-${data.mes}:${row.key}`, e.target.value)}
                    >
                      {ESTADOS.map((e) => (
                        <option key={e} value={e}>
                          {e}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <span className="text-muted-foreground capitalize">
                      {cuotaEstados[`${data.anio}-${data.mes}:${row.key}`] ?? "Cuotas a liquidar"}
                    </span>
                  )}
                </td>
                <td className="py-2 text-right whitespace-nowrap">
                  <Button
                    size="sm"
                    variant="ghost"
                    disabled={row.sin_consumo}
                    onClick={() => setOpenCuota(openCuota === row.key ? null : row.key)}
                  >
                    {openCuota === row.key ? "Ocultar" : "Ver"}
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    disabled={row.sin_consumo}
                    onClick={() => exportarCuota(row, data.mes, data.anio)}
                  >
                    <Download className="h-4 w-4" />
                  </Button>
                </td>
              </tr>
            ))}
            {p.map((row: any) => (
              <tr key={row.key} className={`border-b last:border-0 ${row.sin_consumo ? rojo : ""}`}>
                <td className="py-2 pr-3">{row.servicio}</td>
                <td className="py-2 pr-3 font-medium">
                  {row.proveedor}
                  {row.cargas > 1 && (
                    <span className="ml-2 text-xs font-normal text-muted-foreground">({row.cargas} cargas)</span>
                  )}
                </td>
                <td className="py-2 pr-3">{row.items}</td>
                <td className="py-2 pr-3">{row.afiliados}</td>
                <td className="py-2 pr-3 font-medium">
                  {currency.format(Number(row.a_pagar))}
                  {Number(row.a_descontar) > 0 && (
                    <div className="text-xs font-normal text-muted-foreground">
                      Dto. período: {currency.format(Number(row.a_descontar))}
                    </div>
                  )}
                </td>
                <td className="py-2 pr-3">
                  {!row.submission_ids?.length ? (
                    row.detalle?.length ? (
                      <span className="text-xs text-muted-foreground">Cuotas vigentes</span>
                    ) : (
                      <span className="flex items-center gap-1 text-xs text-destructive">
                        <AlertCircle className="h-3.5 w-3.5" /> No cargó consumos
                      </span>
                    )
                  ) : editable ? (
                    <select
                      className="h-8 rounded-md border border-input bg-background px-2 text-xs capitalize"
                      value={row.estados?.length === 1 ? row.estados[0] : row.estado ?? ""}
                      onChange={(e) => cambiarEstado(row.submission_ids, e.target.value)}
                    >
                      {row.estados?.length > 1 && <option value="">varios…</option>}
                      {ESTADOS.map((e) => (
                        <option key={e} value={e}>
                          {e}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <span className="text-xs capitalize text-muted-foreground">{row.estados?.join(", ") ?? row.estado}</span>
                  )}
                </td>
                <td className="py-2 text-right whitespace-nowrap">
                  <Button
                    size="sm"
                    variant="ghost"
                    disabled={!row.detalle?.length}
                    onClick={() =>
                      setOpenProv(
                        openProv?.key === row.key
                          ? null
                          : {
                              key: row.key,
                              ids: row.submission_ids ?? [],
                              nombre: row.proveedor,
                              servicio: row.servicio,
                              detalle: row.detalle ?? [],
                            },
                      )
                    }
                  >
                    {openProv?.key === row.key ? "Ocultar" : "Ver"}
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    disabled={!row.detalle?.length}
                    onClick={() => exportar(row, `${row.proveedor} ${row.servicio} ${MESES[data.mes - 1]} ${data.anio}`)}
                  >
                    <Download className="h-4 w-4" />
                  </Button>
                </td>
              </tr>
            ))}
            {!p.length && !c.length && (
              <tr>
                <td colSpan={7} className="py-3 text-sm text-muted-foreground">
                  No hay servicios ni proveedores para mostrar.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    );
  }

  const cuotaAbierta = [...(panel?.cuotas ?? []), ...(hist?.cuotas ?? [])].find((c: any) => c.key === openCuota);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Servicios y proveedores del período</h1>
        <p className="text-sm text-muted-foreground">
          Todo lo que se liquida en el período abierto, con lo que cada proveedor y cada servicio con cuotas presenta.
        </p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Buscar servicio o proveedor</CardTitle>
          <CardDescription>Escribí un nombre de servicio o de proveedor para filtrar todo lo de abajo.</CardDescription>
        </CardHeader>
        <CardContent>
          <Input
            className="max-w-md"
            placeholder="Buscar por servicio o proveedor…"
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
        </CardContent>
      </Card>

      <div className="grid gap-4 sm:grid-cols-4">
        {[
          { t: "Líneas del período", v: String(totales.lineas) },
          { t: "Sin consumos", v: String(totales.sinConsumo) },
          { t: "Proveedores a pagar", v: currency.format(totales.provTotal) },
          { t: "Cuotas a descontar", v: currency.format(totales.cuotaTotal) },
        ].map((c) => (
          <Card key={c.t}>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-muted-foreground">{c.t}</CardTitle>
            </CardHeader>
            <CardContent className="text-xl font-bold">{c.v}</CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Período vigente · {vigLbl}</CardTitle>
          <CardDescription>
            Las filas en rojo tenue son servicios o proveedores que todavía no cargaron consumos en este período.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? <p className="text-sm text-muted-foreground">Cargando…</p> : tablaPanel(panel, true)}
        </CardContent>
      </Card>

      {openCuota && cuotaAbierta && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Detalle · {cuotaAbierta.concepto}</CardTitle>
            <CardDescription>Cada descuento con su legajo, cuota e importe.</CardDescription>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground">
                <tr className="border-b">
                  <th className="py-2 pr-3">{cuotaAbierta.key === "cumpleanos" ? "Cumpleaños" : "Grupo"}</th>
                  {cuotaAbierta.key === "colectas" && <th className="py-2 pr-3">Beneficiario</th>}
                  <th className="py-2 pr-3">Legajo</th>
                  <th className="py-2 pr-3">Afiliado</th>
                  <th className="py-2 pr-3">Cuota</th>
                  <th className="py-2 pr-3">A descontar</th>
                  {(cuotaAbierta.key === "cumpleanos" || cuotaAbierta.key === "circulos") && (
                    <th className="py-2 pr-3">{cuotaAbierta.key === "cumpleanos" ? "Agasajado del mes" : "Cobra este mes"}</th>
                  )}
                </tr>
              </thead>
              <tbody>
                {cuotaAbierta.detalle.map((d: any, i: number) => (
                  <tr
                    key={`${d.legajo}-${i}`}
                    className={`border-b last:border-0 ${d.destacado ? "bg-yellow-100 font-medium dark:bg-yellow-500/20" : ""}`}
                  >
                    <td className="py-1.5 pr-3">{d.grupo}</td>
                    {cuotaAbierta.key === "colectas" && <td className="py-1.5 pr-3">{d.beneficiario ?? "—"}</td>}
                    <td className="py-1.5 pr-3 font-mono">{d.legajo}</td>
                    <td className="py-1.5 pr-3">{d.apellido_nombre ?? "—"}</td>
                    <td className="py-1.5 pr-3">{d.cuota}</td>
                    <td className="py-1.5 pr-3">{currency.format(Number(d.importe))}</td>
                    {(cuotaAbierta.key === "cumpleanos" || cuotaAbierta.key === "circulos") && (
                      <td className="py-1.5 pr-3 text-xs">{d.destacado ? (d.nota ?? "SI") : ""}</td>
                    )}
                  </tr>
                ))}

              </tbody>
            </table>
          </CardContent>
        </Card>
      )}

      {openProv && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Detalle · {openProv.nombre} · {openProv.servicio}</CardTitle>
            <CardDescription>
              Lo que se descuenta a cada afiliado en este período, incluidas las cuotas de cargas de meses anteriores.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr className="border-b">
                    <th className="py-2 pr-3">Carga</th>
                    <th className="py-2 pr-3">Fecha</th>
                    <th className="py-2 pr-3">Legajo</th>
                    <th className="py-2 pr-3">Afiliado</th>
                    <th className="py-2 pr-3">Detalle</th>
                    <th className="py-2 pr-3">Importe</th>
                    <th className="py-2 pr-3">Cuota</th>
                    <th className="py-2 pr-3">Subsidio</th>
                    <th className="py-2 pr-3">Dto. del período</th>
                  </tr>
                </thead>
                <tbody>
                  {openProv.detalle.map((i: any, idx: number) => (
                    <tr key={`${i.legajo}-${idx}`} className="border-b last:border-0">
                      <td className="py-1.5 pr-3 text-xs text-muted-foreground">{i.carga || "—"}</td>
                      <td className="py-1.5 pr-3">{i.fecha ?? "—"}</td>
                      <td className="py-1.5 pr-3 font-mono">{i.legajo}</td>
                      <td className="py-1.5 pr-3">{i.apellido_nombre ?? "—"}</td>
                      <td className="py-1.5 pr-3">{i.detalle ?? "—"}</td>
                      <td className="py-1.5 pr-3">{currency.format(Number(i.importe))}</td>
                      <td className="py-1.5 pr-3">{i.cuota}</td>
                      <td className="py-1.5 pr-3">{currency.format(Number(i.subsidio))}</td>
                      <td className="py-1.5 pr-3 font-medium">{currency.format(Number(i.a_descontar))}</td>
                    </tr>
                  ))}
                  {!openProv.detalle.length && (
                    <tr><td colSpan={9} className="py-3 text-muted-foreground">Sin descuentos en este período.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="flex-row items-center justify-between gap-3">
          <div>
            <CardTitle className="text-base">Histórico por período</CardTitle>
            <CardDescription>Elegí un período anterior para ver sus consumos y bajar sus liquidaciones.</CardDescription>
          </div>
          <select
            className="h-10 rounded-md border border-input bg-background px-3 text-sm"
            value={histKey}
            onChange={(e) => setHistKey(e.target.value)}
          >
            <option value="">Elegí un período…</option>
            {(periodos ?? [])
              .filter((p: any) => !panel || p.anio * 12 + p.mes !== panel.anio * 12 + panel.mes)
              .map((p: any) => (
                <option key={`${p.anio}-${p.mes}`} value={`${p.anio}-${p.mes}`}>
                  {MESES[p.mes - 1]} {p.anio}
                </option>
              ))}
          </select>
        </CardHeader>
        <CardContent>
          {!histSel ? (
            <p className="text-sm text-muted-foreground">Seleccioná un período para ver el histórico.</p>
          ) : histLoading ? (
            <p className="text-sm text-muted-foreground">Cargando…</p>
          ) : (
            tablaPanel(hist, false)
          )}
        </CardContent>
      </Card>
    </div>
  );
}
