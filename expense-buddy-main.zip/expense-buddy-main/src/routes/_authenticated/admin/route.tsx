import { createFileRoute, Outlet, redirect, Link, useLocation } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listServices } from "@/lib/crm.functions";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { UtensilsCrossed, LogOut, ChevronDown } from "lucide-react";
import { BackButton } from "@/components/BackButton";

export const Route = createFileRoute("/_authenticated/admin")({
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/auth/admin" });
    const { data: roleRow } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", data.user.id)
      .eq("role", "admin")
      .maybeSingle();
    if (!roleRow) throw redirect({ to: "/" });
  },
  component: AdminLayout,
});

function AdminLayout() {
  const list = useServerFn(listServices);
  const { pathname } = useLocation();
  const enAdelantos = pathname.startsWith("/admin/adelantos");
  const { data: services } = useQuery({
    queryKey: ["services"],
    queryFn: () => list({ data: undefined as any }),
  });


  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/admin" className="flex items-center gap-2 font-semibold">
            <UtensilsCrossed className="h-5 w-5 text-primary" />
            <span>Panel Admin</span>
          </Link>
          <nav className="flex items-center gap-1 flex-wrap">
            <Button asChild variant="ghost" size="sm">
              <Link to="/admin" activeOptions={{ exact: true }}>
                Estadísticas
              </Link>
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm">
                  Servicios <ChevronDown className="h-3.5 w-3.5 ml-1" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                <DropdownMenuLabel>Servicios habilitados</DropdownMenuLabel>
                {(services ?? []).map((s: any) => (
                  <DropdownMenuItem key={s.id} asChild>
                    {s.codigo === "adelantos" ? (
                      <Link to="/admin/adelantos">{s.nombre}</Link>
                    ) : /^refinanc/i.test(
                        String(s.nombre ?? "")
                          .normalize("NFD")
                          .replace(/[\u0300-\u036f]/g, ""),
                      ) ? (
                      <Link to="/admin/refinanciacion">{s.nombre}</Link>
                    ) : (
                      <Link to="/admin/servicio/$codigo" params={{ codigo: s.codigo }}>
                        {s.nombre}
                      </Link>
                    )}
                  </DropdownMenuItem>
                ))}
                {!enAdelantos && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link to="/admin/servicios">Configurar servicios</Link>
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>


            </DropdownMenu>

            <Button asChild variant="ghost" size="sm">
              <Link to="/admin/proveedores">Proveedores</Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link to="/admin/afiliados">Afiliados</Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link to="/admin/cargas">Cargas</Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link to="/admin/crm">Buscador CRM</Link>
            </Button>

            <Button asChild variant="ghost" size="sm">
              <Link to="/admin/informes">Informes contables</Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link to="/admin/liquidacion">Liquidación</Link>
            </Button>


            <Button asChild variant="ghost" size="sm">
              <Link to="/admin/usuarios">Usuarios</Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link to="/admin/mensajes">Mensajes</Link>
            </Button>

            <Button
              variant="ghost"
              size="sm"
              onClick={async () => {
                await supabase.auth.signOut();
                window.location.href = "/";
              }}
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </nav>
        </div>
      </header>
      <main className="max-w-6xl mx-auto px-4 py-6">
        {pathname !== "/admin" && (
          <div className="mb-4">
            <BackButton fallback="/admin" />
          </div>
        )}
        <Outlet />
      </main>
    </div>
  );
}
