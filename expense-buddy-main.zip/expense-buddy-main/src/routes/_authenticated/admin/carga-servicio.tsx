import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listProviders, adminPreviewLiquidation, adminSubmitLiquidation } from "@/lib/crm.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Trash2, Upload } from "lucide-react";
import * as XLSX from "xlsx";
import { toast } from "sonner";
import { compareLegajo } from "@/lib/legajo";

export const Route = createFileRoute("/_authenticated/admin/carga-servicio")({
  component: CargaServicio,
  head: () => ({
    meta: [
      { title: "Cargar consumos de servicios de AGOEC" },
      { name: "description", content: "El administrador carga los consumos de los servicios que presta AGOEC, por Excel o manualmente." },
      { property: "og:title", content: "Cargar consumos de servicios de AGOEC" },
      { property: "og:description", content: "Carga administrativa de consumos por servicio con subsidios y cuotas calculados." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const currency = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });

type Row = {
  uid: number;
  legajo: string;
  fecha: string;
  detalle: string;
  comprobante: string;
  importe: number;
  cuotas: number;
  con_receta: boolean;
  es_cumpleanos: boolean;
};

let seq = 1;
const newRow = (): Row => ({
  uid: seq++,
  legajo: "",
  fecha: new Date().toISOString().slice(0, 10),
  detalle: "",
  comprobante: "",
  importe: 0,
  cuotas: 1,
  con_receta: false,
  es_cumpleanos: false,
});

function CargaServicio() {
  const provsFn = useServerFn(listProviders);
  const previewFn = useServerFn(adminPreviewLiquidation);
  const submitFn = useServerFn(adminSubmitLiquidation);

  const hoy = new Date();
  const [providerId, setProviderId] = useState("");
  const [nombre, setNombre] = useState("");
  const [mes, setMes] = useState(hoy.getMonth() + 1);
  const [anio, setAnio] = useState(hoy.getFullYear());
  const [rows, setRows] = useState<Row[]>([newRow()]);
  const [preview, setPreview] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  const { data: provs } = useQuery({
    queryKey: ["providers"],
    queryFn: () => provsFn({ data: undefined as any }),
  });

  const internos = useMemo(
    () => (provs ?? []).filter((p: any) => (p.tipo ?? (p.interno ? "interno" : "externo")) !== "externo"),
    [provs],
  );
  const provider: any = (provs ?? []).find((p: any) => p.id === providerId);

  const ordenadas = useMemo(
    () => rows.slice().sort((a, b) => compareLegajo(a.legajo, b.legajo)),
    [rows],
  );

  function set(uid: number, patch: Partial<Row>) {
    setRows((r) => r.map((x) => (x.uid === uid ? { ...x, ...patch } : x)));
  }

  function importarExcel(file: File) {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const wb = XLSX.read(e.target?.result, { type: "array" });
        const json = XLSX.utils.sheet_to_json<any>(wb.Sheets[wb.SheetNames[0]], { defval: "" });
        const parsed: Row[] = json
          .map((r) => {
            const get = (...keys: string[]) => {
              for (const k of Object.keys(r)) {
                const norm = k.toString().trim().toLowerCase();
                if (keys.some((kk) => norm.includes(kk))) return r[k];
              }
              return "";
            };
            return {
              uid: seq++,
              legajo: String(get("legajo") ?? "").trim().toUpperCase(),
              fecha: String(get("fecha") ?? "").slice(0, 10),
              detalle: String(get("detalle", "producto", "descrip") ?? ""),
              comprobante: String(get("comprobante", "compro", "factura") ?? ""),
              importe: Number(String(get("importe", "monto", "total")).replace(",", ".")) || 0,
              cuotas: Math.max(1, Number(get("cuota")) || 1),
              con_receta: /si|sí|x|true|1/i.test(String(get("receta") ?? "")),
              es_cumpleanos: /si|sí|x|true|1/i.test(String(get("cumple") ?? "")),
            };
          })
          .filter((r) => r.legajo);
        if (!parsed.length) return toast.error("No se encontraron filas con legajo");
        setRows(parsed);
        setPreview(null);
        toast.success(`${parsed.length} consumos importados`);
      } catch {
        toast.error("No se pudo leer el Excel");
      }
    };
    reader.readAsArrayBuffer(file);
  }

  const payload = () =>
    rows
      .filter((r) => r.legajo.trim())
      .map((r) => ({
        legajo: r.legajo.trim().toUpperCase(),
        fecha: r.fecha || null,
        detalle: r.detalle || null,
        comprobante: r.comprobante || null,
        importe: Number(r.importe) || 0,
        cuotas: Math.max(1, Number(r.cuotas) || 1),
        con_receta: r.con_receta,
        es_cumpleanos: r.es_cumpleanos,
      }));

  async function calcular() {
    if (!providerId) return toast.error("Elegí el prestador");
    const items = payload();
    if (!items.length) return toast.error("Cargá al menos un consumo");
    setBusy(true);
    try {
      setPreview(await previewFn({ data: { provider_id: providerId, items } }));
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo calcular");
    } finally {
      setBusy(false);
    }
  }

  async function guardar() {
    if (!providerId) return toast.error("Elegí el prestador");
    const items = payload();
    if (!items.length) return toast.error("Cargá al menos un consumo");
    setBusy(true);
    try {
      await submitFn({
        data: {
          provider_id: providerId,
          nombre: nombre || `${provider?.nombre ?? "Servicio"} ${mes}/${anio}`,
          periodo_mes: mes,
          periodo_anio: anio,
          observacion: null,
          items,
        },
      });
      toast.success("Consumos cargados y aprobados");
      setRows([newRow()]);
      setPreview(null);
      setNombre("");
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo guardar");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Cargar consumos de AGOEC</h1>
        <p className="text-sm text-muted-foreground">
          Para los servicios que presta AGOEC (prestadores de tipo “De AGOEC” o internos) los consumos
          los carga la administración.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Datos de la liquidación</CardTitle>
          <CardDescription>
            {provider
              ? `Servicio: ${provider.services?.nombre ?? "—"}${
                  provider.services?.usa_receta
                    ? ` · subsidio con receta ${provider.services.subsidio_receta_pct}%`
                    : ""
                }`
              : "Elegí el prestador para ver su configuración."}
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-4">
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="prov">Prestador</Label>
            <select
              id="prov"
              className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
              value={providerId}
              onChange={(e) => {
                setProviderId(e.target.value);
                setPreview(null);
              }}
            >
              <option value="">Elegí un prestador…</option>
              {internos.map((p: any) => (
                <option key={p.id} value={p.id}>
                  {p.nombre} · {p.services?.nombre ?? "—"} ·{" "}
                  {(p.tipo ?? "interno") === "agoec" ? "De AGOEC" : "Interno"}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="mes">Mes</Label>
            <Input id="mes" type="number" min={1} max={12} value={mes} onChange={(e) => setMes(Number(e.target.value))} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="anio">Año</Label>
            <Input id="anio" type="number" value={anio} onChange={(e) => setAnio(Number(e.target.value))} />
          </div>
          <div className="space-y-2 sm:col-span-4">
            <Label htmlFor="nom">Nombre de la liquidación</Label>
            <Input
              id="nom"
              value={nombre}
              onChange={(e) => setNombre(e.target.value)}
              placeholder={`${provider?.nombre ?? "Servicio"} ${mes}/${anio}`}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex-row flex-wrap items-center justify-between gap-3">
          <CardTitle className="text-base">Consumos ({rows.length})</CardTitle>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" asChild>
              <label className="cursor-pointer">
                <Upload className="h-4 w-4" /> Importar Excel
                <input
                  type="file"
                  accept=".xlsx,.xls,.csv"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && importarExcel(e.target.files[0])}
                />
              </label>
            </Button>
            <Button variant="outline" size="sm" onClick={() => setRows((r) => [...r, newRow()])}>
              <Plus className="h-4 w-4" /> Agregar fila
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground">
                <tr className="border-b">
                  <th className="py-2 pr-2">Fecha</th>
                  <th className="py-2 pr-2">Legajo</th>
                  <th className="py-2 pr-2">Detalle</th>
                  <th className="py-2 pr-2">Comprob.</th>
                  <th className="py-2 pr-2">Importe</th>
                  <th className="py-2 pr-2">Cuotas</th>
                  {provider?.services?.usa_receta && <th className="py-2 pr-2">Receta</th>}
                  {provider?.services?.permite_cumpleanos && <th className="py-2 pr-2">Cumple</th>}
                  <th className="py-2" />
                </tr>
              </thead>
              <tbody>
                {ordenadas.map((r) => (
                  <tr key={r.uid} className="border-b last:border-0">
                    <td className="py-1 pr-2">
                      <Input
                        type="date"
                        className="h-8 w-36"
                        value={r.fecha}
                        onChange={(e) => set(r.uid, { fecha: e.target.value })}
                      />
                    </td>
                    <td className="py-1 pr-2">
                      <Input
                        className="h-8 w-28 font-mono"
                        value={r.legajo}
                        onChange={(e) => set(r.uid, { legajo: e.target.value.toUpperCase() })}
                      />
                    </td>
                    <td className="py-1 pr-2">
                      <Input
                        className="h-8 min-w-48"
                        value={r.detalle}
                        onChange={(e) => set(r.uid, { detalle: e.target.value })}
                      />
                    </td>
                    <td className="py-1 pr-2">
                      <Input
                        className="h-8 w-28"
                        value={r.comprobante}
                        onChange={(e) => set(r.uid, { comprobante: e.target.value })}
                      />
                    </td>
                    <td className="py-1 pr-2">
                      <Input
                        type="number"
                        step="0.01"
                        className="h-8 w-28"
                        value={r.importe}
                        onChange={(e) => set(r.uid, { importe: Number(e.target.value) })}
                      />
                    </td>
                    <td className="py-1 pr-2">
                      <Input
                        type="number"
                        min={1}
                        className="h-8 w-20"
                        value={r.cuotas}
                        onChange={(e) => set(r.uid, { cuotas: Number(e.target.value) })}
                      />
                    </td>
                    {provider?.services?.usa_receta && (
                      <td className="py-1 pr-2">
                        <Checkbox
                          checked={r.con_receta}
                          onCheckedChange={(v) => set(r.uid, { con_receta: !!v })}
                        />
                      </td>
                    )}
                    {provider?.services?.permite_cumpleanos && (
                      <td className="py-1 pr-2">
                        <Checkbox
                          checked={r.es_cumpleanos}
                          onCheckedChange={(v) => set(r.uid, { es_cumpleanos: !!v })}
                        />
                      </td>
                    )}
                    <td className="py-1 text-right">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setRows((rs) => rs.filter((x) => x.uid !== r.uid))}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button variant="outline" onClick={calcular} disabled={busy}>
              Calcular totales
            </Button>
            <Button onClick={guardar} disabled={busy}>
              {busy ? "Guardando…" : "Guardar consumos"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {preview && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">
              Vista previa · {preview.proveedor} · {preview.servicio}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-4">
              {[
                { t: "Consumos", v: String(preview.total_items) },
                { t: "Afiliados", v: String(preview.total_afiliados) },
                { t: "Importe total", v: currency.format(preview.total_importe) },
                { t: "A descontar", v: currency.format(preview.total_descuento) },
              ].map((c) => (
                <div key={c.t} className="rounded-lg border p-3">
                  <p className="text-xs text-muted-foreground">{c.t}</p>
                  <p className="text-lg font-bold">{c.v}</p>
                </div>
              ))}
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr className="border-b">
                    <th className="py-2 pr-3">Legajo</th>
                    <th className="py-2 pr-3">Afiliado</th>
                    <th className="py-2 pr-3">Importe</th>
                    <th className="py-2 pr-3">Subsidio</th>
                    <th className="py-2 pr-3">A descontar</th>
                  </tr>
                </thead>
                <tbody>
                  {preview.rows.map((r: any, idx: number) => (
                    <tr key={idx} className={`border-b last:border-0 ${r.valido ? "" : "bg-destructive/10"}`}>
                      <td className="py-1.5 pr-3 font-mono">{r.legajo}</td>
                      <td className="py-1.5 pr-3">{r.apellido_nombre ?? "Legajo no encontrado"}</td>
                      <td className="py-1.5 pr-3">{currency.format(Number(r.importe))}</td>
                      <td className="py-1.5 pr-3">{currency.format(Number(r.subsidio))}</td>
                      <td className="py-1.5 pr-3 font-medium">
                        {currency.format(Number(r.importe_afiliado))}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
