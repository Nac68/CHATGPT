import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listServices, upsertService } from "@/lib/crm.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Pencil, Plus } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/servicios")({
  component: Servicios,
  head: () => ({
    meta: [
      { title: "Servicios del CRM · AGOEC" },
      { name: "description", content: "Alta y configuración de servicios de AGOEC: farmacia, supermercado, comida a descuento y más." },
      { property: "og:title", content: "Servicios del CRM · AGOEC" },
      { property: "og:description", content: "Configurá cada servicio de AGOEC: subsidios por receta, cuotas y cumpleaños." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

type Form = {
  id?: string;
  nombre: string;
  codigo: string;
  descripcion: string;
  activo: boolean;
  usa_receta: boolean;
  subsidio_receta_pct: number;
  permite_cuotas: boolean;
  permite_cumpleanos: boolean;
};

const EMPTY: Form = {
  nombre: "",
  codigo: "",
  descripcion: "",
  activo: true,
  usa_receta: false,
  subsidio_receta_pct: 0,
  permite_cuotas: true,
  permite_cumpleanos: false,
};

function Servicios() {
  const list = useServerFn(listServices);
  const save = useServerFn(upsertService);
  const qc = useQueryClient();
  const [form, setForm] = useState<Form>(EMPTY);
  const [saving, setSaving] = useState(false);

  const { data } = useQuery({ queryKey: ["services"], queryFn: () => list({ data: undefined as any }) });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      await save({
        data: {
          ...(form.id ? { id: form.id } : {}),
          nombre: form.nombre,
          codigo: form.codigo || form.nombre,
          descripcion: form.descripcion || null,
          activo: form.activo,
          usa_receta: form.usa_receta,
          subsidio_receta_pct: Number(form.subsidio_receta_pct) || 0,
          permite_cuotas: form.permite_cuotas,
          permite_cumpleanos: form.permite_cumpleanos,
          campos_requeridos: ["fecha", "legajo", "detalle", "importe"],
        } as any,
      });
      toast.success(form.id ? "Servicio actualizado" : "Servicio creado");
      setForm(EMPTY);
      qc.invalidateQueries({ queryKey: ["services"] });
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo guardar");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Servicios</h1>
        <p className="text-sm text-muted-foreground">
          Cada servicio define cómo se liquidan los consumos de los afiliados.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            {form.id ? <Pencil className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
            {form.id ? "Editar servicio" : "Nuevo servicio"}
          </CardTitle>
          <CardDescription>Ej: Farmacia con 15% de subsidio para productos con receta.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="nombre">Nombre</Label>
              <Input
                id="nombre"
                value={form.nombre}
                onChange={(e) => setForm({ ...form, nombre: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="codigo">Código</Label>
              <Input
                id="codigo"
                value={form.codigo}
                onChange={(e) => setForm({ ...form, codigo: e.target.value })}
                placeholder="farmacia"
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="desc">Descripción</Label>
              <Textarea
                id="desc"
                rows={2}
                value={form.descripcion}
                onChange={(e) => setForm({ ...form, descripcion: e.target.value })}
              />
            </div>
            <div className="space-y-3">
              <label className="flex items-center gap-2 text-sm">
                <Checkbox
                  checked={form.activo}
                  onCheckedChange={(v) => setForm({ ...form, activo: !!v })}
                />
                Servicio activo
              </label>
              <label className="flex items-center gap-2 text-sm">
                <Checkbox
                  checked={form.permite_cuotas}
                  onCheckedChange={(v) => setForm({ ...form, permite_cuotas: !!v })}
                />
                Permite cuotas
              </label>
              <label className="flex items-center gap-2 text-sm">
                <Checkbox
                  checked={form.permite_cumpleanos}
                  onCheckedChange={(v) => setForm({ ...form, permite_cumpleanos: !!v })}
                />
                Permite marcar cumpleaños (sin cargo)
              </label>
            </div>
            <div className="space-y-3">
              <label className="flex items-center gap-2 text-sm">
                <Checkbox
                  checked={form.usa_receta}
                  onCheckedChange={(v) => setForm({ ...form, usa_receta: !!v })}
                />
                Distingue productos con receta
              </label>
              <div className="space-y-2">
                <Label htmlFor="pct">Subsidio con receta (%)</Label>
                <Input
                  id="pct"
                  type="number"
                  min={0}
                  max={100}
                  step="0.1"
                  disabled={!form.usa_receta}
                  value={form.subsidio_receta_pct}
                  onChange={(e) => setForm({ ...form, subsidio_receta_pct: Number(e.target.value) })}
                />
              </div>
            </div>
            <div className="sm:col-span-2 flex gap-2">
              <Button type="submit" disabled={saving}>
                {saving ? "Guardando…" : form.id ? "Guardar cambios" : "Crear servicio"}
              </Button>
              {form.id && (
                <Button type="button" variant="outline" onClick={() => setForm(EMPTY)}>
                  Cancelar
                </Button>
              )}
            </div>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Servicios configurados</CardTitle>
        </CardHeader>
        <CardContent>
          {!data?.length ? (
            <p className="text-sm text-muted-foreground">Todavía no hay servicios.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr className="border-b">
                    <th className="py-2 pr-3">Servicio</th>
                    <th className="py-2 pr-3">Código</th>
                    <th className="py-2 pr-3">Receta</th>
                    <th className="py-2 pr-3">Subsidio</th>
                    <th className="py-2 pr-3">Cuotas</th>
                    <th className="py-2 pr-3">Cumpleaños</th>
                    <th className="py-2 pr-3">Estado</th>
                    <th className="py-2" />
                  </tr>
                </thead>
                <tbody>
                  {data.map((s: any) => (
                    <tr key={s.id} className="border-b last:border-0">
                      <td className="py-2 pr-3 font-medium">{s.nombre}</td>
                      <td className="py-2 pr-3 font-mono text-xs">{s.codigo}</td>
                      <td className="py-2 pr-3">{s.usa_receta ? "Sí" : "—"}</td>
                      <td className="py-2 pr-3">{s.usa_receta ? `${s.subsidio_receta_pct}%` : "—"}</td>
                      <td className="py-2 pr-3">{s.permite_cuotas ? "Sí" : "—"}</td>
                      <td className="py-2 pr-3">{s.permite_cumpleanos ? "Sí" : "—"}</td>
                      <td className="py-2 pr-3">{s.activo ? "Activo" : "Inactivo"}</td>
                      <td className="py-2 text-right">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() =>
                            setForm({
                              id: s.id,
                              nombre: s.nombre,
                              codigo: s.codigo,
                              descripcion: s.descripcion ?? "",
                              activo: s.activo,
                              usa_receta: s.usa_receta,
                              subsidio_receta_pct: Number(s.subsidio_receta_pct ?? 0),
                              permite_cuotas: s.permite_cuotas,
                              permite_cumpleanos: s.permite_cumpleanos,
                            })
                          }
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
