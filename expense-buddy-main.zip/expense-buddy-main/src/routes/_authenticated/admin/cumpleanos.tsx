import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import * as XLSX from "xlsx";
import { toast } from "sonner";
import {
  listBirthdayPlans,
  saveBirthdayPlan,
  deleteBirthdayPlan,
  birthdaysSettlement,
} from "@/lib/birthdays.functions";
import { useAffiliateNames } from "@/hooks/use-affiliate-names";
import { compareLegajo } from "@/lib/legajo";
import { parsePeriodo, periodoNumero } from "@/lib/periodo";
import { ImportPreview, type ImportPreviewData } from "@/components/ImportPreview";
import { IntegrantesDialog } from "@/components/IntegrantesDialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Cake, Download, Plus, Trash2, Upload, Wand2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/cumpleanos")({
  validateSearch: (s: Record<string, unknown>): { product_id?: string; service_id?: string } => ({
    product_id: typeof s.product_id === "string" ? s.product_id : undefined,
    service_id: typeof s.service_id === "string" ? s.service_id : undefined,
  }),
  component: CumpleanosAdmin,
  head: () => ({
    meta: [
      { title: "Cumpleaños · AGOEC" },
      {
        name: "description",
        content:
          "Cargá el servicio de Cumpleaños de AGOEC: importe que cobra el agasajado, período de descuentos y cuotas mensuales por afiliado.",
      },
      { property: "og:title", content: "Cumpleaños · AGOEC" },
      {
        property: "og:description",
        content: "Alta manual o por Excel de los planes de cumpleaños y su liquidación mensual.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const MESES = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre",
];

const money = (n: number) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" }).format(Number(n) || 0);

const uid = () => Math.random().toString(36).slice(2);

const toNumber = (v: unknown) => {
  const s = String(v ?? "").replace(/[^\d,.-]/g, "");
  const norm =
    s.includes(",") && s.lastIndexOf(",") > s.lastIndexOf(".")
      ? s.replace(/\./g, "").replace(",", ".")
      : s.replace(/,/g, "");
  return Number(norm) || 0;
};

const txt = (v: unknown) => String(v ?? "").trim();
const norm = (v: unknown) =>
  txt(v)
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");

/** Serial de Excel o texto -> yyyy-mm-dd */
function toISODate(v: unknown): string {
  if (v === "" || v == null) return "";
  if (typeof v === "number" && v > 20000 && v < 80000) {
    const d = new Date(Date.UTC(1899, 11, 30) as any);
    d.setUTCDate(d.getUTCDate() + Math.round(v));
    return d.toISOString().slice(0, 10);
  }
  const s = txt(v);
  const dmy = s.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})$/);
  if (dmy) {
    const y = dmy[3].length === 2 ? `20${dmy[3]}` : dmy[3];
    return `${y}-${dmy[2].padStart(2, "0")}-${dmy[1].padStart(2, "0")}`;
  }
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
  return "";
}

/** YYYYMM <-> {mes, anio} */
const periodParts = (p: number) => ({ anio: Math.floor(p / 100), mes: p % 100 });
const periodIndex = (p: number) => {
  const { anio, mes } = periodParts(p);
  return anio * 12 + (mes - 1);
};
const cuotasEntre = (ini: number, fin: number) => {
  if (!ini || !fin) return 12;
  const n = periodIndex(fin) - periodIndex(ini) + 1;
  return Math.min(24, Math.max(1, n));
};

type Row = {
  uid: string;
  legajo: string;
  fecha_cobro: string;
  cuotas: string[];
  observacion: string;
};

const emptyRow = (n: number): Row => ({
  uid: uid(),
  legajo: "",
  fecha_cobro: "",
  cuotas: Array.from({ length: n }, () => ""),
  observacion: "",
});

function CumpleanosAdmin() {
  const { product_id, service_id } = Route.useSearch();
  const qc = useQueryClient();
  const load = useServerFn(listBirthdayPlans);
  const save = useServerFn(saveBirthdayPlan);
  const del = useServerFn(deleteBirthdayPlan);
  const liq = useServerFn(birthdaysSettlement);

  const [editId, setEditId] = useState<string | undefined>();
  const [nombre, setNombre] = useState("");
  const [importeTotal, setImporteTotal] = useState("");
  const [pIni, setPIni] = useState("");
  const [pFin, setPFin] = useState("");
  const [observacion, setObservacion] = useState("");
  const [rows, setRows] = useState<Row[]>([emptyRow(12)]);
  const [aplicar, setAplicar] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const excelRef = useRef<HTMLInputElement>(null);

  const hoy = new Date();
  const [mes, setMes] = useState(hoy.getMonth() + 1);
  const [anio, setAnio] = useState(hoy.getFullYear());
  const [preview, setPreview] = useState<(ImportPreviewData & { _rows?: Row[] }) | null>(null);

  const nCuotas = useMemo(() => cuotasEntre(Number(pIni), Number(pFin)), [pIni, pFin]);
  const names = useAffiliateNames(rows.map((r) => r.legajo));

  const { data } = useQuery({
    queryKey: ["birthday-plans", product_id],
    queryFn: () => load({ data: product_id ? { product_id } : {} }),
  });

  const { data: settle } = useQuery({
    queryKey: ["birthday-settlement", mes, anio, product_id],
    queryFn: () => liq({ data: { mes, anio, ...(product_id ? { product_id } : {}) } }),
  });

  const totalDescuentos = rows.reduce(
    (a, r) => a + r.cuotas.slice(0, nCuotas).reduce((x, c) => x + toNumber(c), 0),
    0,
  );

  function setCell(u: string, i: number, v: string) {
    setRows((rs) =>
      rs.map((r) => {
        if (r.uid !== u) return r;
        const cuotas = [...r.cuotas];
        while (cuotas.length < nCuotas) cuotas.push("");
        cuotas[i] = v;
        return { ...r, cuotas };
      }),
    );
  }

  function aplicarATodas() {
    const v = aplicar.trim();
    if (!v) return;
    setRows((rs) =>
      rs.map((r) => ({ ...r, cuotas: Array.from({ length: nCuotas }, (_, i) => r.cuotas[i] || v) })),
    );
    toast.success("Importe aplicado a las cuotas vacías");
  }

  function limpiar() {
    setEditId(undefined);
    setNombre("");
    setImporteTotal("");
    setPIni("");
    setPFin("");
    setObservacion("");
    setRows([emptyRow(12)]);
  }

  function editar(p: any) {
    setEditId(p.id);
    setNombre(p.nombre ?? "");
    setImporteTotal(String(p.importe_total ?? ""));
    setPIni(p.periodo_inicio ? String(p.periodo_inicio) : "");
    setPFin(p.periodo_fin ? String(p.periodo_fin) : "");
    setObservacion(p.observacion ?? "");
    const ms = [...(p.members ?? [])].sort((a: any, b: any) => compareLegajo(a.legajo, b.legajo));
    setRows(
      ms.length
        ? ms.map((m: any) => ({
            uid: uid(),
            legajo: m.legajo,
            fecha_cobro: m.fecha_cobro ?? "",
            cuotas: (Array.isArray(m.cuotas) ? m.cuotas : []).map((c: any) => String(c ?? "")),
            observacion: m.observacion ?? "",
          }))
        : [emptyRow(12)],
    );
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function guardar(e: React.FormEvent) {
    e.preventDefault();
    if (nombre.trim().length < 2) return toast.error("Ponele una descripción al cumpleaños");
    const pi = parsePeriodo(pIni);
    if (!pi) return toast.error("Indicá el período inicial (mes y año), ej. 202601");
    if (pFin.trim() && !parsePeriodo(pFin)) return toast.error("El período final no es válido");
    const members = rows
      .filter((r) => r.legajo.trim())
      .map((r) => ({
        legajo: r.legajo.trim().toUpperCase(),
        fecha_cobro: r.fecha_cobro || null,
        cuotas: Array.from({ length: nCuotas }, (_, i) => toNumber(r.cuotas[i])),
        observacion: r.observacion || null,
      }));
    setBusy("save");
    try {
      await save({
        data: {
          ...(editId ? { id: editId } : {}),
          service_id: service_id ?? null,
          product_id: product_id ?? null,
          nombre: nombre.trim(),
          importe_total: toNumber(importeTotal),
          periodo_inicio: periodoNumero(pi.mes, pi.anio),
          periodo_fin: parsePeriodo(pFin)
            ? periodoNumero(parsePeriodo(pFin)!.mes, parsePeriodo(pFin)!.anio)
            : null,
          observacion: observacion || null,
          members,
        } as any,
      });
      toast.success(editId ? "Cumpleaños actualizado" : "Cumpleaños creado");
      limpiar();
      qc.invalidateQueries({ queryKey: ["birthday-plans"] });
      qc.invalidateQueries({ queryKey: ["birthday-settlement"] });
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo guardar");
    } finally {
      setBusy(null);
    }
  }

  async function borrar(id: string) {
    if (!confirm("¿Eliminar este cumpleaños y sus integrantes?")) return;
    try {
      await del({ data: { id } });
      toast.success("Eliminado");
      qc.invalidateQueries({ queryKey: ["birthday-plans"] });
      qc.invalidateQueries({ queryKey: ["birthday-settlement"] });
    } catch (err: any) {
      toast.error(err?.message ?? "Error");
    }
  }

  /** Importa el modelo oficial: Descripcion/Importe Total, Periodo_Inicio/Fin, Legajo/Nombre/Fecha_Cobro/Cuota_N */
  async function onExcel(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setBusy("excel");
    try {
      const wb = XLSX.read(await file.arrayBuffer(), { type: "array" });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const aoa = XLSX.utils.sheet_to_json<any[]>(sheet, { header: 1, defval: "" });

      let headerIdx = -1;
      let ini = "";
      let fin = "";
      aoa.forEach((row, i) => {
        for (let c = 0; c < row.length; c++) {
          const k = norm(row[c]);
          const v = txt(row[c + 1]);
          if (k === "descripcion" && v) setNombre(v);
          else if (k.startsWith("importe total") && v) setImporteTotal(String(toNumber(v)));
          else if (k.startsWith("periodo_inicio") || k.startsWith("periodo inicio")) {
            if (v) ini = v;
          } else if (k.startsWith("periodo_fin") || k.startsWith("periodo fin")) {
            if (v) fin = v;
          } else if (k === "legajo" && norm(row[c + 1]).includes("nombre")) headerIdx = i;
        }
      });
      const iniP = parsePeriodo(ini);
      const finP = parsePeriodo(fin);
      if (iniP) setPIni(String(periodoNumero(iniP.mes, iniP.anio)));
      if (finP) setPFin(String(periodoNumero(finP.mes, finP.anio)));
      if (headerIdx < 0) throw new Error("No encontré la fila de encabezado (Legajo / Nombre_y_Apellido)");

      const head = aoa[headerIdx].map((h) => norm(h));
      const idxFecha = head.findIndex((h) => h.startsWith("fecha"));
      const cuotaCols = head
        .map((h, i) => ({ h, i }))
        .filter((x) => x.h.startsWith("cuota"))
        .map((x) => x.i);
      const idxObs = head.findIndex((h) => h.startsWith("observ"));

      const nuevas: Row[] = [];
      for (let i = headerIdx + 1; i < aoa.length; i++) {
        const r = aoa[i];
        const legajo = txt(r[0]);
        if (!legajo || norm(legajo).startsWith("total")) continue;
        nuevas.push({
          uid: uid(),
          legajo: legajo.toUpperCase(),
          fecha_cobro: idxFecha >= 0 ? toISODate(r[idxFecha]) : "",
          cuotas: cuotaCols.map((c) => (txt(r[c]) ? String(toNumber(r[c])) : "")),
          observacion: idxObs >= 0 ? txt(r[idxObs]) : "",
        });
      }
      if (!nuevas.length) throw new Error("El archivo no tiene integrantes");
      nuevas.sort((a, b) => compareLegajo(a.legajo, b.legajo));
      setPreview({
        archivo: file.name,
        filas: nuevas.map((r) => ({
          legajo: r.legajo,
          detalle: r.observacion,
          cuotas: r.cuotas.filter((c) => txt(c)).length || 1,
          importe: r.cuotas.reduce((a, c) => a + toNumber(c), 0),
        })),
        _rows: nuevas,
      });
      if (!iniP) toast.warning("No pude leer el período inicial: completalo antes de confirmar");
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo leer el Excel");
    } finally {
      setBusy(null);
    }
  }

  function sheetModelo(d: {
    nombre: string;
    importeTotal: number;
    pIni: string;
    pFin: string;
    n: number;
    members: { legajo: string; nombre: string; fecha: string; cuotas: number[]; observacion: string }[];
  }) {
    const cuotaHeaders = Array.from({ length: d.n }, (_, i) => `Cuota_${i + 1}`);
    const aoa: any[][] = [
      ["Descripcion", d.nombre, "Importe Total", d.importeTotal],
      ["Periodo_Inicio", Number(d.pIni) || "", "Periodo_Fin", Number(d.pFin) || ""],
      [],
      ["Legajo", "Nombre_y_Apellido", "Fecha_Cobro", ...cuotaHeaders, "total a cobrar", "Observaciones"],
    ];
    for (const m of d.members) {
      const cuotas = Array.from({ length: d.n }, (_, i) => m.cuotas[i] ?? "");
      aoa.push([
        m.legajo,
        m.nombre,
        m.fecha,
        ...cuotas,
        Math.round(cuotas.reduce((a, c) => a + (Number(c) || 0), 0) * 100) / 100,
        m.observacion,
      ]);
    }
    aoa.push([]);
    aoa.push([
      "TOTAL",
      "",
      "",
      ...Array.from({ length: d.n }, (_, i) => d.members.reduce((a, m) => a + (m.cuotas[i] ?? 0), 0)),
      d.members.reduce((a, m) => a + m.cuotas.reduce((x, c) => x + (Number(c) || 0), 0), 0),
      "",
    ]);
    return XLSX.utils.aoa_to_sheet(aoa);
  }

  function descargarPlantilla() {
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      sheetModelo({
        nombre: "Cumple SECTOR",
        importeTotal: 0,
        pIni: String(anio * 100 + 1),
        pFin: String(anio * 100 + 12),
        n: 12,
        members: [{ legajo: "", nombre: "", fecha: "", cuotas: [], observacion: "" }],
      }),
      "Hoja1",
    );
    XLSX.writeFile(wb, "modelo_cumpleanos.xlsx");
  }

  function exportarPlan(p: any) {
    const ms = [...(p.members ?? [])].sort((a: any, b: any) => compareLegajo(a.legajo, b.legajo));
    const n = Math.max(1, ...ms.map((m: any) => (Array.isArray(m.cuotas) ? m.cuotas.length : 0)));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      sheetModelo({
        nombre: p.nombre ?? "",
        importeTotal: Number(p.importe_total ?? 0),
        pIni: String(p.periodo_inicio ?? ""),
        pFin: String(p.periodo_fin ?? ""),
        n,
        members: ms.map((m: any) => ({
          legajo: m.legajo,
          nombre: m.apellido_nombre ?? "",
          fecha: m.fecha_cobro ?? "",
          cuotas: (Array.isArray(m.cuotas) ? m.cuotas : []).map((c: any) => Number(c) || 0),
          observacion: m.observacion ?? "",
        })),
      }),
      "Hoja1",
    );
    XLSX.writeFile(wb, `cumpleanos_${String(p.nombre ?? "").replace(/\W+/g, "-")}.xlsx`);
  }

  function exportarLiquidacion() {
    if (!settle?.rows?.length && !settle?.agasajados?.length) {
      toast.error("No hay datos para el período elegido");
      return;
    }
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        [...(settle?.rows ?? [])]
          .sort((a, b) => compareLegajo(a.legajo, b.legajo))
          .map((r) => ({
            Legajo: r.legajo,
            Nombre_y_Apellido: r.apellido_nombre ?? "",
            Detalle: r.planes.map((p) => `${p.nombre} (${p.cuota})`).join(" · "),
            Importe_Descontar: r.importe,
          })),
      ),
      "Descuentos",
    );
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        (settle?.agasajados ?? []).map((a) => ({
          Legajo: a.legajo,
          Nombre_y_Apellido: a.apellido_nombre ?? "",
          Cumpleanos: a.plan,
          Importe_a_Pagar: a.importe,
        })),
      ),
      "Agasajados",
    );
    XLSX.writeFile(wb, `cumpleanos_liquidacion_${anio}-${String(mes).padStart(2, "0")}.xlsx`);
  }

  const pIniP = parsePeriodo(pIni);

  return (
    <div className="space-y-6">
      {preview && (
        <ImportPreview
          data={preview}
          mes={pIniP?.mes ?? 0}
          anio={pIniP?.anio ?? 0}
          onMes={(m) => setPIni(String(periodoNumero(m, pIniP?.anio || hoy.getFullYear())))}
          onAnio={(a) => setPIni(String(periodoNumero(pIniP?.mes || hoy.getMonth() + 1, a)))}
          onConfirm={() => {
            setRows(preview._rows ?? []);
            toast.success(`${(preview._rows ?? []).length} integrantes importados`);
            setPreview(null);
          }}
          onCancel={() => setPreview(null)}
        />
      )}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Cake className="h-6 w-6 text-primary" /> Cumpleaños
          </h1>
          <p className="text-sm text-muted-foreground">
            Importe fijo que cobra el agasajado el mes de su cumpleaños y cuotas fijas que aportan los
            afiliados durante el período.
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={descargarPlantilla}>
          <Download className="h-4 w-4 mr-1" /> Modelo Excel
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{editId ? "Editar cumpleaños" : "Nuevo cumpleaños"}</CardTitle>
          <CardDescription>
            Carga manual o importando el Excel del modelo (Descripcion, Importe Total, Periodo_Inicio /
            Periodo_Fin y las cuotas por legajo).
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={guardar} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="nombre">Descripción</Label>
                <Input
                  id="nombre"
                  value={nombre}
                  onChange={(ev) => setNombre(ev.target.value)}
                  placeholder="Cumple SEG VIAL"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="imp">Importe total (paga AGOEC al agasajado)</Label>
                <Input
                  id="imp"
                  inputMode="decimal"
                  value={importeTotal}
                  onChange={(ev) => setImporteTotal(ev.target.value)}
                  placeholder="14583,30"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-2">
                  <Label htmlFor="ini">Periodo inicio</Label>
                  <Input
                    id="ini"
                    inputMode="numeric"
                    value={pIni}
                    onChange={(ev) => setPIni(ev.target.value)}
                    placeholder="201803"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="fin">Periodo fin</Label>
                  <Input
                    id="fin"
                    inputMode="numeric"
                    value={pFin}
                    onChange={(ev) => setPFin(ev.target.value)}
                    placeholder="201812"
                  />
                </div>
              </div>
              <div className="space-y-2 sm:col-span-2 lg:col-span-4">
                <Label htmlFor="obs">Observación</Label>
                <Input id="obs" value={observacion} onChange={(ev) => setObservacion(ev.target.value)} />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setRows((rs) => [...rs, emptyRow(nCuotas)])}
              >
                <Plus className="h-4 w-4 mr-1" /> Agregar integrante
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                disabled={busy === "excel"}
                onClick={() => excelRef.current?.click()}
              >
                <Upload className="h-4 w-4 mr-1" /> {busy === "excel" ? "Leyendo…" : "Importar Excel"}
              </Button>
              <input
                ref={excelRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={onExcel}
              />
              <div className="flex items-center gap-1">
                <Input
                  className="h-9 w-32"
                  placeholder="Cuota fija"
                  value={aplicar}
                  onChange={(ev) => setAplicar(ev.target.value)}
                />
                <Button type="button" variant="secondary" size="sm" onClick={aplicarATodas}>
                  <Wand2 className="h-4 w-4 mr-1" /> Aplicar
                </Button>
              </div>
              <Badge variant="outline">{nCuotas} cuotas</Badge>
              <Badge variant="outline">{rows.filter((r) => r.legajo.trim()).length} integrantes</Badge>
              <Badge variant="outline">Descuentos: {money(totalDescuentos)}</Badge>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr className="border-b">
                    <th className="py-2 pr-2">Legajo</th>
                    <th className="py-2 pr-2">Nombre y apellido</th>
                    <th className="py-2 pr-2">Fecha cobro</th>
                    {Array.from({ length: nCuotas }, (_, i) => (
                      <th key={i} className="py-2 pr-2 whitespace-nowrap">
                        Cuota {i + 1}
                      </th>
                    ))}
                    <th className="py-2 pr-2">Observaciones</th>
                    <th className="py-2 pr-2 text-right">Total</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => {
                    const nombreAf = names[r.legajo.trim().toUpperCase()];
                    const total = r.cuotas.slice(0, nCuotas).reduce((a, c) => a + toNumber(c), 0);
                    return (
                      <tr key={r.uid} className="border-b last:border-0">
                        <td className="py-1 pr-2">
                          <Input
                            className="h-9 w-24"
                            value={r.legajo}
                            onChange={(ev) =>
                              setRows((rs) =>
                                rs.map((x) => (x.uid === r.uid ? { ...x, legajo: ev.target.value } : x)),
                              )
                            }
                          />
                        </td>
                        <td className="py-1 pr-2 min-w-52">
                          {r.legajo.trim() ? (
                            nombreAf ? (
                              <span>{nombreAf}</span>
                            ) : (
                              <span className="text-destructive text-xs">Legajo sin padrón</span>
                            )
                          ) : (
                            <span className="text-muted-foreground text-xs">—</span>
                          )}
                        </td>
                        <td className="py-1 pr-2">
                          <Input
                            type="date"
                            className="h-9 w-36"
                            value={r.fecha_cobro}
                            onChange={(ev) =>
                              setRows((rs) =>
                                rs.map((x) =>
                                  x.uid === r.uid ? { ...x, fecha_cobro: ev.target.value } : x,
                                ),
                              )
                            }
                          />
                        </td>
                        {Array.from({ length: nCuotas }, (_, i) => (
                          <td key={i} className="py-1 pr-2">
                            <Input
                              className="h-9 w-24"
                              inputMode="decimal"
                              value={r.cuotas[i] ?? ""}
                              onChange={(ev) => setCell(r.uid, i, ev.target.value)}
                            />
                          </td>
                        ))}
                        <td className="py-1 pr-2">
                          <Input
                            className="h-9 w-40"
                            value={r.observacion}
                            onChange={(ev) =>
                              setRows((rs) =>
                                rs.map((x) =>
                                  x.uid === r.uid ? { ...x, observacion: ev.target.value } : x,
                                ),
                              )
                            }
                          />
                        </td>
                        <td className="py-1 pr-2 text-right whitespace-nowrap">{money(total)}</td>
                        <td className="py-1">
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() => setRows((rs) => rs.filter((x) => x.uid !== r.uid))}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="flex gap-2">
              <Button type="submit" disabled={busy === "save"}>
                {busy === "save" ? "Guardando…" : editId ? "Guardar cambios" : "Crear cumpleaños"}
              </Button>
              {editId && (
                <Button type="button" variant="outline" onClick={limpiar}>
                  Cancelar
                </Button>
              )}
            </div>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row flex-wrap items-end justify-between gap-3">
          <div>
            <CardTitle className="text-base">Liquidación mensual</CardTitle>
            <CardDescription>Descuento por afiliado y pagos a los agasajados del mes.</CardDescription>
          </div>
          <div className="flex flex-wrap items-end gap-2">
            <div className="space-y-1">
              <Label className="text-xs">Mes</Label>
              <select
                className="h-9 rounded-md border bg-background px-2 text-sm"
                value={mes}
                onChange={(ev) => setMes(Number(ev.target.value))}
              >
                {MESES.map((m, i) => (
                  <option key={m} value={i + 1}>
                    {m}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Año</Label>
              <Input
                className="h-9 w-24"
                inputMode="numeric"
                value={anio}
                onChange={(ev) => setAnio(Number(ev.target.value) || anio)}
              />
            </div>
            <Button variant="outline" size="sm" onClick={exportarLiquidacion}>
              <Download className="h-4 w-4 mr-1" /> Excel
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline">{settle?.planes ?? 0} cumpleaños activos</Badge>
            <Badge variant="outline">{settle?.aportantes ?? 0} aportantes</Badge>
            <Badge variant="outline">A descontar: {money(settle?.total ?? 0)}</Badge>
            <Badge variant="outline">A pagar agasajados: {money(settle?.total_a_pagar ?? 0)}</Badge>
          </div>
          {!settle?.rows?.length ? (
            <p className="text-sm text-muted-foreground">Sin descuentos para este período.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr className="border-b">
                    <th className="py-2 pr-3">Legajo</th>
                    <th className="py-2 pr-3">Nombre y apellido</th>
                    <th className="py-2 pr-3">Detalle</th>
                    <th className="py-2 text-right">Importe</th>
                  </tr>
                </thead>
                <tbody>
                  {[...settle.rows]
                    .sort((a, b) => compareLegajo(a.legajo, b.legajo))
                    .map((r) => (
                      <tr key={r.legajo} className="border-b last:border-0">
                        <td className="py-2 pr-3 font-mono text-xs">{r.legajo}</td>
                        <td className="py-2 pr-3">{r.apellido_nombre ?? "—"}</td>
                        <td className="py-2 pr-3 text-xs text-muted-foreground">
                          {r.planes.map((p) => `${p.nombre} (${p.cuota})`).join(" · ")}
                        </td>
                        <td className="py-2 text-right">{money(r.importe)}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          )}
          {!!settle?.agasajados?.length && (
            <div className="rounded-md border p-3">
              <p className="text-sm font-medium mb-2">Agasajados de {MESES[mes - 1]}</p>
              <ul className="text-sm space-y-1">
                {settle.agasajados.map((a, i) => (
                  <li key={`${a.legajo}-${i}`} className="flex justify-between gap-3">
                    <span>
                      <span className="font-mono text-xs">{a.legajo}</span>{" "}
                      {a.apellido_nombre ?? "—"}{" "}
                      <span className="text-muted-foreground text-xs">· {a.plan}</span>
                    </span>
                    <span>{money(a.importe)}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Cumpleaños cargados</CardTitle>
        </CardHeader>
        <CardContent>
          {!data?.plans?.length ? (
            <p className="text-sm text-muted-foreground">Todavía no hay cumpleaños cargados.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr className="border-b">
                    <th className="py-2 pr-3">Descripción</th>
                    <th className="py-2 pr-3">Período</th>
                    <th className="py-2 pr-3">Integrantes</th>
                    <th className="py-2 pr-3">Importe agasajado</th>
                    <th className="py-2 pr-3">Total descuentos</th>
                    <th className="py-2" />
                  </tr>
                </thead>
                <tbody>
                  {data.plans.map((p: any) => (
                    <tr key={p.id} className="border-b last:border-0">
                      <td className="py-2 pr-3 font-medium">{p.nombre}</td>
                      <td className="py-2 pr-3">
                        {p.periodo_inicio ?? "—"} → {p.periodo_fin ?? "—"}
                      </td>
                      <td className="py-2 pr-3">{p.integrantes}</td>
                      <td className="py-2 pr-3">{money(p.importe_total)}</td>
                      <td className="py-2 pr-3">{money(p.total_descuentos)}</td>
                      <td className="py-2 text-right whitespace-nowrap">
                        <IntegrantesDialog
                          titulo={`Integrantes · ${p.nombre}`}
                          descripcion="Afiliados a los que se les descuenta este cumpleaños."
                          detalleLabel="Cobra / cuotas"
                          importeLabel="Total a descontar"
                          rows={(p.members ?? []).map((m: any) => ({
                            legajo: String(m.legajo),
                            nombre: m.apellido_nombre,
                            detalle: `${m.fecha_cobro ? `Cobra ${m.fecha_cobro} · ` : ""}${(Array.isArray(m.cuotas) ? m.cuotas : []).length} cuota(s)`,
                            importe: Number(m.total ?? 0),
                            observacion: m.observacion,
                            adelanto: m.fecha_cobro
                              ? {
                                  refKey: `cumple:${p.id}:${String(m.legajo)}`,
                                  tipo: "Cumpleaños",
                                  detalle: p.nombre,
                                  importe: Number(p.importe_total) || 0,
                                }
                              : undefined,
                          }))}
                        />
                        <Button size="sm" variant="ghost" onClick={() => exportarPlan(p)}>
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => editar(p)}>
                          Editar
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => borrar(p.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
