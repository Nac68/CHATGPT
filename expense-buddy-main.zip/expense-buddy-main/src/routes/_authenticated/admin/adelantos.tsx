import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { deleteAdvance, listAdvances, saveAdvances } from "@/lib/advances.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Download, Loader2, Plus, Save, Trash2, Upload } from "lucide-react";
import * as XLSX from "xlsx";
import { compareLegajo, normalizeLegajo } from "@/lib/legajo";
import { MESES, parsePeriodo, periodoError } from "@/lib/periodo";
import { ImportPreview, type ImportPreviewData } from "@/components/ImportPreview";
import {
  closeAdvancePeriod,
  listAdvancePeriods,
  openAdvancePeriod,
  reopenAdvancePeriod,
  reviewAdvancePeriod,
} from "@/lib/advance-periods.functions";


export const Route = createFileRoute("/_authenticated/admin/adelantos")({
  component: AdelantosPanel,
  head: () => ({
    meta: [
      { title: "Adelantos de afiliados | AGOEC" },
      {
        name: "description",
        content:
          "Carga manual o por Excel de los adelantos pedidos por los afiliados, con cuotas y período de liquidación.",
      },
      { property: "og:title", content: "Adelantos de afiliados | AGOEC" },
      {
        property: "og:description",
        content: "Adelantos por legajo con monto, cuotas, período y datos bancarios.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const money = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });
const n2 = (v: number) => Number(Number(v || 0).toFixed(2));
const normalizeTitle = (value: unknown): string =>
  String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();

type Row = {
  uid: number;
  legajo: string;
  fecha: string;
  monto_pedido: number;
  cuotas: number;
  cuil: string;
  banco: string;
  cuenta: string;
  cbu: string;
  cbu2: string;
  concepto: string;
  responsable: string;
  ref_id: string;
};

let seq = 1;
const hoyISO = () => new Date().toISOString().slice(0, 10);
const newRow = (): Row => ({
  uid: seq++,
  legajo: "",
  fecha: hoyISO(),
  monto_pedido: 0,
  cuotas: 1,
  cuil: "",
  banco: "",
  cuenta: "",
  cbu: "",
  cbu2: "",
  concepto: "ADELANTO",
  responsable: "",
  ref_id: "",
});

function excelFecha(v: any): string {
  if (!v) return "";
  if (typeof v === "number") {
    const d = XLSX.SSF.parse_date_code(v);
    if (d) return `${d.y}-${String(d.m).padStart(2, "0")}-${String(d.d).padStart(2, "0")}`;
  }
  const s = String(v);
  const iso = s.match(/(\d{4})-(\d{2})-(\d{2})/);
  if (iso) return iso[0];
  const dmy = s.match(/(\d{1,2})[/-](\d{1,2})[/-](\d{4})/);
  if (dmy) return `${dmy[3]}-${dmy[2].padStart(2, "0")}-${dmy[1].padStart(2, "0")}`;
  return "";
}

function AdelantosPanel() {
  const qc = useQueryClient();
  const listFn = useServerFn(listAdvances);
  const saveFn = useServerFn(saveAdvances);
  const delFn = useServerFn(deleteAdvance);

  const hoy = new Date();
  const [descripcion, setDescripcion] = useState("ADELANTOS");
  const [mes, setMes] = useState(hoy.getMonth() + 1);
  const [anio, setAnio] = useState(hoy.getFullYear());
  const [rows, setRows] = useState<Row[]>([newRow()]);
  const [busca, setBusca] = useState("");
  const [verTodo, setVerTodo] = useState(false);
  const [verCarga, setVerCarga] = useState(false);
  const [verHistorico, setVerHistorico] = useState(false);
  const [preview, setPreview] = useState<(ImportPreviewData & { _rows?: Row[] }) | null>(null);
  const [archivo, setArchivo] = useState("");
  const [leyendo, setLeyendo] = useState(false);
  const [ficha, setFicha] = useState<string | null>(null);
  const errPeriodo = periodoError(mes, anio);

  const listQ = useQuery({
    queryKey: ["adelantos"],
    queryFn: () => listFn({ data: undefined as any }),
  });

  const periodsFn = useServerFn(listAdvancePeriods);
  const openFn = useServerFn(openAdvancePeriod);
  const reviewFn = useServerFn(reviewAdvancePeriod);
  const closeFn = useServerFn(closeAdvancePeriod);
  const reopenFn = useServerFn(reopenAdvancePeriod);

  const periodsQ = useQuery({
    queryKey: ["advance-periods"],
    queryFn: () => periodsFn({ data: undefined as any }),
  });
  const abierto: any = periodsQ.data?.abierto ?? null;
  const control: any = periodsQ.data?.control ?? null;
  const periodos: any[] = periodsQ.data?.periodos ?? [];

  const refetchPeriodos = () => qc.invalidateQueries({ queryKey: ["advance-periods"] });
  const periodMut = useMutation({
    mutationFn: async (a: { accion: "abrir" | "revisar" | "cerrar" | "reabrir"; id?: string }) => {
      if (a.accion === "abrir") return openFn({ data: { periodo_mes: mes, periodo_anio: anio, descripcion } });
      if (a.accion === "revisar") return reviewFn({ data: { id: a.id! } });
      if (a.accion === "cerrar") return closeFn({ data: { id: a.id!, abrir_siguiente: true } });
      return reopenFn({ data: { id: a.id! } });
    },
    onSuccess: (_r, v) => {
      toast.success(
        v.accion === "abrir"
          ? "Período abierto"
          : v.accion === "revisar"
            ? "Período marcado como revisado"
            : v.accion === "cerrar"
              ? "Período cerrado: el histórico quedó congelado y el siguiente ya está operativo"
              : "Período reabierto (queda registrado)",
      );
      refetchPeriodos();
      qc.invalidateQueries({ queryKey: ["adelantos"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "No se pudo actualizar el período"),
  });


  const saveMut = useMutation({
    mutationFn: (items: any[]) => saveFn({ data: { items } }),
    onSuccess: (r: any) => {
      toast.success(`${r.guardados} adelanto(s) guardados`);
      if (r.omitidos?.length) {
        toast.warning(
          `${r.omitidos.length} legajo(s) omitidos por no estar en el padrón: ${r.omitidos
            .slice(0, 10)
            .map((x: any) => x.legajo)
            .join(", ")}${r.omitidos.length > 10 ? "…" : ""}`,
        );
      }
      setRows([newRow()]);
      setPreview(null);
      qc.invalidateQueries({ queryKey: ["adelantos"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "No se pudo guardar"),
  });

  const delMut = useMutation({
    mutationFn: (id: string) => delFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Adelanto eliminado");
      qc.invalidateQueries({ queryKey: ["adelantos"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "No se pudo eliminar"),
  });

  function set(uid: number, patch: Partial<Row>) {
    setRows((r) => r.map((x) => (x.uid === uid ? { ...x, ...patch } : x)));
  }

  function importarExcel(file: File) {
    setArchivo(file.name);
    setLeyendo(true);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const wb = XLSX.read(e.target?.result, { type: "array" });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const matrix: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "" });

        // Encabezado: Descripcion / Periodo, y la fila de títulos con LEGAJO.
        let headerIdx = -1;
        let descDetectada = "";
        let periodoDetectado: { mes: number; anio: number } | null = null;
        for (let i = 0; i < matrix.length; i++) {
          const fila = matrix[i].map(normalizeTitle);
          if (fila.includes("descripcion")) {
            const v = String(matrix[i][1] ?? "").trim();
            if (v) descDetectada = v.toUpperCase();
          }
          if (fila.includes("periodo")) {
            const p = parsePeriodo(matrix[i][1]);
            if (p) periodoDetectado = p;
          }
          if (fila.some((c) => c === "legajo")) {
            headerIdx = i;
            break;
          }
        }
        if (headerIdx < 0) {
          toast.error("No se encontró la fila de títulos. El modelo debe incluir FECHA, LEGAJO, MONTO_PEDIDO y CUOTAS.");
          return;
        }

        const titles = matrix[headerIdx].map(normalizeTitle);
        const col = (...keys: string[]) =>
          titles.findIndex((t) => keys.some((k) => t.replace(/[°º\s_]/g, "").includes(k)));
        const idx = {
          fecha: col("fecha"),
          legajo: col("legajo"),
          monto: col("montopedido", "monto", "importe"),
          cuotas: col("cuotas", "cuota"),
          cuil: col("cuil"),
          banco: col("banco"),
          cuenta: col("decuenta", "cuenta"),
          cbu: col("1cbu", "cbu"),
          cbu2: col("2cbu"),
          concepto: col("concepto"),
          responsable: col("responsable"),
          ref: col("id"),
        };
        if (idx.legajo < 0 || idx.monto < 0) {
          toast.error("El Excel debe contener las columnas LEGAJO y MONTO_PEDIDO.");
          return;
        }

        const parsed: Row[] = [];
        const descartadas: { legajo?: string; motivo: string }[] = [];
        for (let i = headerIdx + 1; i < matrix.length; i++) {
          const f = matrix[i];
          const legajo = normalizeLegajo(f[idx.legajo]);
          const montoRaw = String(f[idx.monto] ?? "");
          const monto =
            Number(montoRaw.toString().replace(/[^\d.,-]/g, "").replace(/\./g, "").replace(",", ".")) || 0;
          if (!legajo) {
            if (monto) descartadas.push({ motivo: "fila sin legajo" });
            continue;
          }
          if (!monto) {
            descartadas.push({ legajo, motivo: "sin monto pedido" });
            continue;
          }
          const get = (k: number) => (k >= 0 ? String(f[k] ?? "").trim() : "");
          parsed.push({
            uid: seq++,
            legajo,
            fecha: excelFecha(f[idx.fecha]) || hoyISO(),
            monto_pedido: monto,
            cuotas: Math.max(1, Number(get(idx.cuotas)) || 1),
            cuil: get(idx.cuil),
            banco: get(idx.banco),
            cuenta: get(idx.cuenta),
            cbu: get(idx.cbu),
            cbu2: get(idx.cbu2),
            concepto: get(idx.concepto) || "ADELANTO",
            responsable: get(idx.responsable),
            ref_id: get(idx.ref),
          });
        }
        if (!parsed.length) return toast.error("No se encontraron adelantos con legajo y monto");

        const filas = parsed.sort((a, b) => compareLegajo(a.legajo, b.legajo));
        if (descDetectada) setDescripcion(descDetectada);
        if (periodoDetectado) {
          setMes(periodoDetectado.mes);
          setAnio(periodoDetectado.anio);
        } else {
          setMes(0 as any);
        }
        setPreview({
          archivo: file.name,
          descripcion: descDetectada || descripcion,
          filas: filas.map((r) => ({
            legajo: r.legajo,
            detalle: r.concepto,
            importe: r.monto_pedido,
            cuotas: r.cuotas,
          })),
          descartadas,
          _rows: filas,
        } as any);
        if (!periodoDetectado)
          toast.warning("No se pudo leer el período del Excel: completalo antes de confirmar");
      } catch (error) {
        toast.error(error instanceof Error ? `No se pudo leer el Excel: ${error.message}` : "No se pudo leer el Excel");
      } finally {
        setLeyendo(false);
      }
    };
    reader.onerror = () => {
      setLeyendo(false);
      toast.error("No se pudo abrir el archivo Excel");
    };
    reader.readAsArrayBuffer(file);
  }

  function confirmarImportacion() {
    const err = periodoError(mes, anio);
    if (err) return toast.error(err);
    const rowsPreview = (preview as any)?._rows as Row[] | undefined;
    if (!rowsPreview?.length) return;
    const items = toItems(rowsPreview);
    saveMut.mutate(items);
  }

  function toItems(source: Row[]) {
    return source
      .filter((r) => normalizeLegajo(r.legajo) && Number(r.monto_pedido) > 0)
      .map((r) => ({
        legajo: normalizeLegajo(r.legajo),
        fecha: r.fecha || null,
        monto_pedido: Number(r.monto_pedido),
        cuotas: Math.max(1, Number(r.cuotas) || 1),
        periodo_mes: mes,
        periodo_anio: anio,
        concepto: r.concepto || "ADELANTO",
        responsable: r.responsable || null,
        ref_id: r.ref_id || null,
        cuil: r.cuil || null,
        banco: r.banco || null,
        cuenta: r.cuenta || null,
        cbu: r.cbu || null,
        cbu2: r.cbu2 || null,
        observacion: descripcion || null,
      }));
  }

  function guardar() {
    const err = periodoError(mes, anio);
    if (err) return toast.error(err);
    const items = toItems(rows);
    if (!items.length) return toast.error("Cargá al menos un adelanto con legajo y monto");
    saveMut.mutate(items);
  }


  const adelantos: any[] = listQ.data?.adelantos ?? [];
  const filtrados = useMemo(() => {
    const q = busca.trim().toLowerCase();
    if (!q) return adelantos;
    return adelantos.filter((a) =>
      [a.legajo, a.apellido_nombre, a.cuil, a.periodo_label, a.concepto, a.banco, a.ref_id]
        .filter(Boolean)
        .some((v: string) => String(v).toLowerCase().includes(q)),
    );
  }, [adelantos, busca]);

  const hayBusqueda = busca.trim().length > 0;
  const visibles = hayBusqueda || verTodo ? filtrados : [];
  const porLegajo = useMemo(() => {
    const map = new Map<string, any[]>();
    for (const a of filtrados) {
      const k = String(a.legajo);
      map.set(k, [...(map.get(k) ?? []), a]);
    }
    return Array.from(map.entries())
      .map(([legajo, ops]) => ({ legajo, ops }))
      .sort((a, b) => compareLegajo(a.legajo, b.legajo));
  }, [filtrados]);

  const totalCargado = rows.reduce((a, r) => a + (Number(r.monto_pedido) || 0), 0);

  // Comportamiento de los últimos 12 períodos por legajo (cantidad de operaciones).
  const ultimos12 = useMemo(() => {
    const base = hoy.getFullYear() * 12 + hoy.getMonth(); // índice del período actual
    const map = new Map<string, { total: number; porPeriodo: Map<number, number> }>();
    for (const a of adelantos) {
      const idx = Number(a.periodo_anio) * 12 + (Number(a.periodo_mes) - 1);
      if (idx > base || idx < base - 11) continue;
      const k = normalizeLegajo(a.legajo);
      const e = map.get(k) ?? { total: 0, porPeriodo: new Map<number, number>() };
      e.total += 1;
      e.porPeriodo.set(idx, (e.porPeriodo.get(idx) ?? 0) + 1);
      map.set(k, e);
    }
    return { base, map };
  }, [adelantos]);

  function historialLegajo(legajoRaw: string) {
    const legajo = normalizeLegajo(legajoRaw);
    if (!legajo) return null;
    const e = ultimos12.map.get(legajo);
    const periodos = Array.from({ length: 12 }, (_, i) => {
      const idx = ultimos12.base - i;
      return {
        label: `${String((idx % 12) + 1).padStart(2, "0")}/${Math.floor(idx / 12)}`,
        cantidad: e?.porPeriodo.get(idx) ?? 0,
      };
    });
    const nombre =
      adelantos.find((a) => normalizeLegajo(a.legajo) === legajo)?.apellido_nombre ?? null;
    return { legajo, nombre, total: e?.total ?? 0, periodos };
  }

  // Resumen del período abierto (se calcula con los adelantos ya listados).
  const resumenPeriodo = useMemo(() => {
    if (!abierto) return null;
    const delPeriodo = adelantos.filter(
      (a) =>
        Number(a.periodo_mes) === Number(abierto.periodo_mes) &&
        Number(a.periodo_anio) === Number(abierto.periodo_anio),
    );
    const porLeg = new Map<string, number>();
    for (const a of delPeriodo) {
      const k = normalizeLegajo(a.legajo);
      porLeg.set(k, (porLeg.get(k) ?? 0) + 1);
    }
    const total = delPeriodo.reduce((s, a) => s + Number(a.monto_pedido || 0), 0);
    return {
      adelantos: delPeriodo.length,
      afiliados: porLeg.size,
      total,
      promedio: delPeriodo.length ? total / delPeriodo.length : 0,
      repetidos: Array.from(porLeg.values()).filter((n) => n > 1).length,
    };
  }, [adelantos, abierto]);




  function exportarExcel() {
    if (!filtrados.length) return toast.error("No hay adelantos para exportar");
    const data = filtrados.map((a) => ({
      FECHA: a.fecha ?? "",
      LEGAJO: a.legajo,
      APELLIDO_Y_NOMBRE: a.apellido_nombre ?? "",
      MONTO_PEDIDO: n2(a.monto_pedido),
      CUOTAS: a.cuotas,
      CUIL: a.cuil ?? "",
      BANCO: a.banco ?? "",
      "N°_DE_CUENTA": a.cuenta ?? "",
      "1°_CBU": a.cbu ?? "",
      "2°_CBU": a.cbu2 ?? "",
      CONCEPTO: a.concepto ?? "",
      RESPONSABLE: a.responsable ?? "",
      ID: a.ref_id ?? "",
    }));
    const ws = XLSX.utils.json_to_sheet(data, { origin: "A4" });
    XLSX.utils.sheet_add_aoa(ws, [["Descripcion", descripcion], ["Periodo", `${anio}${String(mes).padStart(2, "0")}`], []], {
      origin: "A1",
    });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Hoja1");
    XLSX.writeFile(wb, `adelantos_${anio}${String(mes).padStart(2, "0")}.xlsx`);
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Adelantos</h1>
        <p className="text-sm text-muted-foreground">
          El adelanto lo presta siempre AGOEC. Cargalo por Excel (mismo formato del listado) o a
          mano: se descuenta en cuotas iguales a partir del período indicado y puede refinanciarse
          desde el Buscador CRM.
        </p>
        <Badge variant="outline" className="mt-2">Presta: AGOEC</Badge>
      </div>

      {/* Período vigente: estado, control y cierre */}
      <Card>
        <CardHeader className="flex flex-row flex-wrap items-start justify-between gap-3">
          <div>
            <CardTitle className="text-base">
              Período vigente{" "}
              {abierto ? (
                <Badge className="ml-1" variant={abierto.estado === "revisado" ? "secondary" : "default"}>
                  {String(abierto.periodo_mes).padStart(2, "0")}/{abierto.periodo_anio} ·{" "}
                  {abierto.estado === "revisado" ? "Revisado" : "Abierto"}
                </Badge>
              ) : (
                <Badge variant="outline" className="ml-1">Sin período abierto</Badge>
              )}
            </CardTitle>
            <CardDescription>
              Los adelantos se cargan sobre el período abierto. Al cerrar se congela el histórico y se
              prepara el siguiente, sin borrar datos.
            </CardDescription>
          </div>
          <div className="flex flex-wrap gap-2">
            {!abierto && (
              <Button
                onClick={() => periodMut.mutate({ accion: "abrir" })}
                disabled={periodMut.isPending || !!errPeriodo}
              >
                Abrir {errPeriodo ? "período" : `${String(mes).padStart(2, "0")}/${anio}`}
              </Button>
            )}
            {abierto && abierto.estado === "abierto" && (
              <Button
                variant="secondary"
                onClick={() => periodMut.mutate({ accion: "revisar", id: abierto.id })}
                disabled={periodMut.isPending}
              >
                Marcar revisado
              </Button>
            )}
            {abierto && (
              <Button
                onClick={() => periodMut.mutate({ accion: "cerrar", id: abierto.id })}
                disabled={periodMut.isPending || !!control?.errores?.length}
              >
                {periodMut.isPending && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
                Cerrar período
              </Button>
            )}
            <Button variant="outline" onClick={() => setVerHistorico((v) => !v)}>
              {verHistorico ? "Ocultar histórico" : "Histórico"}
            </Button>
          </div>
        </CardHeader>
        {abierto && control && (
          <CardContent className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {[
                ["Adelantos", String(control.adelantos)],
                ["Legajos", String(control.legajos)],
                ["Total solicitado", money.format(control.total_solicitado)],
                ["Enviado a refinanciación", money.format(control.refinanciado_en_periodo)],
                ["Cuotas de Adelantos", money.format(control.cuotas_adelantos)],
                ["Cuotas de Refinanciación", money.format(control.cuotas_refinanciacion)],
                ["Total general del período", money.format(control.total_general)],
                ["Errores", String(control.errores.length)],
              ].map(([label, value]) => (
                <div key={label} className="rounded-md border p-3">
                  <p className="text-xs text-muted-foreground">{label}</p>
                  <p className="text-lg font-semibold">{value}</p>
                </div>
              ))}
            </div>
            {!!control.errores.length && (
              <div className="rounded-md border border-destructive bg-destructive/5 p-3 text-sm text-destructive">
                <p className="font-medium">No se puede cerrar hasta resolver:</p>
                <ul className="mt-1 list-disc pl-5">
                  {control.errores.slice(0, 8).map((e: any, i: number) => (
                    <li key={i}>
                      [{e.tipo}] {e.detalle}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        )}
        {abierto && resumenPeriodo && (
          <CardContent className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5 border-t pt-4">
            {[
              ["Adelantos del período", String(resumenPeriodo.adelantos)],
              ["Afiliados distintos", String(resumenPeriodo.afiliados)],
              ["Monto total", money.format(resumenPeriodo.total)],
              ["Promedio por adelanto", money.format(resumenPeriodo.promedio)],
              ["Con más de un adelanto", String(resumenPeriodo.repetidos)],
            ].map(([label, value]) => (
              <div key={label} className="rounded-md border p-3">
                <p className="text-xs text-muted-foreground">{label}</p>
                <p className="text-lg font-semibold">{value}</p>
              </div>
            ))}
          </CardContent>
        )}

        {verHistorico && (
          <CardContent className="overflow-x-auto">
            {!periodos.length ? (
              <p className="text-sm text-muted-foreground">Todavía no hay períodos registrados.</p>
            ) : (
              <table className="w-full text-sm">
                <thead className="text-xs text-muted-foreground">
                  <tr className="border-b">
                    <th className="text-left p-2">Período</th>
                    <th className="text-left p-2">Estado</th>
                    <th className="text-right p-2">Adelantos</th>
                    <th className="text-right p-2">Solicitado</th>
                    <th className="text-right p-2">Cuotas adelantos</th>
                    <th className="text-right p-2">Cuotas refinanc.</th>
                    <th className="text-right p-2">Total general</th>
                    <th className="text-left p-2">Cerrado</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {periodos.map((p) => (
                    <tr key={p.id} className="border-b">
                      <td className="p-2 whitespace-nowrap">
                        {String(p.periodo_mes).padStart(2, "0")}/{p.periodo_anio}
                      </td>
                      <td className="p-2">
                        <Badge variant={p.estado === "cerrado" ? "secondary" : "default"}>{p.estado}</Badge>
                        {p.reaperturas > 0 && (
                          <span className="ml-2 text-xs text-muted-foreground">
                            {p.reaperturas} reapertura(s)
                          </span>
                        )}
                      </td>
                      <td className="p-2 text-right">{p.total_adelantos}</td>
                      <td className="p-2 text-right">{money.format(p.total_solicitado)}</td>
                      <td className="p-2 text-right">{money.format(p.total_cuotas_adelantos)}</td>
                      <td className="p-2 text-right">{money.format(p.total_cuotas_refinanciacion)}</td>
                      <td className="p-2 text-right font-medium">{money.format(p.total_general)}</td>
                      <td className="p-2 text-xs text-muted-foreground">
                        {p.cerrado_at ? String(p.cerrado_at).slice(0, 10) : "—"}
                      </td>
                      <td className="p-2">
                        {p.estado === "cerrado" && (
                          <Button
                            size="sm"
                            variant="outline"
                            disabled={periodMut.isPending}
                            onClick={() => periodMut.mutate({ accion: "reabrir", id: p.id })}
                          >
                            Reabrir
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </CardContent>
        )}
      </Card>




      <Card>
        <CardHeader>
          <CardTitle className="text-base">Datos del listado</CardTitle>
          <CardDescription>
            El período (mes y año) es el que se liquida: la primera cuota se descuenta en ese
            período.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-4 items-end">
          <div className="space-y-2">
            <Label>Descripción</Label>
            <Input value={descripcion} onChange={(e) => setDescripcion(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Mes del período</Label>
            <select
              className="w-full h-10 rounded-md border bg-background px-3 text-sm"
              value={mes || ""}
              onChange={(e) => setMes(Number(e.target.value))}
            >
              <option value="">Elegí el mes…</option>
              {MESES.map((m, i) => (
                <option key={m} value={i + 1}>
                  {m}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <Label>Año del período</Label>
            <Input
              type="number"
              min={2000}
              max={2100}
              value={anio || ""}
              onChange={(e) => setAnio(Number(e.target.value))}
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <Button asChild variant="secondary">
              <label className="cursor-pointer">
                {leyendo ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Upload className="h-4 w-4 mr-1" />}
                {leyendo ? "Leyendo…" : "Importar Excel"}
                <input
                  type="file"
                  accept=".xlsx,.xls"
                  className="hidden"
                  disabled={leyendo || saveMut.isPending}
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) importarExcel(file);
                    e.currentTarget.value = "";
                  }}
                />
              </label>
            </Button>
            <Button variant="outline" onClick={exportarExcel}>
              <Download className="h-4 w-4 mr-1" /> Excel
            </Button>
          </div>
          {archivo && <p className="md:col-span-4 text-xs text-muted-foreground">Archivo seleccionado: {archivo}</p>}
          {!!errPeriodo && (
            <p className="md:col-span-4 text-sm text-destructive">{errPeriodo}</p>
          )}
        </CardContent>
      </Card>

      {preview && (
        <ImportPreview
          data={preview}
          mes={mes}
          anio={anio}
          onMes={setMes}
          onAnio={setAnio}
          onConfirm={confirmarImportacion}
          onCancel={() => setPreview(null)}
          confirmLabel="Confirmar e importar"
          loading={saveMut.isPending}
        />
      )}

      <div>
        <Button variant="outline" onClick={() => setVerCarga((v) => !v)}>
          {verCarga ? "Ocultar carga manual" : "Cargar adelantos a mano"}
        </Button>
      </div>

      {verCarga && (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between flex-wrap gap-2">
          <div>
            <CardTitle className="text-base">Carga de adelantos ({rows.length})</CardTitle>
            <CardDescription>
              Total pedido: {money.format(totalCargado)} · Período{" "}
              {errPeriodo ? "sin definir" : `${String(mes).padStart(2, "0")}/${anio}`}
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setRows((r) => [...r, newRow()])}>
              <Plus className="h-4 w-4 mr-1" /> Agregar fila
            </Button>
            <Button onClick={guardar} disabled={saveMut.isPending || !!errPeriodo}>
              {saveMut.isPending ? (
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
              ) : (
                <Save className="h-4 w-4 mr-1" />
              )}
              Guardar

            </Button>
          </div>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs text-muted-foreground">
              <tr className="border-b">
                <th className="text-left p-2">Fecha</th>
                <th className="text-left p-2">Legajo</th>
                <th className="text-right p-2">Monto pedido</th>
                <th className="text-right p-2">Cuotas</th>
                <th className="text-right p-2">Cuota</th>
                <th className="text-left p-2">CUIL</th>
                <th className="text-left p-2">Banco</th>
                <th className="text-left p-2">N° de cuenta</th>
                <th className="text-left p-2">CBU</th>
                <th className="text-left p-2">Concepto</th>
                <th className="text-left p-2">Responsable</th>
                <th className="text-left p-2">ID</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.uid} className="border-b">
                  <td className="p-1">
                    <Input
                      type="date"
                      value={r.fecha}
                      onChange={(e) => set(r.uid, { fecha: e.target.value })}
                    />
                  </td>
                  <td className="p-1">
                    <Input
                      className="w-24"
                      value={r.legajo}
                      onChange={(e) => set(r.uid, { legajo: e.target.value.toUpperCase() })}
                    />
                  </td>
                  <td className="p-1">
                    <Input
                      type="number"
                      className="w-32 text-right"
                      value={r.monto_pedido || ""}
                      onChange={(e) => set(r.uid, { monto_pedido: Number(e.target.value) || 0 })}
                    />
                  </td>
                  <td className="p-1">
                    <Input
                      type="number"
                      min={1}
                      className="w-20 text-right"
                      value={r.cuotas}
                      onChange={(e) => set(r.uid, { cuotas: Math.max(1, Number(e.target.value) || 1) })}
                    />
                  </td>
                  <td className="p-2 text-right whitespace-nowrap">
                    {money.format((Number(r.monto_pedido) || 0) / Math.max(1, r.cuotas))}
                  </td>
                  <td className="p-1">
                    <Input className="w-32" value={r.cuil} onChange={(e) => set(r.uid, { cuil: e.target.value })} />
                  </td>
                  <td className="p-1">
                    <Input className="w-28" value={r.banco} onChange={(e) => set(r.uid, { banco: e.target.value })} />
                  </td>
                  <td className="p-1">
                    <Input className="w-28" value={r.cuenta} onChange={(e) => set(r.uid, { cuenta: e.target.value })} />
                  </td>
                  <td className="p-1">
                    <Input className="w-40" value={r.cbu} onChange={(e) => set(r.uid, { cbu: e.target.value })} />
                  </td>
                  <td className="p-1">
                    <Input className="w-28" value={r.concepto} onChange={(e) => set(r.uid, { concepto: e.target.value })} />
                  </td>
                  <td className="p-1">
                    <Input
                      className="w-28"
                      value={r.responsable}
                      onChange={(e) => set(r.uid, { responsable: e.target.value })}
                    />
                  </td>
                  <td className="p-1">
                    <Input className="w-24" value={r.ref_id} onChange={(e) => set(r.uid, { ref_id: e.target.value })} />
                  </td>
                  <td className="p-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setRows((x) => (x.length > 1 ? x.filter((y) => y.uid !== r.uid) : x))}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Comportamiento de los últimos 12 meses del legajo que se está cargando */}
          <div className="mt-4 space-y-3">
            {rows
              .map((r) => ({ uid: r.uid, h: historialLegajo(r.legajo) }))
              .filter((x) => x.h)
              .map(({ uid, h }) => (
                <div key={uid} className="rounded-md border p-3">
                  <p className="text-sm font-medium">
                    Legajo {h!.legajo} {h!.nombre ? `· ${h!.nombre}` : ""} · últimos 12 meses:{" "}
                    {h!.total} adelanto(s)
                  </p>
                  <div className="mt-2 flex flex-wrap gap-1">
                    {h!.periodos.map((p) => (
                      <Badge
                        key={p.label}
                        variant={p.cantidad ? "default" : "outline"}
                        className="font-normal"
                      >
                        {p.label}: {p.cantidad}
                      </Badge>
                    ))}
                  </div>
                  {h!.total === 0 && (
                    <p className="mt-2 text-xs text-muted-foreground">
                      Sin adelantos registrados en los últimos 12 períodos.
                    </p>
                  )}
                </div>
              ))}
          </div>
        </CardContent>

      </Card>
      )}


      <Card>
        <CardHeader className="flex flex-row items-center justify-between flex-wrap gap-2">
          <div>
            <CardTitle className="text-base">Buscar adelantos</CardTitle>
            <CardDescription>
              Buscá por legajo, nombre, CUIL o ID. Cada fila del archivo es una operación
              independiente: un legajo puede tener varios adelantos en el mismo período.
            </CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Input
              className="w-72"
              placeholder="Legajo, nombre, CUIL, período…"
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
            />
            <Button variant="outline" onClick={() => setVerTodo((v) => !v)}>
              {verTodo ? "Ocultar listado" : `Ver listado completo (${adelantos.length})`}
            </Button>
            <Button variant="outline" onClick={exportarExcel}>
              <Download className="h-4 w-4 mr-1" /> Excel
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {listQ.isLoading ? (
            <div className="py-8 text-center text-sm text-muted-foreground">Cargando…</div>
          ) : !adelantos.length ? (
            <div className="py-8 text-center text-sm text-muted-foreground">
              Todavía no hay adelantos cargados.
            </div>
          ) : !hayBusqueda && !verTodo ? (
            <div className="py-8 text-center text-sm text-muted-foreground">
              Escribí un legajo, nombre o CUIL para ver su ficha, o abrí el listado completo.
            </div>
          ) : (
            <>
              {hayBusqueda && (
                <div className="space-y-2">
                  {!porLegajo.length && (
                    <p className="text-sm text-muted-foreground">Sin resultados para “{busca}”.</p>
                  )}
                  {porLegajo.slice(0, 25).map(({ legajo, ops }) => {
                    const abiertoFicha = ficha === legajo;
                    const tot = ops.reduce((s, o) => s + Number(o.monto_pedido || 0), 0);
                    const cuotaMes = ops.reduce((s, o) => s + Number(o.importe_cuota_periodo || 0), 0);
                    return (
                      <div key={legajo} className="rounded-md border">
                        <button
                          type="button"
                          className="flex w-full flex-wrap items-center justify-between gap-2 p-3 text-left hover:bg-muted/50"
                          onClick={() => setFicha(abiertoFicha ? null : legajo)}
                        >
                          <span>
                            <span className="font-medium">{legajo}</span>{" "}
                            <span className="text-muted-foreground">
                              {ops[0].apellido_nombre ?? "—"}
                            </span>
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {ops.length} operación(es) · pedido {money.format(tot)} · cuota del mes{" "}
                            {money.format(cuotaMes)}
                          </span>
                        </button>
                        {abiertoFicha && (
                          <div className="overflow-x-auto border-t">
                            <table className="w-full text-sm">
                              <thead className="text-xs text-muted-foreground">
                                <tr className="border-b">
                                  <th className="text-left p-2">Período</th>
                                  <th className="text-right p-2">Adelanto solicitado</th>
                                  <th className="text-right p-2">Cuotas originales</th>
                                  <th className="text-left p-2">Cuota del período</th>
                                  <th className="text-left p-2">Estado</th>
                                  <th className="text-left p-2">Refinanciación</th>
                                  <th />
                                </tr>
                              </thead>
                              <tbody>
                                {ops.map((a) => (
                                  <tr key={a.id} className="border-b">
                                    <td className="p-2 whitespace-nowrap">{a.periodo_label}</td>
                                    <td className="p-2 text-right">{money.format(a.monto_pedido)}</td>
                                    <td className="p-2 text-right">{a.cuotas}</td>
                                    <td className="p-2">
                                      {a.cuota_actual
                                        ? `${a.cuota_actual}/${a.cuotas} · ${money.format(a.importe_cuota_periodo)}`
                                        : "—"}
                                    </td>
                                    <td className="p-2">
                                      <Badge
                                        variant={
                                          a.refinanciacion ? "secondary" : a.cuota_actual ? "default" : "outline"
                                        }
                                      >
                                        {a.estado_operacion}
                                      </Badge>
                                    </td>
                                    <td className="p-2 text-xs">
                                      {a.refinanciacion ? (
                                        <Link
                                          to="/admin/refinanciacion"
                                          className="text-primary underline"
                                        >
                                          Plan {money.format(a.refinanciacion.total)} en{" "}
                                          {a.refinanciacion.cuotas} cuotas (saldo{" "}
                                          {money.format(a.refinanciacion.saldo)})
                                        </Link>
                                      ) : (
                                        <span className="text-muted-foreground">Sin refinanciar</span>
                                      )}
                                    </td>
                                    <td className="p-2">
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => delMut.mutate(a.id)}
                                        disabled={delMut.isPending}
                                      >
                                        <Trash2 className="h-4 w-4 text-destructive" />
                                      </Button>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {verTodo && (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="text-xs text-muted-foreground">
                      <tr className="border-b">
                        <th className="text-left p-2">Período</th>
                        <th className="text-left p-2">Legajo</th>
                        <th className="text-left p-2">Apellido y nombre</th>
                        <th className="text-right p-2">Monto pedido</th>
                        <th className="text-right p-2">Cuotas</th>
                        <th className="text-right p-2">Importe cuota</th>
                        <th className="text-left p-2">Estado</th>
                        <th className="text-right p-2">Saldo</th>
                        <th className="text-left p-2">Banco / CBU</th>
                        <th />
                      </tr>
                    </thead>
                    <tbody>
                      {visibles.map((a) => (
                        <tr key={a.id} className="border-b">
                          <td className="p-2 whitespace-nowrap">{a.periodo_label}</td>
                          <td className="p-2 font-medium">{a.legajo}</td>
                          <td className="p-2">{a.apellido_nombre ?? "—"}</td>
                          <td className="p-2 text-right">{money.format(a.monto_pedido)}</td>
                          <td className="p-2 text-right">{a.cuotas}</td>
                          <td className="p-2 text-right">{money.format(a.importe_cuota)}</td>
                          <td className="p-2">
                            <Badge
                              variant={a.refinanciacion ? "secondary" : a.cuota_actual ? "default" : "outline"}
                            >
                              {a.estado_operacion}
                            </Badge>
                          </td>
                          <td className="p-2 text-right">{money.format(a.saldo)}</td>
                          <td className="p-2 text-xs text-muted-foreground">
                            {[a.banco, a.cbu].filter(Boolean).join(" · ") || "—"}
                          </td>
                          <td className="p-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => delMut.mutate(a.id)}
                              disabled={delMut.isPending}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

    </div>
  );
}
