import { createFileRoute, Link } from "@tanstack/react-router";
import { MESES } from "@/lib/periodo";
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  circleBirthdayPayout,
  closePayroll,
  getPayrollPeriod,
  listPayrollPeriods,
  payrollPadron,
  previewPayroll,
  reopenPayroll,
} from "@/lib/payroll.functions";
import { downloadCeamseXlsx } from "@/lib/ceamse-xlsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Download, FileDown, FileText, Loader2, Lock, RefreshCw, Search, Unlock } from "lucide-react";
import * as XLSX from "xlsx";


export const Route = createFileRoute("/_authenticated/admin/liquidacion")({
  component: LiquidacionPanel,
  head: () => ({
    meta: [
      { title: "Liquidación por período | AGOEC" },
      {
        name: "description",
        content:
          "Totales a descontar por servicio y subservicio del período, con export a Excel contable y liquidación de círculos y cumpleaños.",
      },
      { property: "og:title", content: "Liquidación por período | AGOEC" },
      {
        property: "og:description",
        content: "Liquidación por período con Excel de descuentos por número contable.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const money = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });
const n2 = (v: number) => Number(Number(v || 0).toFixed(2));

function defaultRange() {
  const now = new Date();
  const pad = (x: number) => String(x).padStart(2, "0");
  const hasta = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 20));
  const desde = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 1, 21));
  const f = (d: Date) => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
  return { desde: f(desde), hasta: f(hasta) };
}

function LiquidacionPanel() {
  const qc = useQueryClient();
  const base = defaultRange();
  const [desde, setDesde] = useState(base.desde);
  const [hasta, setHasta] = useState(base.hasta);
  const [rango, setRango] = useState<{ desde: string; hasta: string } | null>(null);
  const [nombre, setNombre] = useState("");
  const [seleccion, setSeleccion] = useState<string[]>([]);
  const [bajando, setBajando] = useState<string | null>(null);


  const preview = useServerFn(previewPayroll);
  const payout = useServerFn(circleBirthdayPayout);
  const close = useServerFn(closePayroll);
  const reopen = useServerFn(reopenPayroll);
  const periodsFn = useServerFn(listPayrollPeriods);
  const periodFn = useServerFn(getPayrollPeriod);

  const padronFn = useServerFn(payrollPadron);

  /** Excel oficial de CEAMSE (formato NoDescontado) de un período liquidado. */
  async function descargar(p: any) {
    try {
      setBajando(p.id);
      const res: any = await periodFn({ data: { id: p.id } });
      const cs: any[] = res.conceptos ?? [];
      const rs: any[] = res.rows ?? [];
      if (!rs.length) return toast.error("Este período no tiene detalle guardado");
      const { padron } = await padronFn({ data: { legajos: rs.map((r: any) => String(r.legajo)) } });
      const n = downloadCeamseXlsx({
        conceptos: cs,
        rows: rs,
        padron,
        desde: p.desde,
        hasta: p.hasta,
        periodo: p.nombre,
      });
      toast.success(`Liquidación de CEAMSE generada: ${n} afiliados`);
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo generar el Excel");
    } finally {
      setBajando(null);
    }
  }

  /** Excel oficial de CEAMSE del período vigente (antes de cerrarlo). */
  async function descargarCeamseVigente() {
    try {
      setBajando("vigente");
      const rs: any[] = previewQ.data?.rows ?? [];
      if (!rs.length) return toast.error("No hay importes para informar en este período");
      const { padron } = await padronFn({ data: { legajos: rs.map((r: any) => String(r.legajo)) } });
      const n = downloadCeamseXlsx({
        conceptos: (previewQ.data?.conceptos ?? []) as any[],
        rows: rs,
        padron,
        desde: rango?.desde,
        hasta: rango?.hasta,
        periodo: nombrePeriodo,
      });
      toast.success(`Liquidación de CEAMSE generada: ${n} afiliados`);
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo generar el Excel");
    } finally {
      setBajando(null);
    }
  }



  const previewQ = useQuery({
    queryKey: ["payroll-preview", rango?.desde, rango?.hasta],
    queryFn: () => preview({ data: rango! }),
    enabled: !!rango,
  });

  const payoutQ = useQuery({
    queryKey: ["payroll-payout", rango?.desde, rango?.hasta],
    queryFn: () => payout({ data: rango! }),
    enabled: !!rango,
  });

  const periodsQ = useQuery({
    queryKey: ["payroll-periods"],
    queryFn: () => periodsFn({ data: undefined as any }),
  });

  /**
   * Período vigente por corte real: arranca el día siguiente al último cierre
   * total y llega hasta hoy (el día que decidas liquidar). Lo pendiente de
   * cierres parciales anteriores sigue apareciendo porque no está liquidado.
   */
  const vigente = useMemo(() => {
    const ps: any[] = periodsQ.data?.periodos ?? [];
    const totales = ps.filter((p) => !p.concepto_key);
    const ultimo = totales.reduce<string | null>(
      (m, p) => (!m || p.hasta > m ? p.hasta : m),
      null,
    );
    const pad = (x: number) => String(x).padStart(2, "0");
    const f = (d: Date) =>
      `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    const hoy = f(new Date());
    let d = base.desde;
    if (ultimo) {
      const x = new Date(`${ultimo}T12:00:00`);
      x.setDate(x.getDate() + 1);
      d = f(x);
    }
    // Período mensual: el mes siguiente al último "Período <Mes> <aa>" cerrado; si no hay, el mes actual.
    let ult: { mes: number; anio: number } | null = null;
    for (const p of totales) {
      const pm = parseNombrePeriodo(p.nombre);
      if (pm && (!ult || pm.anio * 12 + pm.mes > ult.anio * 12 + ult.mes)) ult = pm;
    }
    const now = new Date();
    const sig = ult
      ? ult.mes === 12
        ? { mes: 1, anio: ult.anio + 1 }
        : { mes: ult.mes + 1, anio: ult.anio }
      : { mes: now.getMonth() + 1, anio: now.getFullYear() };
    return { desde: d > hoy ? hoy : d, hasta: hoy, ultimo, sig };
  }, [periodsQ.data]);

  const [mesP, setMesP] = useState<number>(new Date().getMonth() + 1);
  const [anioP, setAnioP] = useState<number>(new Date().getFullYear());
  const nombrePeriodo = nombreMensual(mesP, anioP);
  const [histSel, setHistSel] = useState<string>("");
  const historicos = useMemo(() => {
    const map = new Map<string, any[]>();
    for (const p of periodsQ.data?.periodos ?? []) {
      const base = String(p.nombre ?? "Sin nombre").split(" · ")[0];
      if (!map.has(base)) map.set(base, []);
      map.get(base)!.push(p);
    }
    return Array.from(map.entries()).map(([nombre, cierres]) => ({ nombre, cierres }));
  }, [periodsQ.data]);
  const histActual = historicos.find((h) => h.nombre === histSel) ?? historicos[0];

  const [autoInit, setAutoInit] = useState(false);
  useEffect(() => {
    if (autoInit || !periodsQ.data) return;
    setAutoInit(true);
    setDesde(vigente.desde);
    setHasta(vigente.hasta);
    setMesP(vigente.sig.mes);
    setAnioP(vigente.sig.anio);
    setRango({ desde: vigente.desde, hasta: vigente.hasta });
  }, [periodsQ.data, autoInit, vigente]);

  const conceptos = previewQ.data?.conceptos ?? [];
  const rows = previewQ.data?.rows ?? [];

  const closeMut = useMutation({
    mutationFn: (vars: { conceptos?: string[]; nombre?: string }) =>
      close({
        data: {
          ...rango!,
          nombre: vars.nombre ?? nombrePeriodo,
          ...(vars.conceptos?.length ? { conceptos: vars.conceptos } : {}),
        },
      }),
    onSuccess: (r: any, vars) => {
      toast.success(`Cerrado: ${r.afiliados} afiliados, ${money.format(r.total)}`);
      setSeleccion([]);
      // Cierre total: se abre automáticamente el período nuevo desde mañana.
      if (!vars?.conceptos?.length) setAutoInit(false);
      qc.invalidateQueries({ queryKey: ["payroll-periods"] });
      qc.invalidateQueries({ queryKey: ["payroll-preview"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Error al cerrar el período"),
  });

  const reopenMut = useMutation({
    mutationFn: (id: string) => reopen({ data: { id } }),
    onSuccess: () => {
      toast.success("Período reabierto: sus consumos vuelven a estar disponibles");
      qc.invalidateQueries({ queryKey: ["payroll-periods"] });
      qc.invalidateQueries({ queryKey: ["payroll-preview"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Error al reabrir"),
  });

  const totalesPorConcepto = useMemo(
    () => conceptos.slice().sort((a: any, b: any) => b.total - a.total),
    [conceptos],
  );

  /** Cierres ya hechos para este mismo período (totales o por servicio). */
  const cierresDelPeriodo = useMemo(
    () =>
      (periodsQ.data?.periodos ?? []).filter(
        (p: any) => rango && p.desde === rango.desde && p.hasta === rango.hasta,
      ),
    [periodsQ.data, rango],
  );

  const cerradoPorConcepto = useMemo(() => {
    const map = new Map<string, any>();
    for (const p of cierresDelPeriodo) {
      const keys: string[] = p.concepto_key
        ? String(p.concepto_key).split(",").filter(Boolean)
        : [];
      for (const k of keys) if (!map.has(k)) map.set(k, p);
    }
    return map;
  }, [cierresDelPeriodo]);

  const totalCerrado = useMemo(
    () =>
      cierresDelPeriodo.reduce((a: number, p: any) => a + Number(p.total_descuento ?? 0), 0),
    [cierresDelPeriodo],
  );

  const pendientes = useMemo(
    () => totalesPorConcepto.filter((c: any) => c.total > 0 && !cerradoPorConcepto.has(c.key)),
    [totalesPorConcepto, cerradoPorConcepto],
  );

  const totalPendiente = useMemo(
    () => pendientes.reduce((a: number, c: any) => a + Number(c.total ?? 0), 0),
    [pendientes],
  );


  /** Excel resumen: detalle por servicio + total de pesos del período. */
  function exportResumenServicios() {
    if (!totalesPorConcepto.length) return toast.error("No hay servicios con importes en el período");
    const data = totalesPorConcepto.map((c: any) => {
      const cerrado = cerradoPorConcepto.get(c.key);
      return {
        "Nº contable": c.cuenta_contable ?? "",
        "Servicio / Subservicio": c.nombre,
        Afiliados: Number(c.afiliados ?? 0),
        "Total a descontar": n2(c.total ?? 0),
        Estado: cerrado ? "Cerrado" : Number(c.total) > 0 ? "Pendiente" : "Sin movimientos",
        "Cerrado en": cerrado?.nombre ?? "",
      };
    });
    const totalRow = {
      "Nº contable": "",
      "Servicio / Subservicio": "TOTAL DEL PERÍODO",
      Afiliados: "",
      "Total a descontar": n2((previewQ.data?.total ?? 0) + totalCerrado),
      Estado: "",
      "Cerrado en": "",
    };
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet([
        { "Nº contable": "Período", "Servicio / Subservicio": `${rango!.desde} al ${rango!.hasta}` } as any,
        {} as any,
        ...data,
        totalRow as any,
      ]),
      "Resumen por servicio",
    );
    XLSX.writeFile(wb, `liquidacion_resumen_servicios_${rango!.desde}_al_${rango!.hasta}.xlsx`);
  }

  function exportDescuentos() {

    if (!rows.length) return toast.error("No hay importes para exportar");
    const colFor = (c: any) => ({
      inf: `${c.cuenta_contable ? c.cuenta_contable + " " : ""}Inf. ${c.nombre}`,
      desc: `${c.cuenta_contable ? c.cuenta_contable + " " : ""}${c.nombre}`,
      no: `NO DESC ${c.nombre}`,
    });
    const data = rows.map((r: any) => {
      const o: Record<string, any> = { ID_EMPLEADO: r.legajo, APELLIDO_NOMBRE: r.apellido_nombre ?? "" };
      for (const c of conceptos) {
        const cols = colFor(c);
        const v = Number(r.por_concepto[c.key] ?? 0);
        o[cols.inf] = "";
        o[cols.desc] = v ? n2(v) : "";
        o[cols.no] = "";
      }
      o["TOTAL A DESCONTAR"] = n2(r.total);
      return o;
    });
    const totalRow: Record<string, any> = { ID_EMPLEADO: "", APELLIDO_NOMBRE: "TOTAL" };
    for (const c of conceptos) {
      const cols = colFor(c);
      totalRow[cols.inf] = "";
      totalRow[cols.desc] = n2(c.total);
      totalRow[cols.no] = "";
    }
    totalRow["TOTAL A DESCONTAR"] = n2(previewQ.data?.total ?? 0);

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet([...data, totalRow]),
      "Resultado",
    );
    XLSX.writeFile(wb, `liquidacion_${rango!.desde}_al_${rango!.hasta}.xlsx`);
  }

  function exportPagos() {
    const pr = payoutQ.data?.rows ?? [];
    if (!pr.length) return toast.error("No hay cobros de círculos ni cumpleaños en el período");
    const data = pr.map((r: any) => ({
      Tipo: r.tipo,
      Detalle: r.detalle,
      Legajo: r.legajo,
      "Apellido y Nombre": r.apellido_nombre ?? "",
      "Importe a cobrar": n2(r.importe),
    }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet([
        ...data,
        {
          Tipo: "",
          Detalle: "",
          Legajo: "",
          "Apellido y Nombre": "TOTAL",
          "Importe a cobrar": n2(payoutQ.data?.total ?? 0),
        },
      ]),
      "Cobros",
    );
    XLSX.writeFile(wb, `liquidacion_circulos_cumpleanos_${rango!.desde}_al_${rango!.hasta}.xlsx`);
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Liquidación</h1>
        <p className="text-sm text-muted-foreground">
          Período vigente: desde el día siguiente al último cierre
          {vigente.ultimo ? ` (${vigente.ultimo})` : ""} hasta hoy. Liquidás el día que decidas
          (todo junto o por servicio); lo cerrado pasa al histórico y lo nuevo queda en el período
          siguiente. Lo ya liquidado nunca se vuelve a cargar.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Período a liquidar</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-3 items-end">
          <div className="space-y-2">
            <Label>Período</Label>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Período</span>
              <select
                className="h-9 rounded-md border border-input bg-background px-2 text-sm"
                value={mesP}
                onChange={(e) => setMesP(Number(e.target.value))}
              >
                {MESES.map((m, i) => (
                  <option key={m} value={i + 1}>{m}</option>
                ))}
              </select>
              <Input
                type="number"
                min={2000}
                className="w-24"
                value={anioP}
                onChange={(e) => setAnioP(Number(e.target.value) || new Date().getFullYear())}
              />
            </div>
          </div>
          <div className="text-sm text-muted-foreground md:col-span-1">
            Incluye todo lo pendiente de liquidar hasta hoy
            {vigente.ultimo ? ` (último cierre: ${vigente.ultimo})` : ""}.
          </div>
          <Button
            onClick={() => {
              setDesde(vigente.desde);
              setHasta(vigente.hasta);
              setRango({ desde: vigente.desde, hasta: vigente.hasta });
            }}
          >
            <Search className="h-4 w-4 mr-1" /> Ver {nombrePeriodo}
          </Button>
        </CardContent>
      </Card>

      {!rango ? (
        <Card>
          <CardContent className="py-10 text-center text-sm text-muted-foreground">
            Cargando el período vigente…
          </CardContent>
        </Card>
      ) : (
        <Tabs defaultValue="descuentos">
          <TabsList>
            <TabsTrigger value="descuentos">Descuentos por servicio</TabsTrigger>
            <TabsTrigger value="pagos">Círculos y Cumpleaños</TabsTrigger>
            
          </TabsList>

          <TabsContent value="descuentos" className="space-y-4 pt-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Stat
                label="Total a liquidar en el período"
                value={money.format((previewQ.data?.total ?? 0) + totalCerrado)}
              />

              <Stat label="Ya cerrado" value={money.format(totalCerrado)} />
              <Stat label="Pendiente de cerrar" value={money.format(totalPendiente)} />
              <Stat label="Período" value={nombrePeriodo} />
            </div>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between flex-wrap gap-2">
                <div>
                  <CardTitle>Servicios del período ({totalesPorConcepto.length})</CardTitle>
                  <p className="text-xs text-muted-foreground mt-1">
                    Cerrá cada servicio por separado, varios juntos o todo el período.
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button
                    className="bg-red-600 hover:bg-red-700 text-white font-semibold"
                    onClick={descargarCeamseVigente}
                    disabled={!rows.length || bajando === "vigente"}
                  >
                    {bajando === "vigente" ? (
                      <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                    ) : (
                      <FileDown className="h-4 w-4 mr-1" />
                    )}
                    Bajar liquidación del período (CEAMSE)
                  </Button>

                  <Button
                    variant="secondary"
                    onClick={exportResumenServicios}
                    disabled={!totalesPorConcepto.length}
                  >
                    <Download className="h-4 w-4 mr-1" /> Excel por servicio (totales)
                  </Button>
                  <Button variant="secondary" onClick={exportDescuentos} disabled={!rows.length}>
                    <Download className="h-4 w-4 mr-1" /> Excel de descuentos
                  </Button>

                  <Button
                    variant="outline"
                    onClick={() => closeMut.mutate({ conceptos: seleccion })}
                    disabled={!seleccion.length || closeMut.isPending}
                  >
                    <Lock className="h-4 w-4 mr-1" /> Cerrar seleccionados ({seleccion.length})
                  </Button>
                  <Button
                    onClick={() => closeMut.mutate({})}
                    disabled={!pendientes.length || closeMut.isPending}
                  >
                    {closeMut.isPending ? (
                      <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                    ) : (
                      <Lock className="h-4 w-4 mr-1" />
                    )}
                    Cerrar todo el período
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {previewQ.isLoading ? (
                  <div className="text-sm">Calculando...</div>
                ) : !conceptos.length ? (
                  <div className="text-sm text-muted-foreground">
                    No hay importes pendientes de liquidar en este período.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="text-left border-b">
                        <tr>
                          <th className="py-2 pr-2">
                            <input
                              type="checkbox"
                              aria-label="Seleccionar todos"
                              checked={!!pendientes.length && seleccion.length === pendientes.length}
                              onChange={(e) =>
                                setSeleccion(
                                  e.target.checked ? pendientes.map((c: any) => c.key) : [],
                                )
                              }
                            />
                          </th>
                          <th className="py-2 pr-2">Nº contable</th>
                          <th className="py-2 pr-2">Servicio / Subservicio</th>
                          <th className="py-2 pr-2 text-center">Afiliados</th>
                          <th className="py-2 pr-2 text-right">Total a descontar</th>
                          <th className="py-2 pr-2">Estado</th>
                          <th className="py-2 pr-2 text-right">Acción</th>
                        </tr>
                      </thead>
                      <tbody>
                        {totalesPorConcepto.map((c: any) => {
                          const cerrado = cerradoPorConcepto.get(c.key);
                          const puede = c.total > 0 && !cerrado;
                          return (
                            <tr key={c.key} className="border-b">
                              <td className="py-2 pr-2">
                                <input
                                  type="checkbox"
                                  aria-label={`Seleccionar ${c.nombre}`}
                                  disabled={!puede}
                                  checked={seleccion.includes(c.key)}
                                  onChange={(e) =>
                                    setSeleccion((s) =>
                                      e.target.checked
                                        ? [...s, c.key]
                                        : s.filter((k) => k !== c.key),
                                    )
                                  }
                                />
                              </td>
                              <td className="py-2 pr-2 font-mono">{c.cuenta_contable ?? "—"}</td>
                              <td className="py-2 pr-2">{c.nombre}</td>
                              <td className="py-2 pr-2 text-center">{c.afiliados}</td>
                              <td className="py-2 pr-2 text-right">{money.format(c.total)}</td>
                              <td className="py-2 pr-2">
                                {cerrado ? (
                                  <span className="rounded bg-primary/15 px-2 py-0.5 text-xs text-primary">
                                    Cerrado
                                  </span>
                                ) : c.total > 0 ? (
                                  <span className="rounded bg-secondary px-2 py-0.5 text-xs text-secondary-foreground">
                                    Pendiente
                                  </span>
                                ) : (
                                  <span className="text-xs text-muted-foreground">Sin movimientos</span>
                                )}
                              </td>
                              <td className="py-2 pr-2 text-right">
                                {cerrado ? (
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => reopenMut.mutate(cerrado.id)}
                                    disabled={reopenMut.isPending}
                                  >
                                    <Unlock className="h-4 w-4 mr-1" /> Reabrir
                                  </Button>
                                ) : (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    disabled={!puede || closeMut.isPending}
                                    onClick={() =>
                                      closeMut.mutate({
                                        conceptos: [c.key],
                                        nombre: `${nombrePeriodo} · ${c.nombre}`,
                                      })
                                    }
                                  >
                                    <Lock className="h-4 w-4 mr-1" /> Cerrar
                                  </Button>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                        <tr className="font-semibold">
                          <td className="py-2 pr-2" colSpan={4}>
                            TOTAL
                          </td>
                          <td className="py-2 pr-2 text-right">
                            {money.format(previewQ.data?.total ?? 0)}
                          </td>
                          <td colSpan={2} />
                        </tr>
                      </tbody>
                    </table>
                    <p className="text-xs text-muted-foreground mt-2">
                      Faltan números contables? Cargalos en{" "}
                      <Link to="/admin/informes" className="underline">
                        Informes contables
                      </Link>
                      .
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>


            <Card>
              <CardHeader>
                <CardTitle>Detalle por afiliado ({rows.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {!rows.length ? (
                  <div className="text-sm text-muted-foreground">Sin descuentos.</div>
                ) : (
                  <div className="overflow-x-auto max-h-[600px]">
                    <table className="w-full text-sm">
                      <thead className="text-left border-b sticky top-0 bg-card">
                        <tr>
                          <th className="py-2 pr-2">Legajo</th>
                          <th className="py-2 pr-2">Apellido y Nombre</th>
                          {conceptos.map((c: any) => (
                            <th key={c.key} className="py-2 pr-2 text-right whitespace-nowrap">
                              {c.cuenta_contable ? `${c.cuenta_contable} ` : ""}
                              {c.nombre}
                            </th>
                          ))}
                          <th className="py-2 pr-2 text-right">Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {rows.map((r: any) => (
                          <tr key={r.legajo} className="border-b">
                            <td className="py-2 pr-2 font-mono">{r.legajo}</td>
                            <td className="py-2 pr-2">{r.apellido_nombre ?? "—"}</td>
                            {conceptos.map((c: any) => (
                              <td key={c.key} className="py-2 pr-2 text-right">
                                {r.por_concepto[c.key] ? money.format(r.por_concepto[c.key]) : "—"}
                              </td>
                            ))}
                            <td className="py-2 pr-2 text-right font-semibold">
                              {money.format(r.total)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pagos" className="space-y-4 pt-4">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <Stat label="Círculos a pagar" value={money.format(payoutQ.data?.total_circulos ?? 0)} />
              <Stat
                label="Cumpleaños a pagar"
                value={money.format(payoutQ.data?.total_cumpleanos ?? 0)}
              />
              <Stat label="Total a pagar" value={money.format(payoutQ.data?.total ?? 0)} />
            </div>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between flex-wrap gap-2">
                <CardTitle>Legajos que cobran en el período</CardTitle>
                <Button
                  variant="secondary"
                  onClick={exportPagos}
                  disabled={!(payoutQ.data?.rows ?? []).length}
                >
                  <Download className="h-4 w-4 mr-1" /> Excel círculos y cumpleaños
                </Button>
              </CardHeader>
              <CardContent>
                {payoutQ.isLoading ? (
                  <div className="text-sm">Calculando...</div>
                ) : !(payoutQ.data?.rows ?? []).length ? (
                  <div className="text-sm text-muted-foreground">
                    Nadie cobra círculo ni cumpleaños en este período.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="text-left border-b">
                        <tr>
                          <th className="py-2 pr-2">Tipo</th>
                          <th className="py-2 pr-2">Detalle</th>
                          <th className="py-2 pr-2">Legajo</th>
                          <th className="py-2 pr-2">Apellido y Nombre</th>
                          <th className="py-2 pr-2 text-right">Importe a cobrar</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(payoutQ.data?.rows ?? []).map((r: any, i: number) => (
                          <tr key={`${r.tipo}-${r.legajo}-${i}`} className="border-b">
                            <td className="py-2 pr-2">{r.tipo}</td>
                            <td className="py-2 pr-2">{r.detalle}</td>
                            <td className="py-2 pr-2 font-mono">{r.legajo}</td>
                            <td className="py-2 pr-2">{r.apellido_nombre ?? "—"}</td>
                            <td className="py-2 pr-2 text-right">{money.format(r.importe)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

        </Tabs>
      )}

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex flex-wrap items-center gap-3">
            <CardTitle>Histórico de períodos</CardTitle>
            {historicos.length ? (
              <select
                aria-label="Elegir período histórico"
                className="h-9 rounded-md border border-input bg-background px-2 text-sm"
                value={histActual?.nombre ?? ""}
                onChange={(e) => setHistSel(e.target.value)}
              >
                {historicos.map((h) => (
                  <option key={h.nombre} value={h.nombre}>{h.nombre}</option>
                ))}
              </select>
            ) : null}
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => qc.invalidateQueries({ queryKey: ["payroll-periods"] })}
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent>
          {!(periodsQ.data?.periodos ?? []).length ? (
            <div className="text-sm text-muted-foreground">Todavía no cerraste períodos.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left border-b">
                  <tr>
                    <th className="py-2 pr-2">Período</th>
                    <th className="py-2 pr-2">Servicios</th>
                    <th className="py-2 pr-2">Cerrado el</th>
                    <th className="py-2 pr-2 text-center">Afiliados</th>
                    <th className="py-2 pr-2 text-right">Total descontado</th>
                    <th className="py-2 pr-2"></th>
                  </tr>
                </thead>
                <tbody>
                  {(histActual?.cierres ?? []).map((p: any) => (
                    <tr key={p.id} className="border-b">
                      <td className="py-2 pr-2 font-medium">{p.nombre}</td>
                      <td className="py-2 pr-2 text-xs text-muted-foreground">
                        {p.concepto_nombre ?? "Todos los servicios"}
                      </td>
                      <td className="py-2 pr-2 font-mono">{p.hasta}</td>
                      <td className="py-2 pr-2 text-center">{p.total_afiliados}</td>
                      <td className="py-2 pr-2 text-right">
                        {money.format(Number(p.total_descuento))}
                      </td>
                      <td className="py-2 pr-2">
                        <div className="flex justify-end gap-1">
                          <Button asChild variant="outline" size="sm">
                            <Link to="/admin/liquidacion/$id" params={{ id: p.id }}>
                              <FileText className="h-4 w-4 mr-1" /> Ver detalle
                            </Link>
                          </Button>
                          <Button
                            size="sm"
                            className="bg-red-600 hover:bg-red-700 text-white font-semibold"
                            onClick={() => descargar(p)}
                            disabled={bajando === p.id}
                          >
                            {bajando === p.id ? (
                              <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                            ) : (
                              <FileDown className="h-4 w-4 mr-1" />
                            )}
                            Bajar liquidación
                          </Button>

                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => reopenMut.mutate(p.id)}
                            disabled={reopenMut.isPending}
                          >
                            <Unlock className="h-4 w-4 mr-1" /> Reabrir
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}


function nombreMensual(mes: number, anio: number) {
  return `Período ${MESES[mes - 1]} ${String(anio).slice(-2)}`;
}

function parseNombrePeriodo(nombre: any): { mes: number; anio: number } | null {
  const m = String(nombre ?? "").match(/per[ií]odo\s+([a-záéíóú]+)\s+(\d{2,4})/i);
  if (!m) return null;
  const i = MESES.findIndex((x) => x.toLowerCase() === m[1].toLowerCase());
  if (i < 0) return null;
  const y = Number(m[2]);
  return { mes: i + 1, anio: y < 100 ? 2000 + y : y };
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="text-xs uppercase text-muted-foreground">{label}</div>
        <div className="text-xl font-bold mt-1">{value}</div>
      </CardContent>
    </Card>
  );
}
