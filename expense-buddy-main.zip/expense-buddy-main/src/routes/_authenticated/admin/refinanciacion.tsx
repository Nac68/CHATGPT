import { createFileRoute } from "@tanstack/react-router";
import { Fragment, useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  listRefinances,
  cancelRefinance,
  refinanceByService,
  rescheduleRefinance,
} from "@/lib/refinance.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Download, Loader2, CreditCard, Trash2 } from "lucide-react";
import * as XLSX from "xlsx";
import { toast } from "sonner";
import { compareLegajo } from "@/lib/legajo";
import { periodoError } from "@/lib/periodo";
import { consolidationPreview } from "@/lib/refinance-plan";


export const Route = createFileRoute("/_authenticated/admin/refinanciacion")({
  head: () => ({
    meta: [
      { title: "Refinanciación de consumos | AGOEC" },
      {
        name: "description",
        content:
          "Legajos con consumos refinanciados en AGOEC: planes de cuotas, saldo pendiente y cuota del período.",
      },
      { property: "og:title", content: "Refinanciación de consumos | AGOEC" },
      {
        property: "og:description",
        content: "Planes de refinanciación por afiliado, cuotas y saldos pendientes.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RefinanciacionPage,
  errorComponent: ({ error }) => (
    <p className="p-6 text-sm text-destructive">No se pudo cargar: {error.message}</p>
  ),
  notFoundComponent: () => <p className="p-6 text-sm text-muted-foreground">No encontrado.</p>,
});

const currency = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });

function RefinanciacionPage() {
  const list = useServerFn(listRefinances);
  const cancelar = useServerFn(cancelRefinance);
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [busyId, setBusyId] = useState<string | null>(null);
  const [abierta, setAbierta] = useState<string | null>(null);
  const [size, setSize] = useState(20);
  const [origen, setOrigen] = useState("todos");
  const [reprogramar, setReprogramar] = useState<any | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["refinanciaciones"],
    queryFn: () => list(),
  });

  const refs = (data?.refinanciaciones ?? []) as any[];
  const resumen = data?.resumen;

  const filtradas = useMemo(() => {
    const t = q.trim().toLowerCase();
    return refs
      .filter((r) => origen === "todos" || (r.origen ?? "consumo") === origen)
      .filter(
        (r) =>
          !t ||
          String(r.legajo).toLowerCase().includes(t) ||
          String(r.apellido_nombre ?? "").toLowerCase().includes(t),
      )
      .sort((a, b) => compareLegajo(a.legajo, b.legajo));
  }, [refs, q, origen]);

  const vigentes = filtradas.filter((r) => !r.finalizada);
  const finalizadas = filtradas.filter((r) => r.finalizada);

  const exportar = (rows: any[], nombre: string) => {
    if (!rows.length) return toast.error("No hay datos para exportar");
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        rows.map((r) => ({
          Legajo: r.legajo,
          "Apellido y Nombre": r.apellido_nombre ?? "",
          Origen: (r.origen ?? "consumo") === "adelanto" ? "Adelanto en cuotas" : "Consumos refinanciados",
          "Refinanciado el": String(r.created_at ?? "").slice(0, 10),
          "Total refinanciado": r.total,

          Cuotas: r.cuotas,
          "Importe cuota": r.importe_cuota,
          "Desde": r.periodo_label,
          "Hasta": r.periodo_fin_label,
          "Cuota actual": r.cuota_actual ?? "",
          "Cuotas restantes": r.cuotas_restantes,
          Saldo: r.saldo,
          Consumos: (r.items ?? []).length,
          Observación: r.observacion ?? "",
        })),
      ),
      "Refinanciaciones",
    );
    XLSX.writeFile(wb, `${nombre}.xlsx`);
  };

  const anular = async (id: string) => {
    setBusyId(id);
    try {
      await cancelar({ data: { id } });
      toast.success("Refinanciación anulada: los consumos vuelven a su cobro original");
      await qc.invalidateQueries({ queryKey: ["refinanciaciones"] });
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo anular");
    } finally {
      setBusyId(null);
    }
  };

  const Tabla = ({ rows }: { rows: any[] }) => {
    const [page, setPage] = useState(1);
    const totalPages = Math.max(1, Math.ceil(rows.length / size));
    const pageSafe = Math.min(page, totalPages);
    const visibles = rows.slice((pageSafe - 1) * size, pageSafe * size);
    return !rows.length ? (
      <p className="py-6 text-sm text-muted-foreground">Sin refinanciaciones en esta vista.</p>
    ) : (
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-muted-foreground">
            <tr className="border-b">
              <th className="py-2 pr-3">Legajo</th>
              <th className="py-2 pr-3">Apellido y Nombre</th>
              <th className="py-2 pr-3">Refinanciado el</th>
              <th className="py-2 pr-3">Total</th>
              <th className="py-2 pr-3">Cuotas</th>
              <th className="py-2 pr-3">Importe cuota</th>
              <th className="py-2 pr-3">Período</th>
              <th className="py-2 pr-3">Estado</th>
              <th className="py-2 pr-3">Saldo</th>
              <th className="py-2 pr-3"></th>
            </tr>
          </thead>
          <tbody>
            {visibles.map((r) => (
              <Fragment key={r.id}>
                <tr className="border-b last:border-0">
                  <td className="py-1.5 pr-3 font-mono">{r.legajo}</td>
                  <td className="py-1.5 pr-3">
                    {r.apellido_nombre ?? "—"}
                    {(r.origen ?? "consumo") === "adelanto" && (
                      <Badge variant="outline" className="ml-2">
                        Adelanto
                      </Badge>
                    )}
                  </td>
                  <td className="py-1.5 pr-3">{String(r.created_at ?? "").slice(0, 10)}</td>

                  <td className="py-1.5 pr-3">{currency.format(r.total)}</td>
                  <td className="py-1.5 pr-3">{r.cuotas}</td>
                  <td className="py-1.5 pr-3">{currency.format(r.importe_cuota)}</td>
                  <td className="py-1.5 pr-3">
                    {r.periodo_label} → {r.periodo_fin_label}
                  </td>
                  <td className="py-1.5 pr-3">
                    {r.consolidada ? (
                      <Badge variant="outline">Reemplazada</Badge>
                    ) : r.finalizada ? (
                      <Badge variant="secondary">Finalizada</Badge>
                    ) : (
                      <Badge>
                        Cuota {r.cuota_actual ?? "—"}/{r.cuotas_efectivas ?? r.cuotas}
                      </Badge>
                    )}
                  </td>
                  <td className="py-1.5 pr-3 font-medium">{currency.format(r.saldo)}</td>
                  <td className="py-1.5 pr-3">
                    <div className="flex justify-end gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setAbierta(abierta === r.id ? null : r.id)}
                      >
                        {abierta === r.id ? "Ocultar" : `Ver ${(r.items ?? []).length} consumos`}
                      </Button>
                      {!r.consolidada && !r.finalizada && (
                        <Button size="sm" variant="secondary" onClick={() => setReprogramar(r)}>
                          Reprogramar
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        disabled={busyId === r.id}
                        onClick={() => anular(r.id)}
                      >
                        {busyId === r.id ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Trash2 className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </td>

                </tr>
                {abierta === r.id && (
                  <tr className="border-b bg-muted/30">
                    <td colSpan={10} className="space-y-3 p-3">
                      <div className="rounded-md border bg-background p-2 text-xs">
                        <p className="mb-1 font-semibold text-muted-foreground">Trazabilidad del plan</p>
                        <div className="grid gap-1 sm:grid-cols-2 lg:grid-cols-3">
                          <span>
                            Cuotas cobradas: <strong>{r.cuotas_cobradas}/{r.cuotas}</strong>
                          </span>
                          <span>
                            Saldo anterior incorporado:{" "}
                            <strong>{currency.format(Number(r.saldo_incorporado ?? 0))}</strong>
                          </span>
                          <span>
                            Nuevos importes:{" "}
                            <strong>
                              {currency.format(
                                Math.round(
                                  (Number(r.total) - Number(r.saldo_incorporado ?? 0)) * 100,
                                ) / 100,
                              )}
                            </strong>
                          </span>
                          <span>
                            Capital consolidado: <strong>{currency.format(r.total)}</strong>
                          </span>
                          <span>
                            Cuotas: <strong>{r.cuotas}</strong> de{" "}
                            <strong>{currency.format(r.importe_cuota)}</strong>
                            {r.importe_ultima_cuota !== r.importe_cuota &&
                              ` (última ${currency.format(r.importe_ultima_cuota)})`}
                          </span>
                          <span>
                            Período inicial: <strong>{r.periodo_label}</strong>
                          </span>
                          {r.reemplaza_a && (
                            <span>
                              Reemplaza al plan anterior{" "}
                              <span className="font-mono">{String(r.reemplaza_a).slice(0, 8)}</span>
                            </span>
                          )}
                          {r.reemplazada_por && (
                            <span>
                              Reemplazada por{" "}
                              <span className="font-mono">{String(r.reemplazada_por).slice(0, 8)}</span>
                              {r.cuotas_efectivas != null &&
                                ` · sólo se cobraron ${r.cuotas_efectivas} cuota(s)`}
                            </span>
                          )}
                        </div>
                      </div>
                      <table className="w-full text-xs">
                        <thead className="text-left text-muted-foreground">
                          <tr>
                            <th className="pb-1 pr-3">Servicio</th>
                            <th className="pb-1 pr-3">Detalle</th>
                            <th className="pb-1 pr-3">Período original</th>
                            <th className="pb-1 pr-3">Importe</th>

                          </tr>
                        </thead>
                        <tbody>
                          {(r.items ?? []).map((i: any) => (
                            <tr key={i.id}>
                              <td className="py-1 pr-3">{i.servicio ?? "—"}</td>
                              <td className="py-1 pr-3">{i.detalle ?? "—"}</td>
                              <td className="py-1 pr-3">{i.periodo ?? "—"}</td>
                              <td className="py-1 pr-3">{currency.format(Number(i.importe ?? 0))}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </td>
                  </tr>
                )}
              </Fragment>
            ))}
          </tbody>
        </table>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <select
            className="h-9 rounded-md border bg-background px-2 text-sm"
            value={size}
            onChange={(e) => {
              setSize(Number(e.target.value));
              setPage(1);
            }}
          >
            {[10, 20, 50, 100].map((n) => (
              <option key={n} value={n}>
                {n} por página
              </option>
            ))}
          </select>
          <Button size="sm" variant="outline" disabled={pageSafe <= 1} onClick={() => setPage(pageSafe - 1)}>
            Anterior
          </Button>
          <span className="text-xs text-muted-foreground">
            Página {pageSafe} de {totalPages} · {rows.length} planes
          </span>
          <Button
            size="sm"
            variant="outline"
            disabled={pageSafe >= totalPages}
            onClick={() => setPage(pageSafe + 1)}
          >
            Siguiente
          </Button>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="flex items-center gap-2 text-2xl font-bold">
          <CreditCard className="h-6 w-6 text-primary" />
          Refinanciación
        </h1>
        <p className="text-sm text-muted-foreground">
          Legajos con consumos refinanciados. Cada plan se descuenta en cuotas y reemplaza el cobro del
          servicio original.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {[
          ["Legajos", String(resumen?.legajos ?? 0)],
          ["Planes activos", String(resumen?.activas ?? 0)],
          ["Total refinanciado", currency.format(resumen?.total ?? 0)],
          ["Saldo pendiente", currency.format(resumen?.saldo ?? 0)],
          ["Cuota del período", currency.format(resumen?.cuota_periodo ?? 0)],
        ].map(([label, value]) => (
          <Card key={label}>
            <CardHeader className="pb-2">
              <CardDescription>{label}</CardDescription>
              <CardTitle className="text-xl">{value}</CardTitle>
            </CardHeader>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Planes de refinanciación</CardTitle>
          <CardDescription>
            Se generan desde el Buscador CRM seleccionando los consumos del afiliado.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex flex-wrap gap-2">
            <Input
              className="max-w-xs"
              placeholder="Buscar por legajo o nombre…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
            <select
              className="h-10 rounded-md border bg-background px-3 text-sm"
              value={origen}
              onChange={(e) => setOrigen(e.target.value)}
            >
              <option value="todos">Todo origen</option>
              <option value="consumo">Consumos refinanciados</option>
              <option value="adelanto">Adelantos en cuotas</option>
            </select>
            <Button variant="outline" onClick={() => exportar(filtradas, "refinanciaciones")}>
              <Download className="mr-2 h-4 w-4" />
              Excel
            </Button>
          </div>
          {isLoading ? (
            <p className="flex items-center gap-2 py-6 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" /> Cargando…
            </p>
          ) : (
            <Tabs defaultValue="vigentes">
              <TabsList>
                <TabsTrigger value="vigentes">En curso ({vigentes.length})</TabsTrigger>
                <TabsTrigger value="finalizadas">Finalizadas ({finalizadas.length})</TabsTrigger>
                <TabsTrigger value="servicios">Por servicio</TabsTrigger>
                <TabsTrigger value="periodos">Por período</TabsTrigger>
              </TabsList>
              <TabsContent value="vigentes" className="pt-4">
                <Tabla rows={vigentes} />
              </TabsContent>
              <TabsContent value="finalizadas" className="pt-4">
                <Tabla rows={finalizadas} />
              </TabsContent>
              <TabsContent value="servicios" className="pt-4">
                <PorServicio />
              </TabsContent>
              <TabsContent value="periodos" className="pt-4">
                <PorPeriodo rows={filtradas} />
              </TabsContent>
            </Tabs>

          )}
        </CardContent>
      </Card>

      <ReprogramarDialog
        plan={reprogramar}
        onOpenChange={(v) => !v && setReprogramar(null)}
        onDone={() => qc.invalidateQueries()}
      />
    </div>
  );
}

/** Cambia la cantidad de cuotas de un plan activo, sólo sobre el saldo futuro. */
function ReprogramarDialog({
  plan,
  onOpenChange,
  onDone,
}: {
  plan: any | null;
  onOpenChange: (v: boolean) => void;
  onDone: () => void;
}) {
  const hoy = new Date();
  const [cuotas, setCuotas] = useState(3);
  const [mes, setMes] = useState(hoy.getUTCMonth() + 1);
  const [anio, setAnio] = useState(hoy.getUTCFullYear());
  const [saving, setSaving] = useState(false);
  const reprogFn = useServerFn(rescheduleRefinance);

  useEffect(() => {
    if (plan) {
      setCuotas(Math.max(1, Number(plan.cuotas_restantes) || 1));
      setMes(hoy.getUTCMonth() + 1);
      setAnio(hoy.getUTCFullYear());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [plan?.id]);

  const cuotasSafe = Math.max(1, Math.min(60, Number(cuotas) || 1));
  const pv = plan
    ? consolidationPreview({
        anterior: plan,
        nuevos: 0,
        cuotas: cuotasSafe,
        mes: Number(mes),
        anio: Number(anio),
      })
    : null;

  const submit = async () => {
    if (!plan) return;
    setSaving(true);
    try {
      await reprogFn({
        data: {
          id: plan.id,
          cuotas: cuotasSafe,
          periodo_mes: Number(mes),
          periodo_anio: Number(anio),
        },
      });
      toast.success("Plan reprogramado sobre el saldo futuro");
      onOpenChange(false);
      onDone();
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo reprogramar");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={!!plan} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Reprogramar refinanciación</DialogTitle>
          <DialogDescription>
            Legajo {plan?.legajo} · sólo se reparte el saldo futuro. Las cuotas ya cobradas y los
            períodos cerrados no se modifican.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-3">
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label htmlFor="rp-cuotas">Cuotas</Label>
              <Input
                id="rp-cuotas"
                type="number"
                min={1}
                max={60}
                value={cuotas}
                onChange={(e) => setCuotas(Number(e.target.value))}
              />
            </div>
            <div>
              <Label htmlFor="rp-mes">Mes inicio</Label>
              <Input
                id="rp-mes"
                type="number"
                min={1}
                max={12}
                value={mes}
                onChange={(e) => setMes(Number(e.target.value))}
              />
            </div>
            <div>
              <Label htmlFor="rp-anio">Año inicio</Label>
              <Input
                id="rp-anio"
                type="number"
                min={2000}
                max={2100}
                value={anio}
                onChange={(e) => setAnio(Number(e.target.value))}
              />
            </div>
          </div>
          {periodoError(mes, anio) ? (
            <p className="rounded-md border border-destructive bg-destructive/5 px-3 py-2 text-sm text-destructive">
              {periodoError(mes, anio)}
            </p>
          ) : (
            <div className="rounded-md border bg-muted/40 px-3 py-2 text-sm space-y-1">
              <p>
                Cuotas conservadas: <strong>{pv?.cuotas_conservadas ?? 0}</strong> de {plan?.cuotas} ·
                saldo a reprogramar <strong>{currency.format(pv?.capital ?? 0)}</strong>
              </p>
              <p>
                {pv?.cuotas} cuotas de <strong>{currency.format(pv?.importe_cuota ?? 0)}</strong> desde{" "}
                {pv?.periodo_label} hasta {pv?.periodo_fin_label}
              </p>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button
            onClick={submit}
            disabled={saving || !!periodoError(mes, anio) || !(pv?.capital ?? 0)}
          >
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Confirmar reprogramación
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}


function PorServicio() {
  const fn = useServerFn(refinanceByService);
  const { data, isLoading } = useQuery({ queryKey: ["refinanciaciones", "servicios"], queryFn: () => fn() });
  const [servicio, setServicio] = useState("todos");
  const [periodo, setPeriodo] = useState("todos");
  const [origen, setOrigen] = useState("todos");
  const [legajo, setLegajo] = useState("");

  const servicios = (data?.servicios ?? []) as any[];
  const detalle = (data?.detalle ?? []) as any[];

  const periodos = useMemo(
    () => Array.from(new Set(detalle.map((d) => d.periodo_label))).sort().reverse(),
    [detalle],
  );

  const filas = useMemo(() => {
    const t = legajo.trim().toLowerCase();
    return detalle.filter(
      (d) =>
        (servicio === "todos" || d.servicio === servicio) &&
        (periodo === "todos" || d.periodo_label === periodo) &&
        (origen === "todos" || (d.origen ?? "consumo") === origen) &&
        (!t ||
          String(d.legajo).toLowerCase().includes(t) ||
          String(d.apellido_nombre ?? "").toLowerCase().includes(t)),
    );
  }, [detalle, servicio, periodo, origen, legajo]);


  const exportar = () => {
    if (!filas.length) return toast.error("No hay datos para exportar");
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        servicios.map((s) => ({
          Servicio: s.servicio,
          Planes: s.planes,
          Legajos: s.legajos,
          Consumos: s.consumos,
          "Total refinanciado": s.total,
          "Saldo pendiente": s.saldo,
        })),
      ),
      "Resumen",
    );
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        filas.map((d) => ({
          Servicio: d.servicio,
          Legajo: d.legajo,
          "Apellido y Nombre": d.apellido_nombre ?? "",
          Origen: (d.origen ?? "consumo") === "adelanto" ? "Adelanto en cuotas" : "Consumos refinanciados",

          Detalle: d.detalle ?? "",
          "Período original": d.periodo_original ?? "",
          Importe: d.importe,
          "Refinanciado el": String(d.fecha ?? "").slice(0, 10),
          "Período inicial": d.periodo_label,
          "Período final": d.periodo_fin_label,
          Cuotas: d.cuotas,
          "Importe cuota": d.importe_cuota,
          "Saldo del consumo": d.saldo,
          Estado: d.finalizada ? "Finalizada" : "En curso",
        })),
      ),
      "Detalle",
    );
    XLSX.writeFile(wb, "refinanciaciones_por_servicio.xlsx");
  };

  if (isLoading)
    return (
      <p className="flex items-center gap-2 py-6 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" /> Cargando…
      </p>
    );

  return (
    <div className="space-y-4">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-muted-foreground">
            <tr className="border-b">
              <th className="py-2 pr-3">Servicio de origen</th>
              <th className="py-2 pr-3">Planes</th>
              <th className="py-2 pr-3">Legajos</th>
              <th className="py-2 pr-3">Consumos</th>
              <th className="py-2 pr-3">Total refinanciado</th>
              <th className="py-2 pr-3">Saldo pendiente</th>
            </tr>
          </thead>
          <tbody>
            {servicios.map((s) => (
              <tr key={s.servicio} className="border-b last:border-0">
                <td className="py-1.5 pr-3 font-medium">{s.servicio}</td>
                <td className="py-1.5 pr-3">{s.planes}</td>
                <td className="py-1.5 pr-3">{s.legajos}</td>
                <td className="py-1.5 pr-3">{s.consumos}</td>
                <td className="py-1.5 pr-3">{currency.format(s.total)}</td>
                <td className="py-1.5 pr-3">{currency.format(s.saldo)}</td>
              </tr>
            ))}
            {!servicios.length && (
              <tr>
                <td colSpan={6} className="py-6 text-center text-sm text-muted-foreground">
                  Todavía no hay consumos refinanciados.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="flex flex-wrap items-end gap-2">
        <select
          className="h-10 rounded-md border bg-background px-3 text-sm"
          value={servicio}
          onChange={(e) => setServicio(e.target.value)}
        >
          <option value="todos">Todos los servicios</option>
          {servicios.map((s) => (
            <option key={s.servicio} value={s.servicio}>
              {s.servicio}
            </option>
          ))}
        </select>
        <select
          className="h-10 rounded-md border bg-background px-3 text-sm"
          value={periodo}
          onChange={(e) => setPeriodo(e.target.value)}
        >
          <option value="todos">Todos los períodos</option>
          {periodos.map((p) => (
            <option key={p} value={p}>
              {p}
            </option>
          ))}
        </select>
        <select
          className="h-10 rounded-md border bg-background px-3 text-sm"
          value={origen}
          onChange={(e) => setOrigen(e.target.value)}
        >
          <option value="todos">Todo origen</option>
          <option value="consumo">Consumos refinanciados</option>
          <option value="adelanto">Adelantos en cuotas</option>
        </select>
        <Input
          className="max-w-[220px]"
          placeholder="Legajo o nombre…"
          value={legajo}
          onChange={(e) => setLegajo(e.target.value)}
        />
        <Button variant="outline" onClick={exportar}>
          <Download className="mr-2 h-4 w-4" />
          Exportar servicios refinanciados
        </Button>
        <span className="self-center text-xs text-muted-foreground">
          {filas.length} consumos · total{" "}
          {currency.format(filas.reduce((a, d) => a + Number(d.importe ?? 0), 0))} · saldo{" "}
          {currency.format(filas.reduce((a, d) => a + Number(d.saldo ?? 0), 0))}
        </span>
      </div>


      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-muted-foreground">
            <tr className="border-b">
              <th className="py-2 pr-3">Servicio</th>
              <th className="py-2 pr-3">Legajo</th>
              <th className="py-2 pr-3">Origen</th>
              <th className="py-2 pr-3">Detalle</th>
              <th className="py-2 pr-3">Período original</th>
              <th className="py-2 pr-3">Importe</th>
              <th className="py-2 pr-3">Refinanciado el</th>
              <th className="py-2 pr-3">Plan</th>
              <th className="py-2 pr-3">Saldo</th>
            </tr>
          </thead>
          <tbody>
            {filas.map((d) => (
              <tr key={d.id} className="border-b last:border-0">
                <td className="py-1.5 pr-3">{d.servicio}</td>
                <td className="py-1.5 pr-3 font-mono">{d.legajo}</td>
                <td className="py-1.5 pr-3">
                  <Badge variant={(d.origen ?? "consumo") === "adelanto" ? "outline" : "secondary"}>
                    {(d.origen ?? "consumo") === "adelanto" ? "Adelanto" : "Consumo"}
                  </Badge>
                </td>
                <td className="py-1.5 pr-3">{d.detalle ?? "—"}</td>
                <td className="py-1.5 pr-3">{d.periodo_original ?? "—"}</td>
                <td className="py-1.5 pr-3">{currency.format(d.importe)}</td>
                <td className="py-1.5 pr-3">{String(d.fecha ?? "").slice(0, 10)}</td>
                <td className="py-1.5 pr-3">
                  {d.cuotas} cuotas · {d.periodo_label} → {d.periodo_fin_label}
                </td>
                <td className="py-1.5 pr-3">{currency.format(d.saldo)}</td>
              </tr>
            ))}
            {!filas.length && (
              <tr>
                <td colSpan={9} className="py-6 text-center text-sm text-muted-foreground">
                  Sin consumos para este filtro.
                </td>
              </tr>
            )}

          </tbody>
        </table>
      </div>
    </div>
  );
}


/** Estadísticas por período (mes/año) de los planes de refinanciación. */
function PorPeriodo({ rows }: { rows: any[] }) {
  const periodos = useMemo(() => {
    const map = new Map<string, any>();
    for (const r of rows) {
      const key = `${r.periodo_anio}-${String(r.periodo_mes).padStart(2, "0")}`;
      const g =
        map.get(key) ??
        {
          key,
          label: r.periodo_label,
          planes: 0,
          legajos: new Set<string>(),
          total: 0,
          saldo: 0,
          cuota: 0,
          adelantos: 0,
          consumos: 0,
          servicios: new Map<string, number>(),
        };
      g.planes += 1;
      g.legajos.add(r.legajo);
      g.total += Number(r.total ?? 0);
      g.saldo += Number(r.saldo ?? 0);
      g.cuota += Number(r.importe_cuota ?? 0);
      if ((r.origen ?? "consumo") === "adelanto") g.adelantos += 1;
      else g.consumos += 1;
      for (const i of r.items ?? []) {
        const sv = (i.servicio || "Sin servicio").toString();
        g.servicios.set(sv, (g.servicios.get(sv) ?? 0) + Number(i.importe ?? 0));
      }
      map.set(key, g);
    }
    return Array.from(map.values())
      .map((g) => ({
        ...g,
        legajos: g.legajos.size,
        total: Math.round(g.total * 100) / 100,
        saldo: Math.round(g.saldo * 100) / 100,
        cuota: Math.round(g.cuota * 100) / 100,
        servicios: (Array.from(g.servicios.entries()) as [string, number][])
          .map(([servicio, total]) => ({ servicio, total: Math.round(total * 100) / 100 }))
          .sort((a, b) => b.total - a.total),

      }))
      .sort((a, b) => (a.key < b.key ? 1 : -1));
  }, [rows]);

  const exportar = () => {
    if (!periodos.length) return toast.error("No hay datos para exportar");
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        periodos.map((p) => ({
          Período: p.label,
          Planes: p.planes,
          Legajos: p.legajos,
          "Total refinanciado": p.total,
          "Saldo pendiente": p.saldo,
          "Cuota mensual": p.cuota,
          "De consumos": p.consumos,
          "De adelantos": p.adelantos,
        })),
      ),
      "Por período",
    );
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        periodos.flatMap((p) =>
          p.servicios.map((s: any) => ({
            Período: p.label,
            Servicio: s.servicio,
            "Total refinanciado": s.total,
            "% del período": p.total ? Math.round((s.total / p.total) * 1000) / 10 : 0,
          })),
        ),
      ),
      "Distribución",
    );
    XLSX.writeFile(wb, "refinanciaciones_por_periodo.xlsx");
  };

  if (!periodos.length)
    return <p className="py-6 text-sm text-muted-foreground">Sin refinanciaciones para resumir.</p>;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <Button variant="outline" onClick={exportar}>
          <Download className="mr-2 h-4 w-4" />
          Excel por período
        </Button>
        <span className="text-xs text-muted-foreground">{periodos.length} períodos con refinanciación</span>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        {periodos.map((p) => (
          <Card key={p.key}>
            <CardHeader className="pb-2">
              <CardDescription>Período de inicio</CardDescription>
              <CardTitle className="text-lg">{p.label}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <div>
                  <p className="text-xs text-muted-foreground">Total refinanciado</p>
                  <p className="font-medium">{currency.format(p.total)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Legajos</p>
                  <p className="font-medium">{p.legajos}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Cuota mensual</p>
                  <p className="font-medium">{currency.format(p.cuota)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Saldo</p>
                  <p className="font-medium">{currency.format(p.saldo)}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Badge variant="secondary">{p.consumos} de consumos</Badge>
                <Badge variant="outline">{p.adelantos} de adelantos</Badge>
              </div>
              <div className="space-y-1">
                <p className="text-xs font-semibold text-muted-foreground">Distribución por servicio</p>
                {p.servicios.length ? (
                  p.servicios.map((s: any) => (
                    <div key={s.servicio} className="flex items-center gap-2">
                      <span className="w-40 truncate text-xs">{s.servicio}</span>
                      <div className="h-2 flex-1 rounded bg-muted">
                        <div
                          className="h-2 rounded bg-primary"
                          style={{ width: `${p.total ? (s.total / p.total) * 100 : 0}%` }}
                        />
                      </div>
                      <span className="w-28 text-right text-xs">{currency.format(s.total)}</span>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-muted-foreground">Sin detalle de servicios.</p>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
