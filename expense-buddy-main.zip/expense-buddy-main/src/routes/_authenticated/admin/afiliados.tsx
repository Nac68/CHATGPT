import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  bulkImportAffiliates,
  createAffiliate,
  deleteAffiliate,
  listAffiliates,
  updateAffiliate,
} from "@/lib/affiliates.functions";
import { resetAffiliatePin } from "@/lib/auth-affiliate.functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Pencil, Trash2, KeyRound, Upload, Loader2, Download } from "lucide-react";
import * as XLSX from "xlsx";
import { compareLegajo } from "@/lib/legajo";
import {
  PADRON_COLUMNS,
  fieldForHeader,
  normalizeCell,
  toExcelRow,
  type PadronRow,
} from "@/lib/padron";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/admin/afiliados")({
  component: Afiliados,
});

const normalize = (s: string) => s.trim().toUpperCase().replace(/\s+/g, "");

// Campos extra del padrón editables a mano
const EXTRA_FIELDS = PADRON_COLUMNS.filter(
  (c) => c.field !== "legajo" && c.field !== "apellido_nombre",
);
const emptyExtra = () =>
  Object.fromEntries(EXTRA_FIELDS.map((c) => [c.field, ""])) as Record<string, string>;


function Afiliados() {
  const [query, setQuery] = useState("");
  const [legajo, setLegajo] = useState("");
  const [nombre, setNombre] = useState("");
  const [extra, setExtra] = useState<Record<string, string>>(emptyExtra);
  const [showExtra, setShowExtra] = useState(false);
  const [editing, setEditing] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState<number>(100);
  const fileRef = useRef<HTMLInputElement>(null);

  const qc = useQueryClient();
  const list = useServerFn(listAffiliates);
  const create = useServerFn(createAffiliate);
  const update = useServerFn(updateAffiliate);
  const del = useServerFn(deleteAffiliate);
  const reset = useServerFn(resetAffiliatePin);
  const bulk = useServerFn(bulkImportAffiliates);

  const { data } = useQuery({
    queryKey: ["affiliates"],
    queryFn: () => list({ data: undefined as any }),
  });

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const base = q
      ? (data ?? []).filter(
          (a: any) =>
            String(a.legajo).toLowerCase().includes(q) ||
            a.apellido_nombre.toLowerCase().includes(q) ||
            String(a.doc_nro ?? "").toLowerCase().includes(q) ||
            String(a.sector ?? "").toLowerCase().includes(q),
        )
      : (data ?? []);
    return [...base].sort((a: any, b: any) => compareLegajo(String(a.legajo), String(b.legajo)));
  }, [data, query]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageRows = useMemo(
    () => filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize),
    [filtered, currentPage, pageSize],
  );

  function resetForm() {
    setLegajo("");
    setNombre("");
    setExtra(emptyExtra());
    setEditing(null);
    setShowExtra(false);
  }

  function startEdit(a: any) {
    setEditing(String(a.legajo));
    setNombre(a.apellido_nombre ?? "");
    setExtra(
      Object.fromEntries(EXTRA_FIELDS.map((c) => [c.field, a?.[c.field] ?? ""])) as Record<
        string,
        string
      >,
    );
    setShowExtra(true);
  }

  function extraPayload() {
    const out: Record<string, string | null> = {};
    for (const c of EXTRA_FIELDS) {
      const v = (extra[c.field] ?? "").trim();
      out[c.field] = v ? v : null;
    }
    return out;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const l = normalize(legajo);
    if (editing == null && !l) return toast.error("Legajo inválido");
    if (nombre.trim().length < 2) return toast.error("Nombre inválido");
    try {
      const payload = { apellido_nombre: nombre.trim(), ...extraPayload() };
      if (editing != null) {
        await update({ data: { legajo: editing, ...payload } as any });
        toast.success("Actualizado");
      } else {
        await create({ data: { legajo: l, ...payload } as any });
        toast.success("Afiliado creado");
      }
      resetForm();
      qc.invalidateQueries({ queryKey: ["affiliates"] });
    } catch (err: any) {
      toast.error(err?.message ?? "Error");
    }
  }

  function exportPadron() {
    const rows = filtered.map(toExcelRow);
    if (!rows.length) return toast.error("No hay afiliados para exportar");
    const ws = XLSX.utils.json_to_sheet(rows, {
      header: PADRON_COLUMNS.map((c) => c.header),
    });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "AFILIADOS");
    XLSX.writeFile(wb, `padron_afiliados_${new Date().toISOString().slice(0, 10)}.xlsx`);
  }


  async function handleDelete(l: string) {
    if (!confirm(`¿Eliminar al afiliado ${l}?`)) return;
    try {
      await del({ data: { legajo: l } });
      toast.success("Eliminado");
      qc.invalidateQueries({ queryKey: ["affiliates"] });
    } catch (err: any) {
      toast.error(err?.message ?? "Error");
    }
  }

  async function handleReset(l: string) {
    const newPin = prompt(`Nuevo PIN para el legajo ${l} (mínimo 4 caracteres)`);
    if (!newPin || newPin.length < 4) return;
    try {
      await reset({ data: { legajo: l, newPin } });
      toast.success("PIN reseteado");
    } catch (err: any) {
      toast.error(err?.message ?? "Error");
    }
  }

  async function onImport(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    setImporting(true);
    try {
      const buf = await f.arrayBuffer();
      const wb = XLSX.read(buf, { type: "array", cellDates: true });

      const rows: PadronRow[] = [];
      // Recorre todas las hojas: toma las que tengan encabezado LEGAJO + nombre.
      for (const name of wb.SheetNames) {
        const ws = wb.Sheets[name];
        const rowsRaw: any[] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null });
        let headerIdx = -1;
        for (let i = 0; i < Math.min(rowsRaw.length, 8); i++) {
          const r = rowsRaw[i] ?? [];
          if (r.some((c: any) => fieldForHeader(c) === "legajo")) {
            headerIdx = i;
            break;
          }
        }
        if (headerIdx < 0) continue;
        const header = rowsRaw[headerIdx] ?? [];
        const cols = header.map((h: any) => fieldForHeader(h));
        if (!cols.includes("legajo") || !cols.includes("apellido_nombre")) continue;

        for (let i = headerIdx + 1; i < rowsRaw.length; i++) {
          const r = rowsRaw[i] ?? [];
          const row: any = {};
          cols.forEach((field: any, idx: number) => {
            if (!field) return;
            const v = normalizeCell(field, r[idx]);
            if (v != null) row[field] = v;
          });
          const legajo = row.legajo ? normalize(String(row.legajo)) : "";
          const apellido_nombre = String(row.apellido_nombre ?? "").trim();
          if (!legajo || apellido_nombre.length < 2) continue;
          rows.push({ ...row, legajo, apellido_nombre });
        }
      }
      if (rows.length === 0)
        throw new Error("No encontré filas con LEGAJO y APELLIDO_Y_NOMBRE en el archivo");

      let escritos = 0;
      const CHUNK = 2000;
      for (let i = 0; i < rows.length; i += CHUNK) {
        const res = await bulk({ data: { rows: rows.slice(i, i + CHUNK) } as any });
        escritos += res.escritos;
      }
      toast.success(`Importados/actualizados: ${escritos} de ${rows.length}`);
      qc.invalidateQueries({ queryKey: ["affiliates"] });
    } catch (err: any) {
      toast.error(err?.message ?? "Error al importar");
    } finally {
      setImporting(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }


  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Afiliados</h1>
        <p className="text-sm text-muted-foreground">
          Legajos alfanuméricos. Podés cargarlos a mano o subir el Excel modelo del padrón (hoja con{" "}
          <b>LEGAJO</b>, <b>APELLIDO_Y_NOMBRE</b>, sector, documento, CUIL, domicilio, teléfonos,
          fechas y lugar de trabajo). El padrón se puede bajar en el mismo formato.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Importar / Exportar padrón</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap items-center gap-2">
          <input
            ref={fileRef}
            type="file"
            accept=".xlsx,.xls,.csv"
            className="hidden"
            onChange={onImport}
          />
          <Button
            type="button"
            variant="secondary"
            onClick={() => fileRef.current?.click()}
            disabled={importing}
          >
            {importing ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Upload className="h-4 w-4 mr-1" />}
            Subir Excel de afiliados
          </Button>
          <Button type="button" variant="outline" onClick={exportPadron}>
            <Download className="h-4 w-4 mr-1" />
            Bajar padrón en Excel
          </Button>
          <span className="text-xs text-muted-foreground">
            Los legajos existentes se actualizan; los nuevos se agregan. La exportación respeta el
            filtro de búsqueda.
          </span>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{editing != null ? `Editar legajo ${editing}` : "Nuevo afiliado"}</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label>Legajo</Label>
              <Input
                value={editing != null ? editing : legajo}
                onChange={(e) => setLegajo(e.target.value.toUpperCase())}
                disabled={editing != null}
                placeholder="Ej: 297 o AB123"
              />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label>Apellido y Nombre</Label>
              <Input value={nombre} onChange={(e) => setNombre(e.target.value)} />
            </div>

            <div className="md:col-span-3">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setShowExtra((v) => !v)}
              >
                {showExtra ? "Ocultar datos del padrón" : "Completar datos del padrón"}
              </Button>
            </div>

            {showExtra &&
              EXTRA_FIELDS.map((c) => (
                <div key={c.field} className="space-y-2">
                  <Label className="text-xs">{c.header.replace(/_/g, " ")}</Label>
                  <Input
                    type={c.date ? "date" : "text"}
                    value={extra[c.field] ?? ""}
                    onChange={(e) =>
                      setExtra((p) => ({ ...p, [c.field]: e.target.value }))
                    }
                  />
                </div>
              ))}

            <div className="md:col-span-3 flex gap-2">
              <Button type="submit">{editing != null ? "Guardar cambios" : "Crear"}</Button>
              {editing != null && (
                <Button type="button" variant="ghost" onClick={resetForm}>
                  Cancelar
                </Button>
              )}
            </div>
          </form>
        </CardContent>
      </Card>


      <Card>
        <CardHeader>
          <CardTitle>Listado ({(data ?? []).length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap items-end gap-3 mb-3">
            <Input
              placeholder="Buscar por legajo, nombre, documento o sector..."
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setPage(1);
              }}
              className="flex-1 min-w-[220px]"
            />
            <div className="space-y-1">
              <Label className="text-xs">Por página</Label>
              <Select
                value={String(pageSize)}
                onValueChange={(v) => {
                  setPageSize(Number(v));
                  setPage(1);
                }}
              >
                <SelectTrigger className="w-[120px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[25, 50, 100, 200, 500, 1000, 5000, 20000].map((n) => (
                    <SelectItem key={n} value={String(n)}>
                      {n >= 20000 ? "Todos" : n}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="rounded border max-h-[540px] overflow-auto">
            <div className="grid grid-cols-12 bg-muted text-xs uppercase font-semibold px-3 py-2 sticky top-0">
              <div className="col-span-2">Legajo</div>
              <div className="col-span-4">Apellido y Nombre</div>
              <div className="col-span-3">Sector / Lugar</div>
              <div className="col-span-1">Doc.</div>
              <div className="col-span-2 text-right">Acciones</div>
            </div>
            {pageRows.map((a: any) => (
              <div
                key={a.legajo}
                className="grid grid-cols-12 px-3 py-2 items-center border-t text-sm"
              >
                <div className="col-span-2 font-mono">{a.legajo}</div>
                <div className="col-span-4 truncate">{a.apellido_nombre}</div>
                <div className="col-span-3 truncate text-xs text-muted-foreground">
                  {a.sector ?? a.lugar_trabajo ?? "—"}
                </div>
                <div className="col-span-1 truncate text-xs font-mono">{a.doc_nro ?? "—"}</div>
                <div className="col-span-2 flex justify-end gap-1">
                  <Button size="icon" variant="ghost" onClick={() => startEdit(a)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant="ghost" onClick={() => handleReset(String(a.legajo))}>
                    <KeyRound className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant="ghost" onClick={() => handleDelete(String(a.legajo))}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2 mt-3">
            <div className="text-xs text-muted-foreground">
              Mostrando {pageRows.length === 0 ? 0 : (currentPage - 1) * pageSize + 1}–
              {(currentPage - 1) * pageSize + pageRows.length} de {filtered.length}
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(1)}
                disabled={currentPage <= 1}
              >
                «
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={currentPage <= 1}
              >
                Anterior
              </Button>
              <span className="text-xs">
                Página {currentPage} de {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage >= totalPages}
              >
                Siguiente
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(totalPages)}
                disabled={currentPage >= totalPages}
              >
                »
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
