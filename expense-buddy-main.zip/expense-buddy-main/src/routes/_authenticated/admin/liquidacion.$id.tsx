import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getPayrollPeriod, payrollPadron } from "@/lib/payroll.functions";
import { downloadCeamseXlsx } from "@/lib/ceamse-xlsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Download, FileDown, Loader2 } from "lucide-react";
import { toast } from "sonner";
import * as XLSX from "xlsx";


export const Route = createFileRoute("/_authenticated/admin/liquidacion/$id")({
  component: PeriodoLiquidado,
  head: () => ({
    meta: [
      { title: "Detalle del período liquidado | AGOEC" },
      {
        name: "description",
        content:
          "Detalle de un período ya liquidado: totales por servicio y subservicio, descuentos por afiliado y descarga del Excel contable.",
      },
      { property: "og:title", content: "Detalle del período liquidado | AGOEC" },
      {
        property: "og:description",
        content: "Totales por servicio y descuentos por afiliado del período liquidado.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const money = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });
const n2 = (v: number) => Number(Number(v || 0).toFixed(2));

function PeriodoLiquidado() {
  const { id } = Route.useParams();
  const fetchFn = useServerFn(getPayrollPeriod);
  const padronFn = useServerFn(payrollPadron);
  const [bajando, setBajando] = useState(false);

  const { data, isLoading, error } = useQuery({
    queryKey: ["payroll-period", id],
    queryFn: () => fetchFn({ data: { id } }),
  });

  const conceptos: any[] = data?.conceptos ?? [];
  const rows: any[] = data?.rows ?? [];
  const period: any = data?.period;

  const ordenados = useMemo(
    () => conceptos.slice().sort((a, b) => b.total - a.total),
    [conceptos],
  );

  function exportExcel() {
    if (!rows.length) return toast.error("Este período no tiene detalle guardado");
    const data1 = rows.map((r) => {
      const o: Record<string, any> = {
        ID_EMPLEADO: r.legajo,
        APELLIDO_NOMBRE: r.apellido_nombre ?? "",
      };
      for (const c of conceptos) {
        const col = `${c.cuenta_contable ? c.cuenta_contable + " " : ""}${c.nombre}`;
        const v = Number(r.por_concepto[c.key] ?? 0);
        o[col] = v ? n2(v) : "";
      }
      o["TOTAL A DESCONTAR"] = n2(r.total);
      return o;
    });
    const totalRow: Record<string, any> = { ID_EMPLEADO: "", APELLIDO_NOMBRE: "TOTAL" };
    for (const c of conceptos) {
      totalRow[`${c.cuenta_contable ? c.cuenta_contable + " " : ""}${c.nombre}`] = n2(c.total);
    }
    totalRow["TOTAL A DESCONTAR"] = n2(data?.total ?? 0);

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet([...data1, totalRow]), "Resultado");
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        ordenados.map((c) => ({
          "Nº contable": c.cuenta_contable ?? "",
          "Servicio / Subservicio": c.nombre,
          Afiliados: c.afiliados,
          "Total a descontar": n2(c.total),
        })),
      ),
      "Totales",
    );
    XLSX.writeFile(wb, `liquidacion_${period?.desde}_al_${period?.hasta}.xlsx`);
  }

  /** Excel con el formato oficial de intercambio con CEAMSE. */
  async function exportCeamse() {
    try {
      setBajando(true);
      if (!rows.length) return toast.error("Este período no tiene detalle guardado");
      const { padron } = await padronFn({
        data: { legajos: rows.map((r: any) => String(r.legajo)) },
      });
      const n = downloadCeamseXlsx({
        conceptos,
        rows,
        padron,
        desde: period?.desde,
        hasta: period?.hasta,
        periodo: period?.nombre,
      });
      toast.success(`Liquidación de CEAMSE generada: ${n} afiliados`);
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo generar el Excel");
    } finally {
      setBajando(false);
    }
  }


  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <Button asChild variant="ghost" size="sm" className="-ml-2 mb-1">
            <Link to="/admin/liquidacion">
              <ArrowLeft className="h-4 w-4 mr-1" /> Volver a Liquidación
            </Link>
          </Button>
          <h1 className="text-2xl font-bold">{period?.nombre ?? "Período liquidado"}</h1>
          <p className="text-sm text-muted-foreground">
            {period ? `${period.desde} → ${period.hasta}` : "Cargando período…"}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            className="bg-red-600 hover:bg-red-700 text-white font-semibold"
            onClick={exportCeamse}
            disabled={!rows.length || bajando}
          >
            {bajando ? (
              <Loader2 className="h-4 w-4 mr-1 animate-spin" />
            ) : (
              <FileDown className="h-4 w-4 mr-1" />
            )}
            Bajar liquidación del período (CEAMSE)
          </Button>
          <Button variant="secondary" onClick={exportExcel} disabled={!rows.length}>
            <Download className="h-4 w-4 mr-1" /> Excel contable
          </Button>
        </div>

      </div>

      {error ? <p className="text-sm text-destructive">{(error as any).message}</p> : null}
      {isLoading ? <p className="text-sm">Cargando…</p> : null}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Stat label="Servicios liquidados" value={String(conceptos.length)} />
        <Stat label="Afiliados" value={String(data?.afiliados ?? 0)} />
        <Stat label="Total descontado" value={money.format(data?.total ?? 0)} />
        <Stat label="Estado" value={period?.estado ?? "—"} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Totales por servicio / subservicio</CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-left border-b">
              <tr>
                <th className="py-2 pr-2">Nº contable</th>
                <th className="py-2 pr-2">Servicio / Subservicio</th>
                <th className="py-2 pr-2 text-center">Afiliados</th>
                <th className="py-2 pr-2 text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {ordenados.map((c) => (
                <tr key={c.key} className="border-b">
                  <td className="py-2 pr-2 font-mono">{c.cuenta_contable ?? "—"}</td>
                  <td className="py-2 pr-2">{c.nombre}</td>
                  <td className="py-2 pr-2 text-center">{c.afiliados}</td>
                  <td className="py-2 pr-2 text-right">{money.format(c.total)}</td>
                </tr>
              ))}
              <tr className="font-semibold">
                <td className="py-2 pr-2" colSpan={3}>
                  TOTAL
                </td>
                <td className="py-2 pr-2 text-right">{money.format(data?.total ?? 0)}</td>
              </tr>
            </tbody>
          </table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Detalle por afiliado ({rows.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto max-h-[600px]">
            <table className="w-full text-sm">
              <thead className="text-left border-b sticky top-0 bg-card">
                <tr>
                  <th className="py-2 pr-2">Legajo</th>
                  <th className="py-2 pr-2">Apellido y Nombre</th>
                  {conceptos.map((c) => (
                    <th key={c.key} className="py-2 pr-2 text-right whitespace-nowrap">
                      {c.cuenta_contable ? `${c.cuenta_contable} ` : ""}
                      {c.nombre}
                    </th>
                  ))}
                  <th className="py-2 pr-2 text-right">Total</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.legajo} className="border-b">
                    <td className="py-2 pr-2 font-mono">{r.legajo}</td>
                    <td className="py-2 pr-2">{r.apellido_nombre ?? "—"}</td>
                    {conceptos.map((c) => (
                      <td key={c.key} className="py-2 pr-2 text-right">
                        {r.por_concepto[c.key] ? money.format(r.por_concepto[c.key]) : "—"}
                      </td>
                    ))}
                    <td className="py-2 pr-2 text-right font-semibold">{money.format(r.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="text-xs uppercase text-muted-foreground">{label}</div>
        <div className="text-xl font-bold mt-1">{value}</div>
      </CardContent>
    </Card>
  );
}
