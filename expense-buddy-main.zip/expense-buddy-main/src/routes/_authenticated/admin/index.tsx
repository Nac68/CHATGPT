import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import * as XLSX from "xlsx";
import { getAdminDashboard } from "@/lib/dashboard.functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AdelantoToggle } from "@/components/AdelantoToggle";
import { AlertTriangle, ArrowRight, Download, UtensilsCrossed } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/")({
  component: AdminHome,
});

const currencyFmt = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });
const MESES = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre",
];

type Pendiente = {
  titulo: string;
  detalle: string;
  to: string;
  urgente?: boolean;
};

function AdminHome() {
  const fn = useServerFn(getAdminDashboard);
  const { data, isLoading } = useQuery({
    queryKey: ["admin-dashboard"],
    queryFn: () => fn({ data: undefined as any }),
    refetchOnMount: "always",
    refetchOnWindowFocus: true,
    staleTime: 0,
  });

  if (isLoading || !data) return <div>Cargando tablero...</div>;

  const { periodo, pagos, proveedores, refinanciacion, comida, resumen } = data;

  const pendientes: Pendiente[] = [];

  if (!comida.hoy_cargado) {
    pendientes.push({
      titulo: "Cargar el formulario de hoy (Comida a Dto.)",
      detalle: `No hay formulario cargado para el ${periodo.hoy}.`,
      to: "/admin/comida-dto",
      urgente: true,
    });
  }
  if (comida.dias_sin_importe > 0) {
    pendientes.push({
      titulo: "Días sin importe cargado",
      detalle: `${comida.dias_sin_importe} día(s) del período sin importe total.`,
      to: "/admin/dias",
      urgente: true,
    });
  }
  if (comida.dias_pendientes > 0) {
    pendientes.push({
      titulo: "Días pendientes de liquidar",
      detalle: `${comida.dias_pendientes} día(s) del período aún no están en una liquidación cerrada.`,
      to: "/admin/liquidaciones",
    });
  }
  for (const liq of comida.liquidaciones_abiertas) {
    pendientes.push({
      titulo: `Liquidación sin cerrar: ${liq.nombre}`,
      detalle: `Estado actual: ${liq.estado}.`,
      to: "/admin/liquidaciones",
    });
  }
  if (proveedores.sin_carga.length > 0) {
    pendientes.push({
      titulo: "Proveedores sin presentación del período",
      detalle: proveedores.sin_carga.map((p) => p.nombre).join(", "),
      to: "/admin/proveedores",
      urgente: true,
    });
  }
  if (refinanciacion.cuotas > 0) {
    pendientes.push({
      titulo: "Cuotas de Refinanciación a descontar",
      detalle: `${refinanciacion.cuotas} cuota(s) por ${currencyFmt.format(refinanciacion.total)} en el período.`,
      to: "/admin/refinanciacion",
    });
  }
  if (pagos.colectas_sin_fecha > 0) {
    pendientes.push({
      titulo: "Colectas sin fecha de pago",
      detalle: `${pagos.colectas_sin_fecha} colecta(s) abiertas sin fecha definida.`,
      to: "/admin/colecta",
      urgente: true,
    });
  }
  if (pagos.sin_datos_bancarios > 0) {
    pendientes.push({
      titulo: "Pagos sin información bancaria",
      detalle: `${pagos.sin_datos_bancarios} pago(s) del período no tienen CBU/alias para transferir.`,
      to: "/admin/afiliados",
    });
  }

  const destinoPago = (tipo: string) =>
    tipo === "Círculo" ? "/admin/circulo" : tipo === "Colecta" ? "/admin/colecta" : "/admin/cumpleanos";

  const descargarExcel = () => {
    const per = `${String(periodo.mes).padStart(2, "0")}/${periodo.anio}`;
    const rows = pagos.rows.filter((r) => !r.adelantado).map((r) => ({
      Periodo: per,
      Tipo: r.tipo,
      Beneficiario: r.beneficiario ?? "",
      Legajo: r.legajo ?? "",
      Importe: r.importe,
      Titular: r.titular ?? (r.falta_bancario ? "FALTA INFORMACIÓN BANCARIA" : ""),
      "CBU/CVU": r.cbu ?? (r.falta_bancario ? "FALTA INFORMACIÓN BANCARIA" : ""),
      Alias: r.alias ?? (r.falta_bancario ? "FALTA INFORMACIÓN BANCARIA" : ""),
      "CUIL/CUIT/DNI": r.cuil ?? "",
      Referencia: r.detalle,
    }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), "Transferencias");
    XLSX.writeFile(
      wb,
      `transferencias_servicios_varios_${String(periodo.mes).padStart(2, "0")}-${periodo.anio}.xlsx`,
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">
            Período {MESES[periodo.mes - 1]} {periodo.anio}
          </h1>
          <p className="text-sm text-muted-foreground">
            Rango {periodo.desde} → {periodo.hasta} (cierre día {periodo.dia_cierre}) ·{" "}
            {periodo.dias_restantes >= 0
              ? `${periodo.dias_restantes} día(s) para el cierre`
              : `cierre vencido hace ${Math.abs(periodo.dias_restantes)} día(s)`}
          </p>
        </div>
        <Badge variant={pendientes.length ? "destructive" : "secondary"}>
          {pendientes.length} pendiente(s)
        </Badge>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Pendientes de este período</CardTitle>
        </CardHeader>
        <CardContent className="divide-y p-0">
          {pendientes.length === 0 && (
            <div className="p-6 text-sm text-muted-foreground">
              No hay pendientes detectados en este período.
            </div>
          )}
          {pendientes.map((p, i) => (
            <Link
              key={i}
              to={p.to}
              className="flex items-center justify-between gap-4 px-6 py-4 hover:bg-muted/50"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2 font-medium">
                  {p.urgente && <AlertTriangle className="h-4 w-4 text-destructive shrink-0" />}
                  <span className="truncate">{p.titulo}</span>
                </div>
                <div className="text-sm text-muted-foreground line-clamp-2">{p.detalle}</div>
              </div>
              <span className="flex shrink-0 items-center gap-1 text-sm font-medium text-primary">
                Resolver <ArrowRight className="h-4 w-4" />
              </span>
            </Link>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-3">
          <CardTitle>Pagos de Servicios Varios del período</CardTitle>
          <div className="flex items-center gap-3">
            <div className="text-sm">
              Total a transferir:{" "}
              <span className="font-bold">{currencyFmt.format(pagos.total)}</span>
              {pagos.total_adelantado > 0 && (
                <span className="ml-2 text-xs text-muted-foreground">
                  (adelantado: {currencyFmt.format(pagos.total_adelantado)})
                </span>
              )}
            </div>
            <Button size="sm" onClick={descargarExcel} disabled={pagos.rows.length === 0}>
              <Download className="mr-2 h-4 w-4" />
              Descargar Excel para transferencias
            </Button>
          </div>
        </CardHeader>
        <CardContent className="divide-y p-0">
          {pagos.rows.length === 0 && (
            <div className="p-6 text-sm text-muted-foreground">
              No hay pagos de Servicios Varios en este período.
            </div>
          )}
          {pagos.rows.map((r, i) => (
            <div
              key={i}
              className={`flex items-center justify-between gap-4 px-6 py-3 ${r.adelantado ? "bg-muted/40 opacity-70" : ""}`}
            >
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge variant="outline">{r.tipo}</Badge>
                  <span className={`font-medium truncate ${r.adelantado ? "line-through" : ""}`}>
                    {r.beneficiario ?? "Sin beneficiario"}
                  </span>
                  {r.legajo && (
                    <span className="font-mono text-xs text-muted-foreground">{r.legajo}</span>
                  )}
                  {r.adelantado && <Badge variant="secondary">Adelantado</Badge>}
                </div>
                <div className="text-sm text-muted-foreground truncate">{r.detalle}</div>
                {r.adelantado_info && (
                  <div className="mt-1 text-xs text-muted-foreground">{r.adelantado_info}</div>
                )}
                {r.falta_bancario && !r.adelantado && (
                  <div className="mt-1 flex items-center gap-1 text-xs text-destructive">
                    <AlertTriangle className="h-3 w-3" /> Falta información bancaria
                  </div>
                )}
                <div className="mt-2">
                  <AdelantoToggle
                    refKey={r.ref_key}
                    tipo={r.tipo}
                    legajo={r.legajo}
                    detalle={r.detalle}
                    importe={r.importe}
                    label="Marcar como pagado por adelantado"
                  />
                </div>
              </div>
              <div className="shrink-0 text-right">
                <div className={`font-semibold ${r.adelantado ? "line-through" : ""}`}>
                  {currencyFmt.format(r.importe)}
                </div>
                <Link
                  to={destinoPago(r.tipo)}
                  className="flex items-center gap-1 text-sm text-primary hover:underline"
                >
                  Resolver <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UtensilsCrossed className="h-5 w-5" /> Comida a Dto. · Hoy
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <Fila
              label="Formulario de hoy"
              value={comida.hoy_cargado ? "Cargado" : "No cargado"}
              alert={!comida.hoy_cargado}
            />
            <Fila
              label="Importe de hoy"
              value={comida.hoy_importe == null ? "—" : currencyFmt.format(comida.hoy_importe)}
              alert={comida.hoy_cargado && comida.hoy_importe == null}
            />
            <Fila label="Comensales de hoy" value={String(comida.consumos_hoy)} />
            {comida.hoy_descripcion && <Fila label="Descripción" value={comida.hoy_descripcion} />}
            <Fila label="Días pendientes del período" value={String(comida.dias_pendientes)} />
            <Fila
              label="Días sin importe"
              value={String(comida.dias_sin_importe)}
              alert={comida.dias_sin_importe > 0}
            />
            <Fila
              label="Liquidaciones sin cerrar"
              value={String(comida.liquidaciones_abiertas.length)}
            />
            <Button asChild size="sm" className="mt-2 w-full">
              <Link to="/admin/comida-dto">
                Ir a Comida a Dto. <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Resumen del período</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <Fila
              label="Total a pagar a proveedores"
              value={currencyFmt.format(resumen.total_a_pagar_proveedores)}
            />
            <Fila
              label="Total a descontar a afiliados"
              value={currencyFmt.format(resumen.total_a_descontar)}
            />
            <Fila label="Afiliados a descontar" value={String(resumen.afiliados_a_descontar)} />
            <Fila
              label="Total a transferir (Servicios Varios)"
              value={currencyFmt.format(resumen.total_a_transferir_servicios)}
            />
            <Fila label="Presentaciones de proveedores" value={String(proveedores.presentaciones)} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Fila({ label, value, alert }: { label: string; value: string; alert?: boolean }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b pb-1 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className={alert ? "font-semibold text-destructive" : "font-semibold"}>{value}</span>
    </div>
  );
}
