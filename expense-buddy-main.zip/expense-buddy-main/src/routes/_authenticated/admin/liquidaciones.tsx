import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  createSettlement,
  deleteSettlement,
  getSettlement,
  listSettlementDays,
  listSettlementEvents,
  logSettlementExport,
  listSettlements,
  previewSettlement,
  recalcSettlement,
  setSettlementEstado,
} from "@/lib/settlement.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { AlertTriangle, Download, Lock, RefreshCw, Trash2, Unlock } from "lucide-react";
import * as XLSX from "xlsx";
import { compareLegajo } from "@/lib/legajo";

export const Route = createFileRoute("/_authenticated/admin/liquidaciones")({
  validateSearch: (s: Record<string, unknown>): { id?: string } => ({
    id: typeof s.id === "string" ? s.id : undefined,
  }),
  component: Liquidaciones,
  head: () => ({
    meta: [
      { title: "Liquidaciones por período | Comida a Dto." },
      {
        name: "description",
        content:
          "Liquidaciones de Comida a Dto. por período con estados borrador, revisada, cerrada y exportada, controles de consistencia y snapshot congelado.",
      },
      { property: "og:title", content: "Liquidaciones por período | Comida a Dto." },
      {
        property: "og:description",
        content: "Cerrá, exportá y consultá el histórico congelado de cada período.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const money = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });
const MESES = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
const per = (m?: number | null, a?: number | null) =>
  m && a ? `${String(m).padStart(2, "0")}/${a}` : "—";

const ESTADO_STYLE: Record<string, string> = {
  borrador: "bg-muted text-muted-foreground",
  revisada: "bg-blue-100 text-blue-800",
  cerrada: "bg-emerald-100 text-emerald-800",
  exportada: "bg-primary/15 text-primary",
};

function Estado({ v }: { v: string }) {
  return <span className={`rounded px-2 py-0.5 text-xs font-semibold capitalize ${ESTADO_STYLE[v] ?? ""}`}>{v}</span>;
}

function Liquidaciones() {
  const { id } = Route.useSearch();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const list = useServerFn(listSettlements);
  const get = useServerFn(getSettlement);
  const del = useServerFn(deleteSettlement);
  const daysFn = useServerFn(listSettlementDays);
  const previewFn = useServerFn(previewSettlement);
  const createFn = useServerFn(createSettlement);
  const recalcFn = useServerFn(recalcSettlement);
  const estadoFn = useServerFn(setSettlementEstado);
  const eventsFn = useServerFn(listSettlementEvents);
  const logExportFn = useServerFn(logSettlementExport);

  const now = new Date();
  const [mes, setMes] = useState(now.getUTCMonth() + 1);
  const [anio, setAnio] = useState(now.getUTCFullYear());
  const [sel, setSel] = useState<string[]>([]);
  const [nombre, setNombre] = useState("");

  const { data: settlements, isLoading } = useQuery({
    queryKey: ["settlements"],
    queryFn: () => list({ data: undefined as any }),
  });

  const daysQ = useQuery({
    queryKey: ["settlement-days"],
    queryFn: () => daysFn({ data: {} }),
  });

  const periodosPendientes = useMemo(
    () =>
      Array.from(new Set((daysQ.data ?? []).map((d: any) => String(d.fecha).slice(0, 7)))).sort(
        (a, b) => b.localeCompare(a),
      ),
    [daysQ.data],
  );
  const periodoSeleccionado = `${anio}-${String(mes).padStart(2, "0")}`;
  const diasPendientes = useMemo(
    () => (daysQ.data ?? []).filter((d: any) => String(d.fecha).startsWith(periodoSeleccionado)),
    [daysQ.data, periodoSeleccionado],
  );

  useEffect(() => {
    if (!periodosPendientes.length || periodosPendientes.includes(periodoSeleccionado)) return;
    const [nextAnio, nextMes] = periodosPendientes[0].split("-").map(Number);
    setAnio(nextAnio);
    setMes(nextMes);
    setSel([]);
  }, [periodoSeleccionado, periodosPendientes]);

  const previewQ = useQuery({
    queryKey: ["settlement-preview", sel],
    queryFn: () => previewFn({ data: { fechas: sel } }),
    enabled: sel.length > 0,
  });

  const detail = useQuery({
    queryKey: ["settlement", id],
    queryFn: () => get({ data: { id: id! } }),
    enabled: !!id,
  });

  const eventsQ = useQuery({
    queryKey: ["settlement-events", id],
    queryFn: () => eventsFn({ data: { id: id! } }),
    enabled: !!id,
  });

  const items = useMemo(
    () =>
      [...(detail.data?.items ?? [])].sort((a: any, b: any) =>
        compareLegajo(String(a.legajo), String(b.legajo)),
      ),
    [detail.data],
  );
  const s: any = detail.data?.settlement;
  const congelada = s && (s.estado === "cerrada" || s.estado === "exportada");

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["settlements"] });
    qc.invalidateQueries({ queryKey: ["settlement-days"] });
    qc.invalidateQueries({ queryKey: ["settlement", id] });
    qc.invalidateQueries({ queryKey: ["settlement-events", id] });
    qc.invalidateQueries({ queryKey: ["settlement-preview"] });
  };

  const crear = useMutation({
    mutationFn: () =>
      createFn({
        data: {
          nombre: nombre.trim() || `Comida a Dto. ${String(mes).padStart(2, "0")}/${anio}`,
          fechas: sel,
          periodo_mes: mes,
          periodo_anio: anio,
        },
      }),
    onSuccess: (r: any) => {
      toast.success("Borrador creado");
      setSel([]);
      setNombre("");
      qc.invalidateQueries({ queryKey: ["settlements"] });
      navigate({ to: "/admin/liquidaciones", search: { id: r.id } });
    },
    onError: (e: any) => toast.error(e?.message ?? "No se pudo crear"),
  });

  const cambiar = useMutation({
    mutationFn: (estado: "borrador" | "revisada" | "cerrada" | "exportada") =>
      estadoFn({ data: { id: id!, estado } }),
    onSuccess: (r: any) => {
      toast.success(`Estado: ${r.estado}`);
      invalidate();
    },
    onError: (e: any) => toast.error(e?.message ?? "No se pudo cambiar el estado"),
  });

  const recalc = useMutation({
    mutationFn: () => recalcFn({ data: { id: id! } }),
    onSuccess: () => {
      toast.success("Borrador recalculado con los datos actuales");
      invalidate();
    },
    onError: (e: any) => toast.error(e?.message ?? "No se pudo recalcular"),
  });

  async function handleDelete(sid: string) {
    if (!confirm("¿Eliminar este borrador de liquidación?")) return;
    try {
      await del({ data: { id: sid } });
      toast.success("Liquidación eliminada");
      if (id === sid) navigate({ to: "/admin/liquidaciones", search: {} });
      qc.invalidateQueries({ queryKey: ["settlements"] });
    } catch (e: any) {
      toast.error(e?.message ?? "Error");
    }
  }

  function exportarTesoreria() {
    if (!s) return;
    if (s.estado !== "cerrada" && s.estado !== "exportada")
      return toast.error("Sólo se puede exportar una liquidación cerrada");
    const snap: any = detail.data?.snapshot;
    const rows = (snap?.rows ?? items).slice().sort((a: any, b: any) => compareLegajo(String(a.legajo), String(b.legajo)));
    const data = rows.map((r: any) => ({
      Legajo: r.legajo,
      "Apellido y Nombre": r.apellido_nombre,
      Desayunos: r.desayunos,
      Almuerzos: r.almuerzos,
      "Total consumos": r.consumos,
      "Total a descontar": Number(Number(r.importe).toFixed(2)),
    }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet([
        { Legajo: s.nombre, "Apellido y Nombre": `Período ${per(s.periodo_mes, s.periodo_anio)} · estado ${s.estado}` },
        {},
        ...data,
        {
          Legajo: "",
          "Apellido y Nombre": "TOTAL",
          Desayunos: data.reduce((a: number, b: any) => a + b.Desayunos, 0),
          Almuerzos: data.reduce((a: number, b: any) => a + b.Almuerzos, 0),
          "Total consumos": data.reduce((a: number, b: any) => a + b["Total consumos"], 0),
          "Total a descontar": Number(Number(s.importe_total).toFixed(2)),
        },
      ]),
      "Descuentos",
    );
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        (detail.data?.consumos ?? []).map((c: any) => ({
          Fecha: c.fecha,
          Legajo: c.legajo,
          "Apellido y Nombre": c.apellido_nombre,
          Desayuno: c.desayuno ? "Sí" : "",
          Almuerzo: c.almuerzo ? "Sí" : "",
          "No paga": c.no_paga ? "Sí" : "",
          Observación: c.observacion ?? "",
          Importe: Number(Number(c.importe).toFixed(2)),
        })),
      ),
      "Detalle congelado",
    );
    XLSX.writeFile(wb, `liquidacion_comida_${per(s.periodo_mes, s.periodo_anio).replace("/", "-")}.xlsx`);
    void logExportFn({ data: { id: String(s.id), filas: data.length } }).catch(() => {});

    if (s.estado === "cerrada") {
      if (confirm("¿Marcar esta liquidación como EXPORTADA a Tesorería?")) cambiar.mutate("exportada");
    }
  }

  const t: any = previewQ.data?.totales;
  const errores: string[] = previewQ.data?.errores ?? [];
  const advertencias: string[] = previewQ.data?.advertencias ?? [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Liquidaciones de Comida a Dto.</h1>
        <p className="text-sm text-muted-foreground">
          Flujo por período: borrador → revisada → cerrada → exportada. Al cerrar se congela el detalle
          liquidado y los históricos ya no cambian.
        </p>
      </div>

      <Tabs defaultValue={id ? "historico" : "nueva"}>
        <TabsList>
          <TabsTrigger value="nueva">Nueva liquidación</TabsTrigger>
          <TabsTrigger value="historico">Histórico ({(settlements ?? []).length})</TabsTrigger>
        </TabsList>

        <TabsContent value="nueva" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">1) Período y días a liquidar</CardTitle>
              <CardDescription>Elegí mes/año y tildá los días incluidos.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap items-end gap-3">
                <div>
                  <label className="text-xs text-muted-foreground">Período pendiente</label>
                  <select
                    className="ml-2 h-9 rounded-md border border-input bg-background px-2 text-sm"
                    value={periodoSeleccionado}
                    disabled={!periodosPendientes.length}
                    onChange={(e) => {
                      const [nextAnio, nextMes] = e.target.value.split("-").map(Number);
                      setAnio(nextAnio);
                      setMes(nextMes);
                      setSel([]);
                    }}
                  >
                    {!periodosPendientes.length && <option>Sin períodos pendientes</option>}
                    {periodosPendientes.map((p) => {
                      const [a, m] = p.split("-").map(Number);
                      return <option key={p} value={p}>{MESES[m - 1]} {a}</option>;
                    })}
                  </select>
                </div>
                <Input
                  className="max-w-xs"
                  placeholder={`Nombre (Comida a Dto. ${String(mes).padStart(2, "0")}/${anio})`}
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                />
                <Button
                  variant="outline"
                  onClick={() => setSel(diasPendientes.map((d: any) => d.fecha))}
                >
                  Seleccionar todos
                </Button>
                <Button variant="ghost" onClick={() => setSel([])}>Limpiar</Button>
              </div>

              {!diasPendientes.length ? (
                <p className="text-sm text-muted-foreground">No hay períodos con días pendientes de liquidar.</p>
              ) : (
                <div className="overflow-x-auto rounded border">
                  <table className="w-full text-sm">
                    <thead className="border-b bg-muted text-left">
                      <tr>
                        <th className="p-2"></th>
                        <th className="p-2">Fecha</th>
                        <th className="p-2">Descripción</th>
                        <th className="p-2 text-center">Comensales</th>
                        <th className="p-2 text-right">Importe día</th>
                        <th className="p-2 text-right">A descontar</th>
                      </tr>
                    </thead>
                    <tbody>
                      {diasPendientes.map((d: any) => (
                        <tr key={d.id} className="border-b last:border-0">
                          <td className="p-2">
                            <input
                              type="checkbox"
                              checked={sel.includes(d.fecha)}
                              onChange={(e) =>
                                setSel((prev) =>
                                  e.target.checked ? [...prev, d.fecha] : prev.filter((f) => f !== d.fecha),
                                )
                              }
                            />
                          </td>
                          <td className="p-2 font-mono">{d.fecha}</td>
                          <td className="p-2">
                            {d.descripcion_comida ?? "—"}
                            {d.es_cumpleanos && <Badge variant="destructive" className="ml-2">cumpleaños</Badge>}
                          </td>
                          <td className="p-2 text-center">{d.comensales}</td>
                          <td className="p-2 text-right">
                            {d.importe == null ? <span className="text-destructive">falta importe</span> : money.format(Number(d.importe))}
                          </td>
                          <td className="p-2 text-right">{money.format(Number(d.a_cobrar))}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>

          {sel.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">2) Controles de consistencia</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {previewQ.isFetching || !t ? (
                  <p className="text-sm text-muted-foreground">Calculando…</p>
                ) : (
                  <>
                    <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-4">
                      {[
                        { l: "Período", v: per(mes, anio) },
                        { l: "Días incluidos", v: String(t.dias) },
                        { l: "Días sin importe", v: String(t.dias_sin_importe) },
                        { l: "Cumpleaños", v: String(t.dias_cumpleanos) },
                        { l: "Consumos", v: String(t.consumos) },
                        { l: "Legajos involucrados", v: String(t.afiliados) },
                        { l: "Importe cargado", v: money.format(t.importe_cargado) },
                        { l: "Total a descontar (afiliados)", v: money.format(t.total_a_descontar) },
                        {
                          l: `A cargo de AGOEC (No paga${t.consumos_no_paga ? `: ${t.consumos_no_paga}` : ""})`,
                          v: money.format(Number(t.a_cargo_agoec_no_paga ?? 0)),
                        },
                        {
                          l: "A cargo de AGOEC (Cumpleaños)",
                          v: money.format(Number(t.a_cargo_agoec_cumpleanos ?? 0)),
                        },
                        {
                          l: "Diferencia sin explicar",
                          v: money.format(Number(t.diferencia_no_explicada ?? t.diferencia ?? 0)),
                        },

                      ].map((x) => (
                        <div key={x.l} className="rounded border p-3">
                          <p className="text-xs text-muted-foreground">{x.l}</p>
                          <p className="font-semibold">{x.v}</p>
                        </div>
                      ))}
                    </div>
                    {errores.map((e) => (
                      <p key={e} className="flex gap-2 text-sm text-destructive">
                        <AlertTriangle className="h-4 w-4 shrink-0" /> {e}
                      </p>
                    ))}
                    {advertencias.map((a) => (
                      <p key={a} className="text-sm text-amber-600">⚠ {a}</p>
                    ))}
                    <Button disabled={crear.isPending} onClick={() => crear.mutate()}>
                      Crear borrador de liquidación
                    </Button>
                    {!!errores.length && (
                      <p className="text-xs text-muted-foreground">
                        Podés guardar el borrador, pero no vas a poder cerrarlo hasta corregir los errores.
                      </p>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="historico" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Liquidaciones por período</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <p className="text-sm text-muted-foreground">Cargando…</p>
              ) : !(settlements ?? []).length ? (
                <p className="text-sm text-muted-foreground">Todavía no hay liquidaciones.</p>
              ) : (
                <div className="overflow-x-auto rounded border">
                  <table className="w-full min-w-[900px] text-sm">
                    <thead className="border-b bg-muted text-left">
                      <tr>
                        <th className="p-2">Nombre</th>
                        <th className="p-2">Período</th>
                        <th className="p-2">Estado</th>
                        <th className="p-2 text-center">Días</th>
                        <th className="p-2 text-center">Legajos</th>
                        <th className="p-2 text-right">Cargado</th>
                        <th className="p-2 text-right">A descontar</th>
                        <th className="p-2 text-right">A cargo AGOEC</th>
                        <th className="p-2"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {(settlements ?? []).map((x: any) => (
                        <tr key={x.id} className="border-b last:border-0">
                          <td className="p-2">
                            <button
                              className="text-left hover:underline"
                              onClick={() => navigate({ to: "/admin/liquidaciones", search: { id: x.id } })}
                            >
                              {x.nombre}
                            </button>
                          </td>
                          <td className="p-2 font-mono text-xs">{per(x.periodo_mes, x.periodo_anio)}</td>
                          <td className="p-2"><Estado v={x.estado} /></td>
                          <td className="p-2 text-center">{(x.fechas ?? []).length}</td>
                          <td className="p-2 text-center">{x.total_afiliados}</td>
                          <td className="p-2 text-right">{money.format(Number(x.importe_cargado ?? 0))}</td>
                          <td className="p-2 text-right">{money.format(Number(x.importe_total ?? 0))}</td>
                          <td className="p-2 text-right">{money.format(Number(x.diferencia ?? 0))}</td>
                          <td className="p-2 text-right">
                            {x.estado === "borrador" || x.estado === "revisada" ? (
                              <Button size="icon" variant="ghost" onClick={() => handleDelete(x.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            ) : null}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>

          {id && s && (
            <>
              <Card>
                <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-3">
                  <div>
                    <CardTitle className="text-base">
                      {s.nombre} · {per(s.periodo_mes, s.periodo_anio)} <Estado v={s.estado} />
                    </CardTitle>
                    <CardDescription>
                      {(s.fechas ?? []).length} día(s) · {s.desde} → {s.hasta}
                      {congelada ? " · detalle congelado al cierre" : " · borrador (se recalcula)"}
                    </CardDescription>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {s.estado === "borrador" && (
                      <>
                        <Button variant="outline" onClick={() => recalc.mutate()} disabled={recalc.isPending}>
                          <RefreshCw className="mr-1 h-4 w-4" /> Recalcular
                        </Button>
                        <Button variant="secondary" onClick={() => cambiar.mutate("revisada")}>
                          Marcar revisada
                        </Button>
                      </>
                    )}
                    {(s.estado === "borrador" || s.estado === "revisada") && (
                      <Button
                        onClick={() => {
                          if (confirm("¿Cerrar la liquidación? Se congela el detalle y no podrá modificarse."))
                            cambiar.mutate("cerrada");
                        }}
                      >
                        <Lock className="mr-1 h-4 w-4" /> Cerrar
                      </Button>
                    )}
                    {(s.estado === "cerrada" || s.estado === "exportada") && (
                      <>
                        <Button variant="secondary" onClick={exportarTesoreria}>
                          <Download className="mr-1 h-4 w-4" /> Excel Tesorería
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => {
                            const msg =
                              s.estado === "exportada"
                                ? "ATENCIÓN: esta liquidación ya fue EXPORTADA y pudo haberse enviado a Tesorería. ¿Reabrir igualmente?"
                                : "¿Reabrir la liquidación cerrada? Volverá a estado borrador.";
                            if (confirm(msg)) cambiar.mutate("borrador");
                          }}
                        >
                          <Unlock className="mr-1 h-4 w-4" /> Reabrir
                        </Button>
                      </>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {s.estado === "exportada" && (
                    <p className="rounded border border-amber-400 bg-amber-50 p-2 text-sm text-amber-800">
                      Exportada a Tesorería el {new Date(s.exportada_at).toLocaleString("es-AR")}.
                      {Number(s.reaperturas ?? 0) > 0 && ` Reaperturas: ${s.reaperturas}.`}
                    </p>
                  )}
                  <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
                    {[
                      { l: "Días", v: String((s.fechas ?? []).length) },
                      { l: "Días sin importe", v: String(s.dias_sin_importe ?? 0) },
                      { l: "Consumos", v: String(s.total_consumos) },
                      { l: "Legajos", v: String(s.total_afiliados) },
                      { l: "Importe cargado", v: money.format(Number(s.importe_cargado ?? 0)) },
                      { l: "Total a descontar (afiliados)", v: money.format(Number(s.importe_total ?? 0)) },
                      { l: "A cargo de AGOEC (No paga/cumpleaños)", v: money.format(Number(s.diferencia ?? 0)) },

                    ].map((x) => (
                      <div key={x.l} className="rounded border p-3">
                        <p className="text-xs text-muted-foreground">{x.l}</p>
                        <p className="font-semibold">{x.v}</p>
                      </div>
                    ))}
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="border-b text-left">
                        <tr>
                          <th className="py-2 pr-2">Legajo</th>
                          <th className="py-2 pr-2">Apellido y Nombre</th>
                          <th className="py-2 pr-2 text-center">Desayunos</th>
                          <th className="py-2 pr-2 text-center">Almuerzos</th>
                          <th className="py-2 pr-2 text-center">Consumos</th>
                          <th className="py-2 pr-2 text-right">A descontar</th>
                        </tr>
                      </thead>
                      <tbody>
                        {items.map((r: any) => (
                          <tr key={r.id} className="border-b last:border-0">
                            <td className="py-2 pr-2 font-mono">{r.legajo}</td>
                            <td className="py-2 pr-2">{r.apellido_nombre}</td>
                            <td className="py-2 pr-2 text-center">{r.desayunos}</td>
                            <td className="py-2 pr-2 text-center">{r.almuerzos}</td>
                            <td className="py-2 pr-2 text-center">{r.consumos}</td>
                            <td className="py-2 pr-2 text-right">{money.format(Number(r.importe))}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              {!!(detail.data?.consumos ?? []).length && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Detalle persona por persona (congelado)</CardTitle>
                    <CardDescription>
                      Cada fila es un consumo real; el legajo de Tesorería puede repetirse con el nombre en
                      observaciones.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="border-b text-left">
                        <tr>
                          <th className="py-2 pr-2">Fecha</th>
                          <th className="py-2 pr-2">Legajo</th>
                          <th className="py-2 pr-2">Apellido y Nombre</th>
                          <th className="py-2 pr-2">Observación</th>
                          <th className="py-2 pr-2 text-center">D</th>
                          <th className="py-2 pr-2 text-center">A</th>
                          <th className="py-2 pr-2 text-right">Importe</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(detail.data?.consumos ?? []).map((c: any, i: number) => (
                          <tr key={i} className={`border-b last:border-0 ${c.no_paga ? "text-destructive" : ""}`}>
                            <td className="py-1.5 pr-2 font-mono">{c.fecha}</td>
                            <td className="py-1.5 pr-2 font-mono">{c.legajo}</td>
                            <td className="py-1.5 pr-2">{c.apellido_nombre}</td>
                            <td className="py-1.5 pr-2">{c.observacion ?? "—"}</td>
                            <td className="py-1.5 pr-2 text-center">{c.desayuno ? "✓" : ""}</td>
                            <td className="py-1.5 pr-2 text-center">{c.almuerzo ? "✓" : ""}</td>
                            <td className="py-1.5 pr-2 text-right">{money.format(Number(c.importe))}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </CardContent>
                </Card>
              )}

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Historial de la liquidación</CardTitle>
                </CardHeader>
                <CardContent>
                  {!(eventsQ.data ?? []).length ? (
                    <p className="text-sm text-muted-foreground">Sin eventos registrados.</p>
                  ) : (
                    <ul className="space-y-1 text-sm">
                      {(eventsQ.data ?? []).map((e: any) => (
                        <li key={e.id} className="flex flex-wrap gap-2">
                          <span className="font-mono text-xs text-muted-foreground">
                            {new Date(e.created_at).toLocaleString("es-AR")}
                          </span>
                          <span className="font-semibold capitalize">{String(e.accion).replace(/_/g, " ")}</span>
                          <span className="text-muted-foreground">{e.nota ?? ""}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
