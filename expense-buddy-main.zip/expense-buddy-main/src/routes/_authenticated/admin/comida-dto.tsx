import { createFileRoute, Link } from "@tanstack/react-router";
import { Fragment, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { comidaOverview } from "@/lib/comida.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CalendarPlus, Download, FileSpreadsheet, ListChecks, Receipt } from "lucide-react";
import * as XLSX from "xlsx";
import { compareLegajo } from "@/lib/legajo";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/comida-dto")({
  component: ComidaDto,
  head: () => ({
    meta: [
      { title: "Comida a Dto. · centro de liquidación AGOEC" },
      {
        name: "description",
        content:
          "Vista rápida de Comida a Dto.: días cargados, importes, y el detalle legajo por legajo para armar la liquidación.",
      },
      { property: "og:title", content: "Comida a Dto. · centro de liquidación AGOEC" },
      {
        property: "og:description",
        content: "Todas las acciones para armar la liquidación de Comida a Dto., legajo por legajo.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const money = (n: number) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" }).format(Number(n) || 0);

function ComidaDto() {
  const fn = useServerFn(comidaOverview);
  const [mes, setMes] = useState<string>("actual");
  const [q, setQ] = useState("");
  const [abierto, setAbierto] = useState<string | null>(null);

  const { data, isLoading, error } = useQuery({
    queryKey: ["comida-overview", mes],
    queryFn: () => fn({ data: { mes: mes === "all" ? null : mes } }),
  });

  const k: any = data?.kpis ?? {};

  const filas = useMemo(() => {
    const needle = q.trim().toUpperCase();
    return (data?.porLegajo ?? [])
      .filter(
        (r: any) =>
          !needle ||
          r.legajo.toUpperCase().includes(needle) ||
          (r.apellido_nombre ?? "").toUpperCase().includes(needle),
      )
      .sort((a: any, b: any) => compareLegajo(a.legajo, b.legajo));
  }, [data, q]);

  function exportar() {
    if (!filas.length) return toast.error("No hay datos para exportar");
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        filas.map((r: any) => ({
          Legajo: r.legajo,
          "Apellido y Nombre": r.apellido_nombre ?? "",
          Días: r.dias,
          Desayunos: r.desayunos,
          Almuerzos: r.almuerzos,
          Consumos: r.consumos,
          "No paga": r.no_paga,
          "A descontar": Number(Number(r.importe).toFixed(2)),
        })),
      ),
      "Por afiliado",
    );
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(
        (data?.dias ?? []).map((d: any) => ({
          Fecha: d.fecha,
          Descripción: d.descripcion ?? "",
          Cumpleaños: d.es_cumpleanos ? "Sí" : "No",
          Comensales: d.comensales,
          Pagan: d.pagan,
          "Importe del día": d.importe ?? "",
          "A descontar": Number(Number(d.a_cobrar).toFixed(2)),
        })),
      ),
      "Por día",
    );
    XLSX.writeFile(wb, `comida-a-dto_${mes === "all" ? "todo" : mes}.xlsx`);
  }

  if (isLoading) return <p className="text-sm text-muted-foreground">Cargando…</p>;
  if (error) return <p className="text-sm text-destructive">{(error as any)?.message}</p>;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Comida a Dto. · centro de liquidación</h1>
          <p className="text-sm text-muted-foreground">
            Servicios Varios · producto de AGOEC. Todo lo necesario para armar la liquidación, más la
            vista legajo por legajo (igual a la que ve el afiliado).
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Select value={mes} onValueChange={setMes}>
            <SelectTrigger className="w-[160px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="actual">Período vigente</SelectItem>
              <SelectItem value="all">Todos los meses</SelectItem>
              {(data?.meses ?? []).map((m: string) => (
                <SelectItem key={m} value={m}>
                  {m}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="secondary" onClick={exportar}>
            <Download className="h-4 w-4 mr-1" /> Excel
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Acciones para armar la liquidación</CardTitle>
          <CardDescription>
            1) Cargá el día · 2) Revisá los formularios y poné el importe total · 3) Elegí los días a
            liquidar · 4) Descargá el Excel de descuentos.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button asChild>
            <Link to="/admin/dia">
              <CalendarPlus className="h-4 w-4 mr-1" /> Nuevo día
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link to="/admin/dias">
              <ListChecks className="h-4 w-4 mr-1" /> Formularios cargados
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link to="/admin/liquidacion">
              <Receipt className="h-4 w-4 mr-1" /> Armar liquidación
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link to="/admin/liquidaciones">
              <FileSpreadsheet className="h-4 w-4 mr-1" /> Liquidaciones guardadas
            </Link>
          </Button>
          <Button asChild variant="ghost">
            <Link to="/admin/crm">Buscador CRM</Link>
          </Button>

          <Button asChild variant="ghost">
            <Link to="/admin/afiliados">Padrón de afiliados</Link>
          </Button>
        </CardContent>
      </Card>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { l: "Días cargados", v: String(k.dias ?? 0) },
          { l: "Días pendientes de liquidar", v: String(k.dias_pendientes ?? 0) },
          { l: "Días ya liquidados", v: String(k.dias_liquidados ?? 0) },
          { l: "Días sin importe", v: String(k.sin_importe ?? 0) },
          { l: "Cumpleaños (sin cargo)", v: String(k.cumpleanos ?? 0) },
          { l: "Último día", v: k.ultimo_dia ?? "—" },

          { l: "Consumos", v: String(k.consumos ?? 0) },
          { l: "Afiliados con consumo", v: String(k.afiliados ?? 0) },
          { l: "Total facturado/pagado por AGOEC", v: money(k.total_pagado ?? 0) },
          { l: "Total a descontar (afiliados)", v: money(k.total_a_descontar ?? 0) },
          {
            l: `A cargo de AGOEC (No paga${k.consumos_no_paga ? `: ${k.consumos_no_paga}` : ""})`,
            v: money(k.a_cargo_agoec_no_paga ?? 0),
          },
          { l: "A cargo de AGOEC (Cumpleaños)", v: money(k.a_cargo_agoec_cumpleanos ?? 0) },
          { l: "Diferencia sin explicar", v: money(k.diferencia_no_explicada ?? 0) },
        ].map((x) => (
          <Card key={x.l}>
            <CardContent className="pt-5">
              <p className="text-xs text-muted-foreground">{x.l}</p>
              <p className="text-lg font-semibold">{x.v}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Días del período</CardTitle>
          <CardDescription>
            El importe del día se divide entre todos los comensales; la parte de los consumos “no
            paga” y los días de cumpleaños no se redistribuyen: quedan a cargo de AGOEC.
          </CardDescription>
        </CardHeader>

        <CardContent>
          {!(data?.dias ?? []).length ? (
            <p className="text-sm text-muted-foreground">Sin días cargados en el período.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b text-left text-muted-foreground">
                  <tr>
                    <th className="py-2 pr-2">Fecha</th>
                    <th className="py-2 pr-2">Descripción</th>
                    <th className="py-2 pr-2 text-center">Comensales</th>
                    <th className="py-2 pr-2 text-center">Pagan</th>
                    <th className="py-2 pr-2 text-right">Importe día</th>
                    <th className="py-2 pr-2 text-right">A descontar</th>
                    <th className="py-2 pr-2 text-right">A cargo AGOEC</th>

                  </tr>
                </thead>
                <tbody>
                  {(data?.dias ?? []).map((d: any) => (
                    <tr key={d.id} className="border-b last:border-0">
                      <td className="py-2 pr-2 font-mono">{d.fecha}</td>
                      <td className="py-2 pr-2">
                        {d.descripcion ?? "—"}
                        {d.es_cumpleanos && (
                          <Badge variant="destructive" className="ml-2">
                            cumpleaños
                          </Badge>
                        )}
                        {d.liquidado && (
                          <Badge variant="secondary" className="ml-2">
                            liquidado
                          </Badge>
                        )}

                      </td>
                      <td className="py-2 pr-2 text-center">{d.comensales}</td>
                      <td className="py-2 pr-2 text-center">{d.pagan}</td>
                      <td className="py-2 pr-2 text-right">
                        {d.importe == null ? (
                          <span className="text-destructive">falta importe</span>
                        ) : (
                          money(d.importe)
                        )}
                      </td>
                      <td className="py-2 pr-2 text-right">{money(d.a_cobrar)}</td>
                      <td className="py-2 pr-2 text-right">
                        {money(d.a_cargo_agoec ?? 0)}
                        {d.no_paga ? (
                          <span className="ml-1 text-xs text-muted-foreground">
                            ({d.no_paga} no paga)
                          </span>
                        ) : null}
                      </td>

                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-3">
          <div>
            <CardTitle className="text-base">Legajo por legajo</CardTitle>
            <CardDescription>
              Tocá un legajo para ver el mismo detalle que ve el afiliado en su cuenta.
            </CardDescription>
          </div>
          <Input
            placeholder="Buscar legajo o nombre"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="w-[240px]"
          />
        </CardHeader>
        <CardContent>
          {!filas.length ? (
            <p className="text-sm text-muted-foreground">Sin consumos en el período.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b text-left text-muted-foreground">
                  <tr>
                    <th className="py-2 pr-2">Legajo</th>
                    <th className="py-2 pr-2">Apellido y Nombre</th>
                    <th className="py-2 pr-2 text-center">Días</th>
                    <th className="py-2 pr-2 text-center">Desayunos</th>
                    <th className="py-2 pr-2 text-center">Almuerzos</th>
                    <th className="py-2 pr-2 text-center">No paga</th>
                    <th className="py-2 pr-2 text-right">A descontar</th>
                  </tr>
                </thead>
                <tbody>
                  {filas.map((r: any) => (
                    <Fragment key={r.legajo}>
                      <tr
                        className="cursor-pointer border-b hover:bg-muted/40"
                        onClick={() => setAbierto(abierto === r.legajo ? null : r.legajo)}
                      >
                        <td className="py-2 pr-2 font-mono">{r.legajo}</td>
                        <td className="py-2 pr-2">{r.apellido_nombre ?? "—"}</td>
                        <td className="py-2 pr-2 text-center">{r.dias}</td>
                        <td className="py-2 pr-2 text-center">{r.desayunos}</td>
                        <td className="py-2 pr-2 text-center">{r.almuerzos}</td>
                        <td className="py-2 pr-2 text-center">
                          {r.no_paga ? (
                            <span className="text-destructive">{r.no_paga}</span>
                          ) : (
                            0
                          )}
                        </td>
                        <td className="py-2 pr-2 text-right font-medium">{money(r.importe)}</td>
                      </tr>
                      {abierto === r.legajo && (
                        <tr className="border-b bg-muted/30">
                          <td colSpan={7} className="p-3">
                            <div className="divide-y">
                              {r.detalle.map((d: any, i: number) => (
                                <div
                                  key={`${d.fecha}-${i}`}
                                  className="flex flex-wrap items-center justify-between gap-2 py-2"
                                >
                                  <div>
                                    <p className="font-mono text-sm">{d.fecha}</p>
                                    <p className="text-xs text-muted-foreground">
                                      {d.descripcion ?? "—"}
                                      {d.observacion ? ` · Obs: ${d.observacion}` : ""}
                                    </p>
                                  </div>
                                  <div className="flex items-center gap-3 text-sm">
                                    {d.desayuno && <span className="text-amber-600">Desayuno</span>}
                                    {d.almuerzo && <span className="text-sky-600">Almuerzo</span>}
                                    {d.es_cumpleanos && (
                                      <Badge variant="destructive">cumpleaños</Badge>
                                    )}
                                    {d.no_paga && <Badge variant="destructive">no paga</Badge>}
                                    <span className="font-mono">{money(d.importe)}</span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
