import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import * as XLSX from "xlsx";
import { toast } from "sonner";

import {
  listAutoProviders,
  upsertPrestacion,
  deletePrestacion,
  previewAutoImport,
  submitAutoImport,
  autoPeriodSummary,
  autoHistory,
} from "@/lib/automotores.functions";
import { parseAutomotoresWorkbook, type AutoParsedFile } from "@/lib/automotores-xlsx";
import { automotoresConsumosSearch } from "@/lib/crm-search.functions";
import { MESES, formatPeriodo, periodoError } from "@/lib/periodo";
import { normalizeLegajo } from "@/lib/legajo";
import { ProveedoresServicioCard } from "@/components/ProveedoresServicioCard";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertTriangle,
  Car,
  Download,
  FileSpreadsheet,
  Plus,
  Search,
  Trash2,
  Upload,
} from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/automotores")({
  component: Automotores,
  head: () => ({
    meta: [
      { title: "Automotores · Liquidación de proveedores AGOEC" },
      {
        name: "description",
        content:
          "Carga de consumos de Automotores por proveedor y período, comisión AGOEC por prestación y neto a pagar.",
      },
      { property: "og:title", content: "Automotores · Liquidación de proveedores AGOEC" },
      {
        property: "og:description",
        content: "Importación del Excel del proveedor, cuotas, comisión AGOEC y neto a pagar por período.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const money = (n: unknown) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" }).format(Number(n) || 0);
const pctFmt = (n: unknown) => `${(Number(n) || 0).toLocaleString("es-AR", { maximumFractionDigits: 2 })} %`;

type ManualRow = {
  fecha: string;
  legajo: string;
  ticket: string;
  prestacion: string;
  importe: string;
  cuotas: string;
  observacion: string;
};
const EMPTY_MANUAL: ManualRow = {
  fecha: new Date().toISOString().slice(0, 10),
  legajo: "",
  ticket: "",
  prestacion: "",
  importe: "",
  cuotas: "1",
  observacion: "",
};

function Automotores() {
  const qc = useQueryClient();
  const provFn = useServerFn(listAutoProviders);
  const savePrest = useServerFn(upsertPrestacion);
  const delPrest = useServerFn(deletePrestacion);
  const previewFn = useServerFn(previewAutoImport);
  const submitFn = useServerFn(submitAutoImport);
  const periodFn = useServerFn(autoPeriodSummary);
  const histFn = useServerFn(autoHistory);

  const hoy = new Date();
  const [mes, setMes] = useState(hoy.getMonth() + 1);
  const [anio, setAnio] = useState(hoy.getFullYear());
  const [providerId, setProviderId] = useState("");
  const [parsed, setParsed] = useState<AutoParsedFile | null>(null);
  const [factura, setFactura] = useState("");
  const [manual, setManual] = useState<ManualRow[]>([{ ...EMPTY_MANUAL }]);
  const [saving, setSaving] = useState(false);
  const [busca, setBusca] = useState("");
  const [q, setQ] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const provQ = useQuery({ queryKey: ["auto-providers"], queryFn: () => provFn({ data: undefined as any }) });
  const providers = provQ.data?.providers ?? [];
  const prov = providers.find((p: any) => p.id === providerId);

  const periodQ = useQuery({
    queryKey: ["auto-period", mes, anio],
    queryFn: () => periodFn({ data: { periodo_mes: mes, periodo_anio: anio } }),
  });

  const histQ = useQuery({
    queryKey: ["auto-history", q],
    queryFn: () => histFn({ data: { q: q || undefined } }),
  });

  // Buscador de consumos del período vigente (solo proveedores habilitados).
  const buscaVigFn = useServerFn(automotoresConsumosSearch);
  const [termV, setTermV] = useState("");
  const [qV, setQV] = useState("");
  const vigBuscaQ = useQuery({
    queryKey: ["auto-consumos-vigente", qV],
    queryFn: () => buscaVigFn({ data: { q: qV } }),
    enabled: qV.length > 0,
  });

  /* ------------------------------ Prestaciones ---------------------------- */
  const [pNombre, setPNombre] = useState("");
  const [pPct, setPPct] = useState("0");

  async function addPrestacion() {
    if (!providerId) return toast.error("Elegí primero el proveedor");
    if (pNombre.trim().length < 2) return toast.error("Poné el nombre de la prestación");
    try {
      await savePrest({
        data: { provider_id: providerId, nombre: pNombre.trim(), comision_pct: Number(pPct) || 0, activo: true },
      });
      setPNombre("");
      setPPct("0");
      qc.invalidateQueries({ queryKey: ["auto-providers"] });
      toast.success("Prestación guardada");
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo guardar");
    }
  }

  async function updatePct(row: any, pct: number) {
    try {
      await savePrest({
        data: { id: row.id, provider_id: row.provider_id, nombre: row.nombre, comision_pct: pct, activo: row.activo },
      });
      qc.invalidateQueries({ queryKey: ["auto-providers"] });
      toast.success("Comisión actualizada (no afecta liquidaciones ya cargadas)");
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo actualizar");
    }
  }

  /* --------------------------------- Excel -------------------------------- */
  async function onFile(f: File) {
    try {
      const buf = await f.arrayBuffer();
      const data = parseAutomotoresWorkbook(f.name, buf);
      setParsed(data);
      setFactura(data.factura ?? "");
      if (data.periodo_mes && data.periodo_anio) {
        setMes(data.periodo_mes);
        setAnio(data.periodo_anio);
      }
      if (!data.filas.length) toast.warning("El archivo no trae filas de consumo válidas");
      else toast.success(`${data.filas.length} fila(s) leída(s)`);
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo leer el Excel");
    } finally {
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  const previewQ = useQuery({
    queryKey: ["auto-preview", providerId, parsed?.archivo, parsed?.filas.length],
    enabled: !!providerId && !!parsed?.filas.length,
    queryFn: () =>
      previewFn({
        data: {
          provider_id: providerId,
          items: (parsed?.filas ?? []).map((r) => ({
            fecha: r.fecha,
            legajo: r.legajo,
            apellido_nombre: r.apellido_nombre,
            ticket: r.ticket,
            prestacion: r.prestacion,
            importe: r.importe,
            observacion: r.observacion,
            cuotas: r.cuotas,
            cuotas_importes: r.cuotas_importes,
          })),
        },
      }),
  });

  const errPeriodo = periodoError(mes, anio);

  async function confirmarImport() {
    if (!providerId || !parsed?.filas.length || errPeriodo) return;
    setSaving(true);
    try {
      const res = await submitFn({
        data: {
          provider_id: providerId,
          nombre: `${prov?.nombre ?? "Proveedor"} · ${formatPeriodo(mes, anio)}${factura ? ` · FC ${factura}` : ""}`,
          factura: factura || null,
          periodo_mes: mes,
          periodo_anio: anio,
          items: parsed.filas.map((r) => ({
            fecha: r.fecha,
            legajo: r.legajo,
            apellido_nombre: r.apellido_nombre,
            ticket: r.ticket,
            prestacion: r.prestacion,
            importe: r.importe,
            observacion: r.observacion,
            cuotas: r.cuotas,
            cuotas_importes: r.cuotas_importes,
          })),
        },
      });
      toast.success(`Importado: ${res.total_items} consumos · neto ${money(res.total_neto)}`);
      setParsed(null);
      qc.invalidateQueries({ queryKey: ["auto-period"] });
      qc.invalidateQueries({ queryKey: ["auto-history"] });
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo importar");
    } finally {
      setSaving(false);
    }
  }

  /* --------------------------------- Manual ------------------------------- */
  async function guardarManual() {
    if (!providerId) return toast.error("Elegí el proveedor");
    if (errPeriodo) return toast.error(errPeriodo);
    const items = manual
      .filter((m) => normalizeLegajo(m.legajo) && Number(m.importe) > 0 && m.prestacion.trim())
      .map((m) => ({
        fecha: m.fecha || null,
        legajo: normalizeLegajo(m.legajo),
        ticket: m.ticket || null,
        prestacion: m.prestacion.trim(),
        importe: Math.round(Number(m.importe) * 100) / 100,
        observacion: m.observacion || null,
        cuotas: Math.min(12, Math.max(1, Number(m.cuotas) || 1)),
        cuotas_importes: null,
      }));
    if (!items.length) return toast.error("Completá legajo, prestación e importe");
    setSaving(true);
    try {
      const res = await submitFn({
        data: {
          provider_id: providerId,
          nombre: `${prov?.nombre ?? "Proveedor"} · ${formatPeriodo(mes, anio)} · carga manual`,
          factura: factura || null,
          periodo_mes: mes,
          periodo_anio: anio,
          items,
        },
      });
      toast.success(`Cargados ${res.total_items} consumos · neto ${money(res.total_neto)}`);
      setManual([{ ...EMPTY_MANUAL }]);
      qc.invalidateQueries({ queryKey: ["auto-period"] });
      qc.invalidateQueries({ queryKey: ["auto-history"] });
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo guardar");
    } finally {
      setSaving(false);
    }
  }

  /* ------------------------------ Exportación ----------------------------- */
  function exportar(rows: any[], nombre: string) {
    if (!rows.length) return toast.error("No hay movimientos para exportar");
    const data = rows.map((r) => ({
      Periodo: `${String(r.periodo_mes ?? mes).padStart(2, "0")}/${r.periodo_anio ?? anio}`,
      Proveedor: r.proveedor ?? prov?.nombre ?? "",
      Fecha: r.fecha ?? "",
      Legajo: r.legajo,
      Afiliado: r.apellido_nombre ?? "",
      Ticket: r.comprobante ?? r.ticket ?? "",
      Servicio: r.prestacion ?? "",
      "Importe bruto": Number(r.importe) || 0,
      Cuotas: Number(r.cuotas) || 1,
      "Comisión %": Number(r.comision_pct) || 0,
      "Comisión $": Number(r.comision_monto) || 0,
      "Neto proveedor": Number(r.neto_proveedor ?? r.importe) || 0,
    }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(data), "Automotores");
    XLSX.writeFile(wb, `${nombre.replace(/[^\w\s-]/g, "")}.xlsx`);
  }

  const histRows = useMemo(() => {
    const rows = histQ.data?.rows ?? [];
    const t = busca.trim().toLowerCase();
    if (!t) return rows.slice(0, 300);
    return rows
      .filter((r: any) =>
        [r.legajo, r.apellido_nombre, r.comprobante, r.prestacion, r.proveedor]
          .filter(Boolean)
          .some((v: any) => String(v).toLowerCase().includes(t)),
      )
      .slice(0, 300);
  }, [histQ.data, busca]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-bold">
            <Car className="h-6 w-6 text-primary" /> Automotores
          </h1>
          <p className="text-sm text-muted-foreground">
            Consumos por proveedor y prestación, cuotas informadas, comisión AGOEC y neto a pagar.
          </p>
        </div>
        <div className="flex flex-wrap items-end gap-2">
          <div>
            <Label className="text-xs">Mes</Label>
            <select
              className="h-10 w-40 rounded-md border bg-background px-3 text-sm"
              value={mes}
              onChange={(e) => setMes(Number(e.target.value))}
            >
              {MESES.map((m, i) => (
                <option key={m} value={i + 1}>
                  {m}
                </option>
              ))}
            </select>
          </div>
          <div>
            <Label className="text-xs">Año</Label>
            <Input
              className="w-28"
              type="number"
              min={2000}
              max={2100}
              value={anio}
              onChange={(e) => setAnio(Number(e.target.value))}
            />
          </div>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {[
          { t: "Período", v: formatPeriodo(mes, anio) },
          { t: "Consumos", v: String(periodQ.data?.totales.consumos ?? 0) },
          { t: "Bruto", v: money(periodQ.data?.totales.bruto) },
          { t: "Comisión AGOEC", v: money(periodQ.data?.totales.comision) },
          { t: "Neto a proveedores", v: money(periodQ.data?.totales.neto) },
        ].map((c) => (
          <Card key={c.t}>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-muted-foreground">{c.t}</CardTitle>
            </CardHeader>
            <CardContent className="text-lg font-bold">{c.v}</CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Search className="h-4 w-4" /> Buscador de consumos del período vigente
          </CardTitle>
          <CardDescription>
            Buscá por legajo o nombre y apellido. Solo se muestran consumos de los proveedores
            habilitados cargados en el período vigente
            {vigBuscaQ.data?.vigente
              ? ` (${formatPeriodo(vigBuscaQ.data.vigente.mes, vigBuscaQ.data.vigente.anio)})`
              : ""}
            .
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setQV(termV.trim());
            }}
            className="flex gap-2"
          >
            <Input
              placeholder="Legajo o nombre del afiliado…"
              value={termV}
              onChange={(e) => setTermV(e.target.value)}
            />
            <Button type="submit">Buscar</Button>
          </form>

          {vigBuscaQ.isFetching && (
            <p className="text-sm text-muted-foreground">Buscando…</p>
          )}
          {!!qV && !vigBuscaQ.isFetching && !vigBuscaQ.data?.items?.length && (
            <p className="text-sm text-muted-foreground">
              Sin consumos del período vigente para “{qV}”.
            </p>
          )}

          {!!vigBuscaQ.data?.totales && !!vigBuscaQ.data.items.length && (
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4 text-sm">
              {[
                { l: "Consumos", v: vigBuscaQ.data.totales.items },
                { l: "Importe total", v: money(vigBuscaQ.data.totales.importe) },
                { l: "Comisión AGOEC", v: money(vigBuscaQ.data.totales.comision) },
                { l: "A descontar", v: money(vigBuscaQ.data.totales.a_descontar) },
              ].map((k) => (
                <div key={k.l} className="rounded-md bg-muted/50 px-3 py-2">
                  <p className="text-[11px] text-muted-foreground">{k.l}</p>
                  <p className="font-medium">{k.v}</p>
                </div>
              ))}
            </div>
          )}

          {!!vigBuscaQ.data?.items?.length && (
            <div className="overflow-x-auto rounded-lg border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/50 text-left text-xs text-muted-foreground">
                    <th className="px-3 py-2">Legajo</th>
                    <th className="px-3 py-2">Afiliado</th>
                    <th className="px-3 py-2">Proveedor</th>
                    <th className="px-3 py-2">Fecha</th>
                    <th className="px-3 py-2">Prestación / Detalle</th>
                    <th className="px-3 py-2">Estado</th>
                    <th className="px-3 py-2 text-right">Importe</th>
                    <th className="px-3 py-2 text-right">Comisión</th>
                    <th className="px-3 py-2 text-right">A descontar</th>
                  </tr>
                </thead>
                <tbody>
                  {vigBuscaQ.data.items.map((it: any) => {
                    const aff = (vigBuscaQ.data.affiliates ?? []).find(
                      (a: any) => a.legajo === it.legajo,
                    );
                    return (
                      <tr key={it.id} className="border-b last:border-0">
                        <td className="px-3 py-2 font-medium">{it.legajo}</td>
                        <td className="px-3 py-2">{aff?.apellido_nombre ?? "—"}</td>
                        <td className="px-3 py-2">{it.proveedor}</td>
                        <td className="px-3 py-2">{it.fecha ?? "—"}</td>
                        <td className="px-3 py-2">{it.prestacion ?? it.detalle ?? "—"}</td>
                        <td className="px-3 py-2 capitalize">{it.estado}</td>
                        <td className="px-3 py-2 text-right">{money(it.importe)}</td>
                        <td className="px-3 py-2 text-right">{money(it.comision_monto)}</td>
                        <td className="px-3 py-2 text-right font-medium">
                          {money(it.a_descontar)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Proveedor</CardTitle>
          <CardDescription>Elegí el proveedor de Automotores para cargar o configurar prestaciones.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-3">
          <div>
            <Label className="text-xs">Proveedor</Label>
            <select
              className="h-10 w-full rounded-md border bg-background px-3 text-sm"
              value={providerId}
              onChange={(e) => setProviderId(e.target.value)}
            >
              <option value="">Elegí el proveedor…</option>
              {providers.map((p: any) => (
                <option key={p.id} value={p.id}>
                  {p.nombre}
                </option>
              ))}
            </select>
          </div>
          <div>
            <Label className="text-xs">Factura (FC B N°)</Label>
            <Input value={factura} onChange={(e) => setFactura(e.target.value)} placeholder="1526" />
          </div>
          <div className="flex items-end text-sm text-muted-foreground">
            {prov ? `${prov.prestaciones.length} prestación(es) configurada(s)` : "—"}
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="excel">
        <TabsList className="flex-wrap">
          <TabsTrigger value="excel">Carga Excel</TabsTrigger>
          <TabsTrigger value="manual">Carga manual</TabsTrigger>
          <TabsTrigger value="prestaciones">Prestaciones y comisión</TabsTrigger>
          <TabsTrigger value="liquidacion">Liquidación del período</TabsTrigger>
          <TabsTrigger value="historial">Historial</TabsTrigger>
        </TabsList>

        {/* ------------------------------ EXCEL ------------------------------ */}
        <TabsContent value="excel" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <FileSpreadsheet className="h-4 w-4 text-primary" /> Excel del proveedor
              </CardTitle>
              <CardDescription>
                Formato real: cabecera Proveedor / FC B N° / Fecha / Periodo y columnas Fecha_Compra, Legajo,
                Apellido_y_Nombre, Ticket, Tipo_Compra, Importe_Total, Observacion, Cuotas y Cuota_1 a Cuota_12.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <input
                ref={fileRef}
                type="file"
                accept=".xlsx,.xls"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])}
              />
              <Button variant="outline" onClick={() => fileRef.current?.click()} disabled={!providerId}>
                <Upload className="h-4 w-4" /> Elegir archivo
              </Button>
              {!providerId && <p className="text-xs text-muted-foreground">Elegí primero el proveedor.</p>}

              {parsed && (
                <div className="space-y-3">
                  <div className="grid gap-3 sm:grid-cols-4">
                    {[
                      { t: "Archivo", v: parsed.archivo },
                      { t: "Factura", v: parsed.factura ?? "—" },
                      {
                        t: "Período del archivo",
                        v:
                          parsed.periodo_mes && parsed.periodo_anio
                            ? formatPeriodo(parsed.periodo_mes, parsed.periodo_anio)
                            : "—",
                      },
                      { t: "Filas válidas", v: `${parsed.filas.length}` },
                    ].map((c) => (
                      <div key={c.t} className="rounded-lg border p-3">
                        <p className="text-xs text-muted-foreground">{c.t}</p>
                        <p className="truncate font-medium">{c.v}</p>
                      </div>
                    ))}
                  </div>

                  {!!parsed.invalidas.length && (
                    <div className="rounded-lg border border-destructive/50 bg-destructive/5 p-3 text-sm">
                      <p className="flex items-center gap-2 font-medium">
                        <AlertTriangle className="h-4 w-4 text-destructive" />
                        {parsed.invalidas.length} fila(s) no se importan
                      </p>
                      <div className="mt-1 max-h-40 space-y-1 overflow-auto text-muted-foreground">
                        {parsed.invalidas.map((r, i) => (
                          <p key={i}>
                            Fila {r.fila} · {r.legajo || "(sin legajo)"} — {r.motivo}
                          </p>
                        ))}
                      </div>
                    </div>
                  )}

                  {!!previewQ.data?.legajos_desconocidos.length && (
                    <div className="rounded-lg border border-amber-500/50 bg-amber-500/5 p-3 text-sm">
                      <p className="font-medium">
                        {previewQ.data.legajos_desconocidos.length} legajo(s) no están en el padrón
                      </p>
                      <p className="mt-1 break-words text-muted-foreground">
                        {previewQ.data.legajos_desconocidos.join(", ")}
                      </p>
                    </div>
                  )}

                  {!!previewQ.data?.prestaciones_nuevas.length && (
                    <div className="rounded-lg border border-amber-500/50 bg-amber-500/5 p-3 text-sm">
                      <p className="font-medium">Prestaciones sin comisión configurada (se aplican al 0 %)</p>
                      <p className="mt-1 text-muted-foreground">{previewQ.data.prestaciones_nuevas.join(", ")}</p>
                    </div>
                  )}

                  {previewQ.data && (
                    <>
                      <div className="grid gap-3 sm:grid-cols-3">
                        <div className="rounded-lg border p-3">
                          <p className="text-xs text-muted-foreground">Bruto</p>
                          <p className="font-medium">{money(previewQ.data.total_importe)}</p>
                        </div>
                        <div className="rounded-lg border p-3">
                          <p className="text-xs text-muted-foreground">Comisión AGOEC</p>
                          <p className="font-medium">{money(previewQ.data.total_comision)}</p>
                        </div>
                        <div className="rounded-lg border p-3">
                          <p className="text-xs text-muted-foreground">Neto proveedor</p>
                          <p className="font-medium">{money(previewQ.data.total_neto)}</p>
                        </div>
                      </div>

                      <div className="max-h-96 overflow-auto rounded-lg border">
                        <table className="w-full text-sm">
                          <thead className="sticky top-0 bg-muted/50">
                            <tr>
                              <th className="p-2 text-left">Fecha</th>
                              <th className="p-2 text-left">Legajo</th>
                              <th className="p-2 text-left">Afiliado</th>
                              <th className="p-2 text-left">Ticket</th>
                              <th className="p-2 text-left">Servicio</th>
                              <th className="p-2 text-right">Importe</th>
                              <th className="p-2 text-right">Cuotas</th>
                              <th className="p-2 text-left">Distribución</th>
                              <th className="p-2 text-right">Com. %</th>
                              <th className="p-2 text-right">Com. $</th>
                              <th className="p-2 text-right">Neto</th>
                              <th className="p-2 text-left">Observación</th>
                            </tr>
                          </thead>
                          <tbody>
                            {previewQ.data.rows.map((r: any, i: number) => (
                              <tr key={i} className="border-t">
                                <td className="p-2">{r.fecha ?? "—"}</td>
                                <td className="p-2 font-mono">
                                  {r.legajo}
                                  {!r.legajo_valido && (
                                    <Badge variant="destructive" className="ml-1">
                                      ?
                                    </Badge>
                                  )}
                                </td>
                                <td className="p-2">{r.apellido_nombre ?? "—"}</td>
                                <td className="p-2">{r.ticket ?? "—"}</td>
                                <td className="p-2">{r.prestacion}</td>
                                <td className="p-2 text-right">{money(r.importe)}</td>
                                <td className="p-2 text-right">{r.cuotas}</td>
                                <td className="p-2 text-xs text-muted-foreground">
                                  {r.cuotas_importes.map((x: number) => money(x)).join(" · ")}
                                </td>
                                <td className="p-2 text-right">{pctFmt(r.comision_pct)}</td>
                                <td className="p-2 text-right">{money(r.comision_monto)}</td>
                                <td className="p-2 text-right">{money(r.neto_proveedor)}</td>
                                <td className="p-2">{r.observacion ?? "—"}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </>
                  )}

                  <div className="flex flex-wrap gap-2">
                    <Button onClick={confirmarImport} disabled={saving || !!errPeriodo || !parsed.filas.length}>
                      Confirmar importación
                    </Button>
                    <Button variant="outline" onClick={() => setParsed(null)}>
                      Cancelar
                    </Button>
                    {!!errPeriodo && <Badge variant="destructive">{errPeriodo}</Badge>}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ------------------------------ MANUAL ----------------------------- */}
        <TabsContent value="manual">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Carga manual</CardTitle>
              <CardDescription>
                Mismo modelo que el Excel. Si no informás importes por cuota, el total se divide en partes iguales.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50">
                    <tr>
                      <th className="p-2 text-left">Fecha</th>
                      <th className="p-2 text-left">Legajo</th>
                      <th className="p-2 text-left">Ticket</th>
                      <th className="p-2 text-left">Servicio / Prestación</th>
                      <th className="p-2 text-left">Importe</th>
                      <th className="p-2 text-left">Cuotas</th>
                      <th className="p-2 text-left">Observación</th>
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    {manual.map((m, i) => (
                      <tr key={i} className="border-t">
                        <td className="p-1">
                          <Input
                            type="date"
                            value={m.fecha}
                            onChange={(e) =>
                              setManual(manual.map((x, j) => (j === i ? { ...x, fecha: e.target.value } : x)))
                            }
                          />
                        </td>
                        <td className="p-1">
                          <Input
                            value={m.legajo}
                            onChange={(e) =>
                              setManual(manual.map((x, j) => (j === i ? { ...x, legajo: e.target.value } : x)))
                            }
                          />
                        </td>
                        <td className="p-1">
                          <Input
                            value={m.ticket}
                            onChange={(e) =>
                              setManual(manual.map((x, j) => (j === i ? { ...x, ticket: e.target.value } : x)))
                            }
                          />
                        </td>
                        <td className="p-1">
                          <Input
                            list="auto-prestaciones"
                            value={m.prestacion}
                            onChange={(e) =>
                              setManual(manual.map((x, j) => (j === i ? { ...x, prestacion: e.target.value } : x)))
                            }
                          />
                        </td>
                        <td className="p-1">
                          <Input
                            type="number"
                            step="0.01"
                            value={m.importe}
                            onChange={(e) =>
                              setManual(manual.map((x, j) => (j === i ? { ...x, importe: e.target.value } : x)))
                            }
                          />
                        </td>
                        <td className="p-1">
                          <Input
                            type="number"
                            min={1}
                            max={12}
                            value={m.cuotas}
                            onChange={(e) =>
                              setManual(manual.map((x, j) => (j === i ? { ...x, cuotas: e.target.value } : x)))
                            }
                          />
                        </td>
                        <td className="p-1">
                          <Input
                            value={m.observacion}
                            onChange={(e) =>
                              setManual(manual.map((x, j) => (j === i ? { ...x, observacion: e.target.value } : x)))
                            }
                          />
                        </td>
                        <td className="p-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setManual(manual.filter((_, j) => j !== i))}
                            aria-label="Quitar fila"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <datalist id="auto-prestaciones">
                  {(prov?.prestaciones ?? []).map((p: any) => (
                    <option key={p.id} value={p.nombre} />
                  ))}
                </datalist>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" onClick={() => setManual([...manual, { ...EMPTY_MANUAL }])}>
                  <Plus className="h-4 w-4" /> Agregar fila
                </Button>
                <Button onClick={guardarManual} disabled={saving || !providerId}>
                  Guardar consumos
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* --------------------------- PRESTACIONES -------------------------- */}
        <TabsContent value="prestaciones">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Prestaciones y comisión AGOEC</CardTitle>
              <CardDescription>
                La comisión se define por proveedor + prestación. Cambiarla no modifica liquidaciones ya cargadas.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {!providerId ? (
                <p className="text-sm text-muted-foreground">Elegí un proveedor.</p>
              ) : (
                <>
                  <div className="flex flex-wrap items-end gap-2">
                    <div>
                      <Label className="text-xs">Servicio / Prestación</Label>
                      <Input value={pNombre} onChange={(e) => setPNombre(e.target.value)} placeholder="Lavado" />
                    </div>
                    <div>
                      <Label className="text-xs">Comisión AGOEC %</Label>
                      <Input
                        className="w-28"
                        type="number"
                        step="0.01"
                        min={0}
                        max={100}
                        value={pPct}
                        onChange={(e) => setPPct(e.target.value)}
                      />
                    </div>
                    <Button onClick={addPrestacion}>
                      <Plus className="h-4 w-4" /> Agregar servicio
                    </Button>
                  </div>

                  <div className="overflow-x-auto rounded-lg border">
                    <table className="w-full text-sm">
                      <thead className="bg-muted/50">
                        <tr>
                          <th className="p-2 text-left">Servicio</th>
                          <th className="p-2 text-left">Comisión AGOEC</th>
                          <th />
                        </tr>
                      </thead>
                      <tbody>
                        {(prov?.prestaciones ?? []).map((p: any) => (
                          <tr key={p.id} className="border-t">
                            <td className="p-2">{p.nombre}</td>
                            <td className="p-2">
                              <Input
                                className="w-28"
                                type="number"
                                step="0.01"
                                min={0}
                                max={100}
                                defaultValue={p.comision_pct}
                                onBlur={(e) => {
                                  const v = Number(e.target.value) || 0;
                                  if (v !== Number(p.comision_pct)) updatePct(p, v);
                                }}
                              />
                            </td>
                            <td className="p-2 text-right">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={async () => {
                                  await delPrest({ data: { id: p.id } });
                                  qc.invalidateQueries({ queryKey: ["auto-providers"] });
                                }}
                                aria-label="Eliminar prestación"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </td>
                          </tr>
                        ))}
                        {!(prov?.prestaciones ?? []).length && (
                          <tr>
                            <td className="p-3 text-center text-muted-foreground" colSpan={3}>
                              Todavía no hay prestaciones configuradas.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* --------------------------- LIQUIDACIÓN --------------------------- */}
        <TabsContent value="liquidacion" className="space-y-4">
          {periodQ.isLoading ? (
            <p className="text-sm text-muted-foreground">Cargando…</p>
          ) : !periodQ.data?.proveedores.length ? (
            <Card>
              <CardContent className="py-6 text-sm text-muted-foreground">
                No hay cargas de Automotores en {formatPeriodo(mes, anio)}.
              </CardContent>
            </Card>
          ) : (
            periodQ.data.proveedores.map((p: any) => (
              <Card key={p.submission_id}>
                <CardHeader>
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <CardTitle className="text-base">
                        {p.proveedor} — {formatPeriodo(mes, anio)}
                      </CardTitle>
                      <CardDescription>
                        {p.consumos} consumos · {p.afiliados} afiliados
                        {p.factura ? ` · FC ${p.factura}` : ""} · {p.estado}
                      </CardDescription>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        exportar(
                          p.items.map((i: any) => ({
                            ...i,
                            proveedor: p.proveedor,
                            periodo_mes: mes,
                            periodo_anio: anio,
                            apellido_nombre: i.apellido_nombre ?? "",
                          })),
                          `Automotores ${p.proveedor} ${anio}-${String(mes).padStart(2, "0")}`,
                        )
                      }
                    >
                      <Download className="h-4 w-4" /> Excel
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="overflow-x-auto rounded-lg border">
                    <table className="w-full text-sm">
                      <thead className="bg-muted/50">
                        <tr>
                          <th className="p-2 text-left">Servicio</th>
                          <th className="p-2 text-right">Bruto</th>
                          <th className="p-2 text-right">Comisión</th>
                          <th className="p-2 text-right">Neto proveedor</th>
                        </tr>
                      </thead>
                      <tbody>
                        {p.subtotales.map((s: any) => (
                          <tr key={s.prestacion} className="border-t">
                            <td className="p-2">
                              {s.prestacion} <span className="text-xs text-muted-foreground">({pctFmt(s.comision_pct)})</span>
                            </td>
                            <td className="p-2 text-right">{money(s.bruto)}</td>
                            <td className="p-2 text-right">{money(s.comision)}</td>
                            <td className="p-2 text-right">{money(s.neto)}</td>
                          </tr>
                        ))}
                        <tr className="border-t bg-muted/30 font-medium">
                          <td className="p-2">TOTAL</td>
                          <td className="p-2 text-right">{money(p.bruto)}</td>
                          <td className="p-2 text-right">{money(p.comision)}</td>
                          <td className="p-2 text-right">{money(p.neto)}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  <div className="max-h-80 overflow-auto rounded-lg border">
                    <table className="w-full text-sm">
                      <thead className="sticky top-0 bg-muted/50">
                        <tr>
                          <th className="p-2 text-left">Fecha</th>
                          <th className="p-2 text-left">Legajo</th>
                          <th className="p-2 text-left">Ticket</th>
                          <th className="p-2 text-left">Servicio</th>
                          <th className="p-2 text-right">Importe</th>
                          <th className="p-2 text-right">Cuotas</th>
                          <th className="p-2 text-right">Com. %</th>
                          <th className="p-2 text-right">Com. $</th>
                          <th className="p-2 text-right">Neto</th>
                        </tr>
                      </thead>
                      <tbody>
                        {p.items.map((i: any) => (
                          <tr key={i.id} className="border-t">
                            <td className="p-2">{i.fecha ?? "—"}</td>
                            <td className="p-2 font-mono">{i.legajo}</td>
                            <td className="p-2">{i.comprobante ?? "—"}</td>
                            <td className="p-2">{i.prestacion ?? "—"}</td>
                            <td className="p-2 text-right">{money(i.importe)}</td>
                            <td className="p-2 text-right">{i.cuotas}</td>
                            <td className="p-2 text-right">{pctFmt(i.comision_pct)}</td>
                            <td className="p-2 text-right">{money(i.comision_monto)}</td>
                            <td className="p-2 text-right">{money(i.neto_proveedor ?? i.importe)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        {/* ----------------------------- HISTORIAL --------------------------- */}
        <TabsContent value="historial">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Historial de movimientos</CardTitle>
              <CardDescription>Buscá por período, proveedor, servicio, legajo, nombre o ticket.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex flex-wrap gap-2">
                <Input
                  className="max-w-sm"
                  placeholder="Legajo, nombre, ticket, servicio o proveedor…"
                  value={busca}
                  onChange={(e) => setBusca(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && setQ(busca)}
                />
                <Button variant="outline" onClick={() => setQ(busca)}>
                  <Search className="h-4 w-4" /> Buscar
                </Button>
                <Button variant="outline" onClick={() => exportar(histRows, "Automotores historial")}>
                  <Download className="h-4 w-4" /> Exportar
                </Button>
              </div>
              <div className="max-h-96 overflow-auto rounded-lg border">
                <table className="w-full text-sm">
                  <thead className="sticky top-0 bg-muted/50">
                    <tr>
                      <th className="p-2 text-left">Período</th>
                      <th className="p-2 text-left">Proveedor</th>
                      <th className="p-2 text-left">Fecha</th>
                      <th className="p-2 text-left">Legajo</th>
                      <th className="p-2 text-left">Afiliado</th>
                      <th className="p-2 text-left">Ticket</th>
                      <th className="p-2 text-left">Servicio</th>
                      <th className="p-2 text-right">Importe</th>
                      <th className="p-2 text-right">Cuotas</th>
                      <th className="p-2 text-right">Com. %</th>
                      <th className="p-2 text-right">Com. $</th>
                      <th className="p-2 text-right">Neto</th>
                    </tr>
                  </thead>
                  <tbody>
                    {histRows.map((r: any) => (
                      <tr key={r.id} className="border-t">
                        <td className="p-2">
                          {r.periodo_mes ? `${String(r.periodo_mes).padStart(2, "0")}/${r.periodo_anio}` : "—"}
                        </td>
                        <td className="p-2">{r.proveedor}</td>
                        <td className="p-2">{r.fecha ?? "—"}</td>
                        <td className="p-2 font-mono">{r.legajo}</td>
                        <td className="p-2">{r.apellido_nombre ?? "—"}</td>
                        <td className="p-2">{r.comprobante ?? "—"}</td>
                        <td className="p-2">{r.prestacion ?? "—"}</td>
                        <td className="p-2 text-right">{money(r.importe)}</td>
                        <td className="p-2 text-right">{r.cuotas}</td>
                        <td className="p-2 text-right">{pctFmt(r.comision_pct)}</td>
                        <td className="p-2 text-right">{money(r.comision_monto)}</td>
                        <td className="p-2 text-right">{money(r.neto_proveedor ?? r.importe)}</td>
                      </tr>
                    ))}
                    {!histRows.length && (
                      <tr>
                        <td className="p-3 text-center text-muted-foreground" colSpan={12}>
                          Sin movimientos.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <ProveedoresServicioCard codigo="1130202" titulo="Proveedores de Automotores" />
    </div>
  );
}
