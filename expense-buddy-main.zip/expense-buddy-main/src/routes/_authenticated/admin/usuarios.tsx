import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  listAppUsers,
  resetUserPassword,
  resetAllPasswords,
  setUserAuthorized,
  setUserRole,
  deleteAppUser,
  grantFullAccess,
} from "@/lib/admin-users.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { KeyRound, Trash2, ShieldCheck } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/usuarios")({
  component: Usuarios,
  head: () => ({
    meta: [
      { title: "Usuarios y accesos · AGOEC" },
      {
        name: "description",
        content: "Autorizá manualmente usuarios registrados, asigná roles y blanqueá claves.",
      },
      { property: "og:title", content: "Usuarios y accesos · AGOEC" },
      {
        property: "og:description",
        content: "Panel de administración de usuarios, roles y claves de acceso de AGOEC.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const ROLES = ["admin", "afiliado", "proveedor"] as const;

function Usuarios() {
  const list = useServerFn(listAppUsers);
  const resetOne = useServerFn(resetUserPassword);
  const resetAll = useServerFn(resetAllPasswords);
  const authorize = useServerFn(setUserAuthorized);
  const setRole = useServerFn(setUserRole);
  const remove = useServerFn(deleteAppUser);
  const grantAll = useServerFn(grantFullAccess);
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);
  const [globalPass, setGlobalPass] = useState("Agoec2026!");
  const [q, setQ] = useState("");
  const [fullEmail, setFullEmail] = useState("");
  const [fullPass, setFullPass] = useState("Agoec2026!");


  const { data, isLoading, error } = useQuery({
    queryKey: ["app-users"],
    queryFn: () => list({ data: undefined as any }),
  });

  function refresh() {
    qc.invalidateQueries({ queryKey: ["app-users"] });
  }

  async function run(fn: () => Promise<any>, msg: string) {
    setBusy(true);
    try {
      await fn();
      toast.success(msg);
      refresh();
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo completar");
    } finally {
      setBusy(false);
    }
  }

  const users = (data ?? []).filter((u: any) => {
    const t = q.trim().toLowerCase();
    if (!t) return true;
    return (
      u.email.toLowerCase().includes(t) ||
      String(u.legajo ?? "").toLowerCase().includes(t) ||
      String(u.proveedor ?? "").toLowerCase().includes(t)
    );
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Usuarios y accesos</h1>
        <p className="text-sm text-muted-foreground">
          Todos los que se registraron, con su clave temporal asignada, roles y autorización manual.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <ShieldCheck className="h-4 w-4" /> Dar acceso total a un email
          </CardTitle>
          <CardDescription>
            Le asigna los tres roles (admin, afiliado y proveedor), lo autoriza y fija su clave. Si
            el email no existe, se crea la cuenta.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap items-end gap-3">
          <div className="space-y-2">
            <Label htmlFor="fe">Email</Label>
            <Input
              id="fe"
              type="email"
              placeholder="persona@empresa.com"
              value={fullEmail}
              onChange={(e) => setFullEmail(e.target.value)}
              className="w-72"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="fp">Clave</Label>
            <Input
              id="fp"
              value={fullPass}
              onChange={(e) => setFullPass(e.target.value)}
              className="w-56"
            />
          </div>
          <Button
            disabled={busy || !fullEmail.includes("@") || fullPass.length < 6}
            onClick={() =>
              run(
                () => grantAll({ data: { email: fullEmail.trim(), password: fullPass } }),
                "Acceso total otorgado",
              )
            }
          >
            Dar acceso total
          </Button>
        </CardContent>
      </Card>

      <Card>

        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <KeyRound className="h-4 w-4" /> Blanquear todas las claves
          </CardTitle>
          <CardDescription>
            Asigna la misma clave temporal a todos los usuarios registrados. Por seguridad sólo se
            muestran las claves que asignás desde acá (las que eligen los usuarios quedan cifradas).
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap items-end gap-3">
          <div className="space-y-2">
            <Label htmlFor="gp">Clave temporal</Label>
            <Input
              id="gp"
              value={globalPass}
              onChange={(e) => setGlobalPass(e.target.value)}
              className="w-56"
            />
          </div>
          <Button
            variant="destructive"
            disabled={busy || globalPass.length < 6}
            onClick={() =>
              run(
                () => resetAll({ data: { password: globalPass } }),
                "Claves blanqueadas",
              )
            }
          >
            Blanquear todas
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-3">
          <CardTitle className="text-base">Usuarios registrados ({users.length})</CardTitle>
          <Input
            placeholder="Buscar por email, legajo o proveedor…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="max-w-xs"
          />
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-sm text-muted-foreground">Cargando…</p>
          ) : error ? (
            <p className="text-sm text-destructive">{(error as any)?.message}</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr className="border-b">
                    <th className="py-2 pr-3">Usuario</th>
                    <th className="py-2 pr-3">Clave temporal</th>
                    <th className="py-2 pr-3">Roles</th>
                    <th className="py-2 pr-3">Autorizado</th>
                    <th className="py-2 pr-3">Último ingreso</th>
                    <th className="py-2" />
                  </tr>
                </thead>
                <tbody>
                  {users.map((u: any) => (
                    <tr key={u.id} className="border-b last:border-0 align-top">
                      <td className="py-2 pr-3">
                        <span className="font-medium">{u.email}</span>
                        <span className="block text-xs text-muted-foreground">
                          {u.legajo ? `Legajo ${u.legajo}` : u.proveedor ?? "—"}
                        </span>
                      </td>
                      <td className="py-2 pr-3 font-mono text-xs">
                        {u.clave_temporal ?? <span className="text-muted-foreground">cifrada</span>}
                      </td>
                      <td className="py-2 pr-3">
                        <div className="flex flex-col gap-1">
                          {ROLES.map((r) => (
                            <label key={r} className="flex items-center gap-2 text-xs">
                              <Checkbox
                                checked={u.roles.includes(r)}
                                disabled={busy}
                                onCheckedChange={(v) =>
                                  run(
                                    () =>
                                      setRole({
                                        data: { user_id: u.id, role: r, enabled: !!v },
                                      }),
                                    "Roles actualizados",
                                  )
                                }
                              />
                              {r}
                            </label>
                          ))}
                        </div>
                      </td>
                      <td className="py-2 pr-3">
                        <Button
                          size="sm"
                          variant={u.autorizado ? "default" : "outline"}
                          disabled={busy}
                          onClick={() =>
                            run(
                              () =>
                                authorize({
                                  data: {
                                    user_id: u.id,
                                    email: u.email || null,
                                    autorizado: !u.autorizado,
                                  },
                                }),
                              u.autorizado ? "Acceso bloqueado" : "Usuario autorizado",
                            )
                          }
                        >
                          <ShieldCheck className="h-3.5 w-3.5 mr-1" />
                          {u.autorizado ? "Autorizado" : "Autorizar"}
                        </Button>
                      </td>
                      <td className="py-2 pr-3 text-xs text-muted-foreground">
                        {u.last_sign_in_at
                          ? new Date(u.last_sign_in_at).toLocaleString("es-AR")
                          : "—"}
                      </td>
                      <td className="py-2 text-right whitespace-nowrap">
                        <Button
                          size="sm"
                          variant="ghost"
                          disabled={busy}
                          onClick={() => {
                            const pass = window.prompt(
                              `Nueva clave para ${u.email}`,
                              "Agoec2026!",
                            );
                            if (!pass || pass.length < 6) return;
                            run(
                              () =>
                                resetOne({
                                  data: { user_id: u.id, email: u.email, password: pass },
                                }),
                              "Clave actualizada",
                            );
                          }}
                        >
                          <KeyRound className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          disabled={busy}
                          onClick={() => {
                            if (!window.confirm(`¿Eliminar el usuario ${u.email}?`)) return;
                            run(() => remove({ data: { user_id: u.id } }), "Usuario eliminado");
                          }}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="text-xs text-muted-foreground">
        <Badge variant="secondary" className="mr-2">
          Nota
        </Badge>
        Las claves elegidas por los usuarios se guardan cifradas y no pueden mostrarse. Si necesitás
        conocer una clave, blanqueala desde acá y queda visible en la tabla.
      </div>
    </div>
  );
}
