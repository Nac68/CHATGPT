import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  getServiceDetail,
  upsertServiceProduct,
  deleteServiceProduct,
} from "@/lib/service-products.functions";
import { getSubserviceStats } from "@/lib/subservices.functions";
import {
  farmaciaConsumosSearch,
  variosConsumosSearch,
} from "@/lib/crm-search.functions";
import { MESES } from "@/lib/periodo";
import { SubserviciosDetalle } from "@/components/SubserviciosDetalle";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  Trash2,
  Pencil,
  Settings2,
  Search,
  CircleDollarSign,
  Cake,
  HandCoins,
  UtensilsCrossed,
  LayoutGrid,
  
} from "lucide-react";

import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/servicio/$codigo")({
  beforeLoad: ({ params }) => {
    if (params.codigo === "adelantos") throw redirect({ to: "/admin/adelantos" });
    // Refinanciación tiene su módulo propio bajo Servicios.
    if (params.codigo === "1130103" || /^refinanc/i.test(params.codigo))
      throw redirect({ to: "/admin/refinanciacion" });
    // Automotores tiene su módulo especializado (comisión AGOEC por prestación y cuotas).
    if (params.codigo === "1130202" || /^automotor/i.test(params.codigo))
      throw redirect({ to: "/admin/automotores" });
  },
  component: ServicioDetalle,
  head: () => ({
    meta: [
      { title: "Detalle de servicio · AGOEC" },
      {
        name: "description",
        content: "Habilitá productos y proveedores dentro de cada servicio de AGOEC.",
      },
      { property: "og:title", content: "Detalle de servicio · AGOEC" },
      {
        property: "og:description",
        content: "Productos y proveedores habilitados por servicio en el CRM de AGOEC.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

type ProdForm = {
  id?: string;
  nombre: string;
  descripcion: string;
  tipo: "externo" | "interno" | "agoec" | "circulo" | "colecta" | "cumpleanos";
  activo: boolean;
};

const EMPTY: ProdForm = { nombre: "", descripcion: "", tipo: "agoec", activo: true };

const money = (n: number) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" }).format(Number(n) || 0);

const TIPO_LABEL: Record<string, string> = {
  externo: "Externo",
  interno: "Interno (afiliado)",
  agoec: "De AGOEC",
  circulo: "Círculo",
  colecta: "Colecta",
  cumpleanos: "Cumpleaños",
};

function ServicioDetalle() {
  const { codigo } = Route.useParams();
  const detail = useServerFn(getServiceDetail);
  const save = useServerFn(upsertServiceProduct);
  const del = useServerFn(deleteServiceProduct);
  const qc = useQueryClient();
  const statsFn = useServerFn(getSubserviceStats);
  const [form, setForm] = useState<ProdForm>(EMPTY);
  const [saving, setSaving] = useState(false);

  const { data, isLoading, error } = useQuery({
    queryKey: ["service-detail", codigo],
    queryFn: () => detail({ data: { codigo } }),
  });

  const norm = (s: string) =>
    (s ?? "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .trim();
  const esVarios =
    codigo === "varios" || norm((data as any)?.service?.nombre ?? "") === "servicios varios";
  const esFarmacia =
    codigo === "1130205" || norm((data as any)?.service?.nombre ?? "") === "farmacia";
  const esIndumentaria =
    codigo === "1130203" || norm((data as any)?.service?.nombre ?? "") === "indumentaria";
  const esSuper =
    codigo === "1130201" || norm((data as any)?.service?.nombre ?? "") === "supermercado";
  const conBuscador = esFarmacia || esIndumentaria || esSuper;
  const rubroLbl = esIndumentaria ? "Indumentaria" : esSuper ? "Supermercado" : "Farmacia";
  const provLbl = esIndumentaria
    ? "proveedores de indumentaria"
    : esSuper
      ? "supermercados"
      : "farmacias";

  const statsQ = useQuery({
    queryKey: ["subservice-stats"],
    queryFn: () => statsFn({}),
    enabled: esVarios,
  });

  const farmaciaFn = useServerFn(farmaciaConsumosSearch);
  const [termF, setTermF] = useState("");
  const [qF, setQF] = useState("");
  const farmaciaQ = useQuery({
    queryKey: ["farmacia-consumos", rubroLbl, qF],
    queryFn: () =>
      farmaciaFn({
        data: { q: qF, rubro: esIndumentaria ? "indumentaria" : esSuper ? "supermercado" : "farmacia" },
      }),
    enabled: conBuscador && qF.length > 0,
  });

  // Buscador de consumos de Servicios Varios del período vigente.
  const variosFn = useServerFn(variosConsumosSearch);
  const [termV, setTermV] = useState("");
  const [qV, setQV] = useState("");
  const variosQ = useQuery({
    queryKey: ["varios-consumos-vigente", qV],
    queryFn: () => variosFn({ data: { q: qV } }),
    enabled: esVarios && qV.length > 0,
  });
  const vig: any = (variosQ.data as any)?.vigente;
  const vigLbl = vig ? `${MESES[vig.mes - 1]} ${vig.anio}` : "período vigente";




  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!data?.service) return;
    setSaving(true);
    try {
      await save({
        data: {
          ...(form.id ? { id: form.id } : {}),
          service_id: (data.service as any).id,
          nombre: form.nombre,
          descripcion: form.descripcion || null,
          tipo: form.tipo,
          activo: form.activo,
        } as any,
      });
      toast.success(form.id ? "Producto actualizado" : "Producto habilitado");
      setForm(EMPTY);
      qc.invalidateQueries({ queryKey: ["service-detail", codigo] });
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo guardar");
    } finally {
      setSaving(false);
    }
  }

  async function remove(id: string) {
    try {
      await del({ data: { id } });
      qc.invalidateQueries({ queryKey: ["service-detail", codigo] });
      toast.success("Producto eliminado");
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo eliminar");
    }
  }

  if (isLoading) return <p className="text-sm text-muted-foreground">Cargando…</p>;
  if (error) return <p className="text-sm text-destructive">{(error as any)?.message}</p>;

  const svc: any = data?.service;
  const t: any = data?.totales ?? {};
  const stats: any = data?.comidaStats;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">{svc?.nombre}</h1>
          <p className="text-sm text-muted-foreground">
            {svc?.descripcion || "Productos habilitados y proveedores de este servicio."}
          </p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            <Badge variant={svc?.activo ? "default" : "secondary"}>
              {svc?.activo ? "Activo" : "Inactivo"}
            </Badge>
            <Badge variant="outline">Código: {svc?.codigo}</Badge>
            {svc?.usa_receta && (
              <Badge variant="outline">Subsidio receta {svc?.subsidio_receta_pct}%</Badge>
            )}
            {svc?.permite_cuotas && <Badge variant="outline">Permite cuotas</Badge>}
            {svc?.permite_cumpleanos && <Badge variant="outline">Cumpleaños sin cargo</Badge>}
          </div>
        </div>
        <div className="flex gap-2">
          <Button asChild variant="outline" size="sm">
            <Link to="/admin/servicios">
              <Settings2 className="h-4 w-4 mr-1" /> Configurar servicios
            </Link>
          </Button>
          <Button asChild variant="outline" size="sm">
            <Link to="/admin/proveedores">Alta de proveedores</Link>
          </Button>
        </div>
      </div>

      {esVarios && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Search className="h-4 w-4" /> Buscador de consumos del período vigente
            </CardTitle>
            <CardDescription>
              Buscá por número de legajo o por nombre y apellido. Solo se muestran los consumos de
              Servicios Varios (Comida a Dto., Círculos, Cumpleaños y Colectas) cargados en el
              período {vigLbl}.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setQV(termV.trim());
              }}
              className="flex gap-2"
            >
              <Input
                placeholder="Legajo o nombre del afiliado…"
                value={termV}
                onChange={(e) => setTermV(e.target.value)}
              />
              <Button type="submit">Buscar</Button>
            </form>

            {variosQ.isFetching && <p className="text-sm text-muted-foreground">Buscando…</p>}
            {!!qV && !variosQ.isFetching && !variosQ.data?.items?.length && (
              <p className="text-sm text-muted-foreground">
                Sin consumos de Servicios Varios en el período {vigLbl} para “{qV}”.
              </p>
            )}

            {!!(variosQ.data as any)?.totales && !!variosQ.data?.items?.length && (
              <div className="grid gap-2 sm:grid-cols-3 text-sm">
                {[
                  { l: "Consumos", v: (variosQ.data as any).totales.items },
                  { l: "Importe total", v: money((variosQ.data as any).totales.importe) },
                  { l: "A descontar", v: money((variosQ.data as any).totales.a_descontar) },
                ].map((k) => (
                  <div key={k.l} className="rounded-md bg-muted/50 px-3 py-2">
                    <p className="text-[11px] text-muted-foreground">{k.l}</p>
                    <p className="font-medium">{k.v}</p>
                  </div>
                ))}
              </div>
            )}

            {!!(variosQ.data as any)?.porSubservicio?.length && (
              <div className="rounded-lg border p-3">
                <p className="text-sm font-semibold mb-2">Por subservicio</p>
                {(variosQ.data as any).porSubservicio.map((s: any) => (
                  <div key={s.subservicio} className="flex justify-between text-sm py-1">
                    <span>
                      {s.subservicio} · {s.consumos} consumo(s)
                    </span>
                    <span className="font-medium">{money(s.a_descontar)}</span>
                  </div>
                ))}
              </div>
            )}

            {!!variosQ.data?.items?.length && (
              <div className="overflow-x-auto rounded-lg border">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/50 text-left text-xs text-muted-foreground">
                      <th className="px-3 py-2">Legajo</th>
                      <th className="px-3 py-2">Afiliado</th>
                      <th className="px-3 py-2">Subservicio</th>
                      <th className="px-3 py-2">Detalle</th>
                      <th className="px-3 py-2">Fecha</th>
                      <th className="px-3 py-2">Cuota</th>
                      <th className="px-3 py-2">Estado</th>
                      <th className="px-3 py-2 text-right">Importe</th>
                      <th className="px-3 py-2 text-right">A descontar</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(variosQ.data as any).items.map((it: any) => (
                      <tr key={it.id} className="border-b last:border-0">
                        <td className="px-3 py-2 font-medium">{it.legajo}</td>
                        <td className="px-3 py-2">{it.afiliado}</td>
                        <td className="px-3 py-2">{it.subservicio}</td>
                        <td className="px-3 py-2">{it.detalle}</td>
                        <td className="px-3 py-2">{it.fecha ?? "—"}</td>
                        <td className="px-3 py-2">{it.cuota ?? "—"}</td>
                        <td className="px-3 py-2 capitalize">{it.estado}</td>
                        <td className="px-3 py-2 text-right">{money(it.importe)}</td>
                        <td className="px-3 py-2 text-right font-medium">
                          {money(it.a_descontar)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {!esVarios && (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { l: "Productos habilitados", v: data?.products?.length ?? 0 },
            { l: "Proveedores", v: `${t.habilitados ?? 0} / ${t.proveedores ?? 0} habilitados` },
            { l: "Cargas recibidas", v: `${t.cargas ?? 0} (${t.pendientes ?? 0} pend.)` },
            { l: "Total consumido", v: money(t.importe ?? 0) },
          ].map((k) => (
            <Card key={k.l}>
              <CardContent className="pt-5">
                <p className="text-xs text-muted-foreground">{k.l}</p>
                <p className="text-lg font-semibold">{k.v}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {esVarios && (
        <section>
          <h2 className="text-lg font-semibold text-muted-foreground">
            Subservicios de Servicios Varios
          </h2>
          <div className="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                n: "Círculos",
                d: "Círculos con período, aportes mensuales y quién cobra el pozo.",
                to: "/admin/circulo",
                b: "Gestionar círculos",
                icon: CircleDollarSign,
              },
              {
                n: "Cumpleaños",
                d: "Planes de cumpleaños, aportes de afiliados y pago al agasajado.",
                to: "/admin/cumpleanos",
                b: "Gestionar cumpleaños",
                icon: Cake,
              },
              {
                n: "Colectas",
                d: "Colectas con beneficiario, cuotas y liquidación mensual.",
                to: "/admin/colecta",
                b: "Gestionar colectas",
                icon: HandCoins,
              },
              {
                n: "Comida a Dto.",
                d: "Formularios diarios, comensales y liquidación del período.",
                to: "/admin/comida-dto",
                b: "Gestionar comida a dto.",
                icon: UtensilsCrossed,
              },
              {
                n: "Adelantos",
                d: "Adelantos pedidos por los afiliados, en cuotas y por período.",
                to: "/admin/adelantos",
                b: "Gestionar adelantos",
                icon: HandCoins,
              },
              {
                n: "Más Servicios",
                d: "Carga administrativa de consumos varios por legajo.",
                to: "/admin/carga-servicio",
                b: "Gestionar más servicios",
                icon: LayoutGrid,
              },


            ].map((s) => (
              <Card key={s.n} className="flex flex-col border-t-4 border-t-primary">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <s.icon className="h-5 w-5 text-primary" />
                    <CardTitle>{s.n}</CardTitle>
                  </div>
                  <CardDescription>{s.d}</CardDescription>
                </CardHeader>
                <CardContent className="mt-auto">
                  <Button asChild className="w-full">
                    <Link to={s.to}>{s.b}</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}


      {esVarios && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Estadísticas generales por subservicio</CardTitle>
            <CardDescription>
              Resumen consolidado de Círculos, Cumpleaños, Colectas y Comida a Dto.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {statsQ.isLoading ? (
              <p className="text-sm text-muted-foreground">Cargando estadísticas…</p>
            ) : (
              (statsQ.data?.subservicios ?? []).map((s: any) => (
                <div key={s.key} className="rounded-lg border p-4">
                  <p className="font-semibold">{s.nombre}</p>
                  <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4 text-sm">
                    {s.kpis.map((k: any) => (
                      <div key={k.l} className="rounded-md bg-muted/50 px-3 py-2">
                        <p className="text-[11px] text-muted-foreground">{k.l}</p>
                        <p className="font-medium">{k.money ? money(k.v) : k.v}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      )}

      {/* En Farmacia no se habilitan productos: se gestionan las farmacias prestadoras. */}
      {!conBuscador && !esVarios && (
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            {form.id ? <Pencil className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
            {form.id
              ? esVarios
                ? "Editar subservicio"
                : "Editar producto"
              : esVarios
                ? "Habilitar subservicio nuevo"
                : "Habilitar producto"}
          </CardTitle>
          <CardDescription>
            Ej.: en Servicios Varios, el subservicio <strong>Comida a Dto.</strong> lo provee AGOEC.
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="pnombre">Producto</Label>
              <Input
                id="pnombre"
                required
                value={form.nombre}
                onChange={(e) => setForm({ ...form, nombre: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Tipo de producto</Label>
              <Select
                value={form.tipo}
                onValueChange={(v) => setForm({ ...form, tipo: v as ProdForm["tipo"] })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="externo">Externo (proveedor externo)</SelectItem>
                  <SelectItem value="interno">Interno (afiliado)</SelectItem>
                  <SelectItem value="agoec">De AGOEC</SelectItem>
                  <SelectItem value="circulo">Círculo (fondo rotativo)</SelectItem>
                  <SelectItem value="colecta">Colecta (solidaria)</SelectItem>
                  <SelectItem value="cumpleanos">Cumpleaños</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="pdesc">Descripción</Label>
              <Input
                id="pdesc"
                value={form.descripcion}
                onChange={(e) => setForm({ ...form, descripcion: e.target.value })}
              />
            </div>
            <label className="flex items-center gap-2 text-sm">
              <Checkbox
                checked={form.activo}
                onCheckedChange={(v) => setForm({ ...form, activo: !!v })}
              />
              Producto habilitado
            </label>
            <div className="flex gap-2 sm:justify-end">
              <Button type="submit" disabled={saving}>
                {saving ? "Guardando…" : form.id ? "Guardar" : "Habilitar"}
              </Button>
              {form.id && (
                <Button type="button" variant="outline" onClick={() => setForm(EMPTY)}>
                  Cancelar
                </Button>
              )}
            </div>
          </form>
        </CardContent>
      </Card>
      )}

      {esVarios && <SubserviciosDetalle serviceId={svc?.id} />}

      {conBuscador && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Search className="h-4 w-4" /> Buscador de consumos de {rubroLbl}
            </CardTitle>
            <CardDescription>
              Buscá por número de legajo o por nombre y apellido. Solo se muestran consumos
              cargados por los {provLbl} habilitados
              {esSuper ? " en el período vigente." : "."}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setQF(termF.trim());
              }}
              className="flex gap-2"
            >
              <Input
                placeholder="Legajo o nombre del afiliado…"
                value={termF}
                onChange={(e) => setTermF(e.target.value)}
              />
              <Button type="submit">Buscar</Button>
            </form>

            {farmaciaQ.isFetching && (
              <p className="text-sm text-muted-foreground">Buscando…</p>
            )}
            {!!qF && !farmaciaQ.isFetching && !farmaciaQ.data?.items?.length && (
              <p className="text-sm text-muted-foreground">
                Sin consumos de {provLbl} habilitados para “{qF}”.
              </p>
            )}

            {!!farmaciaQ.data?.totales && !!farmaciaQ.data.items.length && (
              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4 text-sm">
                {[
                  { l: "Consumos", v: farmaciaQ.data.totales.items },
                  { l: "Importe total", v: money(farmaciaQ.data.totales.importe) },
                  { l: "Subsidio AGOEC", v: money(farmaciaQ.data.totales.subsidio) },
                  { l: "A descontar", v: money(farmaciaQ.data.totales.a_descontar) },
                ].map((k) => (
                  <div key={k.l} className="rounded-md bg-muted/50 px-3 py-2">
                    <p className="text-[11px] text-muted-foreground">{k.l}</p>
                    <p className="font-medium">{k.v}</p>
                  </div>
                ))}
              </div>
            )}

            {!!farmaciaQ.data?.items?.length && (
              <div className="overflow-x-auto rounded-lg border">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/50 text-left text-xs text-muted-foreground">
                      <th className="px-3 py-2">Legajo</th>
                      <th className="px-3 py-2">Afiliado</th>
                      <th className="px-3 py-2">{esFarmacia ? "Farmacia" : "Proveedor"}</th>
                      <th className="px-3 py-2">Fecha</th>
                      <th className="px-3 py-2">Detalle</th>
                      <th className="px-3 py-2">Período</th>
                      <th className="px-3 py-2">Estado</th>
                      <th className="px-3 py-2 text-right">Importe</th>
                      <th className="px-3 py-2 text-right">Subsidio</th>
                      <th className="px-3 py-2 text-right">A descontar</th>
                    </tr>
                  </thead>
                  <tbody>
                    {farmaciaQ.data.items.map((it: any) => {
                      const aff = (farmaciaQ.data.affiliates ?? []).find(
                        (a: any) => a.legajo === it.legajo,
                      );
                      return (
                        <tr key={it.id} className="border-b last:border-0">
                          <td className="px-3 py-2 font-medium">{it.legajo}</td>
                          <td className="px-3 py-2">{aff?.apellido_nombre ?? "—"}</td>
                          <td className="px-3 py-2">{it.farmacia}</td>
                          <td className="px-3 py-2">{it.fecha ?? "—"}</td>
                          <td className="px-3 py-2">
                            {it.detalle ?? "—"}
                            {it.con_receta && (
                              <Badge variant="outline" className="ml-1">Receta</Badge>
                            )}
                          </td>
                          <td className="px-3 py-2">{it.periodo}</td>
                          <td className="px-3 py-2 capitalize">{it.estado}</td>
                          <td className="px-3 py-2 text-right">{money(it.importe)}</td>
                          <td className="px-3 py-2 text-right">{money(it.subsidio)}</td>
                          <td className="px-3 py-2 text-right font-medium">
                            {money(it.a_descontar)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {!conBuscador && !esVarios && (
      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            {esVarios ? "Productos configurados" : "Productos del servicio"}
          </CardTitle>
          <CardDescription>
            {esVarios
              ? `Productos dados de alta en la base para ${svc?.nombre}.`
              : `Toda la información de cada producto habilitado en ${svc?.nombre}.`}
          </CardDescription>

        </CardHeader>
        <CardContent className="space-y-3">
          {!data?.products?.length ? (
            <p className="text-sm text-muted-foreground">Todavía no hay productos habilitados.</p>
          ) : (
            data.products.map((p: any) => {
              const provs = (data.providers ?? []).filter(
                (x: any) => x.product_id === p.id || (!x.product_id && data.products.length === 1),
              );
              const esComida = p.codigo === "comida-dto";
              return (
                <div key={p.id} className="rounded-lg border p-4">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="font-semibold">{p.nombre}</p>
                      {p.descripcion && (
                        <p className="text-xs text-muted-foreground">{p.descripcion}</p>
                      )}
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        <Badge variant="outline">{TIPO_LABEL[p.tipo] ?? p.tipo}</Badge>
                        <Badge variant={p.activo ? "default" : "secondary"}>
                          {p.activo ? "Habilitado" : "Inactivo"}
                        </Badge>
                        <Badge variant="outline">{provs.length} proveedor(es)</Badge>
                        {p.codigo && <Badge variant="outline">{p.codigo}</Badge>}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 flex-wrap justify-end">
                      {esComida && (
                        <>
                          <Button asChild size="sm">
                            <Link to="/admin/comida-dto">Centro de liquidación</Link>
                          </Button>
                          <Button asChild size="sm" variant="secondary">
                            <Link to="/admin/dia">Nuevo día</Link>
                          </Button>
                          <Button asChild size="sm" variant="outline">
                            <Link to="/admin/dias">Formularios</Link>
                          </Button>
                          <Button asChild size="sm" variant="outline">
                            <Link to="/admin/liquidacion">Liquidación</Link>
                          </Button>
                          <Button asChild size="sm" variant="outline">
                            <Link to="/admin/liquidaciones">Liquidaciones</Link>
                          </Button>
                        </>
                      )}

                      {p.tipo === "circulo" && (
                        <Button asChild size="sm">
                          <Link
                            to="/admin/circulo"
                            search={{ product_id: p.id, service_id: svc?.id }}
                          >
                            Gestionar círculos
                          </Link>
                        </Button>
                      )}

                      {p.tipo === "colecta" && (
                        <Button asChild size="sm">
                          <Link
                            to="/admin/colecta"
                            search={{ product_id: p.id, service_id: svc?.id }}
                          >
                            Gestionar colectas
                          </Link>
                        </Button>
                      )}

                      {p.tipo === "cumpleanos" && (
                        <Button asChild size="sm">
                          <Link
                            to="/admin/cumpleanos"
                            search={{ product_id: p.id, service_id: svc?.id }}
                          >
                            Gestionar cumpleaños
                          </Link>
                        </Button>
                      )}



                      {p.tipo === "agoec" && !esComida && (
                        <Button asChild size="sm" variant="ghost">
                          <Link to="/admin/carga-servicio">Cargar AGOEC</Link>
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() =>
                          setForm({
                            id: p.id,
                            nombre: p.nombre,
                            descripcion: p.descripcion ?? "",
                            tipo: (p.tipo ?? "agoec") as ProdForm["tipo"],
                            activo: p.activo,
                          })
                        }
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => remove(p.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>

                  {esComida && stats && (
                    <div className="mt-3 grid gap-2 sm:grid-cols-3 lg:grid-cols-5 text-sm">
                      {[
                        { l: "Días cargados", v: stats.dias },
                        { l: "Último día", v: stats.ultimo_dia ?? "—" },
                        { l: "Total pagado", v: money(stats.total_gastado) },
                        { l: "Consumos", v: stats.consumos },
                        { l: "A descontar", v: money(stats.total_afiliados_importe) },
                      ].map((k) => (
                        <div key={k.l} className="rounded-md bg-muted/50 px-3 py-2">
                          <p className="text-[11px] text-muted-foreground">{k.l}</p>
                          <p className="font-medium">{k.v}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </CardContent>
      </Card>
      )}

      {!esVarios && (
      <Card>

        <CardHeader>
          <CardTitle className="text-base">
            {esFarmacia ? "Farmacias habilitadas" : "Proveedores del servicio"}
          </CardTitle>
          <CardDescription>
            Datos de contacto, cobro y liquidaciones de cada prestador. Los altas y accesos se
            gestionan en Proveedores.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {!data?.providers?.length ? (
            <p className="text-sm text-muted-foreground">Sin proveedores asignados.</p>
          ) : (
            data.providers.map((p: any) => (
              <div key={p.id} className="rounded-lg border p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="font-semibold">{p.nombre}</p>
                    <p className="text-xs text-muted-foreground">{p.email || "sin email"}</p>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      <Badge variant={p.habilitado ? "default" : "secondary"}>
                        {p.habilitado ? "Habilitado" : "Deshabilitado"}
                      </Badge>
                      <Badge variant="outline">{TIPO_LABEL[p.tipo] ?? p.tipo}</Badge>
                      <Badge variant="outline">{p.user_id ? "Con acceso" : "Sin acceso"}</Badge>
                      {p.cargas_pendientes > 0 && (
                        <Badge variant="destructive">{p.cargas_pendientes} pendiente(s)</Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex flex-wrap justify-end gap-1">
                    <Button asChild size="sm">
                      <Link
                        to="/admin/proveedor/$id/liquidaciones"
                        params={{ id: p.id }}
                      >
                        Liquidaciones
                      </Link>
                    </Button>
                    <Button asChild size="sm" variant="outline">
                      <Link to="/admin/cargas">Ver cargas</Link>
                    </Button>
                  </div>
                </div>


                <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4 text-sm">
                  {[
                    { l: "CUIT", v: p.cuit || "—" },
                    { l: "Titular", v: p.titular || "—" },
                    { l: "Banco", v: p.banco || "—" },
                    { l: "CBU / Alias", v: p.cbu || p.alias || "—" },
                    { l: "Cargas", v: p.cargas },
                    { l: "Afiliados", v: p.afiliados },
                    { l: "Total consumido", v: money(p.total_importe) },
                    { l: "Subsidio AGOEC", v: money(p.total_subsidio) },
                    { l: "A descontar afiliados", v: money(p.total_afiliado) },
                    {
                      l: "Última liquidación",
                      v: p.ultima_carga
                        ? `${p.ultima_carga.periodo} · ${p.ultima_carga.estado} · ${money(p.ultima_carga.total_a_pagar)}`
                        : "—",
                    },
                  ].map((k) => (
                    <div key={k.l} className="rounded-md bg-muted/50 px-3 py-2">
                      <p className="text-[11px] text-muted-foreground">{k.l}</p>
                      <p className="font-medium break-all">{k.v}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>
      )}
    </div>

  );
}

