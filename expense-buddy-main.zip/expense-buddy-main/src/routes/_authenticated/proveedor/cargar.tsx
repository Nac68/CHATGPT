import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  getMyProvider,
  parseProviderPhoto,
  previewLiquidation,
  submitLiquidation,
} from "@/lib/crm.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Camera, Loader2, Plus, Trash2, Upload } from "lucide-react";
import * as XLSX from "xlsx";
import { compareLegajo } from "@/lib/legajo";
import { useAffiliateNames } from "@/hooks/use-affiliate-names";


export const Route = createFileRoute("/_authenticated/proveedor/cargar")({
  component: CargarLiquidacion,
});

type Row = {
  uid: string;
  legajo: string;
  fecha: string;
  detalle: string;
  comprobante: string;
  importe: string;
  cuotas: string;
  con_receta: boolean;
  es_cumpleanos: boolean;
};

const MESES = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre",
];

const currency = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });
const uid = () => Math.random().toString(36).slice(2);
const emptyRow = (): Row => ({
  uid: uid(),
  legajo: "",
  fecha: "",
  detalle: "",
  comprobante: "",
  importe: "",
  cuotas: "1",
  con_receta: false,
  es_cumpleanos: false,
});

const pick = (obj: any, keys: string[]) => {
  const entries = Object.entries(obj).map(([k, v]) => [String(k).toLowerCase().trim(), v] as const);
  for (const key of keys) {
    const hit = entries.find(([k]) => k === key || k.includes(key));
    if (hit && hit[1] != null && String(hit[1]).trim() !== "") return String(hit[1]).trim();
  }
  return "";
};

const toDate = (v: string) => {
  if (!v) return "";
  if (/^\d{4}-\d{2}-\d{2}/.test(v)) return v.slice(0, 10);
  const m = v.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})/);
  if (m) {
    const y = m[3].length === 2 ? `20${m[3]}` : m[3];
    return `${y}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}`;
  }
  const n = Number(v);
  if (Number.isFinite(n) && n > 20000 && n < 60000) {
    const d = new Date(Math.round((n - 25569) * 86400 * 1000));
    return d.toISOString().slice(0, 10);
  }
  return "";
};

const toNumber = (v: string) => {
  if (!v) return 0;
  const s = v.replace(/[^\d,.-]/g, "");
  const norm =
    s.includes(",") && s.lastIndexOf(",") > s.lastIndexOf(".")
      ? s.replace(/\./g, "").replace(",", ".")
      : s.replace(/,/g, "");
  return Number(norm) || 0;
};

const truthy = (v: string) => /^(si|sí|s|yes|y|true|1|x)$/i.test(v.trim());

function CargarLiquidacion() {
  const navigate = useNavigate();
  const getProv = useServerFn(getMyProvider);
  const preview = useServerFn(previewLiquidation);
  const submitFn = useServerFn(submitLiquidation);
  const ocr = useServerFn(parseProviderPhoto);

  const now = new Date();
  const [mes, setMes] = useState(String(now.getMonth() + 1));
  const [anio, setAnio] = useState(String(now.getFullYear()));
  const [nombre, setNombre] = useState("");
  const [observacion, setObservacion] = useState("");
  const [rows, setRows] = useState<Row[]>([emptyRow()]);
  const [busy, setBusy] = useState<string | null>(null);
  const [prev, setPrev] = useState<any>(null);
  const excelRef = useRef<HTMLInputElement>(null);
  const photoRef = useRef<HTMLInputElement>(null);

  const { data: provider } = useQuery({
    queryKey: ["my-provider"],
    queryFn: () => getProv({ data: undefined as any }),
  });
  const svc = provider?.services;
  const usaReceta = !!svc?.usa_receta;
  const usaCumple = !!svc?.permite_cumpleanos;

  const nombresPadron = useAffiliateNames(rows.map((r) => r.legajo));


  const items = useMemo(
    () =>
      rows
        .filter((r) => r.legajo.trim())
        .map((r) => ({
          legajo: r.legajo.trim().toUpperCase(),
          fecha: r.fecha || null,
          detalle: r.detalle || null,
          comprobante: r.comprobante || null,
          importe: toNumber(r.importe),
          cuotas: Math.max(1, Number(r.cuotas) || 1),
          con_receta: r.con_receta,
          es_cumpleanos: r.es_cumpleanos,
        })),
    [rows],
  );

  const localTotals = useMemo(() => {
    const pct = usaReceta ? Number(svc?.subsidio_receta_pct ?? 0) : 0;
    let total = 0;
    let subsidio = 0;
    let descuento = 0;
    for (const i of items) {
      total += i.importe;
      const sr = i.con_receta && pct > 0 ? (i.importe * pct) / 100 : 0;
      const exento = usaCumple && i.es_cumpleanos;
      subsidio += exento ? i.importe : sr;
      descuento += exento ? 0 : i.importe - sr;
    }
    return {
      total,
      subsidio,
      descuento,
      afiliados: new Set(items.map((i) => i.legajo)).size,
      items: items.length,
    };
  }, [items, usaReceta, usaCumple, svc]);

  function setRow(uidKey: string, patch: Partial<Row>) {
    setRows((rs) => rs.map((r) => (r.uid === uidKey ? { ...r, ...patch } : r)));
  }

  function addRows(newRows: Omit<Row, "uid">[]) {
    setRows((rs) => {
      const kept = rs.filter((r) => r.legajo.trim());
      const merged = [...kept, ...newRows.map((r) => ({ ...r, uid: uid() }))];
      return merged
        .sort((a, b) => compareLegajo(a.legajo, b.legajo))
        .concat(merged.length ? [] : [emptyRow()]);
    });
  }

  async function onExcel(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy("excel");
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: "array" });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const json = XLSX.utils.sheet_to_json<any>(ws, { defval: "" });
      const parsed = json
        .map((r) => ({
          legajo: pick(r, ["legajo", "leg"]).toUpperCase(),
          fecha: toDate(pick(r, ["fecha", "dia", "día"])),
          detalle: pick(r, ["detalle", "descripcion", "descripción", "producto", "concepto"]),
          comprobante: pick(r, ["comprobante", "compr", "factura", "ticket", "nro"]),
          importe: pick(r, ["importe", "total", "monto", "precio"]),
          cuotas: pick(r, ["cuotas", "cuota"]) || "1",
          con_receta: truthy(pick(r, ["receta", "con receta"])),
          es_cumpleanos: truthy(pick(r, ["cumple", "cumpleaños", "cumpleanos"])),
        }))
        .filter((r) => r.legajo);
      if (!parsed.length) {
        toast.error("No se detectaron filas con legajo en el Excel");
      } else {
        addRows(parsed);
        toast.success(`${parsed.length} filas importadas del Excel`);
      }
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo leer el Excel");
    } finally {
      setBusy(null);
      if (excelRef.current) excelRef.current.value = "";
    }
  }

  async function onPhoto(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy("foto");
    try {
      const base64 = await new Promise<string>((res, rej) => {
        const fr = new FileReader();
        fr.onload = () => res(String(fr.result));
        fr.onerror = rej;
        fr.readAsDataURL(file);
      });
      const out = await ocr({ data: { base64 } });
      if (!out.items.length) {
        toast.error("La IA no detectó filas en la foto");
      } else {
        addRows(
          out.items.map((i: any) => ({
            legajo: i.legajo,
            fecha: i.fecha ?? "",
            detalle: i.detalle ?? "",
            comprobante: i.comprobante ?? "",
            importe: String(i.importe ?? ""),
            cuotas: String(i.cuotas ?? 1),
            con_receta: i.con_receta,
            es_cumpleanos: i.es_cumpleanos,
          })),
        );
        toast.success(`${out.items.length} filas leídas de la foto (podés editar y agregar más)`);
      }
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo leer la foto");
    } finally {
      setBusy(null);
      if (photoRef.current) photoRef.current.value = "";
    }
  }

  async function validar() {
    if (!items.length) return toast.error("Cargá al menos una fila");
    setBusy("preview");
    try {
      const out = await preview({ data: { items } });
      setPrev(out);
      const invalidos = out.rows.filter((r: any) => !r.valido).length;
      if (invalidos) toast.warning(`${invalidos} legajos no están en el padrón de afiliados`);
      else toast.success("Todos los legajos existen en el padrón");
    } catch (e: any) {
      toast.error(e?.message ?? "Error al validar");
    } finally {
      setBusy(null);
    }
  }

  async function enviar() {
    if (!items.length) return toast.error("Cargá al menos una fila");
    if (nombre.trim().length < 2) return toast.error("Ponele un nombre a la liquidación");
    setBusy("submit");
    try {
      await submitFn({
        data: {
          nombre: nombre.trim(),
          periodo_mes: Number(mes),
          periodo_anio: Number(anio),
          observacion: observacion || null,
          items,
        },
      });
      toast.success("Liquidación enviada a la administración");
      navigate({ to: "/proveedor" });
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo enviar");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Nueva liquidación mensual</CardTitle>
          <CardDescription>
            Servicio: {svc?.nombre ?? "—"}
            {usaReceta
              ? ` · Los productos con receta reciben ${Number(svc?.subsidio_receta_pct ?? 0)}% de subsidio.`
              : ""}
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-4">
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="nombre">Nombre de la liquidación</Label>
            <Input
              id="nombre"
              placeholder="Ej: Consumos julio 2026"
              value={nombre}
              onChange={(e) => setNombre(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label>Mes</Label>
            <Select value={mes} onValueChange={setMes}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {MESES.map((m, i) => (
                  <SelectItem key={m} value={String(i + 1)}>
                    {m}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="anio">Año</Label>
            <Input id="anio" value={anio} onChange={(e) => setAnio(e.target.value)} />
          </div>
          <div className="space-y-2 sm:col-span-4">
            <Label htmlFor="obs">Observaciones para tesorería</Label>
            <Textarea
              id="obs"
              rows={2}
              value={observacion}
              onChange={(e) => setObservacion(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-3">
          <CardTitle className="text-base">Consumos</CardTitle>
          <div className="flex flex-wrap gap-2">
            <input
              ref={excelRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              className="hidden"
              onChange={onExcel}
            />
            <input
              ref={photoRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={onPhoto}
            />
            <Button variant="outline" size="sm" onClick={() => excelRef.current?.click()} disabled={!!busy}>
              {busy === "excel" ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Upload className="h-4 w-4" />
              )}
              Importar Excel
            </Button>
            <Button variant="outline" size="sm" onClick={() => photoRef.current?.click()} disabled={!!busy}>
              {busy === "foto" ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Camera className="h-4 w-4" />
              )}
              Leer foto con IA
            </Button>
            <Button size="sm" variant="secondary" onClick={() => setRows((r) => [...r, emptyRow()])}>
              <Plus className="h-4 w-4" /> Agregar fila
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground">
                <tr className="border-b">
                  <th className="py-2 pr-2">Fecha</th>
                  <th className="py-2 pr-2">Legajo</th>
                  <th className="py-2 pr-2">Afiliado</th>
                  <th className="py-2 pr-2">Detalle</th>

                  <th className="py-2 pr-2">Comprobante</th>
                  <th className="py-2 pr-2">Importe</th>
                  <th className="py-2 pr-2">Cuotas</th>
                  {usaReceta && <th className="py-2 pr-2">Receta</th>}
                  {usaCumple && <th className="py-2 pr-2">Cumple</th>}
                  <th className="py-2" />
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.uid} className="border-b last:border-0">
                    <td className="py-1 pr-2">
                      <Input
                        type="date"
                        className="h-8 w-36"
                        value={r.fecha}
                        onChange={(e) => setRow(r.uid, { fecha: e.target.value })}
                      />
                    </td>
                    <td className="py-1 pr-2">
                      <Input
                        className="h-8 w-24 font-mono"
                        value={r.legajo}
                        onChange={(e) => setRow(r.uid, { legajo: e.target.value.toUpperCase() })}
                      />
                    </td>
                    <td className="py-1 pr-2 min-w-48 text-xs">
                      {!r.legajo.trim() ? (
                        <span className="text-muted-foreground">—</span>
                      ) : nombresPadron[r.legajo.trim().toUpperCase()] === undefined ? (
                        <span className="text-muted-foreground">buscando…</span>
                      ) : nombresPadron[r.legajo.trim().toUpperCase()] ? (
                        <span className="font-medium">
                          {nombresPadron[r.legajo.trim().toUpperCase()]}
                        </span>
                      ) : (
                        <span className="text-destructive">no está en el padrón</span>
                      )}
                    </td>

                    <td className="py-1 pr-2">
                      <Input
                        className="h-8 min-w-48"
                        value={r.detalle}
                        onChange={(e) => setRow(r.uid, { detalle: e.target.value })}
                      />
                    </td>
                    <td className="py-1 pr-2">
                      <Input
                        className="h-8 w-28"
                        value={r.comprobante}
                        onChange={(e) => setRow(r.uid, { comprobante: e.target.value })}
                      />
                    </td>
                    <td className="py-1 pr-2">
                      <Input
                        className="h-8 w-28"
                        inputMode="decimal"
                        value={r.importe}
                        onChange={(e) => setRow(r.uid, { importe: e.target.value })}
                      />
                    </td>
                    <td className="py-1 pr-2">
                      <Input
                        className="h-8 w-16"
                        inputMode="numeric"
                        value={r.cuotas}
                        onChange={(e) => setRow(r.uid, { cuotas: e.target.value })}
                      />
                    </td>
                    {usaReceta && (
                      <td className="py-1 pr-2">
                        <Checkbox
                          checked={r.con_receta}
                          onCheckedChange={(v) => setRow(r.uid, { con_receta: !!v })}
                        />
                      </td>
                    )}
                    {usaCumple && (
                      <td className="py-1 pr-2">
                        <Checkbox
                          checked={r.es_cumpleanos}
                          onCheckedChange={(v) => setRow(r.uid, { es_cumpleanos: !!v })}
                        />
                      </td>
                    )}
                    <td className="py-1 text-right">
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => setRows((rs) => rs.filter((x) => x.uid !== r.uid))}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 sm:grid-cols-4">
        {[
          { t: "Ítems", v: String(localTotals.items) },
          { t: "Afiliados", v: String(localTotals.afiliados) },
          { t: "Total a pagar por AGOEC", v: currency.format(localTotals.total) },
          { t: "Subsidios / exenciones", v: currency.format(localTotals.subsidio) },
        ].map((c) => (
          <Card key={c.t}>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-muted-foreground">{c.t}</CardTitle>
            </CardHeader>
            <CardContent className="text-xl font-bold">{c.v}</CardContent>
          </Card>
        ))}
      </div>

      <div className="flex flex-wrap gap-2">
        <Button variant="outline" onClick={validar} disabled={!!busy}>
          {busy === "preview" && <Loader2 className="h-4 w-4 animate-spin" />} Validar legajos
        </Button>
        <Button onClick={enviar} disabled={!!busy}>
          {busy === "submit" && <Loader2 className="h-4 w-4 animate-spin" />} Enviar liquidación
        </Button>
      </div>

      {prev && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Vista previa validada</CardTitle>
            <CardDescription>
              Descuento total a afiliados: {currency.format(prev.total_descuento)} · Total a pagar al
              proveedor: {currency.format(prev.total_a_pagar)}
            </CardDescription>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground">
                <tr className="border-b">
                  <th className="py-2 pr-3">Legajo</th>
                  <th className="py-2 pr-3">Afiliado</th>
                  <th className="py-2 pr-3">Importe</th>
                  <th className="py-2 pr-3">Subsidio</th>
                  <th className="py-2 pr-3">Dto. afiliado</th>
                </tr>
              </thead>
              <tbody>
                {prev.rows.map((r: any, idx: number) => (
                  <tr
                    key={idx}
                    className={`border-b last:border-0 ${r.valido ? "" : "bg-destructive/10"}`}
                  >
                    <td className="py-1.5 pr-3 font-mono">{r.legajo}</td>
                    <td className="py-1.5 pr-3">
                      {r.apellido_nombre ?? <span className="text-destructive">No está en el padrón</span>}
                    </td>
                    <td className="py-1.5 pr-3">{currency.format(r.importe)}</td>
                    <td className="py-1.5 pr-3">{currency.format(r.subsidio)}</td>
                    <td className="py-1.5 pr-3">{currency.format(r.importe_afiliado)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
