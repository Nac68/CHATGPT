import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getMyProvider, updateMyBankDetails } from "@/lib/crm.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/proveedor/datos")({
  component: DatosCobro,
});

function DatosCobro() {
  const get = useServerFn(getMyProvider);
  const save = useServerFn(updateMyBankDetails);
  const { data } = useQuery({ queryKey: ["my-provider"], queryFn: () => get({ data: undefined as any }) });

  const [form, setForm] = useState({ banco: "", cbu: "", alias: "", titular: "", cuit: "" });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (data)
      setForm({
        banco: data.banco ?? "",
        cbu: data.cbu ?? "",
        alias: data.alias ?? "",
        titular: data.titular ?? "",
        cuit: data.cuit ?? "",
      });
  }, [data]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      await save({
        data: {
          banco: form.banco || null,
          cbu: form.cbu || null,
          alias: form.alias || null,
          titular: form.titular || null,
          cuit: form.cuit || null,
        },
      });
      toast.success("Datos de cobro actualizados");
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo guardar");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card className="max-w-2xl">
      <CardHeader>
        <CardTitle>Datos de cobro</CardTitle>
        <CardDescription>
          Dónde AGOEC deposita los pagos de tus liquidaciones. Los cambios quedan visibles para
          tesorería.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="titular">Titular de la cuenta</Label>
            <Input
              id="titular"
              value={form.titular}
              onChange={(e) => setForm({ ...form, titular: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="cuit">CUIT</Label>
            <Input id="cuit" value={form.cuit} onChange={(e) => setForm({ ...form, cuit: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="banco">Banco</Label>
            <Input
              id="banco"
              value={form.banco}
              onChange={(e) => setForm({ ...form, banco: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="cbu">CBU / CVU</Label>
            <Input id="cbu" value={form.cbu} onChange={(e) => setForm({ ...form, cbu: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="alias">Alias</Label>
            <Input
              id="alias"
              value={form.alias}
              onChange={(e) => setForm({ ...form, alias: e.target.value })}
            />
          </div>
          <div className="sm:col-span-2">
            <Button type="submit" disabled={saving}>
              {saving ? "Guardando…" : "Guardar datos"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
