import { createFileRoute, Outlet, Link, useLocation } from "@tanstack/react-router";
import { BackButton } from "@/components/BackButton";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getMyProvider } from "@/lib/crm.functions";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Store, LogOut } from "lucide-react";

export const Route = createFileRoute("/_authenticated/proveedor")({
  component: ProveedorLayout,
});

function ProveedorLayout() {
  const { pathname } = useLocation();
  const getProv = useServerFn(getMyProvider);
  const { data: prov } = useQuery({
    queryKey: ["my-provider"],
    queryFn: () => getProv({ data: undefined as any }),
  });

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/proveedor" className="flex items-center gap-2 font-semibold">
            <Store className="h-5 w-5 text-primary" />
            <span className="leading-tight">
              {(prov as any)?.nombre ?? "Panel Proveedor"}
              <span className="block text-xs font-normal text-muted-foreground">
                {(prov as any)?.services?.nombre
                  ? `${(prov as any).services.nombre} · AGOEC`
                  : "AGOEC"}
              </span>
            </span>
          </Link>
          <nav className="flex items-center gap-1 flex-wrap">
            <Button asChild variant="ghost" size="sm">
              <Link to="/proveedor" activeOptions={{ exact: true }}>
                Mis liquidaciones
              </Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link to="/proveedor/cargar">Nueva liquidación</Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link to="/proveedor/datos">Datos de cobro</Link>
            </Button>
            <Button asChild variant="ghost" size="sm">
              <Link to="/proveedor/mensajes">Mensajes</Link>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={async () => {
                await supabase.auth.signOut();
                window.location.href = "/";
              }}
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </nav>
        </div>
      </header>
      <main className="max-w-6xl mx-auto px-4 py-6">
        {pathname !== "/proveedor" && (
          <div className="mb-4">
            <BackButton fallback="/proveedor" />
          </div>
        )}
        <Outlet />
      </main>
    </div>
  );
}
