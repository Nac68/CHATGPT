import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listMySubmissions, getSubmission } from "@/lib/crm.functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, FileSpreadsheet, Loader2, Plus } from "lucide-react";
import * as XLSX from "xlsx";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/proveedor/")({
  component: MisLiquidaciones,
});

const MESES = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre",
];

const currency = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });

const ESTADO_CLASS: Record<string, string> = {
  enviada: "bg-secondary text-secondary-foreground",
  revisada: "bg-secondary text-secondary-foreground",
  aprobada: "bg-primary/15 text-primary",
  pagada: "bg-primary text-primary-foreground",
  rechazada: "bg-destructive/15 text-destructive",
};

function MisLiquidaciones() {
  const fn = useServerFn(listMySubmissions);
  const detail = useServerFn(getSubmission);
  const [openId, setOpenId] = useState<string | null>(null);

  const { data, isLoading, error } = useQuery({
    queryKey: ["my-submissions"],
    queryFn: () => fn({ data: undefined as any }),
  });

  const { data: det, isFetching: loadingDet } = useQuery({
    queryKey: ["submission", openId],
    queryFn: () => detail({ data: { id: openId! } }),
    enabled: !!openId,
  });

  const resumen = useMemo(() => {
    const subs = data?.submissions ?? [];
    return {
      cantidad: subs.length,
      total: subs.reduce((a: number, b: any) => a + Number(b.total_a_pagar ?? 0), 0),
      pagado: subs
        .filter((s: any) => s.estado === "pagada")
        .reduce((a: number, b: any) => a + Number(b.total_a_pagar ?? 0), 0),
      pendiente: subs
        .filter((s: any) => s.estado !== "pagada")
        .reduce((a: number, b: any) => a + Number(b.total_a_pagar ?? 0), 0),
    };
  }, [data]);

  async function exportar(id: string, nombre: string) {
    try {
      const d = await detail({ data: { id } });
      const rows = d.items.map((i: any) => ({
        Fecha: i.fecha ?? "",
        Legajo: i.legajo,
        "Apellido y Nombre": i.apellido_nombre ?? "",
        Detalle: i.detalle ?? "",
        Comprobante: i.comprobante ?? "",
        Importe: Number(i.importe),
        Cuotas: i.cuotas,
        "Con receta": i.con_receta ? "SI" : "",
        Cumpleaños: i.es_cumpleanos ? "SI" : "",
        Subsidio: Number(i.subsidio),
        "Descuento al afiliado": Number(i.importe_afiliado),
      }));
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), "Liquidación");
      XLSX.writeFile(wb, `${nombre.replace(/[^\w\s-]/g, "")}.xlsx`);
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo exportar");
    }
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Acceso de proveedor</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-muted-foreground">
          <p>{(error as any)?.message ?? "No se pudo cargar tu panel."}</p>
          <Button asChild variant="outline">
            <Link to="/">Volver al inicio</Link>
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">{data?.provider?.nombre ?? "Proveedor"}</h1>
          <p className="text-sm text-muted-foreground">
            Servicio: {data?.provider?.services?.nombre ?? "—"} ·{" "}
            {data?.provider?.interno ? "Proveedor interno de AGOEC" : "Proveedor externo"}
          </p>
        </div>
        <Button asChild>
          <Link to="/proveedor/cargar">
            <Plus className="h-4 w-4" /> Nueva liquidación
          </Link>
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-4">
        {[
          { t: "Liquidaciones", v: String(resumen.cantidad) },
          { t: "Total presentado", v: currency.format(resumen.total) },
          { t: "Cobrado", v: currency.format(resumen.pagado) },
          { t: "Pendiente de pago", v: currency.format(resumen.pendiente) },
        ].map((c) => (
          <Card key={c.t}>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-muted-foreground">{c.t}</CardTitle>
            </CardHeader>
            <CardContent className="text-xl font-bold">{c.v}</CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <FileSpreadsheet className="h-4 w-4 text-primary" /> Histórico de liquidaciones
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-sm text-muted-foreground">Cargando…</p>
          ) : !data?.submissions.length ? (
            <p className="text-sm text-muted-foreground">Todavía no cargaste liquidaciones.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr className="border-b">
                    <th className="py-2 pr-3">Período</th>
                    <th className="py-2 pr-3">Nombre</th>
                    <th className="py-2 pr-3">Ítems</th>
                    <th className="py-2 pr-3">Afiliados</th>
                    <th className="py-2 pr-3">Total a pagar</th>
                    <th className="py-2 pr-3">Subsidios</th>
                    <th className="py-2 pr-3">Estado</th>
                    <th className="py-2" />
                  </tr>
                </thead>
                <tbody>
                  {data.submissions.map((s: any) => (
                    <tr key={s.id} className="border-b last:border-0">
                      <td className="py-2 pr-3">
                        {MESES[s.periodo_mes - 1]} {s.periodo_anio}
                      </td>
                      <td className="py-2 pr-3">{s.nombre}</td>
                      <td className="py-2 pr-3">{s.total_items}</td>
                      <td className="py-2 pr-3">{s.total_afiliados}</td>
                      <td className="py-2 pr-3 font-medium">
                        {currency.format(Number(s.total_a_pagar))}
                      </td>
                      <td className="py-2 pr-3">{currency.format(Number(s.total_subsidio))}</td>
                      <td className="py-2 pr-3">
                        <span
                          className={`rounded px-2 py-0.5 text-xs capitalize ${ESTADO_CLASS[s.estado] ?? "bg-muted"}`}
                        >
                          {s.estado}
                        </span>
                      </td>
                      <td className="py-2 text-right whitespace-nowrap">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setOpenId(openId === s.id ? null : s.id)}
                        >
                          {openId === s.id ? "Ocultar" : "Ver detalle"}
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => exportar(s.id, s.nombre)}>
                          <Download className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {openId && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Detalle de la liquidación</CardTitle>
          </CardHeader>
          <CardContent>
            {loadingDet ? (
              <p className="text-sm text-muted-foreground flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin" /> Cargando…
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="text-left text-muted-foreground">
                    <tr className="border-b">
                      <th className="py-2 pr-3">Fecha</th>
                      <th className="py-2 pr-3">Legajo</th>
                      <th className="py-2 pr-3">Afiliado</th>
                      <th className="py-2 pr-3">Detalle</th>
                      <th className="py-2 pr-3">Comprob.</th>
                      <th className="py-2 pr-3">Importe</th>
                      <th className="py-2 pr-3">Cuotas</th>
                      <th className="py-2 pr-3">Subsidio</th>
                      <th className="py-2 pr-3">Dto. afiliado</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(det?.items ?? []).map((i: any) => (
                      <tr key={i.id} className="border-b last:border-0">
                        <td className="py-1.5 pr-3">{i.fecha ?? "—"}</td>
                        <td className="py-1.5 pr-3 font-mono">{i.legajo}</td>
                        <td className="py-1.5 pr-3">{i.apellido_nombre ?? "—"}</td>
                        <td className="py-1.5 pr-3">{i.detalle ?? "—"}</td>
                        <td className="py-1.5 pr-3">{i.comprobante ?? "—"}</td>
                        <td className="py-1.5 pr-3">{currency.format(Number(i.importe))}</td>
                        <td className="py-1.5 pr-3">{i.cuotas}</td>
                        <td className="py-1.5 pr-3">{currency.format(Number(i.subsidio))}</td>
                        <td className="py-1.5 pr-3">
                          {currency.format(Number(i.importe_afiliado))}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
