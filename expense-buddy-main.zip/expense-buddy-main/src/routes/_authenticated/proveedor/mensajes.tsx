import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listMyMessages, sendProviderMessage } from "@/lib/crm.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/proveedor/mensajes")({
  component: Mensajes,
});

function Mensajes() {
  const list = useServerFn(listMyMessages);
  const send = useServerFn(sendProviderMessage);
  const qc = useQueryClient();
  const [asunto, setAsunto] = useState("");
  const [mensaje, setMensaje] = useState("");
  const [sending, setSending] = useState(false);

  const { data } = useQuery({
    queryKey: ["my-messages"],
    queryFn: () => list({ data: undefined as any }),
  });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (mensaje.trim().length < 2) return toast.error("Escribí tu consulta");
    setSending(true);
    try {
      await send({ data: { asunto: asunto || null, mensaje } });
      setAsunto("");
      setMensaje("");
      toast.success("Consulta enviada a la administración");
      qc.invalidateQueries({ queryKey: ["my-messages"] });
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo enviar");
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Nueva consulta</CardTitle>
          <CardDescription>La administración de AGOEC te responde por este mismo canal.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="asunto">Asunto</Label>
              <Input id="asunto" value={asunto} onChange={(e) => setAsunto(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="mensaje">Mensaje</Label>
              <Textarea
                id="mensaje"
                rows={6}
                value={mensaje}
                onChange={(e) => setMensaje(e.target.value)}
              />
            </div>
            <Button type="submit" disabled={sending}>
              {sending ? "Enviando…" : "Enviar consulta"}
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Conversación</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {!data?.length ? (
            <p className="text-sm text-muted-foreground">Todavía no hay mensajes.</p>
          ) : (
            data.map((m: any) => (
              <div
                key={m.id}
                className={`rounded-lg border p-3 text-sm ${
                  m.desde_admin ? "bg-secondary" : "bg-card"
                }`}
              >
                <p className="text-xs text-muted-foreground">
                  {m.desde_admin ? "Administración AGOEC" : "Vos"} ·{" "}
                  {new Date(m.created_at).toLocaleString("es-AR")}
                </p>
                {m.asunto && <p className="font-medium mt-1">{m.asunto}</p>}
                <p className="whitespace-pre-wrap mt-1">{m.mensaje}</p>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}
