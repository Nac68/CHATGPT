import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getMyServiceConsumptions } from "@/lib/crm.functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAffiliateNames } from "@/hooks/use-affiliate-names";
import { ForcePinChangeGate } from "@/components/ForcePinChangeGate";
import { BackButton } from "@/components/BackButton";


export const Route = createFileRoute("/_authenticated/mis-servicios")({
  ssr: false,
  component: MisServicios,
  head: () => ({
    meta: [
      { title: "Mis consumos por servicio · AGOEC" },
      { name: "description", content: "Consultá tus consumos en farmacia, supermercado y demás servicios de AGOEC, con subsidios aplicados." },
      { property: "og:title", content: "Mis consumos por servicio · AGOEC" },
      { property: "og:description", content: "Historial de consumos por servicio y período con el importe a descontar." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

const currency = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });

function MisServicios() {
  const fn = useServerFn(getMyServiceConsumptions);
  const { data, isLoading } = useQuery({
    queryKey: ["my-service-consumptions"],
    queryFn: () => fn({ data: undefined as any }),
  });
  const nombres = useAffiliateNames(data?.legajo ? [String(data.legajo)] : []);


  const items = data?.items ?? [];

  const porPeriodo = useMemo(() => {
    const map = new Map<string, { periodo: string; items: number; total: number }>();
    for (const i of items as any[]) {
      const cur = map.get(i.periodo) ?? { periodo: i.periodo, items: 0, total: 0 };
      cur.items += 1;
      cur.total += Number(i.importe_afiliado ?? 0);
      map.set(i.periodo, cur);
    }
    return Array.from(map.values()).sort((a, b) => b.periodo.localeCompare(a.periodo));
  }, [items]);

  const totalAnual = porPeriodo.reduce((a, b) => a + b.total, 0);

  return (
    <ForcePinChangeGate>
    <div className="mx-auto max-w-5xl space-y-6 px-4 py-6">
      <BackButton fallback="/mis-consumos" />
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">
            {nombres[String(data?.legajo ?? "").toUpperCase()] ?? "Mis consumos por servicio"}
          </h1>
          <p className="text-sm text-muted-foreground">
            Legajo {data?.legajo ?? "—"} · farmacia, supermercado, indumentaria y demás servicios.
          </p>

        </div>
        <Button asChild variant="outline">
          <Link to="/mis-consumos">Ver comida a descuento</Link>
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        {[
          { t: "Consumos registrados", v: String(items.length) },
          { t: "Períodos", v: String(porPeriodo.length) },
          { t: "Total a descontar", v: currency.format(totalAnual) },
        ].map((c) => (
          <Card key={c.t}>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-muted-foreground">{c.t}</CardTitle>
            </CardHeader>
            <CardContent className="text-xl font-bold">{c.v}</CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Resumen por período</CardTitle>
        </CardHeader>
        <CardContent>
          {!porPeriodo.length ? (
            <p className="text-sm text-muted-foreground">Todavía no hay consumos cargados por proveedores.</p>
          ) : (
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground">
                <tr className="border-b">
                  <th className="py-2 pr-3">Período</th>
                  <th className="py-2 pr-3">Consumos</th>
                  <th className="py-2 pr-3">A descontar</th>
                </tr>
              </thead>
              <tbody>
                {porPeriodo.map((p) => (
                  <tr key={p.periodo} className="border-b last:border-0">
                    <td className="py-2 pr-3">{p.periodo}</td>
                    <td className="py-2 pr-3">{p.items}</td>
                    <td className="py-2 pr-3 font-medium">{currency.format(p.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Detalle de consumos</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-sm text-muted-foreground">Cargando…</p>
          ) : !items.length ? (
            <p className="text-sm text-muted-foreground">Sin movimientos.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr className="border-b">
                    <th className="py-2 pr-3">Período</th>
                    <th className="py-2 pr-3">Servicio</th>
                    <th className="py-2 pr-3">Fecha</th>
                    <th className="py-2 pr-3">Detalle</th>
                    <th className="py-2 pr-3">Comprob.</th>
                    <th className="py-2 pr-3">Importe</th>
                    <th className="py-2 pr-3">Cuotas</th>
                    <th className="py-2 pr-3">Subsidio</th>
                    <th className="py-2 pr-3">A descontar</th>
                  </tr>
                </thead>
                <tbody>
                  {(items as any[]).map((i) => (
                    <tr key={i.id} className="border-b last:border-0">
                      <td className="py-1.5 pr-3">{i.periodo}</td>
                      <td className="py-1.5 pr-3">{i.servicio}</td>
                      <td className="py-1.5 pr-3">{i.fecha ?? "—"}</td>
                      <td className="py-1.5 pr-3">{i.detalle ?? "—"}</td>
                      <td className="py-1.5 pr-3">{i.comprobante ?? "—"}</td>
                      <td className="py-1.5 pr-3">{currency.format(Number(i.importe ?? 0))}</td>
                      <td className="py-1.5 pr-3">{i.cuotas}</td>
                      <td className="py-1.5 pr-3">{currency.format(Number(i.subsidio ?? 0))}</td>
                      <td className="py-1.5 pr-3 font-medium">
                        {currency.format(Number(i.importe_afiliado ?? 0))}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
    </ForcePinChangeGate>
  );
}
