import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

// Endpoint de rescate: permite fijar la clave y otorgar acceso total (admin +
// afiliado + proveedor + autorizado) a un email. Requiere el token secreto
// BOOTSTRAP_ADMIN_TOKEN en la cabecera x-bootstrap-token.
const bodySchema = z.object({
  email: z.string().email(),
  password: z.string().min(6).max(72),
});

export const Route = createFileRoute("/api/public/bootstrap-admin")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const expected = process.env["BOOTSTRAP_ADMIN_TOKEN"];
        const token = request.headers.get("x-bootstrap-token") ?? "";
        if (!expected || token.length !== expected.length || token !== expected) {
          return new Response("Unauthorized", { status: 401 });
        }

        const parsed = bodySchema.safeParse(await request.json().catch(() => null));
        if (!parsed.success) return new Response("Bad request", { status: 400 });
        const { email, password } = parsed.data;

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        let userId: string | null = null;
        for (let page = 1; page <= 20 && !userId; page++) {
          const { data, error } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 200 });
          if (error) return new Response(error.message, { status: 500 });
          userId = data.users.find((u) => u.email?.toLowerCase() === email.toLowerCase())?.id ?? null;
          if (!data.users.length || data.users.length < 200) break;
        }

        if (!userId) {
          const { data, error } = await supabaseAdmin.auth.admin.createUser({
            email,
            password,
            email_confirm: true,
          });
          if (error || !data.user) return new Response(error?.message ?? "error", { status: 500 });
          userId = data.user.id;
        } else {
          const { error } = await supabaseAdmin.auth.admin.updateUserById(userId, {
            password,
            email_confirm: true,
          });
          if (error) return new Response(error.message, { status: 500 });
        }

        for (const role of ["admin", "afiliado", "proveedor"] as const) {
          await supabaseAdmin
            .from("user_roles")
            .upsert({ user_id: userId, role } as any, { onConflict: "user_id,role" });
        }
        await supabaseAdmin.from("user_accounts").upsert(
          {
            user_id: userId,
            email,
            autorizado: true,
            clave_temporal: password,
            updated_at: new Date().toISOString(),
          } as any,
          { onConflict: "user_id" },
        );

        return Response.json({ ok: true, user_id: userId, roles: ["admin", "afiliado", "proveedor"] });
      },
    },
  },
});
