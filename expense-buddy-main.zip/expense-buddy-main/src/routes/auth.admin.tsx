import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { claimAdminIfFirst, getMyRole } from "@/lib/auth-admin.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";

export const Route = createFileRoute("/auth/admin")({
  head: () => ({
    meta: [
      { title: "Acceso administrador — Comida a Dto." },
      { name: "description", content: "Ingreso al panel de administración." },
    ],
  }),
  component: AdminAuth,
});

function AdminAuth() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const claim = useServerFn(claimAdminIfFirst);
  const myRole = useServerFn(getMyRole);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        const { data: session } = await supabase.auth.getSession();
        if (!session.session) {
          toast.success("Cuenta creada. Revisá tu email para confirmar (o intentá ingresar).");
          setMode("signin");
          return;
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
      // Try to promote to admin if none exists yet
      await claim({ data: undefined as any }).catch(() => null);
      const role = await myRole({ data: undefined as any });
      if (!role.isAdmin) {
        await supabase.auth.signOut();
        throw new Error("Esta cuenta no es administrador. Pedile a un admin que te asigne el rol.");
      }
      toast.success("Bienvenido");
      navigate({ to: "/admin" });
    } catch (err: any) {
      toast.error(err?.message ?? "Error al ingresar");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-200 dark:from-slate-900 dark:to-slate-950 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>{mode === "signin" ? "Ingreso administrador" : "Crear cuenta admin"}</CardTitle>
          <CardDescription>
            {mode === "signin"
              ? "Ingresá con tu email y contraseña."
              : "La primera cuenta creada se convierte en administrador del sistema."}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Contraseña</Label>
              <Input
                id="password"
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Procesando..." : mode === "signin" ? "Ingresar" : "Crear cuenta"}
            </Button>
            <button
              type="button"
              className="w-full text-sm text-muted-foreground hover:text-foreground"
              onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
            >
              {mode === "signin"
                ? "¿No tenés cuenta? Crear una"
                : "¿Ya tenés cuenta? Ingresar"}
            </button>
            <div className="text-center">
              <Link to="/" className="text-xs text-muted-foreground hover:underline">
                Volver al inicio
              </Link>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
