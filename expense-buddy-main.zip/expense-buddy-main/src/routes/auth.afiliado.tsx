import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { loginAffiliate } from "@/lib/auth-affiliate.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";

export const Route = createFileRoute("/auth/afiliado")({
  head: () => ({
    meta: [
      { title: "Acceso afiliado — Comida a Dto." },
      { name: "description", content: "Ingresá con tu número de legajo y PIN." },
    ],
  }),
  component: AfiliadoAuth,
});

function AfiliadoAuth() {
  const [legajo, setLegajo] = useState("");
  const [pin, setPin] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const login = useServerFn(loginAffiliate);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const l = legajo.trim().toUpperCase();
      if (!l) throw new Error("Legajo inválido");
      const { email } = await login({ data: { legajo: l, pin } });
      const { error } = await supabase.auth.signInWithPassword({ email, password: pin });
      if (error) throw error;
      toast.success("Bienvenido");
      navigate({ to: "/mis-consumos" });
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo ingresar");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-200 dark:from-slate-900 dark:to-slate-950 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Ingreso afiliado</CardTitle>
          <CardDescription>
            Ingresá con tu legajo (letras y/o números). La primera vez, tu PIN son los últimos 4
            caracteres de tu legajo.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="legajo">Legajo</Label>
              <Input
                id="legajo"
                required
                value={legajo}
                onChange={(e) => setLegajo(e.target.value.toUpperCase())}
                autoComplete="username"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="pin">PIN</Label>
              <Input
                id="pin"
                type="password"
                required
                minLength={4}
                value={pin}
                onChange={(e) => setPin(e.target.value)}
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Ingresando..." : "Ingresar"}
            </Button>
            <div className="text-center">
              <Link to="/" className="text-xs text-muted-foreground hover:underline">
                Volver al inicio
              </Link>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
