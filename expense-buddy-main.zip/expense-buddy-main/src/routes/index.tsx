import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ShieldCheck, User, Store, Leaf } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AGOEC — Portal de servicios para afiliados y proveedores" },
      {
        name: "description",
        content:
          "Portal de AGOEC: acceso para administración, afiliados y proveedores. Consumos, liquidaciones y servicios con descuento.",
      },
      { property: "og:title", content: "AGOEC — Portal de servicios" },
      {
        property: "og:description",
        content:
          "Asociación Gremial Obreros y Empleados de la Conservación Ecológica. Servicios con descuento para afiliados.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Landing,
});

const accesos = [
  {
    to: "/auth/admin" as const,
    icon: ShieldCheck,
    titulo: "Administración",
    desc: "Tesorería: CRM de servicios, proveedores, liquidaciones y estadísticas.",
    cta: "Ingresar como administrador",
    variant: "default" as const,
  },
  {
    to: "/auth/afiliado" as const,
    icon: User,
    titulo: "Afiliados",
    desc: "Consultá tus consumos por servicio, subsidios y descuentos del mes.",
    cta: "Ingresar con mi legajo",
    variant: "secondary" as const,
  },
  {
    to: "/auth/proveedor" as const,
    icon: Store,
    titulo: "Proveedores",
    desc: "Subí las liquidaciones mensuales, revisá pagos y comunicate con tesorería.",
    cta: "Ingresar como proveedor",
    variant: "outline" as const,
  },
];

function Landing() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b bg-card">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center gap-3">
          <span className="h-10 w-10 rounded-xl bg-primary text-primary-foreground grid place-items-center font-bold">
            <Leaf className="h-5 w-5" />
          </span>
          <div className="leading-tight">
            <p className="font-bold tracking-wide">AGOEC</p>
            <p className="text-[11px] text-muted-foreground">Portal de servicios</p>
          </div>
        </div>
      </header>

      <main className="flex-1">
        <section className="relative overflow-hidden border-b">
          <div
            className="absolute inset-0 opacity-95"
            style={{
              background:
                "linear-gradient(135deg, var(--brand-green-strong) 0%, var(--brand-green) 45%, var(--brand-blue) 100%)",
            }}
            aria-hidden="true"
          />
          <div className="relative max-w-6xl mx-auto px-6 py-16 md:py-24 text-primary-foreground">
            <p className="text-6xl md:text-8xl font-black tracking-tight">AGOEC</p>
            <h1 className="mt-3 text-xl md:text-3xl font-semibold max-w-3xl">
              Asociación Gremial Obreros y Empleados de la Conservación Ecológica
            </h1>
            <p className="mt-4 max-w-2xl text-primary-foreground/90">
              Servicios con descuento para nuestros afiliados: comida a descuento, farmacia,
              supermercado, automotores, indumentaria, adelantos y más.
            </p>
          </div>
        </section>

        <section className="max-w-6xl mx-auto px-6 py-12">
          <h2 className="text-lg font-semibold text-muted-foreground">Elegí cómo querés ingresar</h2>
          <div className="mt-6 grid gap-5 md:grid-cols-3">
            {accesos.map((a) => (
              <Card key={a.to} className="flex flex-col border-t-4 border-t-primary">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <a.icon className="h-5 w-5 text-primary" />
                    <CardTitle>{a.titulo}</CardTitle>
                  </div>
                  <CardDescription>{a.desc}</CardDescription>
                </CardHeader>
                <CardContent className="mt-auto">
                  <Button asChild variant={a.variant} className="w-full">
                    <Link to={a.to}>{a.cta}</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </main>

      <footer className="border-t bg-card">
        <div className="max-w-6xl mx-auto px-6 py-5 text-xs text-muted-foreground">
          AGOEC — Asociación Gremial Obreros y Empleados de la Conservación Ecológica. Portal interno
          de servicios.
        </div>
      </footer>
    </div>
  );
}
