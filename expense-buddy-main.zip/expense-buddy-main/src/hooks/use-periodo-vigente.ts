import { useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getPeriodoVigente } from "@/lib/payroll.functions";

/** Llama a onReady una sola vez con el período abierto. */
export function usePeriodoVigente(onReady: (p: { mes: number; anio: number }) => void) {
  const fn = useServerFn(getPeriodoVigente);
  const q = useQuery({ queryKey: ["periodo-vigente"], queryFn: () => fn() });
  const done = useRef(false);
  useEffect(() => {
    if (q.data && !done.current) {
      done.current = true;
      onReady(q.data);
    }
  }, [q.data]);
  return q.data;
}
