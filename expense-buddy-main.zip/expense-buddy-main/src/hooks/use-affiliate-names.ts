import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { lookupAffiliateNames } from "@/lib/affiliate-lookup.functions";

/**
 * Devuelve un mapa legajo -> apellido y nombre para los legajos tipeados.
 * Cachea los ya consultados y sólo pide los nuevos (con un pequeño debounce).
 */
export function useAffiliateNames(legajos: string[]) {
  const lookup = useServerFn(lookupAffiliateNames);
  const [names, setNames] = useState<Record<string, string | null>>({});
  const pedidos = useRef(new Set<string>());

  const key = Array.from(new Set(legajos.map((l) => l.trim().toUpperCase()).filter(Boolean)))
    .sort()
    .join("|");

  useEffect(() => {
    const wanted = key ? key.split("|") : [];
    const faltan = wanted.filter((l) => !pedidos.current.has(l));
    if (!faltan.length) return;
    const t = setTimeout(async () => {
      faltan.forEach((l) => pedidos.current.add(l));
      try {
        const out = await lookup({ data: { legajos: faltan } });
        setNames((prev) => {
          const next = { ...prev };
          for (const l of faltan) next[l] = out.names[l] ?? null;
          return next;
        });
      } catch {
        faltan.forEach((l) => pedidos.current.delete(l));
      }
    }, 350);
    return () => clearTimeout(t);
  }, [key, lookup]);

  return names;
}
