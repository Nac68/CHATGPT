import { useMemo, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Users } from "lucide-react";
import { compareLegajo } from "@/lib/legajo";
import { AdelantoToggle } from "@/components/AdelantoToggle";

export type IntegranteRow = {
  legajo: string;
  nombre: string | null;
  detalle?: string;
  importe: number;
  observacion?: string | null;
  /** Si se informa, muestra el tilde de pago adelantado para esta fila. */
  adelanto?: { refKey: string; tipo: string; importe: number; detalle?: string };
};

const money = (n: number) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" }).format(Number(n) || 0);

export function IntegrantesDialog({
  titulo,
  descripcion,
  rows,
  label = "Ver integrantes",
  detalleLabel = "Detalle",
  importeLabel = "A descontar",
}: {
  titulo: string;
  descripcion?: string;
  rows: IntegranteRow[];
  label?: string;
  detalleLabel?: string;
  importeLabel?: string;
}) {
  const [q, setQ] = useState("");
  const lista = useMemo(() => {
    const t = q.trim().toLowerCase();
    return [...rows]
      .sort((a, b) => compareLegajo(a.legajo, b.legajo))
      .filter(
        (r) =>
          !t || r.legajo.toLowerCase().includes(t) || (r.nombre ?? "").toLowerCase().includes(t),
      );
  }, [rows, q]);
  const total = lista.reduce((a, r) => a + (Number(r.importe) || 0), 0);
  const hayDetalle = rows.some((r) => r.detalle);
  const hayObs = rows.some((r) => r.observacion);
  const hayAdel = rows.some((r) => r.adelanto);

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline">
          <Users className="mr-2 h-4 w-4" /> {label} ({rows.length})
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[85vh] max-w-3xl overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>{titulo}</DialogTitle>
          {descripcion && <DialogDescription>{descripcion}</DialogDescription>}
        </DialogHeader>
        <Input
          placeholder="Buscar por legajo o nombre"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <div className="overflow-auto">
          {!lista.length ? (
            <p className="py-4 text-sm text-muted-foreground">Sin integrantes.</p>
          ) : (
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-background text-left text-muted-foreground">
                <tr className="border-b">
                  <th className="py-2 pr-3">Legajo</th>
                  <th className="py-2 pr-3">Apellido y nombre</th>
                  {hayDetalle && <th className="py-2 pr-3">{detalleLabel}</th>}
                  {hayObs && <th className="py-2 pr-3">Observación</th>}
                  <th className="py-2 text-right">{importeLabel}</th>
                  {hayAdel && <th className="py-2 pl-3">Cobro</th>}
                </tr>
              </thead>
              <tbody>
                {lista.map((r, i) => (
                  <tr key={`${r.legajo}-${i}`} className="border-b last:border-0">
                    <td className="py-1.5 pr-3 font-mono">{r.legajo}</td>
                    <td className="py-1.5 pr-3">{r.nombre || "—"}</td>
                    {hayDetalle && <td className="py-1.5 pr-3">{r.detalle || "—"}</td>}
                    {hayObs && <td className="py-1.5 pr-3">{r.observacion || ""}</td>}
                    <td className="py-1.5 text-right">{money(r.importe)}</td>
                    {hayAdel && (
                      <td className="py-1.5 pl-3">
                        {r.adelanto && (
                          <AdelantoToggle
                            refKey={r.adelanto.refKey}
                            tipo={r.adelanto.tipo}
                            legajo={r.legajo}
                            detalle={r.adelanto.detalle}
                            importe={r.adelanto.importe}
                            label="Adelantado"
                          />
                        )}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="font-semibold">
                  <td className="py-2 pr-3" colSpan={2 + (hayDetalle ? 1 : 0) + (hayObs ? 1 : 0)}>
                    Total ({lista.length})
                  </td>
                  <td className="py-2 text-right">{money(total)}</td>
                  {hayAdel && <td />}
                </tr>
              </tfoot>
            </table>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
