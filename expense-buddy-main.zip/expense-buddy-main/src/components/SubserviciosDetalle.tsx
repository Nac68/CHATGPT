import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import * as XLSX from "xlsx";
import { listCircles } from "@/lib/circles.functions";
import { listBirthdayPlans } from "@/lib/birthdays.functions";
import { listCollections } from "@/lib/collections.functions";
import { comidaOverview } from "@/lib/comida.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Download, Search } from "lucide-react";
import { toast } from "sonner";

const money = (n: number) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" }).format(Number(n) || 0);

const norm = (s: any) =>
  String(s ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();

const nowIdx = () => {
  const d = new Date();
  return d.getFullYear() * 12 + d.getMonth();
};
/** AAAAMM -> índice de mes */
const idxFromPeriodo = (p: any) => {
  const n = Number(p);
  if (!n) return null;
  return Math.floor(n / 100) * 12 + ((n % 100) - 1);
};
const idxFromMesAnio = (mes: any, anio: any) => {
  const m = Number(mes);
  const a = Number(anio);
  if (!m || !a) return null;
  return a * 12 + (m - 1);
};

type Row = {
  id: string;
  subservicio: string;
  detalle: string;
  periodo: string;
  participantes: number;
  importe: number;
  gestionar: string;
  vencido: boolean;
  /** texto extra para buscar por legajo / nombre de integrante / nº de círculo */
  busqueda: string;
  exportar?: () => void;
};

const miembrosTexto = (ms: any[]) =>
  (ms ?? [])
    .map((m: any) => `${m.legajo ?? ""} ${m.apellido_nombre ?? ""}`)
    .join(" ");


/** Todos los subservicios de Servicios Varios con su detalle, buscador, paginación y Excel. */
export function SubserviciosDetalle({ serviceId }: { serviceId?: string }) {
  const circlesFn = useServerFn(listCircles);
  const plansFn = useServerFn(listBirthdayPlans);
  const colectasFn = useServerFn(listCollections);
  const comidaFn = useServerFn(comidaOverview);

  const [q, setQ] = useState("");
  const [sub, setSub] = useState("todos");
  const [tab, setTab] = useState<"vigentes" | "vencidos">("vigentes");
  const [qLegajo, setQLegajo] = useState("");
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState("10");


  const circlesQ = useQuery({ queryKey: ["sub-circles"], queryFn: () => circlesFn({}) });
  const plansQ = useQuery({ queryKey: ["sub-plans"], queryFn: () => plansFn({}) });
  const colectasQ = useQuery({ queryKey: ["sub-colectas"], queryFn: () => colectasFn({}) });
  const comidaQ = useQuery({ queryKey: ["sub-comida"], queryFn: () => comidaFn({}) });

  const cargando =
    circlesQ.isLoading || plansQ.isLoading || colectasQ.isLoading || comidaQ.isLoading;

  function exportCirculo(c: any) {
    const ms = c.members ?? [];
    const aoa: any[][] = [
      ["Circulo_Numero", c.numero ?? "", "Descripcion", c.nombre ?? ""],
      ["Periodo_Inicio", c.periodo_inicio ?? "", "Periodo_Fin", c.periodo_fin ?? ""],
      ["Total General", Number(c.importe ?? 0), "", ""],
      ["", "", "", ""],
      ["Legajo", "Nombre_y_Apellido", "Importe", "Fecha_Cobro", "Observaciones"],
      ...ms.map((m: any) => [
        m.legajo,
        m.apellido_nombre ?? "",
        Number(m.importe_mensual ?? 0),
        m.fecha_cobro ?? "",
        m.observacion ?? "",
      ]),
      ["", "", "", "", ""],
      [
        "",
        "",
        Math.round(ms.reduce((a: number, m: any) => a + (Number(m.importe_mensual) || 0), 0) * 100) /
          100,
        "",
        "",
      ],
    ];
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [{ wch: 16 }, { wch: 34 }, { wch: 14 }, { wch: 16 }, { wch: 28 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Hoja1");
    XLSX.writeFile(wb, `CIRCULO_${c.numero ?? c.nombre}.xlsx`);
  }

  function exportPlan(p: any) {
    const ms = p.members ?? [];
    const n = Math.max(1, ...ms.map((m: any) => (Array.isArray(m.cuotas) ? m.cuotas.length : 0)));
    const cuotaHeaders = Array.from({ length: n }, (_, i) => `Cuota_${i + 1}`);
    const aoa: any[][] = [
      ["Descripcion", p.nombre ?? "", "Importe Total", Number(p.importe_total ?? 0)],
      ["Periodo_Inicio", Number(p.periodo_inicio) || "", "Periodo_Fin", Number(p.periodo_fin) || ""],
      [],
      ["Legajo", "Nombre_y_Apellido", "Fecha_Cobro", ...cuotaHeaders, "total a cobrar", "Observaciones"],
    ];
    for (const m of ms) {
      const cs = Array.from({ length: n }, (_, i) =>
        Array.isArray(m.cuotas) ? (Number(m.cuotas[i]) || "") : "",
      );
      aoa.push([
        m.legajo,
        m.apellido_nombre ?? "",
        m.fecha_cobro ?? "",
        ...cs,
        Math.round(cs.reduce((a: number, c: any) => a + (Number(c) || 0), 0) * 100) / 100,
        m.observacion ?? "",
      ]);
    }
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Hoja1");
    XLSX.writeFile(wb, `cumpleanos_${String(p.nombre ?? "").replace(/\W+/g, "-")}.xlsx`);
  }

  function exportColecta(c: any) {
    const per = (mes: number, anio: number) => `${anio}${String(mes).padStart(2, "0")}`;
    const m0 = Number(c.mes_inicio) || 1;
    const a0 = Number(c.anio_inicio) || new Date().getFullYear();
    const n = Math.max(1, Number(c.cuotas) || 1);
    const fin = new Date(a0, m0 - 1 + (n - 1), 1);
    const ms = c.members ?? [];
    const aoa: any[][] = [
      ["Descripción", c.nombre ?? "", "", ""],
      ["Periodo Desde", per(m0, a0), "Periodo Hasta", per(fin.getMonth() + 1, fin.getFullYear())],
      ["Legajo Beneficiario", c.beneficiario_legajo ?? "", "Nombre Beneficiario", c.beneficiario_nombre ?? ""],
      ["", "", "", ""],
      ["Legajo", "Nombre_y_Apellido", "Importe_Descontar", ""],
      ...ms.map((m: any) => [
        m.legajo,
        m.apellido_nombre ?? "",
        Number(Number(m.importe_cuota ?? m.importe_total ?? 0).toFixed(2)),
        m.observacion ?? "",
      ]),
      ["", "", "", ""],
      [
        "",
        "",
        Math.round(
          ms.reduce((a: number, m: any) => a + (Number(m.importe_cuota ?? m.importe_total) || 0), 0) *
            100,
        ) / 100,
        "",
      ],
    ];
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [{ wch: 20 }, { wch: 28 }, { wch: 20 }, { wch: 22 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Hoja1");
    XLSX.writeFile(wb, `colecta_${String(c.nombre ?? "").replace(/\W+/g, "-")}.xlsx`);
  }

  function exportComidaResumen() {
    const dias = (comidaQ.data as any)?.dias ?? [];
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(
      dias.map((d: any) => ({
        Fecha: d.fecha,
        Descripcion: d.descripcion ?? "",
        Cumpleanos: d.es_cumpleanos ? "SI" : "",
        Comensales: d.comensales ?? 0,
        Pagan: d.pagan ?? 0,
        Importe_total: Number(d.importe ?? 0),
        A_descontar: Number(d.a_cobrar ?? 0),
      })),
    );
    ws["!cols"] = [{ wch: 12 }, { wch: 34 }, { wch: 12 }, { wch: 12 }, { wch: 10 }, { wch: 14 }, { wch: 14 }];
    XLSX.utils.book_append_sheet(wb, ws, "Comida a Dto");
    XLSX.writeFile(wb, "comida-a-dto_resumen.xlsx");
  }

  const rows = useMemo<Row[]>(() => {
    const out: Row[] = [];
    const per = (a: any, b: any) => [a, b].filter(Boolean).join(" a ") || "—";
    const hoy = nowIdx();

    for (const c of (circlesQ.data as any)?.circles ?? []) {
      const fin = idxFromPeriodo(c.periodo_fin);
      out.push({
        id: `circulo:${c.id}`,
        subservicio: "Círculos",
        detalle: c.numero ? `Círculo ${c.numero} · ${c.nombre}` : c.nombre,
        periodo: per(c.periodo_inicio, c.periodo_fin),
        participantes: c.integrantes ?? (c.members ?? []).length,
        importe: Number(c.total_mensual ?? 0),
        gestionar: "/admin/circulo",
        vencido: fin != null && fin < hoy,
        busqueda: `${c.numero ?? ""} ${c.nombre ?? ""} ${miembrosTexto(c.members)}`,
        exportar: () => exportCirculo(c),
      });
    }
    for (const p of (plansQ.data as any)?.plans ?? []) {
      const ms = p.members ?? [];
      const cuotas = Math.max(
        1,
        ...ms.map((m: any) => (Array.isArray(m.cuotas) ? m.cuotas.length : 0)),
      );
      const inicio = idxFromPeriodo(p.periodo_inicio);
      const finP = idxFromPeriodo(p.periodo_fin);
      const fin = finP ?? (inicio != null ? inicio + cuotas - 1 : null);
      out.push({
        id: `cumple:${p.id}`,
        subservicio: "Cumpleaños",
        detalle: p.nombre,
        periodo: per(p.periodo_inicio, p.periodo_fin),
        participantes: p.integrantes ?? ms.length,
        importe: Number(p.total_descuentos ?? p.importe_total ?? 0),
        gestionar: "/admin/cumpleanos",
        vencido: fin != null && fin < hoy,
        busqueda: `${p.nombre ?? ""} ${miembrosTexto(ms)}`,
        exportar: () => exportPlan(p),
      });
    }
    for (const c of (colectasQ.data as any)?.collections ?? []) {
      const inicio = idxFromMesAnio(c.mes_inicio, c.anio_inicio);
      const fin = inicio != null ? inicio + Math.max(1, Number(c.cuotas) || 1) - 1 : null;
      out.push({
        id: `colecta:${c.id}`,
        subservicio: "Colectas",
        detalle: c.motivo ? `${c.nombre} (${c.motivo})` : c.nombre,
        periodo:
          c.mes_inicio && c.anio_inicio
            ? `${c.anio_inicio}${String(c.mes_inicio).padStart(2, "0")} · ${c.cuotas} cuota(s)`
            : "—",
        participantes: c.aportantes ?? (c.members ?? []).length,
        importe: Number(c.total_aportes ?? 0),
        gestionar: "/admin/colecta",
        vencido: !!c.cerrada || (fin != null && fin < hoy),
        busqueda: `${c.nombre ?? ""} ${c.motivo ?? ""} ${c.beneficiario_legajo ?? ""} ${c.beneficiario_nombre ?? ""} ${miembrosTexto(c.members)}`,
        exportar: () => exportColecta(c),
      });
    }
    const comidaKpis = (comidaQ.data as any)?.kpis;
    if (comidaKpis?.dias) {
      out.push({
        id: "comida:resumen",
        subservicio: "Comida a Dto.",
        detalle: `Total acumulado · ${comidaKpis.dias} día(s) cargados`,
        periodo: comidaKpis.ultimo_dia ? `Último día: ${comidaKpis.ultimo_dia}` : "—",
        participantes: comidaKpis.afiliados ?? 0,
        importe: Number(comidaKpis.total_a_descontar ?? 0),
        gestionar: "/admin/comida-dto",
        vencido: false,
        busqueda: "comida a dto",
        exportar: exportComidaResumen,
      });
    }
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [circlesQ.data, plansQ.data, colectasQ.data, comidaQ.data]);


  const subservicios = ["Círculos", "Cumpleaños", "Colectas", "Comida a Dto."];

  const delTab = useMemo(
    () => rows.filter((r) => (tab === "vencidos" ? r.vencido : !r.vencido)),
    [rows, tab],
  );

  const filtradas = useMemo(() => {
    const t = norm(q.trim());
    const l = tab === "vencidos" ? norm(qLegajo.trim()) : "";
    return delTab.filter(
      (r) =>
        (sub === "todos" || r.subservicio === sub) &&
        (!t || norm(r.subservicio).includes(t) || norm(r.detalle).includes(t) || norm(r.periodo).includes(t)) &&
        (!l || norm(r.busqueda).includes(l) || norm(r.detalle).includes(l)),
    );
  }, [delTab, q, sub, qLegajo, tab]);


  const size = Number(perPage);
  const totalPages = Math.max(1, Math.ceil(filtradas.length / size));
  const pageSafe = Math.min(page, totalPages);
  const visibles = filtradas.slice((pageSafe - 1) * size, pageSafe * size);

  function exportarTodo() {
    try {
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(
        wb,
        XLSX.utils.json_to_sheet(
          filtradas.map((r) => ({
            Subservicio: r.subservicio,
            Detalle: r.detalle,
            Período: r.periodo,
            Participantes: r.participantes,
            Importe: r.importe,
          })),
        ),
        "Subservicios",
      );
      XLSX.writeFile(wb, "subservicios-varios.xlsx");
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo exportar");
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Subservicios habilitados</CardTitle>
        <CardDescription>
          Detalle completo de Círculos, Cumpleaños, Colectas y Comida a Dto., con descarga en el
          mismo formato con el que se importa cada planilla.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          {(["vigentes", "vencidos"] as const).map((t) => (
            <Button
              key={t}
              size="sm"
              variant={tab === t ? "default" : "outline"}
              onClick={() => {
                setTab(t);
                setPage(1);
              }}
            >
              {t === "vigentes" ? "Vigentes" : "Vencidos (archivo)"} ·{" "}
              {rows.filter((r) => (t === "vencidos" ? r.vencido : !r.vencido)).length}
            </Button>
          ))}
        </div>
        {tab === "vencidos" && (
          <div className="flex flex-wrap items-center gap-2 rounded-md border bg-muted/40 p-2">
            <div className="relative flex-1 min-w-[240px]">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                className="pl-8"
                placeholder="Filtrar archivo por legajo, integrante o Nº de círculo…"
                value={qLegajo}
                onChange={(e) => {
                  setQLegajo(e.target.value);
                  setPage(1);
                }}
              />
            </div>
            {qLegajo && (
              <Button size="sm" variant="ghost" onClick={() => setQLegajo("")}>
                Limpiar
              </Button>
            )}
            <p className="text-xs text-muted-foreground">
              {filtradas.length} registro(s) vencidos coinciden
            </p>
          </div>
        )}
        <div className="flex flex-wrap gap-2">

          <div className="relative flex-1 min-w-[220px]">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              className="pl-8"
              placeholder="Buscar por subservicio, nombre o período…"
              value={q}
              onChange={(e) => {
                setQ(e.target.value);
                setPage(1);
              }}
            />
          </div>
          <Select
            value={sub}
            onValueChange={(v) => {
              setSub(v);
              setPage(1);
            }}
          >
            <SelectTrigger className="w-[190px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos los subservicios</SelectItem>
              {subservicios.map((s) => (
                <SelectItem key={s} value={s}>
                  {s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select
            value={perPage}
            onValueChange={(v) => {
              setPerPage(v);
              setPage(1);
            }}
          >
            <SelectTrigger className="w-[110px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {["10", "25", "50", "100"].map((n) => (
                <SelectItem key={n} value={n}>
                  {n} / pág.
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={exportarTodo} disabled={!filtradas.length}>
            <Download className="mr-1.5 h-4 w-4" /> Excel del listado
          </Button>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {subservicios.map((s) => (
            <Badge key={s} variant="outline">
              {s}: {delTab.filter((r) => r.subservicio === s).length}
            </Badge>
          ))}
        </div>

        {cargando ? (
          <p className="text-sm text-muted-foreground">Cargando subservicios…</p>
        ) : !filtradas.length ? (
          <p className="text-sm text-muted-foreground">No hay registros para mostrar.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground">
                <tr className="border-b">
                  <th className="py-2 pr-3">Subservicio</th>
                  <th className="py-2 pr-3">Detalle</th>
                  <th className="py-2 pr-3">Período / Fecha</th>
                  <th className="py-2 pr-3">Participantes</th>
                  <th className="py-2 pr-3">Importe</th>
                  <th className="py-2" />
                </tr>
              </thead>
              <tbody>
                {visibles.map((r) => (
                  <tr key={r.id} className="border-b last:border-0">
                    <td className="py-1.5 pr-3">
                      <Badge variant="secondary">{r.subservicio}</Badge>
                    </td>
                    <td className="py-1.5 pr-3">{r.detalle}</td>
                    <td className="py-1.5 pr-3">{r.periodo}</td>
                    <td className="py-1.5 pr-3">{r.participantes}</td>
                    <td className="py-1.5 pr-3 font-medium">{money(r.importe)}</td>
                    <td className="py-1.5">
                      <div className="flex justify-end gap-1">
                        {r.exportar && (
                          <Button size="sm" variant="outline" onClick={r.exportar}>
                            <Download className="h-4 w-4" />
                          </Button>
                        )}
                        <Button asChild size="sm" variant="ghost">
                          <Link to={r.gestionar as any} search={serviceId ? ({ service_id: serviceId } as any) : undefined}>
                            Gestionar
                          </Link>
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {filtradas.length > size && (
          <div className="flex items-center justify-between gap-2">
            <p className="text-xs text-muted-foreground">
              {filtradas.length} registros · página {pageSafe} de {totalPages}
            </p>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                disabled={pageSafe <= 1}
                onClick={() => setPage(pageSafe - 1)}
              >
                Anterior
              </Button>
              <Button
                size="sm"
                variant="outline"
                disabled={pageSafe >= totalPages}
                onClick={() => setPage(pageSafe + 1)}
              >
                Siguiente
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
