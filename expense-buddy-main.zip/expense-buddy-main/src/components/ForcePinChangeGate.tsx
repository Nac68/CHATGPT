import { useState, type ReactNode } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { myPinStatus, changeMyPin } from "@/lib/auth-affiliate.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

/**
 * Gate del portal afiliado: si la cuenta tiene must_change_pin activo
 * (primer ingreso con PIN inicial o reset administrativo), bloquea el
 * contenido y exige el cambio antes de mostrar `children`.
 */
export function ForcePinChangeGate({ children }: { children: ReactNode }) {
  const statusFn = useServerFn(myPinStatus);
  const change = useServerFn(changeMyPin);
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["my-pin-status"],
    queryFn: () => statusFn({ data: undefined as any }),
  });

  const [actual, setActual] = useState("");
  const [nuevo, setNuevo] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (nuevo !== confirm) {
      toast.error("La confirmación no coincide con el nuevo PIN");
      return;
    }
    setLoading(true);
    try {
      await change({ data: { currentPin: actual, newPin: nuevo } });
      toast.success("PIN actualizado. Ya podés usar el portal.");
      await queryClient.invalidateQueries({ queryKey: ["my-pin-status"] });
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo cambiar el PIN");
    } finally {
      setLoading(false);
    }
  }

  if (isLoading) {
    return <div className="flex min-h-screen items-center justify-center text-sm">Cargando…</div>;
  }

  if (!data?.must_change_pin) return <>{children}</>;

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Cambio obligatorio de PIN</CardTitle>
          <CardDescription>
            Por seguridad, antes de ingresar al portal debés reemplazar tu PIN inicial por uno
            personal. No puede ser igual al PIN inicial de tu legajo.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="pin-actual">PIN actual</Label>
              <Input
                id="pin-actual"
                type="password"
                required
                value={actual}
                onChange={(e) => setActual(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="pin-nuevo">PIN nuevo</Label>
              <Input
                id="pin-nuevo"
                type="password"
                required
                minLength={4}
                value={nuevo}
                onChange={(e) => setNuevo(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="pin-confirm">Confirmar PIN nuevo</Label>
              <Input
                id="pin-confirm"
                type="password"
                required
                minLength={4}
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Actualizando…" : "Cambiar PIN y continuar"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
