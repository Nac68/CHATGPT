import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getServiceDetail } from "@/lib/service-products.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const money = (n: unknown) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" }).format(Number(n) || 0);

const TIPO_LABEL: Record<string, string> = {
  externo: "Externo",
  interno: "Interno (afiliado)",
  agoec: "De AGOEC",
  circulo: "Círculo",
};

/** Tarjeta de proveedores de un servicio (misma vista que Farmacia). */
export function ProveedoresServicioCard({ codigo, titulo }: { codigo: string; titulo: string }) {
  const detail = useServerFn(getServiceDetail);
  const { data, isLoading } = useQuery({
    queryKey: ["service-detail", codigo],
    queryFn: () => detail({ data: { codigo } }),
  });
  const providers: any[] = (data as any)?.providers ?? [];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">{titulo}</CardTitle>
        <CardDescription>
          Datos de contacto, cobro y liquidaciones de cada prestador. Las altas y accesos se
          gestionan en Proveedores.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Cargando…</p>
        ) : !providers.length ? (
          <p className="text-sm text-muted-foreground">Sin proveedores asignados.</p>
        ) : (
          providers.map((p) => (
            <div key={p.id} className="rounded-lg border p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-semibold">{p.nombre}</p>
                  <p className="text-xs text-muted-foreground">{p.email || "sin email"}</p>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    <Badge variant={p.habilitado ? "default" : "secondary"}>
                      {p.habilitado ? "Habilitado" : "Deshabilitado"}
                    </Badge>
                    <Badge variant="outline">{TIPO_LABEL[p.tipo] ?? p.tipo}</Badge>
                    <Badge variant="outline">{p.user_id ? "Con acceso" : "Sin acceso"}</Badge>
                    {p.cargas_pendientes > 0 && (
                      <Badge variant="destructive">{p.cargas_pendientes} pendiente(s)</Badge>
                    )}
                  </div>
                </div>
                <div className="flex flex-wrap justify-end gap-1">
                  <Button asChild size="sm">
                    <Link to="/admin/proveedor/$id/liquidaciones" params={{ id: p.id }}>
                      Liquidaciones
                    </Link>
                  </Button>
                  <Button asChild size="sm" variant="outline">
                    <Link to="/admin/cargas">Ver cargas</Link>
                  </Button>
                </div>
              </div>
              <div className="mt-3 grid gap-2 text-sm sm:grid-cols-2 lg:grid-cols-4">
                {[
                  { l: "CUIT", v: p.cuit || "—" },
                  { l: "Titular", v: p.titular || "—" },
                  { l: "Banco", v: p.banco || "—" },
                  { l: "CBU / Alias", v: p.cbu || p.alias || "—" },
                  { l: "Cargas", v: p.cargas },
                  { l: "Afiliados", v: p.afiliados },
                  { l: "Total consumido", v: money(p.total_importe) },
                  { l: "A descontar afiliados", v: money(p.total_afiliado) },
                  {
                    l: "Última liquidación",
                    v: p.ultima_carga
                      ? `${p.ultima_carga.periodo} · ${p.ultima_carga.estado} · ${money(p.ultima_carga.total_a_pagar)}`
                      : "—",
                  },
                ].map((k) => (
                  <div key={k.l} className="rounded-md bg-muted/50 px-3 py-2">
                    <p className="text-[11px] text-muted-foreground">{k.l}</p>
                    <p className="break-all font-medium">{k.v}</p>
                  </div>
                ))}
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
