import { useRouter } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export function BackButton({ fallback = "/admin" }: { fallback?: string }) {
  const router = useRouter();
  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={() => {
        if (window.history.length > 1) {
          router.history.back();
        } else {
          router.navigate({ to: fallback });
        }
      }}
    >
      <ArrowLeft className="h-4 w-4 mr-1" /> Volver
    </Button>
  );
}
