import { useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import * as XLSX from "xlsx";
import { toast } from "sonner";
import { importProviders } from "@/lib/crm.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Upload, Download } from "lucide-react";

type Row = {
  uid: string;
  nombre: string;
  cuit: string;
  cuenta_contable: string;
  email: string;
  banco: string;
  cbu: string;
  alias: string;
  titular: string;
  tipo: "externo" | "interno" | "agoec";
};

const uid = () => Math.random().toString(36).slice(2);
const emptyRow = (): Row => ({
  uid: uid(),
  nombre: "",
  cuit: "",
  cuenta_contable: "",
  email: "",
  banco: "",
  cbu: "",
  alias: "",
  titular: "",
  tipo: "externo",
});

const pick = (r: any, keys: string[]) => {
  for (const k of Object.keys(r)) {
    const norm = k
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .trim();
    if (keys.some((x) => norm === x || norm.includes(x))) return String(r[k] ?? "").trim();
  }
  return "";
};

/** Carga manual o por archivo de prestadores (sin acceso al portal). */
export function ImportProvidersCard({ services }: { services: any[] }) {
  const qc = useQueryClient();
  const importar = useServerFn(importProviders);
  const [serviceId, setServiceId] = useState("");
  const [rows, setRows] = useState<Row[]>([emptyRow()]);
  const [busy, setBusy] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const validas = rows.filter((r) => r.nombre.trim().length >= 2);

  function setRow(k: string, patch: Partial<Row>) {
    setRows((rs) => rs.map((r) => (r.uid === k ? { ...r, ...patch } : r)));
  }

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy("file");
    try {
      const wb = XLSX.read(await file.arrayBuffer(), { type: "array" });
      const json = XLSX.utils.sheet_to_json<any>(wb.Sheets[wb.SheetNames[0]], { defval: "" });
      const parsed: Row[] = json
        .map((r) => ({
          uid: uid(),
          nombre: pick(r, ["nombre", "razon", "prestador", "proveedor", "farmacia"]),
          cuit: pick(r, ["cuit", "cuil"]),
          cuenta_contable: pick(r, ["contable", "cuenta"]),
          email: pick(r, ["email", "mail", "correo"]),
          banco: pick(r, ["banco"]),
          cbu: pick(r, ["cbu"]),
          alias: pick(r, ["alias"]),
          titular: pick(r, ["titular"]),
          tipo: (pick(r, ["tipo"]).toLowerCase() as Row["tipo"]) || "externo",
        }))
        .filter((r) => r.nombre)
        .map((r) => ({
          ...r,
          tipo: ["externo", "interno", "agoec"].includes(r.tipo) ? r.tipo : "externo",
        }));
      if (!parsed.length) toast.error("No se detectaron prestadores en el archivo");
      else {
        setRows((rs) => [...rs.filter((r) => r.nombre.trim()), ...parsed]);
        toast.success(`${parsed.length} prestadores leídos`);
      }
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo leer el archivo");
    } finally {
      setBusy(null);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function guardar() {
    if (!serviceId) return toast.error("Elegí el servicio");
    if (!validas.length) return toast.error("Cargá al menos un prestador con nombre");
    setBusy("save");
    try {
      const out = await importar({
        data: {
          service_id: serviceId,
          providers: validas.map((r) => ({
            nombre: r.nombre.trim(),
            cuit: r.cuit || null,
            cuenta_contable: r.cuenta_contable || null,
            email: r.email ? r.email.trim().toLowerCase() : null,
            banco: r.banco || null,
            cbu: r.cbu || null,
            alias: r.alias || null,
            titular: r.titular || null,
            tipo: r.tipo,
          })),
        } as any,
      });
      toast.success(`${(out as any).insertados} prestadores dados de alta`);
      setRows([emptyRow()]);
      qc.invalidateQueries({ queryKey: ["providers"] });
    } catch (err: any) {
      toast.error(err?.message ?? "No se pudo importar");
    } finally {
      setBusy(null);
    }
  }

  function plantilla() {
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet([
        {
          Nombre: "Prestador ejemplo",
          CUIT: "30-12345678-9",
          "Cuenta contable": "001/002/003",
          Email: "",
          Banco: "",
          CBU: "",
          Alias: "",
          Titular: "",
          Tipo: "externo",
        },
      ]),
      "Prestadores",
    );
    XLSX.writeFile(wb, "plantilla_prestadores.xlsx");
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Carga de prestadores (manual o por archivo)</CardTitle>
        <CardDescription>
          Alta masiva de prestadores para Servicios Varios y cualquier otro servicio. No crea acceso
          al portal: si después necesitan entrar, se los habilita desde “Nuevo proveedor”.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="imp-servicio">Servicio</Label>
            <select
              id="imp-servicio"
              className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
              value={serviceId}
              onChange={(e) => setServiceId(e.target.value)}
            >
              <option value="">Elegí un servicio…</option>
              {(services ?? []).map((s: any) => (
                <option key={s.id} value={s.id}>
                  {s.nombre}
                </option>
              ))}
            </select>
          </div>
          <div className="flex flex-wrap items-end gap-2">
            <Button type="button" variant="outline" size="sm" onClick={() => setRows((rs) => [...rs, emptyRow()])}>
              <Plus className="h-4 w-4 mr-1" /> Agregar fila
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={busy === "file"}
              onClick={() => fileRef.current?.click()}
            >
              <Upload className="h-4 w-4 mr-1" /> {busy === "file" ? "Leyendo…" : "Importar archivo"}
            </Button>
            <Button type="button" variant="ghost" size="sm" onClick={plantilla}>
              <Download className="h-4 w-4 mr-1" /> Plantilla
            </Button>
            <input
              ref={fileRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              className="hidden"
              onChange={onFile}
            />
            <Badge variant="outline">{validas.length} a dar de alta</Badge>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-left text-muted-foreground">
              <tr className="border-b">
                <th className="py-2 pr-3">Prestador</th>
                <th className="py-2 pr-3">CUIT</th>
                <th className="py-2 pr-3">N° contable</th>
                <th className="py-2 pr-3">Email</th>
                <th className="py-2 pr-3">Banco</th>
                <th className="py-2 pr-3">CBU / Alias</th>
                <th className="py-2 pr-3">Titular</th>
                <th className="py-2 pr-3">Tipo</th>
                <th className="py-2" />
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.uid} className="border-b last:border-0">
                  <td className="py-2 pr-3">
                    <Input
                      className="h-8 min-w-40"
                      value={r.nombre}
                      onChange={(e) => setRow(r.uid, { nombre: e.target.value })}
                    />
                  </td>
                  <td className="py-2 pr-3">
                    <Input
                      className="h-8 w-32"
                      value={r.cuit}
                      onChange={(e) => setRow(r.uid, { cuit: e.target.value })}
                    />
                  </td>
                  <td className="py-2 pr-3">
                    <Input
                      className="h-8 w-28 font-mono text-xs"
                      placeholder="001/002/003"
                      value={r.cuenta_contable}
                      onChange={(e) => setRow(r.uid, { cuenta_contable: e.target.value })}
                    />
                  </td>
                  <td className="py-2 pr-3">
                    <Input
                      className="h-8 min-w-40"
                      value={r.email}
                      onChange={(e) => setRow(r.uid, { email: e.target.value })}
                    />
                  </td>
                  <td className="py-2 pr-3">
                    <Input
                      className="h-8 w-28"
                      value={r.banco}
                      onChange={(e) => setRow(r.uid, { banco: e.target.value })}
                    />
                  </td>
                  <td className="py-2 pr-3">
                    <div className="flex gap-1">
                      <Input
                        className="h-8 w-36"
                        placeholder="CBU"
                        value={r.cbu}
                        onChange={(e) => setRow(r.uid, { cbu: e.target.value })}
                      />
                      <Input
                        className="h-8 w-28"
                        placeholder="Alias"
                        value={r.alias}
                        onChange={(e) => setRow(r.uid, { alias: e.target.value })}
                      />
                    </div>
                  </td>
                  <td className="py-2 pr-3">
                    <Input
                      className="h-8 min-w-36"
                      value={r.titular}
                      onChange={(e) => setRow(r.uid, { titular: e.target.value })}
                    />
                  </td>
                  <td className="py-2 pr-3">
                    <select
                      className="h-8 rounded-md border border-input bg-background px-2 text-xs"
                      value={r.tipo}
                      onChange={(e) => setRow(r.uid, { tipo: e.target.value as Row["tipo"] })}
                    >
                      <option value="externo">Externo</option>
                      <option value="interno">Interno</option>
                      <option value="agoec">De AGOEC</option>
                    </select>
                  </td>
                  <td className="py-2">
                    <Button
                      type="button"
                      size="icon"
                      variant="ghost"
                      onClick={() => setRows((rs) => rs.filter((x) => x.uid !== r.uid))}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <Button type="button" onClick={guardar} disabled={busy === "save"}>
          {busy === "save" ? "Importando…" : "Dar de alta prestadores"}
        </Button>
      </CardContent>
    </Card>
  );
}
