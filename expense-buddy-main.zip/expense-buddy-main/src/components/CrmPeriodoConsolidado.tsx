import { Fragment, useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { crmAffiliatePeriod, crmPeriodList } from "@/lib/crm-period.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ChevronDown, ChevronRight, Download, Loader2, Printer } from "lucide-react";
import { formatPeriodo } from "@/lib/periodo";
import * as XLSX from "xlsx";
import { toast } from "sonner";

const currency = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });

/**
 * Consulta consolidada del afiliado por período (21 -> 20): resumen por servicio,
 * detalle desplegable con el origen real de cada importe, Excel e impresión.
 * Pantalla, Excel e impresión usan el MISMO dataset (crmAffiliatePeriod).
 */
export function CrmPeriodoConsolidado({
  legajo,
  modo = "actual",
}: {
  legajo: string;
  modo?: "actual" | "historico";
}) {
  const fetchPeriodos = useServerFn(crmPeriodList);
  const fetchDatos = useServerFn(crmAffiliatePeriod);

  const { data: lista } = useQuery({
    queryKey: ["crm-periodos"],
    queryFn: () => fetchPeriodos({} as any),
  });

  const [sel, setSel] = useState<string>("");
  useEffect(() => {
    if (modo === "actual" && !sel && lista?.vigente)
      setSel(`${lista.vigente.anio}-${lista.vigente.mes}`);
  }, [lista, sel, modo]);

  const cerrados = useMemo(
    () => (lista?.periodos ?? []).filter((p: any) => p.estado === "CERRADO"),
    [lista],
  );

  const [anio, mes] = sel ? sel.split("-").map(Number) : [0, 0];

  const { data, isFetching } = useQuery({
    queryKey: ["crm-aff-periodo", legajo, sel],
    queryFn: () => fetchDatos({ data: { legajo, mes, anio } }),
    enabled: !!legajo && !!mes && !!anio,
  });

  const [abiertos, setAbiertos] = useState<Record<string, boolean>>({});
  const [origenes, setOrigenes] = useState<Record<string, boolean>>({});

  const porServicio = data?.por_servicio ?? [];
  const movsPorServicio = useMemo(() => {
    const map = new Map<string, any[]>();
    for (const m of data?.movimientos ?? []) {
      const arr = map.get(m.servicio) ?? [];
      arr.push(m);
      map.set(m.servicio, arr);
    }
    return map;
  }, [data]);

  function exportar() {
    if (!data) return;
    try {
      const wb = XLSX.utils.book_new();
      const filas = data.movimientos.map((m: any) => ({
        Período: data.periodo.label,
        Desde: data.desde,
        Hasta: data.hasta,
        Legajo: data.legajo,
        Afiliado: data.afiliado?.apellido_nombre ?? "",
        Servicio: m.servicio,
        "Origen / Proveedor": m.origen,
        Detalle: m.detalle,
        Fecha: m.fecha ?? "",
        "Ticket / Referencia": m.referencia ?? "",
        Cuota: m.cuota ?? "",
        "Cantidad de cuotas": m.cuotas,
        Importe: m.importe,
        Plan: m.servicio === "Refinanciación" ? m.detalle : "",
        "Orígenes de la refinanciación": (m.origenes ?? [])
          .map(
            (o: any) =>
              `${o.servicio ?? "—"} | ${o.detalle ?? "—"} | ${o.periodo ?? "—"} | ${o.importe}`,
          )
          .join(" ;; "),
      }));
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(filas), "Movimientos");

      const resumen = [
        ...porServicio.map((s: any) => ({
          Período: data.periodo.label,
          Servicio: s.servicio,
          Movimientos: s.movimientos,
          Subtotal: s.total,
        })),
        { Período: data.periodo.label, Servicio: "TOTAL DEL PERÍODO", Movimientos: data.movimientos.length, Subtotal: data.total },
      ];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(resumen), "Resumen");

      if (data.liquidado.length) {
        XLSX.utils.book_append_sheet(
          wb,
          XLSX.utils.json_to_sheet([
            ...data.liquidado.map((l: any) => ({ Servicio: l.servicio, Liquidado: l.importe })),
            { Servicio: "TOTAL LIQUIDADO", Liquidado: data.liquidado_total },
          ]),
          "Liquidado (histórico)",
        );
      }

      XLSX.writeFile(wb, `consumos-${data.legajo}-${anio}${String(mes).padStart(2, "0")}.xlsx`);
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo exportar");
    }
  }

  function imprimir() {
    document.body.classList.add("printing-crm");
    const limpiar = () => {
      document.body.classList.remove("printing-crm");
      window.removeEventListener("afterprint", limpiar);
    };
    window.addEventListener("afterprint", limpiar);
    window.print();
    setTimeout(limpiar, 1500);
  }

  const esActual = modo === "actual";

  return (
    <Card className={`crm-print-root ${esActual ? "border-primary/60 shadow-sm" : "bg-accent/30"}`}>
      <CardHeader className="gap-3">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <CardTitle className={esActual ? "text-lg" : "text-base"}>
              {esActual
                ? "Período vigente · qué tiene para descontar ahora"
                : "Períodos históricos cerrados"}
            </CardTitle>
            <CardDescription>
              {esActual
                ? "Período administrativo AGOEC del día 21 al día 20. Cada importe muestra su origen real."
                : "Fotografía de lo liquidado. Elegí un período para ver subtotales y orígenes."}
            </CardDescription>
          </div>
          <div className="flex items-center gap-2 print-hide">
            {esActual ? null : (
              <Select value={sel} onValueChange={setSel}>
                <SelectTrigger className="w-[220px]">
                  <SelectValue placeholder="Período cerrado" />
                </SelectTrigger>
                <SelectContent>
                  {cerrados.map((p: any) => (
                    <SelectItem key={`${p.anio}-${p.mes}`} value={`${p.anio}-${p.mes}`}>
                      {formatPeriodo(p.mes, p.anio)} · cerrado
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            <Button variant="outline" size="sm" onClick={exportar} disabled={!data}>
              <Download className="h-4 w-4" /> Excel
            </Button>
            <Button variant="outline" size="sm" onClick={imprimir} disabled={!data}>
              <Printer className="h-4 w-4" /> Imprimir
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="print-only mb-2 text-sm">
          <p className="font-semibold">AGOEC · Consulta de consumos del afiliado</p>
        </div>

        {!esActual ? (
          <div className="overflow-hidden rounded-lg border print-hide">
            {!cerrados.length ? (
              <p className="p-3 text-sm text-muted-foreground">
                Todavía no hay períodos cerrados para consultar.
              </p>
            ) : (
              cerrados.map((p: any, i: number) => {
                const val = `${p.anio}-${p.mes}`;
                const activo = sel === val;
                return (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setSel(activo ? "" : val)}
                    className={`flex w-full items-center justify-between px-3 py-2 text-left text-sm ${
                      i % 2 === 0 ? "bg-background" : "bg-accent/40"
                    } ${activo ? "font-semibold" : ""}`}
                  >
                    <span className="flex items-center gap-2">
                      {activo ? (
                        <ChevronDown className="h-4 w-4" />
                      ) : (
                        <ChevronRight className="h-4 w-4" />
                      )}
                      {formatPeriodo(p.mes, p.anio)}
                    </span>
                    <span className="text-muted-foreground">
                      {activo && data ? currency.format(data.total) : "cerrado"}
                    </span>
                  </button>
                );
              })
            )}
          </div>
        ) : null}

        {isFetching && !data ? (
          <p className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Cargando período…
          </p>
        ) : !data ? null : (
          <>
            {/* Cabecera */}
            <div className={`rounded-lg border p-3 text-sm ${esActual ? "bg-accent/40" : ""}`}>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                <span className="font-mono font-semibold">{data.legajo}</span>
                <span className="font-semibold">{data.afiliado?.apellido_nombre ?? "—"}</span>
                {data.afiliado?.cuil ? <span className="text-muted-foreground">CUIL {data.afiliado.cuil}</span> : null}
                {data.afiliado?.lugar_trabajo ? (
                  <span className="text-muted-foreground">{data.afiliado.lugar_trabajo}</span>
                ) : null}
                <Badge variant={data.estado === "CERRADO" ? "secondary" : "default"}>{data.estado}</Badge>
              </div>
              <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-muted-foreground">
                <span>
                  Período {formatPeriodo(data.periodo.mes, data.periodo.anio)} · {data.desde} a {data.hasta}
                </span>
                {data.estado === "ABIERTO" && data.corte !== data.hasta ? (
                  <span>Acumulado hasta {data.corte}</span>
                ) : null}
              </div>
              <p
                className={`mt-2 font-semibold text-foreground ${esActual ? "text-2xl" : "text-base"}`}
              >
                Total del período: {currency.format(data.total)}
              </p>
              {data.cierres.length ? (
                <p className="mt-1 text-xs text-muted-foreground">
                  Liquidado en: {data.cierres.map((c: any) => c.nombre).join(" · ")}
                </p>
              ) : null}
            </div>


            {/* Resumen por servicio con detalle desplegable */}
            {!porServicio.length ? (
              <p className="text-sm text-muted-foreground">
                Este afiliado no tiene movimientos en el período seleccionado.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="text-left text-muted-foreground">
                    <tr className="border-b">
                      <th className="py-2 pr-3">Servicio</th>
                      <th className="py-2 pr-3">Movimientos</th>
                      <th className="py-2 pr-3">Subtotal</th>
                    </tr>
                  </thead>
                  <tbody>
                    {porServicio.map((s: any) => {
                      const open = !!abiertos[s.servicio];
                      const movs = movsPorServicio.get(s.servicio) ?? [];
                      return (
                        <Fragment key={s.servicio}>
                          <tr className="border-b">
                            <td className="py-1.5 pr-3">
                              <button
                                type="button"
                                className="flex items-center gap-1 font-medium"
                                onClick={() => setAbiertos((p) => ({ ...p, [s.servicio]: !open }))}
                              >
                                {open ? (
                                  <ChevronDown className="h-4 w-4" />
                                ) : (
                                  <ChevronRight className="h-4 w-4" />
                                )}
                                {s.servicio}
                              </button>
                            </td>
                            <td className="py-1.5 pr-3">{s.movimientos}</td>
                            <td className="py-1.5 pr-3 font-medium">{currency.format(s.total)}</td>
                          </tr>
                          {(open || true) && (
                            <tr className={open ? "" : "hidden print:table-row"}>
                              <td colSpan={3} className="pb-3">
                                <div className="overflow-x-auto rounded-md border">
                                  <table className="w-full text-xs">
                                    <thead className="text-left text-muted-foreground">
                                      <tr className="border-b">
                                        <th className="px-2 py-1.5">Origen / Proveedor</th>
                                        <th className="px-2 py-1.5">Detalle / Prestación</th>
                                        <th className="px-2 py-1.5">Fecha</th>
                                        <th className="px-2 py-1.5">Ticket / Ref.</th>
                                        <th className="px-2 py-1.5">Cuota</th>
                                        <th className="px-2 py-1.5">Importe</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {movs.map((m: any) => (
                                        <Fragment key={m.id}>
                                          <tr className="border-b last:border-0">
                                            <td className="px-2 py-1.5">{m.origen}</td>
                                            <td className="px-2 py-1.5">{m.detalle}</td>
                                            <td className="px-2 py-1.5">{m.fecha ?? "—"}</td>
                                            <td className="px-2 py-1.5">{m.referencia ?? "—"}</td>
                                            <td className="px-2 py-1.5">
                                              {m.cuota ? `${m.cuota}/${m.cuotas}` : "—"}
                                            </td>
                                            <td className="px-2 py-1.5 font-medium">
                                              {currency.format(m.importe)}
                                              {m.origenes?.length ? (
                                                <button
                                                  type="button"
                                                  className="ml-2 underline print-hide"
                                                  onClick={() =>
                                                    setOrigenes((p) => ({ ...p, [m.id]: !p[m.id] }))
                                                  }
                                                >
                                                  orígenes ({m.origenes.length})
                                                </button>
                                              ) : null}
                                            </td>
                                          </tr>
                                          {m.origenes?.length && (origenes[m.id] || false) ? (
                                            <tr className="border-b bg-muted/40">
                                              <td colSpan={6} className="px-2 py-1.5">
                                                <p className="mb-1 font-medium">
                                                  Orígenes incluidos en el plan
                                                </p>
                                                <ul className="space-y-0.5">
                                                  {m.origenes.map((o: any, i: number) => (
                                                    <li key={i}>
                                                      {o.servicio ?? "—"} · {o.detalle ?? "—"} ·{" "}
                                                      {o.periodo ?? "—"} · {currency.format(o.importe)}
                                                    </li>
                                                  ))}
                                                </ul>
                                              </td>
                                            </tr>
                                          ) : null}
                                        </Fragment>
                                      ))}
                                    </tbody>
                                  </table>
                                </div>
                              </td>
                            </tr>
                          )}
                        </Fragment>
                      );
                    })}
                    <tr className="border-t-2">
                      <td className="py-2 pr-3 font-semibold">TOTAL DEL PERÍODO</td>
                      <td className="py-2 pr-3 font-semibold">{data.movimientos.length}</td>
                      <td className="py-2 pr-3 font-semibold">{currency.format(data.total)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}

            {data.liquidado.length ? (
              <div>
                <h4 className="mb-1 text-sm font-semibold">
                  Fotografía histórica liquidada · {currency.format(data.liquidado_total)}
                </h4>
                <p className="mb-2 text-xs text-muted-foreground">
                  Importes tal como quedaron en el cierre del período (no se recalculan).
                </p>
                <table className="w-full text-sm">
                  <tbody>
                    {data.liquidado.map((l: any) => (
                      <tr key={l.servicio} className="border-b last:border-0">
                        <td className="py-1.5 pr-3">{l.servicio}</td>
                        <td className="py-1.5 font-medium">{currency.format(l.importe)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : null}
          </>
        )}
      </CardContent>
    </Card>
  );
}
