import { useMemo, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, CheckCircle2, FileSpreadsheet, X } from "lucide-react";
import { MESES, periodoError } from "@/lib/periodo";

export type PreviewRow = {
  legajo?: string;
  nombre?: string;
  importe?: number;
  cuotas?: number;
  detalle?: string;
  motivo?: string | null;
};

export type ImportPreviewData = {
  archivo?: string;
  descripcion?: string;
  filas: PreviewRow[];
  descartadas?: PreviewRow[];
  legajosDesconocidos?: string[];
};

const money = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });

type Props = {
  data: ImportPreviewData;
  mes: number;
  anio: number;
  onMes: (v: number) => void;
  onAnio: (v: number) => void;
  onConfirm: () => void;
  onCancel: () => void;
  confirmLabel?: string;
  loading?: boolean;
  /** Ocultar el editor de período cuando la pantalla usa otro esquema (ej. rango de períodos). */
  hidePeriodo?: boolean;
};

export function ImportPreview({
  data,
  mes,
  anio,
  onMes,
  onAnio,
  onConfirm,
  onCancel,
  confirmLabel = "Confirmar importación",
  loading,
  hidePeriodo,
}: Props) {
  const [busca, setBusca] = useState("");
  const err = hidePeriodo ? null : periodoError(mes, anio);

  const total = useMemo(() => data.filas.reduce((a, r) => a + (Number(r.importe) || 0), 0), [data.filas]);
  const cuotasSet = useMemo(
    () => Array.from(new Set(data.filas.map((r) => Number(r.cuotas) || 1))).sort((a, b) => a - b),
    [data.filas],
  );

  const visibles = useMemo(() => {
    const q = busca.trim().toLowerCase();
    const base = data.filas;
    if (!q) return base.slice(0, 50);
    return base
      .filter((r) => [r.legajo, r.nombre, r.detalle].filter(Boolean).some((v) => String(v).toLowerCase().includes(q)))
      .slice(0, 50);
  }, [data.filas, busca]);

  return (
    <Card className="border-primary/40">
      <CardHeader>
        <div className="flex items-start justify-between gap-3">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <FileSpreadsheet className="h-4 w-4 text-primary" />
              Previsualización de la importación
            </CardTitle>
            <CardDescription>
              Revisá los datos detectados{data.archivo ? ` en ${data.archivo}` : ""} antes de confirmar. Nada se guarda
              hasta que confirmes.
            </CardDescription>
          </div>
          <Button variant="ghost" size="icon" onClick={onCancel} aria-label="Cancelar importación">
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-4">
          <div className="rounded-lg border p-3">
            <p className="text-xs text-muted-foreground">Descripción detectada</p>
            <p className="font-medium">{data.descripcion || "—"}</p>
          </div>
          <div className="rounded-lg border p-3">
            <p className="text-xs text-muted-foreground">Filas válidas</p>
            <p className="font-medium">{data.filas.length}</p>
          </div>
          <div className="rounded-lg border p-3">
            <p className="text-xs text-muted-foreground">Total importado</p>
            <p className="font-medium">{money.format(total)}</p>
          </div>
          <div className="rounded-lg border p-3">
            <p className="text-xs text-muted-foreground">Cuotas detectadas</p>
            <p className="font-medium">{cuotasSet.length ? cuotasSet.join(", ") : "—"}</p>
          </div>
        </div>

        {!hidePeriodo && (
          <div className={`rounded-lg border p-3 ${err ? "border-destructive bg-destructive/5" : ""}`}>
            <p className="text-sm font-medium mb-2 flex items-center gap-2">
              Período a liquidar
              {err ? (
                <span className="text-destructive text-xs flex items-center gap-1">
                  <AlertTriangle className="h-3 w-3" /> {err}
                </span>
              ) : (
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <CheckCircle2 className="h-3 w-3 text-primary" /> {MESES[mes - 1]} {anio}
                </span>
              )}
            </p>
            <div className="grid gap-3 sm:grid-cols-2 max-w-md">
              <div>
                <Label className="text-xs">Mes</Label>
                <select
                  className="w-full h-10 rounded-md border bg-background px-3 text-sm"
                  value={mes || ""}
                  onChange={(e) => onMes(Number(e.target.value))}
                >
                  <option value="">Elegí el mes…</option>
                  {MESES.map((m, i) => (
                    <option key={m} value={i + 1}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <Label className="text-xs">Año</Label>
                <Input
                  type="number"
                  min={2000}
                  max={2100}
                  value={anio || ""}
                  onChange={(e) => onAnio(Number(e.target.value))}
                />
              </div>
            </div>
          </div>
        )}

        {!!data.legajosDesconocidos?.length && (
          <div className="rounded-lg border border-amber-500/50 bg-amber-500/5 p-3 text-sm">
            <p className="font-medium flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
              {data.legajosDesconocidos.length} legajo(s) no están en el padrón de afiliados
            </p>
            <p className="text-muted-foreground mt-1 break-words">{data.legajosDesconocidos.join(", ")}</p>
          </div>
        )}

        {!!data.descartadas?.length && (
          <div className="rounded-lg border p-3 text-sm">
            <p className="font-medium mb-2">{data.descartadas.length} fila(s) descartadas</p>
            <div className="max-h-40 overflow-auto space-y-1">
              {data.descartadas.slice(0, 30).map((r, i) => (
                <p key={i} className="text-muted-foreground">
                  {r.legajo || "(sin legajo)"} — {r.motivo || "fila incompleta"}
                </p>
              ))}
            </div>
          </div>
        )}

        <div>
          <Input
            placeholder="Buscar por legajo, nombre o detalle…"
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            className="max-w-sm mb-2"
          />
          <div className="border rounded-lg overflow-x-auto max-h-80 overflow-y-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 sticky top-0">
                <tr>
                  <th className="text-left p-2">Legajo</th>
                  <th className="text-left p-2">Nombre / Detalle</th>
                  <th className="text-right p-2">Importe</th>
                  <th className="text-right p-2">Cuotas</th>
                </tr>
              </thead>
              <tbody>
                {visibles.map((r, i) => (
                  <tr key={i} className="border-t">
                    <td className="p-2 font-mono">{r.legajo || "—"}</td>
                    <td className="p-2">{r.nombre || r.detalle || "—"}</td>
                    <td className="p-2 text-right">{money.format(Number(r.importe) || 0)}</td>
                    <td className="p-2 text-right">{r.cuotas ?? 1}</td>
                  </tr>
                ))}
                {!visibles.length && (
                  <tr>
                    <td className="p-3 text-center text-muted-foreground" colSpan={4}>
                      Sin filas para mostrar
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          {data.filas.length > visibles.length && (
            <p className="text-xs text-muted-foreground mt-1">
              Mostrando {visibles.length} de {data.filas.length} filas.
            </p>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          <Button onClick={onConfirm} disabled={!!err || !data.filas.length || loading}>
            {confirmLabel}
          </Button>
          <Button variant="outline" onClick={onCancel}>
            Cancelar
          </Button>
          {!!err && <Badge variant="destructive">Completá el período para poder confirmar</Badge>}
        </div>
      </CardContent>
    </Card>
  );
}
