import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Checkbox } from "@/components/ui/checkbox";
import { listPagosAdelantados, setPagoAdelantado } from "@/lib/pagos-adelantados.functions";

export function usePagosAdelantados() {
  const fn = useServerFn(listPagosAdelantados);
  return useQuery({ queryKey: ["pagos-adelantados"], queryFn: () => fn() });
}

/** Tilde "Pago adelantado / ya cobrado" para un pozo, agasajo o colecta. */
export function AdelantoToggle({
  refKey,
  tipo,
  legajo,
  detalle,
  importe = 0,
  label = "Pago adelantado",
}: {
  refKey: string;
  tipo: string;
  legajo?: string | null;
  detalle?: string | null;
  importe?: number;
  label?: string;
}) {
  const qc = useQueryClient();
  const { data } = usePagosAdelantados();
  const setFn = useServerFn(setPagoAdelantado);
  const reg = (data ?? []).find((a: any) => a.ref_key === refKey);
  const checked = !!reg;

  const toggle = async (v: boolean) => {
    try {
      await setFn({ data: { ref_key: refKey, tipo, legajo, detalle, importe, marcar: v } });
      toast.success(v ? "Marcado como pagado por adelantado" : "Se quitó la marca de adelantado");
      qc.invalidateQueries({ queryKey: ["pagos-adelantados"] });
      qc.invalidateQueries({ queryKey: ["admin-dashboard"] });
    } catch (e: any) {
      toast.error(e?.message ?? "No se pudo guardar");
    }
  };

  return (
    <label
      className="inline-flex cursor-pointer items-center gap-2 text-xs"
      onClick={(e) => e.stopPropagation()}
      title={
        reg
          ? `Adelantado en ${String(reg.pagado_mes).padStart(2, "0")}/${reg.pagado_anio}${reg.pagado_por_email ? ` por ${reg.pagado_por_email}` : ""}`
          : undefined
      }
    >
      <Checkbox checked={checked} onCheckedChange={(v) => toggle(!!v)} />
      <span className={checked ? "font-medium text-primary" : "text-muted-foreground"}>
        {checked ? "Ya pagado (adelantado)" : label}
      </span>
    </label>
  );
}
