export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      adelantos: {
        Row: {
          apellido_nombre: string | null
          banco: string | null
          cbu: string | null
          cbu2: string | null
          concepto: string
          created_at: string
          created_by: string | null
          cuenta: string | null
          cuil: string | null
          cuotas: number
          fecha: string | null
          id: string
          legajo: string
          monto_pedido: number
          observacion: string | null
          periodo_anio: number
          periodo_mes: number
          ref_id: string | null
          responsable: string | null
          updated_at: string
        }
        Insert: {
          apellido_nombre?: string | null
          banco?: string | null
          cbu?: string | null
          cbu2?: string | null
          concepto?: string
          created_at?: string
          created_by?: string | null
          cuenta?: string | null
          cuil?: string | null
          cuotas?: number
          fecha?: string | null
          id?: string
          legajo: string
          monto_pedido?: number
          observacion?: string | null
          periodo_anio: number
          periodo_mes: number
          ref_id?: string | null
          responsable?: string | null
          updated_at?: string
        }
        Update: {
          apellido_nombre?: string | null
          banco?: string | null
          cbu?: string | null
          cbu2?: string | null
          concepto?: string
          created_at?: string
          created_by?: string | null
          cuenta?: string | null
          cuil?: string | null
          cuotas?: number
          fecha?: string | null
          id?: string
          legajo?: string
          monto_pedido?: number
          observacion?: string | null
          periodo_anio?: number
          periodo_mes?: number
          ref_id?: string | null
          responsable?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      advance_periods: {
        Row: {
          cerrado_at: string | null
          cerrado_por: string | null
          created_at: string
          created_by: string | null
          descripcion: string
          estado: string
          id: string
          periodo_anio: number
          periodo_mes: number
          reabierto_at: string | null
          reabierto_por: string | null
          reaperturas: number
          snapshot: Json | null
          total_adelantos: number
          total_cuotas_adelantos: number
          total_cuotas_refinanciacion: number
          total_general: number
          total_legajos: number
          total_solicitado: number
          updated_at: string
        }
        Insert: {
          cerrado_at?: string | null
          cerrado_por?: string | null
          created_at?: string
          created_by?: string | null
          descripcion?: string
          estado?: string
          id?: string
          periodo_anio: number
          periodo_mes: number
          reabierto_at?: string | null
          reabierto_por?: string | null
          reaperturas?: number
          snapshot?: Json | null
          total_adelantos?: number
          total_cuotas_adelantos?: number
          total_cuotas_refinanciacion?: number
          total_general?: number
          total_legajos?: number
          total_solicitado?: number
          updated_at?: string
        }
        Update: {
          cerrado_at?: string | null
          cerrado_por?: string | null
          created_at?: string
          created_by?: string | null
          descripcion?: string
          estado?: string
          id?: string
          periodo_anio?: number
          periodo_mes?: number
          reabierto_at?: string | null
          reabierto_por?: string | null
          reaperturas?: number
          snapshot?: Json | null
          total_adelantos?: number
          total_cuotas_adelantos?: number
          total_cuotas_refinanciacion?: number
          total_general?: number
          total_legajos?: number
          total_solicitado?: number
          updated_at?: string
        }
        Relationships: []
      }
      affiliate_pin_status: {
        Row: {
          created_at: string
          legajo: string | null
          must_change_pin: boolean
          pin_changed_at: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          legajo?: string | null
          must_change_pin?: boolean
          pin_changed_at?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          legajo?: string | null
          must_change_pin?: boolean
          pin_changed_at?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      affiliates: {
        Row: {
          apellido_nombre: string
          calle: string | null
          celular: string | null
          codigo_lugar_trabajo: string | null
          cp: string | null
          created_at: string
          cuil: string | null
          depto: string | null
          doc_nro: string | null
          estado_civil: string | null
          fecha_afiliacion: string | null
          fecha_ingreso: string | null
          fecha_nac: string | null
          legajo: string
          localidad: string | null
          lugar_trabajo: string | null
          numero: string | null
          observaciones: string | null
          piso: string | null
          sector: string | null
          sexo: string | null
          telefono: string | null
          tipo_doc: string | null
          user_id: string | null
        }
        Insert: {
          apellido_nombre: string
          calle?: string | null
          celular?: string | null
          codigo_lugar_trabajo?: string | null
          cp?: string | null
          created_at?: string
          cuil?: string | null
          depto?: string | null
          doc_nro?: string | null
          estado_civil?: string | null
          fecha_afiliacion?: string | null
          fecha_ingreso?: string | null
          fecha_nac?: string | null
          legajo: string
          localidad?: string | null
          lugar_trabajo?: string | null
          numero?: string | null
          observaciones?: string | null
          piso?: string | null
          sector?: string | null
          sexo?: string | null
          telefono?: string | null
          tipo_doc?: string | null
          user_id?: string | null
        }
        Update: {
          apellido_nombre?: string
          calle?: string | null
          celular?: string | null
          codigo_lugar_trabajo?: string | null
          cp?: string | null
          created_at?: string
          cuil?: string | null
          depto?: string | null
          doc_nro?: string | null
          estado_civil?: string | null
          fecha_afiliacion?: string | null
          fecha_ingreso?: string | null
          fecha_nac?: string | null
          legajo?: string
          localidad?: string | null
          lugar_trabajo?: string | null
          numero?: string | null
          observaciones?: string | null
          piso?: string | null
          sector?: string | null
          sexo?: string | null
          telefono?: string | null
          tipo_doc?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      audit_events: {
        Row: {
          accion: string
          created_at: string
          entidad: string
          entidad_id: string | null
          id: string
          legajo: string | null
          nota: string | null
          user_email: string | null
          user_id: string | null
          valor_anterior: Json | null
          valor_nuevo: Json | null
        }
        Insert: {
          accion: string
          created_at?: string
          entidad: string
          entidad_id?: string | null
          id?: string
          legajo?: string | null
          nota?: string | null
          user_email?: string | null
          user_id?: string | null
          valor_anterior?: Json | null
          valor_nuevo?: Json | null
        }
        Update: {
          accion?: string
          created_at?: string
          entidad?: string
          entidad_id?: string | null
          id?: string
          legajo?: string | null
          nota?: string | null
          user_email?: string | null
          user_id?: string | null
          valor_anterior?: Json | null
          valor_nuevo?: Json | null
        }
        Relationships: []
      }
      birthday_members: {
        Row: {
          apellido_nombre: string | null
          created_at: string
          cuotas: Json
          fecha_cobro: string | null
          id: string
          legajo: string
          observacion: string | null
          plan_id: string
          total: number
        }
        Insert: {
          apellido_nombre?: string | null
          created_at?: string
          cuotas?: Json
          fecha_cobro?: string | null
          id?: string
          legajo: string
          observacion?: string | null
          plan_id: string
          total?: number
        }
        Update: {
          apellido_nombre?: string | null
          created_at?: string
          cuotas?: Json
          fecha_cobro?: string | null
          id?: string
          legajo?: string
          observacion?: string | null
          plan_id?: string
          total?: number
        }
        Relationships: [
          {
            foreignKeyName: "birthday_members_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "birthday_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      birthday_plans: {
        Row: {
          created_at: string
          id: string
          importe_total: number
          nombre: string
          observacion: string | null
          periodo_fin: number | null
          periodo_inicio: number | null
          product_id: string | null
          service_id: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          importe_total?: number
          nombre: string
          observacion?: string | null
          periodo_fin?: number | null
          periodo_inicio?: number | null
          product_id?: string | null
          service_id?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          importe_total?: number
          nombre?: string
          observacion?: string | null
          periodo_fin?: number | null
          periodo_inicio?: number | null
          product_id?: string | null
          service_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "birthday_plans_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "service_products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "birthday_plans_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      circle_members: {
        Row: {
          anio_cobro: number | null
          apellido_nombre: string | null
          circle_id: string
          created_at: string
          fecha_cobro: string | null
          id: string
          importe_mensual: number
          legajo: string
          mes_cobro: number | null
          observacion: string | null
        }
        Insert: {
          anio_cobro?: number | null
          apellido_nombre?: string | null
          circle_id: string
          created_at?: string
          fecha_cobro?: string | null
          id?: string
          importe_mensual?: number
          legajo: string
          mes_cobro?: number | null
          observacion?: string | null
        }
        Update: {
          anio_cobro?: number | null
          apellido_nombre?: string | null
          circle_id?: string
          created_at?: string
          fecha_cobro?: string | null
          id?: string
          importe_mensual?: number
          legajo?: string
          mes_cobro?: number | null
          observacion?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "circle_members_circle_id_fkey"
            columns: ["circle_id"]
            isOneToOne: false
            referencedRelation: "circles"
            referencedColumns: ["id"]
          },
        ]
      }
      circles: {
        Row: {
          created_at: string
          fecha_fin: string | null
          fecha_inicio: string | null
          id: string
          importe: number
          nombre: string
          numero: string | null
          observacion: string | null
          periodo_fin: number | null
          periodo_inicio: number | null
          product_id: string | null
          service_id: string | null
        }
        Insert: {
          created_at?: string
          fecha_fin?: string | null
          fecha_inicio?: string | null
          id?: string
          importe?: number
          nombre: string
          numero?: string | null
          observacion?: string | null
          periodo_fin?: number | null
          periodo_inicio?: number | null
          product_id?: string | null
          service_id?: string | null
        }
        Update: {
          created_at?: string
          fecha_fin?: string | null
          fecha_inicio?: string | null
          id?: string
          importe?: number
          nombre?: string
          numero?: string | null
          observacion?: string | null
          periodo_fin?: number | null
          periodo_inicio?: number | null
          product_id?: string | null
          service_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "circles_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "service_products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "circles_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      collection_members: {
        Row: {
          apellido_nombre: string | null
          collection_id: string
          created_at: string
          cuotas: number
          id: string
          importe_cuota: number
          importe_total: number
          legajo: string
          observacion: string | null
        }
        Insert: {
          apellido_nombre?: string | null
          collection_id: string
          created_at?: string
          cuotas?: number
          id?: string
          importe_cuota?: number
          importe_total?: number
          legajo: string
          observacion?: string | null
        }
        Update: {
          apellido_nombre?: string | null
          collection_id?: string
          created_at?: string
          cuotas?: number
          id?: string
          importe_cuota?: number
          importe_total?: number
          legajo?: string
          observacion?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "collection_members_collection_id_fkey"
            columns: ["collection_id"]
            isOneToOne: false
            referencedRelation: "collections"
            referencedColumns: ["id"]
          },
        ]
      }
      collections: {
        Row: {
          anio_inicio: number | null
          beneficiario_legajo: string | null
          beneficiario_nombre: string | null
          cerrada: boolean
          created_at: string
          cuotas: number
          fecha: string | null
          id: string
          importe_objetivo: number
          mes_inicio: number | null
          motivo: string | null
          nombre: string
          observacion: string | null
          product_id: string | null
          service_id: string | null
          updated_at: string
        }
        Insert: {
          anio_inicio?: number | null
          beneficiario_legajo?: string | null
          beneficiario_nombre?: string | null
          cerrada?: boolean
          created_at?: string
          cuotas?: number
          fecha?: string | null
          id?: string
          importe_objetivo?: number
          mes_inicio?: number | null
          motivo?: string | null
          nombre: string
          observacion?: string | null
          product_id?: string | null
          service_id?: string | null
          updated_at?: string
        }
        Update: {
          anio_inicio?: number | null
          beneficiario_legajo?: string | null
          beneficiario_nombre?: string | null
          cerrada?: boolean
          created_at?: string
          cuotas?: number
          fecha?: string | null
          id?: string
          importe_objetivo?: number
          mes_inicio?: number | null
          motivo?: string | null
          nombre?: string
          observacion?: string | null
          product_id?: string | null
          service_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "collections_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "service_products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "collections_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      daily_consumptions: {
        Row: {
          almuerzo: boolean
          created_at: string
          daily_form_id: string
          desayuno: boolean
          id: string
          importe: number | null
          legajo: string
          no_paga: boolean
          observacion: string | null
        }
        Insert: {
          almuerzo?: boolean
          created_at?: string
          daily_form_id: string
          desayuno?: boolean
          id?: string
          importe?: number | null
          legajo: string
          no_paga?: boolean
          observacion?: string | null
        }
        Update: {
          almuerzo?: boolean
          created_at?: string
          daily_form_id?: string
          desayuno?: boolean
          id?: string
          importe?: number | null
          legajo?: string
          no_paga?: boolean
          observacion?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "daily_consumptions_daily_form_id_fkey"
            columns: ["daily_form_id"]
            isOneToOne: false
            referencedRelation: "daily_forms"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "daily_consumptions_legajo_fkey"
            columns: ["legajo"]
            isOneToOne: false
            referencedRelation: "affiliates"
            referencedColumns: ["legajo"]
          },
        ]
      }
      daily_forms: {
        Row: {
          created_at: string
          created_by: string | null
          descripcion_comida: string | null
          es_cumpleanos: boolean
          fecha: string
          foto_url: string | null
          id: string
          importe: number | null
          observacion: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          descripcion_comida?: string | null
          es_cumpleanos?: boolean
          fecha: string
          foto_url?: string | null
          id?: string
          importe?: number | null
          observacion?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          descripcion_comida?: string | null
          es_cumpleanos?: boolean
          fecha?: string
          foto_url?: string | null
          id?: string
          importe?: number | null
          observacion?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      monthly_settlements: {
        Row: {
          anio: number
          generado_at: string
          id: string
          importe_por_consumo: number
          importe_total: number
          mes: number
          total_consumos: number
        }
        Insert: {
          anio: number
          generado_at?: string
          id?: string
          importe_por_consumo: number
          importe_total: number
          mes: number
          total_consumos: number
        }
        Update: {
          anio?: number
          generado_at?: string
          id?: string
          importe_por_consumo?: number
          importe_total?: number
          mes?: number
          total_consumos?: number
        }
        Relationships: []
      }
      pagos_adelantados: {
        Row: {
          created_at: string
          detalle: string | null
          id: string
          importe: number
          legajo: string | null
          nota: string | null
          pagado_anio: number | null
          pagado_mes: number | null
          pagado_por: string | null
          pagado_por_email: string | null
          ref_key: string
          tipo: string
        }
        Insert: {
          created_at?: string
          detalle?: string | null
          id?: string
          importe?: number
          legajo?: string | null
          nota?: string | null
          pagado_anio?: number | null
          pagado_mes?: number | null
          pagado_por?: string | null
          pagado_por_email?: string | null
          ref_key: string
          tipo: string
        }
        Update: {
          created_at?: string
          detalle?: string | null
          id?: string
          importe?: number
          legajo?: string | null
          nota?: string | null
          pagado_anio?: number | null
          pagado_mes?: number | null
          pagado_por?: string | null
          pagado_por_email?: string | null
          ref_key?: string
          tipo?: string
        }
        Relationships: []
      }
      payroll_consumed: {
        Row: {
          created_at: string
          id: string
          period_id: string
          source_key: string
        }
        Insert: {
          created_at?: string
          id?: string
          period_id: string
          source_key: string
        }
        Update: {
          created_at?: string
          id?: string
          period_id?: string
          source_key?: string
        }
        Relationships: [
          {
            foreignKeyName: "payroll_consumed_period_id_fkey"
            columns: ["period_id"]
            isOneToOne: false
            referencedRelation: "payroll_periods"
            referencedColumns: ["id"]
          },
        ]
      }
      payroll_period_items: {
        Row: {
          apellido_nombre: string | null
          created_at: string
          cuenta_contable: string | null
          id: string
          importe: number
          legajo: string
          period_id: string
          servicio: string
        }
        Insert: {
          apellido_nombre?: string | null
          created_at?: string
          cuenta_contable?: string | null
          id?: string
          importe?: number
          legajo: string
          period_id: string
          servicio: string
        }
        Update: {
          apellido_nombre?: string | null
          created_at?: string
          cuenta_contable?: string | null
          id?: string
          importe?: number
          legajo?: string
          period_id?: string
          servicio?: string
        }
        Relationships: [
          {
            foreignKeyName: "payroll_period_items_period_id_fkey"
            columns: ["period_id"]
            isOneToOne: false
            referencedRelation: "payroll_periods"
            referencedColumns: ["id"]
          },
        ]
      }
      payroll_periods: {
        Row: {
          cerrado_at: string | null
          concepto_key: string | null
          concepto_nombre: string | null
          created_at: string
          created_by: string | null
          desde: string
          estado: string
          hasta: string
          id: string
          nombre: string
          total_afiliados: number
          total_descuento: number
          updated_at: string
        }
        Insert: {
          cerrado_at?: string | null
          concepto_key?: string | null
          concepto_nombre?: string | null
          created_at?: string
          created_by?: string | null
          desde: string
          estado?: string
          hasta: string
          id?: string
          nombre: string
          total_afiliados?: number
          total_descuento?: number
          updated_at?: string
        }
        Update: {
          cerrado_at?: string | null
          concepto_key?: string | null
          concepto_nombre?: string | null
          created_at?: string
          created_by?: string | null
          desde?: string
          estado?: string
          hasta?: string
          id?: string
          nombre?: string
          total_afiliados?: number
          total_descuento?: number
          updated_at?: string
        }
        Relationships: []
      }
      provider_messages: {
        Row: {
          asunto: string | null
          autor_user_id: string | null
          created_at: string
          desde_admin: boolean
          id: string
          leido: boolean
          mensaje: string
          provider_id: string
        }
        Insert: {
          asunto?: string | null
          autor_user_id?: string | null
          created_at?: string
          desde_admin?: boolean
          id?: string
          leido?: boolean
          mensaje: string
          provider_id: string
        }
        Update: {
          asunto?: string | null
          autor_user_id?: string | null
          created_at?: string
          desde_admin?: boolean
          id?: string
          leido?: boolean
          mensaje?: string
          provider_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "provider_messages_provider_id_fkey"
            columns: ["provider_id"]
            isOneToOne: false
            referencedRelation: "providers"
            referencedColumns: ["id"]
          },
        ]
      }
      provider_prestaciones: {
        Row: {
          activo: boolean
          comision_pct: number
          created_at: string
          id: string
          nombre: string
          provider_id: string
          updated_at: string
        }
        Insert: {
          activo?: boolean
          comision_pct?: number
          created_at?: string
          id?: string
          nombre: string
          provider_id: string
          updated_at?: string
        }
        Update: {
          activo?: boolean
          comision_pct?: number
          created_at?: string
          id?: string
          nombre?: string
          provider_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "provider_prestaciones_provider_id_fkey"
            columns: ["provider_id"]
            isOneToOne: false
            referencedRelation: "providers"
            referencedColumns: ["id"]
          },
        ]
      }
      provider_submissions: {
        Row: {
          created_at: string
          estado: string
          factura: string | null
          id: string
          nombre: string
          observacion: string | null
          periodo_anio: number
          periodo_mes: number
          provider_id: string
          service_id: string
          total_a_pagar: number
          total_afiliados: number
          total_comision: number
          total_importe: number
          total_items: number
          total_neto: number
          total_subsidio: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          estado?: string
          factura?: string | null
          id?: string
          nombre: string
          observacion?: string | null
          periodo_anio: number
          periodo_mes: number
          provider_id: string
          service_id: string
          total_a_pagar?: number
          total_afiliados?: number
          total_comision?: number
          total_importe?: number
          total_items?: number
          total_neto?: number
          total_subsidio?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          estado?: string
          factura?: string | null
          id?: string
          nombre?: string
          observacion?: string | null
          periodo_anio?: number
          periodo_mes?: number
          provider_id?: string
          service_id?: string
          total_a_pagar?: number
          total_afiliados?: number
          total_comision?: number
          total_importe?: number
          total_items?: number
          total_neto?: number
          total_subsidio?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "provider_submissions_provider_id_fkey"
            columns: ["provider_id"]
            isOneToOne: false
            referencedRelation: "providers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "provider_submissions_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      providers: {
        Row: {
          alias: string | null
          banco: string | null
          cbu: string | null
          created_at: string
          cuenta_contable: string | null
          cuit: string | null
          email: string | null
          habilitado: boolean
          id: string
          interno: boolean
          nombre: string
          product_id: string | null
          service_id: string
          tipo: string
          titular: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          alias?: string | null
          banco?: string | null
          cbu?: string | null
          created_at?: string
          cuenta_contable?: string | null
          cuit?: string | null
          email?: string | null
          habilitado?: boolean
          id?: string
          interno?: boolean
          nombre: string
          product_id?: string | null
          service_id: string
          tipo?: string
          titular?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          alias?: string | null
          banco?: string | null
          cbu?: string | null
          created_at?: string
          cuenta_contable?: string | null
          cuit?: string | null
          email?: string | null
          habilitado?: boolean
          id?: string
          interno?: boolean
          nombre?: string
          product_id?: string | null
          service_id?: string
          tipo?: string
          titular?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "providers_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "service_products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "providers_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      refinanciacion_items: {
        Row: {
          created_at: string
          detalle: string | null
          id: string
          importe: number
          periodo: string | null
          refinanciacion_id: string
          servicio: string | null
          source_key: string
        }
        Insert: {
          created_at?: string
          detalle?: string | null
          id?: string
          importe?: number
          periodo?: string | null
          refinanciacion_id: string
          servicio?: string | null
          source_key: string
        }
        Update: {
          created_at?: string
          detalle?: string | null
          id?: string
          importe?: number
          periodo?: string | null
          refinanciacion_id?: string
          servicio?: string | null
          source_key?: string
        }
        Relationships: [
          {
            foreignKeyName: "refinanciacion_items_refinanciacion_id_fkey"
            columns: ["refinanciacion_id"]
            isOneToOne: false
            referencedRelation: "refinanciaciones"
            referencedColumns: ["id"]
          },
        ]
      }
      refinanciaciones: {
        Row: {
          apellido_nombre: string | null
          consolidada_at: string | null
          consolidada_por: string | null
          created_at: string
          created_by: string | null
          cuotas: number
          cuotas_cobradas: number | null
          cuotas_efectivas: number | null
          estado: string
          id: string
          legajo: string
          observacion: string | null
          origen: string
          periodo_anio: number
          periodo_mes: number
          reemplaza_a: string | null
          reemplazada_por: string | null
          saldo_incorporado: number
          total: number
          updated_at: string
        }
        Insert: {
          apellido_nombre?: string | null
          consolidada_at?: string | null
          consolidada_por?: string | null
          created_at?: string
          created_by?: string | null
          cuotas?: number
          cuotas_cobradas?: number | null
          cuotas_efectivas?: number | null
          estado?: string
          id?: string
          legajo: string
          observacion?: string | null
          origen?: string
          periodo_anio: number
          periodo_mes: number
          reemplaza_a?: string | null
          reemplazada_por?: string | null
          saldo_incorporado?: number
          total?: number
          updated_at?: string
        }
        Update: {
          apellido_nombre?: string | null
          consolidada_at?: string | null
          consolidada_por?: string | null
          created_at?: string
          created_by?: string | null
          cuotas?: number
          cuotas_cobradas?: number | null
          cuotas_efectivas?: number | null
          estado?: string
          id?: string
          legajo?: string
          observacion?: string | null
          origen?: string
          periodo_anio?: number
          periodo_mes?: number
          reemplaza_a?: string | null
          reemplazada_por?: string | null
          saldo_incorporado?: number
          total?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "refinanciaciones_reemplaza_a_fkey"
            columns: ["reemplaza_a"]
            isOneToOne: false
            referencedRelation: "refinanciaciones"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "refinanciaciones_reemplazada_por_fkey"
            columns: ["reemplazada_por"]
            isOneToOne: false
            referencedRelation: "refinanciaciones"
            referencedColumns: ["id"]
          },
        ]
      }
      service_products: {
        Row: {
          activo: boolean
          codigo: string | null
          created_at: string
          cuenta_contable: string | null
          descripcion: string | null
          id: string
          nombre: string
          service_id: string
          tipo: string
        }
        Insert: {
          activo?: boolean
          codigo?: string | null
          created_at?: string
          cuenta_contable?: string | null
          descripcion?: string | null
          id?: string
          nombre: string
          service_id: string
          tipo?: string
        }
        Update: {
          activo?: boolean
          codigo?: string | null
          created_at?: string
          cuenta_contable?: string | null
          descripcion?: string | null
          id?: string
          nombre?: string
          service_id?: string
          tipo?: string
        }
        Relationships: [
          {
            foreignKeyName: "service_products_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      services: {
        Row: {
          activo: boolean
          campos_requeridos: Json
          codigo: string
          created_at: string
          cuenta_contable: string | null
          descripcion: string | null
          id: string
          nombre: string
          permite_cumpleanos: boolean
          permite_cuotas: boolean
          subsidio_receta_pct: number
          updated_at: string
          usa_receta: boolean
        }
        Insert: {
          activo?: boolean
          campos_requeridos?: Json
          codigo: string
          created_at?: string
          cuenta_contable?: string | null
          descripcion?: string | null
          id?: string
          nombre: string
          permite_cumpleanos?: boolean
          permite_cuotas?: boolean
          subsidio_receta_pct?: number
          updated_at?: string
          usa_receta?: boolean
        }
        Update: {
          activo?: boolean
          campos_requeridos?: Json
          codigo?: string
          created_at?: string
          cuenta_contable?: string | null
          descripcion?: string | null
          id?: string
          nombre?: string
          permite_cumpleanos?: boolean
          permite_cuotas?: boolean
          subsidio_receta_pct?: number
          updated_at?: string
          usa_receta?: boolean
        }
        Relationships: []
      }
      settlement_days: {
        Row: {
          created_at: string
          daily_form_id: string
          fecha: string
          id: string
          settlement_id: string
        }
        Insert: {
          created_at?: string
          daily_form_id: string
          fecha: string
          id?: string
          settlement_id: string
        }
        Update: {
          created_at?: string
          daily_form_id?: string
          fecha?: string
          id?: string
          settlement_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "settlement_days_daily_form_id_fkey"
            columns: ["daily_form_id"]
            isOneToOne: false
            referencedRelation: "daily_forms"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "settlement_days_settlement_id_fkey"
            columns: ["settlement_id"]
            isOneToOne: false
            referencedRelation: "settlements"
            referencedColumns: ["id"]
          },
        ]
      }
      settlement_events: {
        Row: {
          accion: string
          created_at: string
          id: string
          nota: string | null
          settlement_id: string
          user_email: string | null
          user_id: string | null
        }
        Insert: {
          accion: string
          created_at?: string
          id?: string
          nota?: string | null
          settlement_id: string
          user_email?: string | null
          user_id?: string | null
        }
        Update: {
          accion?: string
          created_at?: string
          id?: string
          nota?: string | null
          settlement_id?: string
          user_email?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "settlement_events_settlement_id_fkey"
            columns: ["settlement_id"]
            isOneToOne: false
            referencedRelation: "settlements"
            referencedColumns: ["id"]
          },
        ]
      }
      settlement_items: {
        Row: {
          almuerzos: number
          apellido_nombre: string
          consumos: number
          created_at: string
          desayunos: number
          id: string
          importe: number
          legajo: string
          settlement_id: string
        }
        Insert: {
          almuerzos?: number
          apellido_nombre: string
          consumos?: number
          created_at?: string
          desayunos?: number
          id?: string
          importe?: number
          legajo: string
          settlement_id: string
        }
        Update: {
          almuerzos?: number
          apellido_nombre?: string
          consumos?: number
          created_at?: string
          desayunos?: number
          id?: string
          importe?: number
          legajo?: string
          settlement_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "settlement_items_settlement_id_fkey"
            columns: ["settlement_id"]
            isOneToOne: false
            referencedRelation: "settlements"
            referencedColumns: ["id"]
          },
        ]
      }
      settlements: {
        Row: {
          cerrada_at: string | null
          cerrada_por: string | null
          created_at: string
          created_by: string | null
          desde: string | null
          dias_sin_importe: number
          diferencia: number
          estado: string
          exportada_at: string | null
          exportada_por: string | null
          fechas: string[]
          hasta: string | null
          id: string
          importe_cargado: number
          importe_total: number
          nombre: string
          periodo_anio: number | null
          periodo_mes: number | null
          reabierta_at: string | null
          reabierta_por: string | null
          reaperturas: number
          revisada_at: string | null
          revisada_por: string | null
          snapshot: Json | null
          total_afiliados: number
          total_consumos: number
          updated_at: string
        }
        Insert: {
          cerrada_at?: string | null
          cerrada_por?: string | null
          created_at?: string
          created_by?: string | null
          desde?: string | null
          dias_sin_importe?: number
          diferencia?: number
          estado?: string
          exportada_at?: string | null
          exportada_por?: string | null
          fechas?: string[]
          hasta?: string | null
          id?: string
          importe_cargado?: number
          importe_total?: number
          nombre: string
          periodo_anio?: number | null
          periodo_mes?: number | null
          reabierta_at?: string | null
          reabierta_por?: string | null
          reaperturas?: number
          revisada_at?: string | null
          revisada_por?: string | null
          snapshot?: Json | null
          total_afiliados?: number
          total_consumos?: number
          updated_at?: string
        }
        Update: {
          cerrada_at?: string | null
          cerrada_por?: string | null
          created_at?: string
          created_by?: string | null
          desde?: string | null
          dias_sin_importe?: number
          diferencia?: number
          estado?: string
          exportada_at?: string | null
          exportada_por?: string | null
          fechas?: string[]
          hasta?: string | null
          id?: string
          importe_cargado?: number
          importe_total?: number
          nombre?: string
          periodo_anio?: number | null
          periodo_mes?: number | null
          reabierta_at?: string | null
          reabierta_por?: string | null
          reaperturas?: number
          revisada_at?: string | null
          revisada_por?: string | null
          snapshot?: Json | null
          total_afiliados?: number
          total_consumos?: number
          updated_at?: string
        }
        Relationships: []
      }
      submission_items: {
        Row: {
          comision_monto: number
          comision_pct: number
          comprobante: string | null
          con_receta: boolean
          created_at: string
          cuotas: number
          cuotas_importes: Json | null
          detalle: string | null
          es_cumpleanos: boolean
          fecha: string | null
          id: string
          importe: number
          importe_afiliado: number
          legajo: string
          neto_proveedor: number | null
          prestacion: string | null
          provider_id: string
          service_id: string
          submission_id: string
          subsidio: number
        }
        Insert: {
          comision_monto?: number
          comision_pct?: number
          comprobante?: string | null
          con_receta?: boolean
          created_at?: string
          cuotas?: number
          cuotas_importes?: Json | null
          detalle?: string | null
          es_cumpleanos?: boolean
          fecha?: string | null
          id?: string
          importe?: number
          importe_afiliado?: number
          legajo: string
          neto_proveedor?: number | null
          prestacion?: string | null
          provider_id: string
          service_id: string
          submission_id: string
          subsidio?: number
        }
        Update: {
          comision_monto?: number
          comision_pct?: number
          comprobante?: string | null
          con_receta?: boolean
          created_at?: string
          cuotas?: number
          cuotas_importes?: Json | null
          detalle?: string | null
          es_cumpleanos?: boolean
          fecha?: string | null
          id?: string
          importe?: number
          importe_afiliado?: number
          legajo?: string
          neto_proveedor?: number | null
          prestacion?: string | null
          provider_id?: string
          service_id?: string
          submission_id?: string
          subsidio?: number
        }
        Relationships: [
          {
            foreignKeyName: "submission_items_provider_id_fkey"
            columns: ["provider_id"]
            isOneToOne: false
            referencedRelation: "providers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "submission_items_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "submission_items_submission_id_fkey"
            columns: ["submission_id"]
            isOneToOne: false
            referencedRelation: "provider_submissions"
            referencedColumns: ["id"]
          },
        ]
      }
      user_accounts: {
        Row: {
          autorizado: boolean
          clave_temporal: string | null
          email: string | null
          nota: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          autorizado?: boolean
          clave_temporal?: string | null
          email?: string | null
          nota?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          autorizado?: boolean
          clave_temporal?: string | null
          email?: string | null
          nota?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          legajo: string | null
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          legajo?: string | null
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          legajo?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      current_legajo: { Args: never; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      owns_provider: { Args: { _provider_id: string }; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "afiliado" | "proveedor"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "afiliado", "proveedor"],
    },
  },
} as const
