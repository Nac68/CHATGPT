import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

/** Lista de pagos a beneficiarios ya adelantados (círculos, cumpleaños, colectas). */
export const listPagosAdelantados = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { data, error } = await context.supabase.from("pagos_adelantados" as any).select("*");
    if (error) throw new Error(error.message);
    return (data ?? []) as any[];
  });

/** Marca o desmarca un pago como adelantado. Sólo afecta el egreso, nunca el descuento. */
export const setPagoAdelantado = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        ref_key: z.string().min(3).max(200),
        tipo: z.string().max(40),
        legajo: z.string().max(32).nullable().optional(),
        detalle: z.string().max(300).nullable().optional(),
        importe: z.number().default(0),
        marcar: z.boolean(),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const sb = context.supabase as any;
    if (!data.marcar) {
      const { error } = await sb.from("pagos_adelantados").delete().eq("ref_key", data.ref_key);
      if (error) throw new Error(error.message);
      return { ok: true };
    }
    const { periodoVigente } = await import("./periodo-vigente.server");
    const { mes, anio } = await periodoVigente();
    const email = (context as any).claims?.email ?? null;
    const { error } = await sb.from("pagos_adelantados").upsert(
      {
        ref_key: data.ref_key,
        tipo: data.tipo,
        legajo: data.legajo ?? null,
        detalle: data.detalle ?? null,
        importe: data.importe,
        pagado_mes: mes,
        pagado_anio: anio,
        pagado_por: context.userId,
        pagado_por_email: email,
      },
      { onConflict: "ref_key" },
    );
    if (error) throw new Error(error.message);
    return { ok: true };
  });
