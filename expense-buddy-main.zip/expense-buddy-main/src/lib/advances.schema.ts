import { z } from "zod";

export const adelantoSchema = z.object({
  id: z.string().uuid().optional(),
  legajo: z.string().trim().min(1).max(32),
  fecha: z.string().nullable().optional(),
  monto_pedido: z.number().positive(),
  cuotas: z.number().int().min(1).max(120).default(1),
  periodo_mes: z.number().int().min(1).max(12),
  periodo_anio: z.number().int().min(2000).max(2100),
  concepto: z.string().trim().max(120).default("ADELANTO"),
  responsable: z.string().trim().max(120).nullable().optional(),
  ref_id: z.string().trim().max(60).nullable().optional(),
  cuil: z.string().trim().max(30).nullable().optional(),
  banco: z.string().trim().max(120).nullable().optional(),
  cuenta: z.string().trim().max(60).nullable().optional(),
  cbu: z.string().trim().max(40).nullable().optional(),
  cbu2: z.string().trim().max(40).nullable().optional(),
  observacion: z.string().trim().max(300).nullable().optional(),
});