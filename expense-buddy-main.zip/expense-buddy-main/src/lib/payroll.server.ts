// Helpers server-only para la Liquidación por período (del ~20 de un mes al ~20 del siguiente).
// Cada concepto (servicio / subservicio) tiene su número contable y arma una columna del Excel.

export const r2 = (n: number) => Math.round((Number(n) || 0) * 100) / 100;

export type PayrollConcept = {
  key: string;
  nombre: string;
  cuenta_contable: string | null;
  total: number;
  afiliados: number;
};

export type PayrollRow = {
  legajo: string;
  apellido_nombre: string | null;
  por_concepto: Record<string, number>;
  total: number;
  keys: string[];
  /** source_keys agrupados por concepto, para poder cerrar servicio por servicio. */
  keys_por_concepto: Record<string, string[]>;
};


const ymd = (d: Date) =>
  `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(
    d.getUTCDate(),
  ).padStart(2, "0")}`;

/** Mes/año de referencia del período: el del "hasta" (es el mes que se liquida). */
export function periodMonth(hasta: string) {
  const d = new Date(`${hasta}T00:00:00Z`);
  return { mes: d.getUTCMonth() + 1, anio: d.getUTCFullYear() };
}

export function defaultPeriod() {
  const now = new Date();
  const hasta = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 20));
  const desde = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 1, 21));
  return { desde: ymd(desde), hasta: ymd(hasta) };
}

const inRange = (fecha: string | null, desde: string, hasta: string) =>
  !!fecha && fecha >= desde && fecha <= hasta;

/**
 * Junta todo lo descontable del período, salteando lo que ya se liquidó antes.
 * Devuelve conceptos (columnas contables), filas por legajo y totales.
 */
export async function buildPayroll(args: { desde: string; hasta: string }) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { desde, hasta } = args;
  const { mes, anio } = periodMonth(hasta);
  const ym = `${anio}${String(mes).padStart(2, "0")}`;

  const [
    { data: services },
    { data: products },
    { data: consumed },
    { data: subs },
    { data: forms },
    { data: circles },
    { data: circleMembers },
    { data: plans },
    { data: planMembers },
    { data: colectas },
    { data: colectaMembers },
    { data: adelantos },
    { data: refinanciaciones },
    { data: refinItems },
  ] = await Promise.all([
    supabaseAdmin.from("services").select("id, nombre, codigo, cuenta_contable"),
    supabaseAdmin.from("service_products").select("id, nombre, codigo, service_id, cuenta_contable"),
    supabaseAdmin.from("payroll_consumed").select("source_key"),
    supabaseAdmin
      .from("provider_submissions")
      .select("id, service_id, estado, periodo_mes, periodo_anio")
      .neq("estado", "rechazado"),
    supabaseAdmin.from("daily_forms").select("id, fecha, es_cumpleanos").gte("fecha", desde).lte("fecha", hasta),
    supabaseAdmin.from("circles").select("*"),
    supabaseAdmin.from("circle_members").select("*"),
    supabaseAdmin.from("birthday_plans").select("*"),
    supabaseAdmin.from("birthday_members").select("*"),
    supabaseAdmin.from("collections").select("*"),
    supabaseAdmin.from("collection_members").select("*"),
    supabaseAdmin.from("adelantos" as any).select("*"),
    supabaseAdmin.from("refinanciaciones" as any).select("*"),
    supabaseAdmin.from("refinanciacion_items" as any).select("source_key"),
  ]);


  // Lo refinanciado ya no se cobra por su concepto original: sólo por cuotas.
  const done = new Set([
    ...(consumed ?? []).map((c: any) => String(c.source_key)),
    ...((refinItems ?? []) as any[]).map((r: any) => String(r.source_key)),
  ]);

  const svcById = new Map((services ?? []).map((s: any) => [s.id, s]));

  const productoCuenta = (nombre: string) => {
    const n = nombre.toLowerCase();
    const p = (products ?? []).find((x: any) => String(x.nombre).toLowerCase().includes(n));
    return p?.cuenta_contable ?? null;
  };

  const conceptos = new Map<string, { nombre: string; cuenta_contable: string | null }>();
  const rows = new Map<string, PayrollRow>();

  const add = (
    conceptKey: string,
    nombre: string,
    cuenta: string | null,
    legajo: string,
    nombreAfiliado: string | null,
    importe: number,
    sourceKey: string,
  ) => {
    const monto = r2(importe);
    if (!monto || !legajo) return;
    if (!conceptos.has(conceptKey)) conceptos.set(conceptKey, { nombre, cuenta_contable: cuenta });
    let row = rows.get(legajo);
    if (!row) {
      row = {
        legajo,
        apellido_nombre: nombreAfiliado,
        por_concepto: {},
        total: 0,
        keys: [],
        keys_por_concepto: {},
      };
      rows.set(legajo, row);
    }
    const r: PayrollRow = row;
    if (!r.apellido_nombre && nombreAfiliado) r.apellido_nombre = nombreAfiliado;
    r.por_concepto[conceptKey] = r2((r.por_concepto[conceptKey] ?? 0) + monto);
    r.total = r2(r.total + monto);
    r.keys.push(sourceKey);
    (r.keys_por_concepto[conceptKey] ??= []).push(sourceKey);
  };


  // 1) Consumos de servicios cargados por proveedores / AGOEC (farmacia, supermercado, etc.).
  //    Se liquidan por PERÍODO (mes/año declarado en la carga), no por fecha, y en cuotas:
  //    cada período descuenta 1/cuotas del importe del afiliado.
  const subIds = (subs ?? []).map((s: any) => s.id);
  const subById = new Map((subs ?? []).map((s: any) => [s.id, s]));
  if (subIds.length) {
    const CH = 200;
    for (let i = 0; i < subIds.length; i += CH) {
      const { data: items } = await supabaseAdmin
        .from("submission_items")
        .select("id, submission_id, service_id, legajo, fecha, importe_afiliado, cuotas, cuotas_importes")
        .in("submission_id", subIds.slice(i, i + CH));
      for (const it of items ?? []) {
        const sub: any = subById.get(it.submission_id);
        if (!sub?.periodo_mes || !sub?.periodo_anio) continue;
        const cuotas = Math.max(1, Number(it.cuotas) || 1);
        const idx =
          anio * 12 + (mes - 1) - (Number(sub.periodo_anio) * 12 + (Number(sub.periodo_mes) - 1));
        if (idx < 0 || idx >= cuotas) continue;
        const key = cuotas > 1 ? `submission_item:${it.id}:${ym}` : `submission_item:${it.id}`;
        if (done.has(key) || done.has(`submission_item:${it.id}`)) continue;
        const svc: any = svcById.get(it.service_id) ?? {};
        // Si el proveedor informó los importes de cada cuota (Automotores), se respetan;
        // si no, se divide el importe del afiliado en partes iguales como siempre.
        const explicitas: number[] = Array.isArray((it as any).cuotas_importes)
          ? ((it as any).cuotas_importes as any[]).map((x) => Number(x) || 0)
          : [];
        const monto =
          explicitas.length === cuotas
            ? explicitas[idx]
            : Number(it.importe_afiliado ?? 0) / cuotas;
        add(
          `svc:${it.service_id}`,
          svc.nombre ?? "Servicio",
          svc.cuenta_contable ?? null,
          String(it.legajo),
          null,
          monto,
          key,
        );
      }
    }
  }


  // 2) Comida a Dto.
  const formIds = (forms ?? []).filter((f: any) => !f.es_cumpleanos).map((f: any) => f.id);
  if (formIds.length) {
    const { data: cons } = await supabaseAdmin
      .from("daily_consumptions")
      .select("id, legajo, importe, no_paga, daily_form_id")
      .in("daily_form_id", formIds);
    const cuenta = productoCuenta("comida");
    for (const c of cons ?? []) {
      const key = `daily_consumption:${c.id}`;
      if (done.has(key) || c.no_paga) continue;
      add("comida", "Comida a Dto.", cuenta, String(c.legajo), null, Number(c.importe ?? 0), key);
    }
  }

  // 3) Círculos (aporte mensual del mes liquidado).
  {
    const { circleActivo } = await import("./circles.server");
    const cuenta = productoCuenta("círculo") ?? productoCuenta("circulo");
    const activos = new Set(
      (circles ?? [])
        .filter((c: any) => circleActivo(c.periodo_inicio, c.periodo_fin, mes, anio))
        .map((c: any) => c.id),
    );
    for (const m of circleMembers ?? []) {
      if (!activos.has(m.circle_id)) continue;
      const key = `circle_member:${m.id}:${ym}`;
      if (done.has(key)) continue;
      add("circulo", "Círculos", cuenta, String(m.legajo), m.apellido_nombre ?? null, Number(m.importe_mensual ?? 0), key);
    }
  }

  // 4) Cumpleaños (cuota del mes liquidado).
  {
    const { cuotaIndex } = await import("./birthdays.server");
    const cuenta = productoCuenta("cumplea");
    const planById = new Map((plans ?? []).map((p: any) => [p.id, p]));
    for (const m of planMembers ?? []) {
      const p: any = planById.get(m.plan_id);
      if (!p) continue;
      const cuotas: number[] = Array.isArray(m.cuotas) ? m.cuotas.map((x: any) => Number(x) || 0) : [];
      const idx = cuotaIndex(p.periodo_inicio, cuotas.length, mes, anio);
      if (!idx) continue;
      const key = `birthday_member:${m.id}:${ym}`;
      if (done.has(key)) continue;
      add("cumpleanos", "Cumpleaños", cuenta, String(m.legajo), m.apellido_nombre ?? null, cuotas[idx - 1] ?? 0, key);
    }
  }

  // 5) Colectas (cuota del mes liquidado).
  {
    const { cuotaIndex } = await import("./collections.server");
    const cuenta = productoCuenta("colecta");
    const colById = new Map((colectas ?? []).map((c: any) => [c.id, c]));
    for (const m of colectaMembers ?? []) {
      const c: any = colById.get(m.collection_id);
      if (!c || c.cerrada) continue;
      const idx = cuotaIndex(c, mes, anio);
      if (!idx) continue;
      const key = `collection_member:${m.id}:${ym}`;
      if (done.has(key)) continue;
      const cuotasTotales = Math.max(1, Number(c.cuotas) || 1);
      const importe = Number(m.importe_cuota ?? 0) || Number(m.importe_total ?? 0) / cuotasTotales;
      add("colecta", "Colectas", cuenta, String(m.legajo), m.apellido_nombre ?? null, importe, key);
    }
  }

  // 6) Adelantos (cuota del período liquidado: monto pedido / cuotas).
  const { cuotaPlan } = await import("./refinance-plan");
  {
    const cuenta = productoCuenta("adelanto");
    for (const a of (adelantos ?? []) as any[]) {
      const cuotas = Math.max(1, Number(a.cuotas) || 1);
      const idx =
        anio * 12 + (mes - 1) - (Number(a.periodo_anio) * 12 + (Number(a.periodo_mes) - 1));
      if (idx < 0 || idx >= cuotas) continue;
      const key = `adelanto:${a.id}:${ym}`;
      if (done.has(key)) continue;
      add(
        "adelanto",
        "Adelantos",
        cuenta,
        String(a.legajo),
        a.apellido_nombre ?? null,
        cuotaPlan(Number(a.monto_pedido ?? 0), cuotas)[idx],
        key,
      );
    }
  }

  // 7) Refinanciaciones (cuota del período; los planes consolidados sólo
  // conservan sus cuotas ya devengadas, las futuras las cobra el plan nuevo).
  {
    const cuenta = productoCuenta("refinanc");
    for (const rf of (refinanciaciones ?? []) as any[]) {
      const cuotas = Math.max(1, Number(rf.cuotas) || 1);
      const tope = rf.cuotas_efectivas == null ? cuotas : Math.max(0, Number(rf.cuotas_efectivas));
      const idx =
        anio * 12 + (mes - 1) - (Number(rf.periodo_anio) * 12 + (Number(rf.periodo_mes) - 1));
      if (idx < 0 || idx >= cuotas || idx >= tope) continue;
      const key = `refinanciacion:${rf.id}:${ym}`;
      if (done.has(key)) continue;
      add(
        "refinanciacion",
        "Refinanciación",
        cuenta,
        String(rf.legajo),
        rf.apellido_nombre ?? null,
        cuotaPlan(Number(rf.total ?? 0), cuotas)[idx],
        key,
      );
    }
  }



  // Nombres de los afiliados.
  const legajos = [...rows.keys()];
  for (let i = 0; i < legajos.length; i += 500) {
    const { data: affs } = await supabaseAdmin
      .from("affiliates")
      .select("legajo, apellido_nombre")
      .in("legajo", legajos.slice(i, i + 500));
    for (const a of affs ?? []) {
      const row = rows.get(String(a.legajo));
      if (row) row.apellido_nombre = a.apellido_nombre ?? row.apellido_nombre;
    }
  }

  const { compareLegajo } = await import("./legajo");
  const list = [...rows.values()].sort((a, b) => compareLegajo(a.legajo, b.legajo));

  // Todos los servicios y subservicios deben figurar como columna, incluso sin movimientos.
  for (const s of services ?? []) {
    if (!conceptos.has(`svc:${s.id}`))
      conceptos.set(`svc:${s.id}`, { nombre: s.nombre, cuenta_contable: s.cuenta_contable ?? null });
  }
  for (const [key, nombre, busca] of [
    ["comida", "Comida a Dto.", "comida"],
    ["circulo", "Círculos", "círculo"],
    ["cumpleanos", "Cumpleaños", "cumplea"],
    ["colecta", "Colectas", "colecta"],
    ["adelanto", "Adelantos", "adelanto"],
    ["refinanciacion", "Refinanciación", "refinanc"],


  ] as const) {
    if (!conceptos.has(key))
      conceptos.set(key, { nombre, cuenta_contable: productoCuenta(busca) ?? null });

  }

  const conceptosList: PayrollConcept[] = [...conceptos.entries()].map(([key, c]) => ({
    key,
    nombre: c.nombre,
    cuenta_contable: c.cuenta_contable,
    total: r2(list.reduce((a, r) => a + (r.por_concepto[key] ?? 0), 0)),
    afiliados: list.filter((r) => (r.por_concepto[key] ?? 0) !== 0).length,
  }));


  return {
    desde,
    hasta,
    mes,
    anio,
    conceptos: conceptosList,
    rows: list,
    total: r2(list.reduce((a, r) => a + r.total, 0)),
    afiliados: list.length,
  };
}

/** Legajos que COBRAN en el período: pozos de círculos y agasajados de cumpleaños. */
export async function buildCircleBirthdayPayout(args: { desde: string; hasta: string }) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { mes, anio } = periodMonth(args.hasta);

  const [{ data: circles }, { data: circleMembers }, { data: plans }, { data: planMembers }] =
    await Promise.all([
      supabaseAdmin.from("circles").select("*"),
      supabaseAdmin.from("circle_members").select("*"),
      supabaseAdmin.from("birthday_plans").select("*"),
      supabaseAdmin.from("birthday_members").select("*"),
    ]);

  const { buildCircleSettlement } = await import("./circles.server");
  const { buildBirthdaySettlement } = await import("./birthdays.server");

  const circ = buildCircleSettlement(
    (circles ?? []).map((c: any) => ({
      ...c,
      members: (circleMembers ?? []).filter((m: any) => m.circle_id === c.id),
    })) as any,
    mes,
    anio,
  );
  const cumple = buildBirthdaySettlement(
    (plans ?? []).map((p: any) => ({
      ...p,
      members: (planMembers ?? []).filter((m: any) => m.plan_id === p.id),
    })) as any,
    mes,
    anio,
  );

  const rows = [
    ...circ.cobradores.map((c) => ({
      tipo: "Círculo",
      ref_key: `circulo:${c.circle_id}:${c.legajo}`,
      detalle: c.numero ? `Círculo ${c.numero} - ${c.circulo}` : c.circulo,
      legajo: c.legajo,
      apellido_nombre: c.apellido_nombre,
      importe: r2(c.importe),
    })),
    ...cumple.agasajados.map((a) => ({
      tipo: "Cumpleaños",
      ref_key: `cumple:${a.plan_id}:${a.legajo}`,
      detalle: a.plan,
      legajo: a.legajo,
      apellido_nombre: a.apellido_nombre,
      importe: r2(a.importe),
    })),
  ];

  const legajos = [...new Set(rows.map((r) => r.legajo))];
  for (let i = 0; i < legajos.length; i += 500) {
    const { data: affs } = await supabaseAdmin
      .from("affiliates")
      .select("legajo, apellido_nombre")
      .in("legajo", legajos.slice(i, i + 500));
    const map = new Map((affs ?? []).map((a: any) => [String(a.legajo), a.apellido_nombre]));
    for (const r of rows) if (map.get(r.legajo)) r.apellido_nombre = map.get(r.legajo) ?? null;
  }

  return {
    mes,
    anio,
    rows,
    total: r2(rows.reduce((a, r) => a + r.importe, 0)),
    total_circulos: r2(circ.total_a_pagar),
    total_cumpleanos: r2(cumple.total_a_pagar),
  };
}
