import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const memberSchema = z.object({
  legajo: z.string().trim().min(1).max(32),
  fecha_cobro: z.string().nullable().optional(),
  cuotas: z.array(z.number().nonnegative()).default([]),
  observacion: z.string().max(300).nullable().optional(),
});

export const listBirthdayPlans = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ product_id: z.string().uuid().optional() }).parse(raw ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);

    let q = context.supabase
      .from("birthday_plans")
      .select("*")
      .order("created_at", { ascending: false });
    if (data.product_id) q = q.eq("product_id", data.product_id);
    const { data: plans, error } = await q;
    if (error) throw new Error(error.message);

    const ids = (plans ?? []).map((p: any) => p.id);
    let members: any[] = [];
    if (ids.length) {
      const { data: ms, error: e2 } = await context.supabase
        .from("birthday_members")
        .select("*")
        .in("plan_id", ids)
        .order("legajo");
      if (e2) throw new Error(e2.message);
      members = ms ?? [];
    }

    return {
      plans: (plans ?? []).map((p: any) => {
        const ms = members.filter((m) => m.plan_id === p.id);
        return {
          ...p,
          members: ms,
          integrantes: ms.length,
          total_descuentos: ms.reduce((a, m) => a + Number(m.total ?? 0), 0),
        };
      }),
    };
  });

export const saveBirthdayPlan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        id: z.string().uuid().optional(),
        service_id: z.string().uuid().nullable().optional(),
        product_id: z.string().uuid().nullable().optional(),
        nombre: z.string().trim().min(2).max(160),
        importe_total: z.number().nonnegative().default(0),
        periodo_inicio: z.number().int().min(200001).max(210012, "Período inicial inválido"),
        periodo_fin: z.number().int().min(200001).max(210012).nullable().optional(),
        observacion: z.string().max(500).nullable().optional(),
        members: z.array(memberSchema).default([]),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { r2 } = await import("./birthdays.server");

    const header = {
      ...(data.id ? { id: data.id } : {}),
      service_id: data.service_id ?? null,
      product_id: data.product_id ?? null,
      nombre: data.nombre,
      importe_total: data.importe_total,
      periodo_inicio: data.periodo_inicio ?? null,
      periodo_fin: data.periodo_fin ?? null,
      observacion: data.observacion ?? null,
    };

    const { data: saved, error } = await context.supabase
      .from("birthday_plans")
      .upsert(header as any, { onConflict: "id" })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    const planId = saved.id as string;

    await context.supabase.from("birthday_members").delete().eq("plan_id", planId);

    const legajos = data.members.map((m) => m.legajo.trim().toUpperCase());
    let nombres: Record<string, string | null> = {};
    if (legajos.length) {
      const { data: afs } = await context.supabase
        .from("affiliates")
        .select("legajo, apellido_nombre")
        .in("legajo", legajos);
      nombres = Object.fromEntries((afs ?? []).map((a: any) => [a.legajo, a.apellido_nombre]));
    }

    if (data.members.length) {
      const rows = data.members.map((m) => {
        const legajo = m.legajo.trim().toUpperCase();
        const cuotas = m.cuotas.map((c) => r2(c));
        return {
          plan_id: planId,
          legajo,
          apellido_nombre: nombres[legajo] ?? null,
          fecha_cobro: m.fecha_cobro || null,
          cuotas: cuotas as any,
          total: r2(cuotas.reduce((a, c) => a + c, 0)),
          observacion: m.observacion ?? null,
        };
      });
      const { error: e3 } = await context.supabase.from("birthday_members").insert(rows as any);
      if (e3) throw new Error(e3.message);
    }

    return { ok: true, id: planId };
  });

export const deleteBirthdayPlan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { error } = await context.supabase.from("birthday_plans").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Liquidación mensual de cumpleaños: descuento por afiliado y pagos a los agasajados. */
export const birthdaysSettlement = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        mes: z.number().int().min(1).max(12),
        anio: z.number().int().min(2000).max(2100),
        product_id: z.string().uuid().optional(),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { buildBirthdaySettlement } = await import("./birthdays.server");

    let q = context.supabase.from("birthday_plans").select("*");
    if (data.product_id) q = q.eq("product_id", data.product_id);
    const { data: plans, error } = await q;
    if (error) throw new Error(error.message);

    const ids = (plans ?? []).map((p: any) => p.id);
    let members: any[] = [];
    if (ids.length) {
      const { data: ms, error: e2 } = await context.supabase
        .from("birthday_members")
        .select("*")
        .in("plan_id", ids);
      if (e2) throw new Error(e2.message);
      members = ms ?? [];
    }

    const full = (plans ?? []).map((p: any) => ({
      ...p,
      members: members.filter((m) => m.plan_id === p.id),
    }));

    return {
      mes: data.mes,
      anio: data.anio,
      ...buildBirthdaySettlement(full as any, data.mes, data.anio),
    };
  });
