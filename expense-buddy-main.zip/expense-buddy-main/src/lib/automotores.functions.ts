import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const ItemSchema = z.object({
  fecha: z.string().nullable().optional(),
  legajo: z.string().trim().min(1).max(32),
  apellido_nombre: z.string().max(160).nullable().optional(),
  ticket: z.string().max(80).nullable().optional(),
  prestacion: z.string().trim().min(1).max(120),
  importe: z.number().positive(),
  observacion: z.string().max(500).nullable().optional(),
  cuotas: z.number().int().min(1).max(12),
  cuotas_importes: z.array(z.number()).max(12).nullable().optional(),
});

const zPeriodo = z.object({
  periodo_mes: z.number().int().min(1).max(12),
  periodo_anio: z.number().int().min(2000).max(2100),
});

/* ---------------------- PRESTACIONES + COMISIÓN AGOEC --------------------- */

export const listAutoProviders = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./crm.server");
    const { getAutomotoresService } = await import("./automotores.server");
    await assertAdmin(context);
    const svc = await getAutomotoresService(context);
    const [{ data: provs, error }, { data: prest }] = await Promise.all([
      context.supabase
        .from("providers")
        .select("id, nombre, cuit, cuenta_contable, habilitado, banco, cbu, alias, titular")
        .eq("service_id", svc.id)
        .order("nombre", { ascending: true }),
      context.supabase.from("provider_prestaciones").select("*").order("nombre", { ascending: true }),
    ]);
    if (error) throw new Error(error.message);
    const byProv = new Map<string, any[]>();
    for (const p of prest ?? []) {
      if (!byProv.has(p.provider_id)) byProv.set(p.provider_id, []);
      byProv.get(p.provider_id)!.push(p);
    }
    return {
      service: svc,
      providers: (provs ?? []).map((p: any) => ({ ...p, prestaciones: byProv.get(p.id) ?? [] })),
    };
  });

export const upsertPrestacion = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        id: z.string().uuid().optional(),
        provider_id: z.string().uuid(),
        nombre: z.string().trim().min(2).max(120),
        comision_pct: z.number().min(0).max(100),
        activo: z.boolean().default(true),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { data: row, error } = await context.supabase
      .from("provider_prestaciones")
      .upsert(data as any, { onConflict: "id" })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const deletePrestacion = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { error } = await context.supabase.from("provider_prestaciones").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ------------------------------ IMPORTACIÓN ------------------------------ */

export const previewAutoImport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ provider_id: z.string().uuid(), items: z.array(ItemSchema) }).parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    const { comisionMap, computeAutoItems, autoTotals, subtotalesPorPrestacion, normNombre } =
      await import("./automotores.server");
    await assertAdmin(context);

    const comisiones = await comisionMap(context, data.provider_id);
    const items = computeAutoItems(data.items as any, comisiones);

    const legajos = Array.from(new Set(items.map((i) => i.legajo)));
    const { data: affs } = await context.supabase
      .from("affiliates")
      .select("legajo, apellido_nombre")
      .in("legajo", legajos.length ? legajos : ["__none__"]);
    const map = new Map((affs ?? []).map((a: any) => [a.legajo, a.apellido_nombre]));

    const rows = items.map((i) => ({
      ...i,
      apellido_nombre: (map.get(i.legajo) as string) ?? i.apellido_nombre ?? null,
      legajo_valido: map.has(i.legajo),
      prestacion_configurada: comisiones.has(normNombre(i.prestacion)),
    }));

    return {
      rows,
      ...autoTotals(items),
      subtotales: subtotalesPorPrestacion(items),
      legajos_desconocidos: rows.filter((r) => !r.legajo_valido).map((r) => r.legajo),
      prestaciones_nuevas: Array.from(
        new Set(rows.filter((r) => !r.prestacion_configurada).map((r) => r.prestacion)),
      ),
    };
  });

export const submitAutoImport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        provider_id: z.string().uuid(),
        nombre: z.string().trim().min(2).max(120),
        factura: z.string().max(80).nullable().optional(),
        observacion: z.string().max(1000).nullable().optional(),
        items: z.array(ItemSchema).min(1),
      })
      .merge(zPeriodo)
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin, providerRowById } = await import("./crm.server");
    const { comisionMap, computeAutoItems, autoTotals } = await import("./automotores.server");
    await assertAdmin(context);
    const prov = await providerRowById(context, data.provider_id);

    const comisiones = await comisionMap(context, prov.id);
    const items = computeAutoItems(data.items as any, comisiones);
    const t = autoTotals(items);

    const { data: sub, error } = await context.supabase
      .from("provider_submissions")
      .insert({
        provider_id: prov.id,
        service_id: prov.service_id,
        nombre: data.nombre,
        periodo_mes: data.periodo_mes,
        periodo_anio: data.periodo_anio,
        observacion: data.observacion ?? null,
        factura: data.factura ?? null,
        estado: "aprobada",
        total_importe: t.total_importe,
        total_subsidio: 0,
        total_a_pagar: t.total_neto,
        total_comision: t.total_comision,
        total_neto: t.total_neto,
        total_items: t.total_items,
        total_afiliados: t.total_afiliados,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);

    // Cada movimiento conserva identidad propia: no se agrupa ni deduplica por legajo.
    const payload = items.map((i) => ({
      submission_id: sub.id,
      provider_id: prov.id,
      service_id: prov.service_id,
      legajo: i.legajo,
      fecha: i.fecha || null,
      detalle: i.observacion ?? null,
      comprobante: i.ticket ?? null,
      prestacion: i.prestacion,
      importe: i.importe,
      cuotas: i.cuotas,
      cuotas_importes: i.cuotas_importes,
      con_receta: false,
      es_cumpleanos: false,
      subsidio: 0,
      importe_afiliado: i.importe,
      // Comisión congelada al momento de la carga: no se recalcula después.
      comision_pct: i.comision_pct,
      comision_monto: i.comision_monto,
      neto_proveedor: i.neto_proveedor,
    }));
    const { error: itErr } = await context.supabase.from("submission_items").insert(payload);
    if (itErr) throw new Error(itErr.message);

    try {
      const { logAudit } = await import("./audit.server");
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      await logAudit(supabaseAdmin, {
        entidad: "automotores_liquidacion",
        entidad_id: sub.id,
        accion: "importar",
        userId: context.userId,
        nota: `${prov.nombre} · ${data.periodo_mes}/${data.periodo_anio} · ${t.total_items} consumos`,
        valor_nuevo: t,
      });
    } catch {
      /* la auditoría nunca bloquea la carga */
    }

    return { id: sub.id, ...t };
  });

/* --------------------------- LIQUIDACIÓN / HISTORIAL --------------------------- */

export const autoPeriodSummary = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => zPeriodo.parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    const { getAutomotoresService, subtotalesPorPrestacion, r2 } = await import("./automotores.server");
    await assertAdmin(context);
    const svc = await getAutomotoresService(context);

    const { data: subs, error } = await context.supabase
      .from("provider_submissions")
      .select("*, providers(nombre, cuenta_contable, cbu, alias, titular)")
      .eq("service_id", svc.id)
      .eq("periodo_mes", data.periodo_mes)
      .eq("periodo_anio", data.periodo_anio)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);

    const ids = (subs ?? []).map((s: any) => s.id);
    let items: any[] = [];
    if (ids.length) {
      const { data: its, error: e2 } = await context.supabase
        .from("submission_items")
        .select("*")
        .in("submission_id", ids)
        .order("fecha", { ascending: true });
      if (e2) throw new Error(e2.message);
      items = its ?? [];
    }

    const porProveedor = (subs ?? []).map((s: any) => {
      const own = items.filter((i) => i.submission_id === s.id);
      return {
        submission_id: s.id,
        provider_id: s.provider_id,
        proveedor: s.providers?.nombre ?? "—",
        cuenta_contable: s.providers?.cuenta_contable ?? null,
        titular: s.providers?.titular ?? null,
        cbu: s.providers?.cbu ?? null,
        alias: s.providers?.alias ?? null,
        estado: s.estado,
        factura: s.factura ?? null,
        nombre: s.nombre,
        consumos: own.length,
        afiliados: new Set(own.map((i) => i.legajo)).size,
        bruto: r2(own.reduce((a, b) => a + Number(b.importe || 0), 0)),
        comision: r2(own.reduce((a, b) => a + Number(b.comision_monto || 0), 0)),
        neto: r2(own.reduce((a, b) => a + Number(b.neto_proveedor ?? b.importe ?? 0), 0)),
        subtotales: subtotalesPorPrestacion(own as any),
        items: own,
      };
    });

    return {
      periodo: { mes: data.periodo_mes, anio: data.periodo_anio },
      proveedores: porProveedor,
      totales: {
        consumos: items.length,
        afiliados: new Set(items.map((i) => i.legajo)).size,
        bruto: r2(items.reduce((a, b) => a + Number(b.importe || 0), 0)),
        comision: r2(items.reduce((a, b) => a + Number(b.comision_monto || 0), 0)),
        neto: r2(items.reduce((a, b) => a + Number(b.neto_proveedor ?? b.importe ?? 0), 0)),
      },
    };
  });

/** Historial y búsqueda por período, proveedor, prestación, legajo, nombre o ticket. */
export const autoHistory = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        q: z.string().max(120).optional(),
        provider_id: z.string().uuid().nullable().optional(),
        periodo_mes: z.number().int().min(1).max(12).nullable().optional(),
        periodo_anio: z.number().int().min(2000).max(2100).nullable().optional(),
      })
      .parse(raw ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    const { getAutomotoresService, normNombre } = await import("./automotores.server");
    await assertAdmin(context);
    const svc = await getAutomotoresService(context);

    let subQ = context.supabase
      .from("provider_submissions")
      .select("id, provider_id, periodo_mes, periodo_anio, estado, factura, providers(nombre)")
      .eq("service_id", svc.id);
    if (data.provider_id) subQ = subQ.eq("provider_id", data.provider_id);
    if (data.periodo_mes) subQ = subQ.eq("periodo_mes", data.periodo_mes);
    if (data.periodo_anio) subQ = subQ.eq("periodo_anio", data.periodo_anio);
    const { data: subs, error } = await subQ;
    if (error) throw new Error(error.message);

    const subById = new Map((subs ?? []).map((s: any) => [s.id, s]));
    const ids = Array.from(subById.keys());
    if (!ids.length) return { rows: [], periodos: [] };

    const { data: items, error: e2 } = await context.supabase
      .from("submission_items")
      .select("*")
      .in("submission_id", ids)
      .order("fecha", { ascending: false })
      .limit(3000);
    if (e2) throw new Error(e2.message);

    const legajos = Array.from(new Set((items ?? []).map((i: any) => i.legajo)));
    const { data: affs } = await context.supabase
      .from("affiliates")
      .select("legajo, apellido_nombre")
      .in("legajo", legajos.length ? legajos : ["__none__"]);
    const nombres = new Map((affs ?? []).map((a: any) => [a.legajo, a.apellido_nombre]));

    const q = normNombre(data.q ?? "");
    const rows = (items ?? [])
      .map((i: any) => {
        const s: any = subById.get(i.submission_id);
        return {
          ...i,
          apellido_nombre: (nombres.get(i.legajo) as string) ?? null,
          proveedor: s?.providers?.nombre ?? "—",
          periodo_mes: s?.periodo_mes ?? null,
          periodo_anio: s?.periodo_anio ?? null,
          estado: s?.estado ?? null,
          factura: s?.factura ?? null,
        };
      })
      .filter((r: any) =>
        !q
          ? true
          : [r.legajo, r.apellido_nombre, r.comprobante, r.prestacion, r.proveedor]
              .filter(Boolean)
              .some((v) => normNombre(v).includes(q)),
      );

    const periodos = Array.from(
      new Set((subs ?? []).map((s: any) => `${s.periodo_anio}-${String(s.periodo_mes).padStart(2, "0")}`)),
    ).sort((a, b) => b.localeCompare(a));

    return { rows, periodos };
  });
