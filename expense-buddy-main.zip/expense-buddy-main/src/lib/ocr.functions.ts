import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

export const ocrDailyPhoto = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ base64: z.string() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Sólo administradores");

    const { callLovableAI } = await import("./ai-gateway.server");

    const systemPrompt = `Eres un asistente que analiza fotos de la ficha diaria de "COMIDA A DTO" de una empresa argentina.
La ficha tiene columnas: Legajo | Nombre y Apellido | DESAYUNO (tilde) | ALMUERZO (tilde) | Observaciones (opcional).
Los legajos pueden ser alfanuméricos (letras y números). Devolvé el legajo tal cual, sin ceros a izquierda.
Devolvé ÚNICAMENTE un JSON con la clave "consumos" (array).
Cada item: { "legajo": string, "desayuno": boolean, "almuerzo": boolean, "observacion": string | null }.
Sólo incluí filas con al menos un tilde o una observación. Ignorá filas vacías.`;

    const res = await callLovableAI({
      model: "google/gemini-3.6-flash",
      messages: [
        { role: "system", content: systemPrompt },
        {
          role: "user",
          content: [
            { type: "text", text: "Extraé la lista de consumos de esta ficha." },
            { type: "image_url", image_url: { url: data.base64 } },
          ],
        },
      ],
      response_format: { type: "json_object" },
    });

    if (!res.ok) {
      const text = await res.text();
      if (res.status === 429) throw new Error("La IA está sobrecargada. Probá en un rato.");
      if (res.status === 402) throw new Error("Sin créditos de IA. Añadí créditos en Lovable Cloud.");
      throw new Error(`Error IA (${res.status}): ${text.slice(0, 200)}`);
    }

    const json = (await res.json()) as any;
    const raw = json.choices?.[0]?.message?.content ?? "{}";
    let parsed: any;
    try {
      parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
    } catch {
      throw new Error("La IA no devolvió JSON válido");
    }
    const list = Array.isArray(parsed?.consumos) ? parsed.consumos : [];
    const consumos = list
      .map((c: any) => ({
        legajo: String(c.legajo ?? "").trim().toUpperCase(),
        desayuno: Boolean(c.desayuno),
        almuerzo: Boolean(c.almuerzo),
        observacion: c.observacion ? String(c.observacion).slice(0, 500) : null,
      }))
      .filter((c: any) => c.legajo.length > 0);
    return { consumos };
  });

// Lee una foto/planilla de un CÍRCULO: legajo, importe mensual y mes que cobra.
export const ocrCirclePhoto = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ base64: z.string() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);

    const { callLovableAI } = await import("./ai-gateway.server");

    const systemPrompt = `Analizás fotos de planillas de "círculos" (fondos rotativos) de un sindicato argentino.
Columnas típicas: Legajo | Apellido y Nombre | Importe mensual | Mes que cobra (puede venir como nombre de mes o número) | Observaciones.
Los legajos pueden ser alfanuméricos; devolvelos tal cual, sin ceros a la izquierda.
Devolvé ÚNICAMENTE un JSON con la clave "integrantes" (array).
Cada item: { "legajo": string, "importe_mensual": number, "mes_cobro": number|null, "anio_cobro": number|null, "observacion": string|null }.
mes_cobro debe ser un número 1-12. Ignorá filas sin legajo.`;

    const res = await callLovableAI({
      model: "google/gemini-3.6-flash",
      messages: [
        { role: "system", content: systemPrompt },
        {
          role: "user",
          content: [
            { type: "text", text: "Extraé los integrantes del círculo de esta planilla." },
            { type: "image_url", image_url: { url: data.base64 } },
          ],
        },
      ],
      response_format: { type: "json_object" },
    });

    if (!res.ok) {
      const text = await res.text();
      if (res.status === 429) throw new Error("La IA está sobrecargada. Probá en un rato.");
      if (res.status === 402) throw new Error("Sin créditos de IA. Añadí créditos en Lovable Cloud.");
      throw new Error(`Error IA (${res.status}): ${text.slice(0, 200)}`);
    }

    const json = (await res.json()) as any;
    const raw = json.choices?.[0]?.message?.content ?? "{}";
    let parsed: any;
    try {
      parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
    } catch {
      throw new Error("La IA no devolvió JSON válido");
    }
    const list = Array.isArray(parsed?.integrantes) ? parsed.integrantes : [];
    const integrantes = list
      .map((c: any) => ({
        legajo: String(c.legajo ?? "").trim().toUpperCase(),
        importe_mensual: Number(c.importe_mensual ?? 0) || 0,
        mes_cobro: c.mes_cobro ? Number(c.mes_cobro) : null,
        anio_cobro: c.anio_cobro ? Number(c.anio_cobro) : null,
        observacion: c.observacion ? String(c.observacion).slice(0, 300) : null,
      }))
      .filter((c: any) => c.legajo.length > 0);
    return { integrantes };
  });
