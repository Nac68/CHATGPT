/**
 * Auditoría económica mínima.
 * Registra en public.audit_events las operaciones que pueden mover dinero
 * o alterar el resultado de una liquidación.
 *
 * Reglas:
 * - Nunca se registran PIN, claves, tokens, headers ni secretos.
 * - Sólo identificadores/legajos y valores económicos (sin duplicar datos personales).
 * - Si el registro falla, NO interrumpe el flujo principal.
 */

const emailCache = new Map<string, string | null>();

async function resolveEmail(supabaseAdmin: any, userId: string | null) {
  if (!userId) return null;
  if (emailCache.has(userId)) return emailCache.get(userId) ?? null;
  let email: string | null = null;
  try {
    const { data } = await supabaseAdmin.auth.admin.getUserById(userId);
    email = data?.user?.email ?? null;
  } catch {
    email = null;
  }
  emailCache.set(userId, email);
  return email;
}

export type AuditEvent = {
  entidad: string;
  entidad_id?: string | null;
  accion: string;
  userId: string | null;
  legajo?: string | null;
  nota?: string | null;
  valor_anterior?: unknown;
  valor_nuevo?: unknown;
};

/** Claves que nunca se persisten en la auditoría. */
const BLOCKED = /pin|pass|clave|token|secret|session|authorization|apikey|api_key|key$/i;

function sanitize(value: unknown): unknown {
  if (value == null) return null;
  if (Array.isArray(value)) return value.map(sanitize);
  if (typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (BLOCKED.test(k)) continue;
      out[k] = sanitize(v);
    }
    return out;
  }
  return value;
}

export async function logAudit(supabaseAdmin: any, ev: AuditEvent) {
  try {
    const email = await resolveEmail(supabaseAdmin, ev.userId);
    await supabaseAdmin.from("audit_events").insert({
      entidad: ev.entidad,
      entidad_id: ev.entidad_id ?? null,
      accion: ev.accion,
      user_id: ev.userId,
      user_email: email,
      legajo: ev.legajo ?? null,
      nota: ev.nota ?? null,
      valor_anterior: (sanitize(ev.valor_anterior) as any) ?? null,
      valor_nuevo: (sanitize(ev.valor_nuevo) as any) ?? null,
    });
  } catch (e) {
    // La auditoría es secundaria: nunca bloquea la operación económica.
    console.error("[audit] no se pudo registrar el evento", (e as Error)?.message);
  }
}
