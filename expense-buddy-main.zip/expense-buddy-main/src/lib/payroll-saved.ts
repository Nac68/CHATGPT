// Rearma la vista de un período ya liquidado a partir del detalle guardado.
import type { PayrollConcept, PayrollRow } from "./payroll.server";

const r2 = (n: number) => Math.round((Number(n) || 0) * 100) / 100;

export function buildSavedPayroll(items: any[]) {
  const conceptos = new Map<string, PayrollConcept>();
  type SavedRow = Omit<PayrollRow, "keys" | "keys_por_concepto">;
  const rows = new Map<string, SavedRow>();

  for (const it of items) {
    const key = String(it.servicio);
    if (!conceptos.has(key)) {
      conceptos.set(key, {
        key,
        nombre: key,
        cuenta_contable: it.cuenta_contable ?? null,
        total: 0,
        afiliados: 0,
      });
    }
    const legajo = String(it.legajo);
    let row = rows.get(legajo);
    if (!row) {
      row = { legajo, apellido_nombre: it.apellido_nombre ?? null, por_concepto: {}, total: 0 };
      rows.set(legajo, row);
    }
    const r: SavedRow = row;
    const monto = r2(it.importe);
    r.por_concepto[key] = r2((r.por_concepto[key] ?? 0) + monto);
    r.total = r2(r.total + monto);

  }

  const list = [...rows.values()];
  for (const c of conceptos.values()) {
    c.total = r2(list.reduce((a, r) => a + (r.por_concepto[c.key] ?? 0), 0));
    c.afiliados = list.filter((r) => (r.por_concepto[c.key] ?? 0) !== 0).length;
  }

  return {
    conceptos: [...conceptos.values()],
    rows: list,
    total: r2(list.reduce((a, r) => a + r.total, 0)),
    afiliados: list.length,
  };
}
