import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

// Servicio + productos habilitados + proveedores asociados (por código de servicio),
// con toda la información de cargas, importes y datos de cobro.
export const getServiceDetail = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ codigo: z.string().min(1).max(60) }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { data: service, error } = await context.supabase
      .from("services")
      .select("*")
      .eq("codigo", data.codigo)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!service) throw new Error("Servicio no encontrado");

    const [{ data: products }, { data: providers }, { data: subs }, { data: items }] =
      await Promise.all([
        context.supabase
          .from("service_products")
          .select("*")
          .eq("service_id", service.id)
          .order("nombre"),
        context.supabase.from("providers").select("*").eq("service_id", service.id).order("nombre"),
        context.supabase
          .from("provider_submissions")
          .select("*")
          .eq("service_id", service.id)
          .order("created_at", { ascending: false }),
        context.supabase
          .from("submission_items")
          .select("provider_id, legajo, importe, importe_afiliado, subsidio, fecha")
          .eq("service_id", service.id),
      ]);

    const subsList = subs ?? [];
    const itemsList = items ?? [];

    const providersFull = (providers ?? []).map((p: any) => {
      const ps = subsList.filter((s: any) => s.provider_id === p.id);
      const pi = itemsList.filter((i: any) => i.provider_id === p.id);
      const legajos = new Set(pi.map((i: any) => i.legajo));
      const ultima = ps[0] ?? null;
      return {
        ...p,
        cargas: ps.length,
        cargas_pendientes: ps.filter((s: any) => s.estado === "pendiente").length,
        items: pi.length,
        afiliados: legajos.size,
        total_importe: pi.reduce((a: number, i: any) => a + Number(i.importe ?? 0), 0),
        total_subsidio: pi.reduce((a: number, i: any) => a + Number(i.subsidio ?? 0), 0),
        total_afiliado: pi.reduce((a: number, i: any) => a + Number(i.importe_afiliado ?? 0), 0),
        ultima_carga: ultima
          ? {
              nombre: ultima.nombre,
              periodo: `${String(ultima.periodo_mes).padStart(2, "0")}/${ultima.periodo_anio}`,
              estado: ultima.estado,
              total_a_pagar: Number(ultima.total_a_pagar ?? 0),
              created_at: ultima.created_at,
            }
          : null,
      };
    });

    // Métricas específicas del producto interno de AGOEC "Comida a Dto."
    let comidaStats: any = null;
    if ((products ?? []).some((p: any) => p.codigo === "comida-dto")) {
      const [{ data: forms }, { data: cons }] = await Promise.all([
        context.supabase.from("daily_forms").select("fecha, importe, es_cumpleanos"),
        context.supabase.from("daily_consumptions").select("legajo, importe_afiliado"),
      ]);
      const f = forms ?? [];
      const c = cons ?? [];
      comidaStats = {
        dias: f.length,
        ultimo_dia: f.map((x: any) => x.fecha).sort().slice(-1)[0] ?? null,
        total_gastado: f.reduce((a: number, x: any) => a + Number(x.importe ?? 0), 0),
        consumos: c.length,
        afiliados: new Set(c.map((x: any) => x.legajo)).size,
        total_afiliados_importe: c.reduce(
          (a: number, x: any) => a + Number(x.importe_afiliado ?? 0),
          0,
        ),
      };
    }

    return {
      service,
      products: products ?? [],
      providers: providersFull,
      comidaStats,
      totales: {
        proveedores: providersFull.length,
        habilitados: providersFull.filter((p: any) => p.habilitado).length,
        cargas: subsList.length,
        pendientes: subsList.filter((s: any) => s.estado === "pendiente").length,
        importe: itemsList.reduce((a: number, i: any) => a + Number(i.importe ?? 0), 0),
        subsidio: itemsList.reduce((a: number, i: any) => a + Number(i.subsidio ?? 0), 0),
        afiliado: itemsList.reduce((a: number, i: any) => a + Number(i.importe_afiliado ?? 0), 0),
        afiliados: new Set(itemsList.map((i: any) => i.legajo)).size,
      },
    };
  });


export const upsertServiceProduct = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        id: z.string().uuid().optional(),
        service_id: z.string().uuid(),
        nombre: z.string().trim().min(2).max(120),
        descripcion: z.string().max(500).nullable().optional(),
        cuenta_contable: z.string().trim().max(40).nullable().optional(),
        tipo: z.enum(["externo", "interno", "agoec", "circulo", "colecta"]).default("agoec"),
        activo: z.boolean().default(true),

      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const codigo = data.nombre.toLowerCase().replace(/[^a-z0-9]+/g, "-");
    const payload = { ...data, codigo, descripcion: data.descripcion ?? null };
    const { error } = await context.supabase
      .from("service_products")
      .upsert(payload as any, { onConflict: "id" });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteServiceProduct = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { error } = await context.supabase.from("service_products").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// Busca el nombre del afiliado por legajo (para mostrar siempre legajo + nombre).
export const lookupAffiliate = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ legajo: z.string().min(1).max(32) }).parse(raw))
  .handler(async ({ data, context }) => {
    const legajo = data.legajo.trim().toUpperCase();
    const { data: row } = await context.supabase
      .from("affiliates")
      .select("legajo, apellido_nombre")
      .eq("legajo", legajo)
      .maybeSingle();
    return { legajo, apellido_nombre: row?.apellido_nombre ?? null };
  });
