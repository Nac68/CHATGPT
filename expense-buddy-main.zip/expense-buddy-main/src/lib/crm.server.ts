// Helpers server-only para el CRM de servicios y proveedores.

export type ServiceCfg = {
  id: string;
  nombre: string;
  codigo: string;
  usa_receta: boolean;
  subsidio_receta_pct: number;
  permite_cumpleanos: boolean;
};

export type RawItem = {
  legajo: string;
  fecha: string | null;
  detalle: string | null;
  comprobante: string | null;
  importe: number;
  /** Importe a cargo del afiliado ya con el descuento de obra social. Si falta, es el 100%. */
  base_afiliado?: number | null;
  cuotas: number;
  con_receta: boolean;
  es_cumpleanos: boolean;
};


export type ComputedItem = RawItem & {
  subsidio: number;
  importe_afiliado: number;
};

const r2 = (n: number) => Math.round(n * 100) / 100;

export async function isAdmin(context: { supabase: any; userId: string }) {
  const { data } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  return !!data;
}

export async function assertAdmin(context: { supabase: any; userId: string }) {
  if (!(await isAdmin(context))) throw new Error("Sólo administradores");
}

export async function myProviderRow(context: { supabase: any; userId: string }) {
  const { data, error } = await context.supabase
    .from("providers")
    .select("*, services(*)")
    .eq("user_id", context.userId)
    .maybeSingle();
  if (error) throw new Error(error.message);

  // Un administrador puede entrar al panel de proveedor aunque no tenga ficha propia:
  // ve el primer proveedor habilitado para poder operar/controlar todo.
  if (!data || !data.habilitado) {
    if (await isAdmin(context)) {
      if (data) return data;
      const { data: any1 } = await context.supabase
        .from("providers")
        .select("*, services(*)")
        .order("nombre", { ascending: true })
        .limit(1)
        .maybeSingle();
      if (any1) return any1;
      throw new Error("Todavía no hay proveedores cargados");
    }
  }
  if (!data) throw new Error("Tu usuario no está vinculado a ningún proveedor");
  if (!data.habilitado) throw new Error("Tu cuenta de proveedor está deshabilitada");
  return data;
}

export function computeItems(items: RawItem[], svc: ServiceCfg): ComputedItem[] {
  const pct = svc.usa_receta ? Number(svc.subsidio_receta_pct ?? 0) : 0;
  return items.map((it) => {
    const importe = r2(Number(it.importe) || 0);
    // Base a cargo del afiliado (ya con descuento de obra social). Si no viene, es el 100%.
    const base =
      it.base_afiliado == null || !Number.isFinite(Number(it.base_afiliado))
        ? importe
        : r2(Number(it.base_afiliado));
    // El subsidio del 15% se calcula siempre sobre el importe al 100%.
    const subsidioReceta = it.con_receta && pct > 0 ? r2((importe * pct) / 100) : 0;
    const exento = svc.permite_cumpleanos && it.es_cumpleanos;
    const importe_afiliado = exento ? 0 : Math.max(0, r2(base - subsidioReceta));

    return {
      ...it,
      importe,
      subsidio: exento ? importe : subsidioReceta,
      importe_afiliado,
    };
  });
}

export function totals(items: ComputedItem[]) {
  const total_importe = r2(items.reduce((a, b) => a + b.importe, 0));
  const total_subsidio = r2(items.reduce((a, b) => a + b.subsidio, 0));
  const total_descuento = r2(items.reduce((a, b) => a + b.importe_afiliado, 0));
  return {
    total_importe,
    total_subsidio,
    // Al proveedor se le paga siempre el total facturado: el subsidio lo absorbe AGOEC.
    total_a_pagar: total_importe,
    total_descuento,
    total_items: items.length,
    total_afiliados: new Set(items.map((i) => i.legajo)).size,
  };
}

export async function providerRowById(context: { supabase: any; userId: string }, id: string) {
  const { data, error } = await context.supabase
    .from("providers")
    .select("*, services(*)")
    .eq("id", id)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Proveedor no encontrado");
  return data;
}

// OCR de una foto de listado de consumos, adaptado a la configuración del servicio.
export async function parsePhotoItems(svc: ServiceCfg, base64: string) {
  const { callLovableAI } = await import("./ai-gateway.server");

  const system = `Analizás fotos de listados de consumos de afiliados del servicio "${svc.nombre}" en Argentina.
Columnas típicas: fecha | legajo | detalle | comprobante | importe | cuotas${svc.usa_receta ? " | con receta (sí/no)" : ""}.
Los legajos pueden ser alfanuméricos. Los importes son en pesos, usá punto decimal y sin separador de miles.
Devolvé ÚNICAMENTE JSON con la clave "items" (array). Cada item:
{ "legajo": string, "fecha": "YYYY-MM-DD" | null, "detalle": string | null, "comprobante": string | null, "importe": number, "cuotas": number, "con_receta": boolean, "es_cumpleanos": boolean }`;

  const res = await callLovableAI({
    model: "google/gemini-3.6-flash",
    messages: [
      { role: "system", content: system },
      {
        role: "user",
        content: [
          { type: "text", text: "Extraé el listado de consumos de esta imagen." },
          { type: "image_url", image_url: { url: base64 } },
        ],
      },
    ],
    response_format: { type: "json_object" },
  });
  if (!res.ok) {
    if (res.status === 429) throw new Error("La IA está sobrecargada. Probá en un rato.");
    if (res.status === 402) throw new Error("Sin créditos de IA.");
    throw new Error(`Error IA (${res.status})`);
  }
  const json = (await res.json()) as any;
  const raw = json.choices?.[0]?.message?.content ?? "{}";
  let parsed: any;
  try {
    parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
  } catch {
    throw new Error("La IA no devolvió JSON válido");
  }
  const list = Array.isArray(parsed?.items) ? parsed.items : [];
  return list
    .map((i: any) => ({
      legajo: String(i.legajo ?? "").trim().toUpperCase(),
      fecha: i.fecha ? String(i.fecha).slice(0, 10) : null,
      detalle: i.detalle ? String(i.detalle).slice(0, 500) : null,
      comprobante: i.comprobante ? String(i.comprobante).slice(0, 80) : null,
      importe: Number(i.importe) || 0,
      cuotas: Math.max(1, Number(i.cuotas) || 1),
      con_receta: Boolean(i.con_receta),
      es_cumpleanos: Boolean(i.es_cumpleanos),
    }))
    .filter((i: any) => i.legajo.length > 0);
}
