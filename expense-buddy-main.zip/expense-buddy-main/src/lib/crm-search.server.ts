// Helpers server-only para la búsqueda unificada del CRM.

export type CrmAffiliateHit = {
  legajo: string;
  apellido_nombre: string;
  sector?: string | null;
};

export type CrmProviderHit = {
  id: string;
  nombre: string;
  cuenta_contable: string | null;
  servicio: string | null;
  tipo: string | null;
  habilitado: boolean;
};

const r2 = (n: number) => Math.round(n * 100) / 100;
const periodo = (anio: number, mes: number) => `${anio}-${String(mes).padStart(2, "0")}`;

export async function searchAll(q: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const term = q.trim();
  if (!term) return { affiliates: [] as CrmAffiliateHit[], providers: [] as CrmProviderHit[] };
  const like = `%${term}%`;

  const [{ data: affs }, { data: provs }] = await Promise.all([
    supabaseAdmin
      .from("affiliates")
      .select("legajo, apellido_nombre, sector")
      .or(`legajo.ilike.${like},apellido_nombre.ilike.${like}`)
      .limit(25),
    supabaseAdmin
      .from("providers")
      .select("id, nombre, cuenta_contable, tipo, habilitado, services(nombre)")
      .or(`nombre.ilike.${like},cuenta_contable.ilike.${like},email.ilike.${like}`)
      .limit(25),
  ]);

  return {
    affiliates: (affs ?? []).map((a: any) => ({
      legajo: a.legajo,
      apellido_nombre: a.apellido_nombre,
      sector: a.sector ?? null,
    })) as CrmAffiliateHit[],
    providers: (provs ?? []).map((p: any) => ({
      id: p.id,
      nombre: p.nombre,
      cuenta_contable: p.cuenta_contable ?? null,
      servicio: p.services?.nombre ?? null,
      tipo: p.tipo ?? null,
      habilitado: !!p.habilitado,
    })) as CrmProviderHit[],
  };
}

export async function affiliateHistory(legajoRaw: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const legajo = legajoRaw.trim().toUpperCase();

  const [
    { data: aff },
    { data: items },
    { data: comida },
    { data: circleMembers },
    { data: planMembers },
    { data: colectaMembers },
    { data: adelantos },
  ] = await Promise.all([
    supabaseAdmin.from("affiliates").select("*").eq("legajo", legajo).maybeSingle(),
    supabaseAdmin
      .from("submission_items")
      .select(
        "*, providers(nombre, cuenta_contable), services(nombre, codigo), provider_submissions(periodo_mes, periodo_anio, estado, nombre)",
      )
      .eq("legajo", legajo)
      .order("fecha", { ascending: false })
      .limit(3000),
    supabaseAdmin
      .from("daily_consumptions")
      .select("*, daily_forms(fecha, descripcion_comida, es_cumpleanos)")
      .eq("legajo", legajo)
      .limit(3000),
    supabaseAdmin
      .from("circle_members")
      .select("*, circles(nombre, numero, periodo_inicio, periodo_fin)")
      .eq("legajo", legajo),
    supabaseAdmin
      .from("birthday_members")
      .select("*, birthday_plans(nombre, periodo_inicio)")
      .eq("legajo", legajo),
    supabaseAdmin
      .from("collection_members")
      .select("*, collections(nombre, cuotas, mes_inicio, anio_inicio, cerrada, motivo)")
      .eq("legajo", legajo),
    supabaseAdmin.from("adelantos" as any).select("*").eq("legajo", legajo),
  ]);



  const consumos = (items ?? []).map((i: any) => ({
    id: i.id,
    fecha: i.fecha,
    servicio: i.services?.nombre ?? "—",
    proveedor: i.providers?.nombre ?? "—",
    cuenta_contable: i.providers?.cuenta_contable ?? null,
    detalle: i.detalle,
    comprobante: i.comprobante,
    cuotas: i.cuotas,
    con_receta: i.con_receta,
    importe: Number(i.importe ?? 0),
    subsidio: Number(i.subsidio ?? 0),
    importe_afiliado: Number(i.importe_afiliado ?? 0),
    estado: i.provider_submissions?.estado ?? "—",
    liquidacion: i.provider_submissions?.nombre ?? "—",
    periodo: i.provider_submissions
      ? periodo(i.provider_submissions.periodo_anio, i.provider_submissions.periodo_mes)
      : "—",
  }));

  const comidas = (comida ?? [])
    .map((c: any) => ({
      id: c.id,
      fecha: c.daily_forms?.fecha ?? null,
      descripcion: c.daily_forms?.descripcion_comida ?? null,
      desayuno: !!c.desayuno,
      almuerzo: !!c.almuerzo,
      no_paga: !!c.no_paga || !!c.daily_forms?.es_cumpleanos,
      observacion: c.observacion ?? null,
      importe: Number(c.importe ?? 0),
    }))
    .sort((a, b) => String(b.fecha ?? "").localeCompare(String(a.fecha ?? "")));

  // Subservicios de Servicios Varios (Círculos, Cumpleaños, Colectas) expandidos por mes.
  const { circleActivo, monthIndex } = await import("./circles.server");
  const { cuotaIndex: cuotaCumple } = await import("./birthdays.server");
  const { cuotaIndex: cuotaColecta } = await import("./collections.server");

  const now = new Date();
  const hoyIdx = now.getUTCFullYear() * 12 + now.getUTCMonth();
  const idxToPeriodo = (idx: number) => periodo(Math.floor(idx / 12), (idx % 12) + 1);
  const ymKey = (mes: number, anio: number) => `${anio}${String(mes).padStart(2, "0")}`;
  const varios: {
    id: string;
    source_key: string;
    subservicio: string;
    detalle: string;
    periodo: string;
    cuota: string | null;
    importe: number;
  }[] = [];


  for (const m of circleMembers ?? []) {
    const c: any = (m as any).circles;
    if (!c) continue;
    const importe = Number(m.importe_mensual ?? 0);
    if (!importe) continue;
    const inicio = c.periodo_inicio
      ? Math.floor(Number(c.periodo_inicio) / 100) * 12 + ((Number(c.periodo_inicio) % 100) - 1)
      : hoyIdx;
    const finBase = c.periodo_fin
      ? Math.floor(Number(c.periodo_fin) / 100) * 12 + ((Number(c.periodo_fin) % 100) - 1)
      : hoyIdx;
    const fin = Math.min(finBase, hoyIdx);
    for (let i = inicio; i <= fin; i++) {
      const mes = (i % 12) + 1;
      const anio = Math.floor(i / 12);
      if (!circleActivo(c.periodo_inicio, c.periodo_fin, mes, anio)) continue;
      if (monthIndex(mes, anio) > hoyIdx) continue;
      varios.push({
        id: `circle:${m.id}:${anio}${mes}`,
        source_key: `circle_member:${m.id}:${ymKey(mes, anio)}`,

        subservicio: "Círculos",
        detalle: c.numero ? `Círculo ${c.numero} - ${c.nombre}` : c.nombre,
        periodo: idxToPeriodo(i),
        cuota: null,
        importe: r2(importe),
      });
    }
  }

  for (const m of planMembers ?? []) {
    const p: any = (m as any).birthday_plans;
    if (!p) continue;
    const cuotas: number[] = Array.isArray(m.cuotas) ? (m.cuotas as any[]).map((x) => Number(x) || 0) : [];
    for (let k = 1; k <= cuotas.length; k++) {
      const importe = r2(cuotas[k - 1] ?? 0);
      if (!importe) continue;
      const base = p.periodo_inicio
        ? Math.floor(Number(p.periodo_inicio) / 100) * 12 + ((Number(p.periodo_inicio) % 100) - 1)
        : null;
      if (base == null) continue;
      const idx = base + (k - 1);
      if (idx > hoyIdx) continue;
      const mes = (idx % 12) + 1;
      const anio = Math.floor(idx / 12);
      if (!cuotaCumple(p.periodo_inicio, cuotas.length, mes, anio)) continue;
      varios.push({
        id: `birthday:${m.id}:${k}`,
        source_key: `birthday_member:${m.id}:${ymKey(mes, anio)}`,

        subservicio: "Cumpleaños",
        detalle: p.nombre,
        periodo: idxToPeriodo(idx),
        cuota: `${k}/${cuotas.length}`,
        importe,
      });
    }
  }

  for (const m of colectaMembers ?? []) {
    const c: any = (m as any).collections;
    if (!c || c.mes_inicio == null || c.anio_inicio == null) continue;
    const cuotasTotales = Math.max(1, Number(c.cuotas) || 1);
    const importe = r2(Number(m.importe_cuota ?? 0) || Number(m.importe_total ?? 0) / cuotasTotales);
    if (!importe) continue;
    const base = Number(c.anio_inicio) * 12 + (Number(c.mes_inicio) - 1);
    for (let k = 1; k <= cuotasTotales; k++) {
      const idx = base + (k - 1);
      if (idx > hoyIdx) continue;
      const mes = (idx % 12) + 1;
      const anio = Math.floor(idx / 12);
      if (!cuotaColecta(c, mes, anio)) continue;
      varios.push({
        id: `collection:${m.id}:${k}`,
        source_key: `collection_member:${m.id}:${ymKey(mes, anio)}`,

        subservicio: "Colectas",
        detalle: c.motivo ? `${c.nombre} (${c.motivo})` : c.nombre,
        periodo: idxToPeriodo(idx),
        cuota: `${k}/${cuotasTotales}`,
        importe,
      });
    }
  }

  // Adelantos (los presta AGOEC): una fila por cuota vencida, refinanciables.
  for (const a of (adelantos ?? []) as any[]) {
    const cuotasTotales = Math.max(1, Number(a.cuotas) || 1);
    const importe = r2(Number(a.monto_pedido ?? 0) / cuotasTotales);
    if (!importe) continue;
    const base = Number(a.periodo_anio) * 12 + (Number(a.periodo_mes) - 1);
    for (let k = 1; k <= cuotasTotales; k++) {
      const idx = base + (k - 1);
      if (idx > hoyIdx) continue;
      const mes = (idx % 12) + 1;
      const anio = Math.floor(idx / 12);
      varios.push({
        id: `adelanto:${a.id}:${k}`,
        source_key: `adelanto:${a.id}:${ymKey(mes, anio)}`,
        subservicio: "Adelantos",
        detalle: a.concepto || "ADELANTO",
        periodo: idxToPeriodo(idx),
        cuota: `${k}/${cuotasTotales}`,
        importe,
      });
    }
  }

  varios.sort((a, b) => b.periodo.localeCompare(a.periodo) || a.subservicio.localeCompare(b.subservicio));
  const adelantosCrm = varios.filter((v) => v.subservicio === "Adelantos");
  const serviciosVarios = varios.filter((v) => v.subservicio !== "Adelantos");


  // Resumen mensual combinando servicios (CRM), Comida a Dto. y subservicios varios.
  const meses = new Map<string, { periodo: string; consumos: number; importe: number; a_descontar: number }>();
  for (const c of consumos) {
    const k = c.periodo !== "—" ? c.periodo : String(c.fecha ?? "").slice(0, 7) || "—";
    const row = meses.get(k) ?? { periodo: k, consumos: 0, importe: 0, a_descontar: 0 };
    row.consumos += 1;
    row.importe += c.importe;
    row.a_descontar += c.importe_afiliado;
    meses.set(k, row);
  }
  for (const c of comidas) {
    const k = String(c.fecha ?? "").slice(0, 7) || "—";
    const row = meses.get(k) ?? { periodo: k, consumos: 0, importe: 0, a_descontar: 0 };
    row.consumos += 1;
    row.importe += c.importe;
    row.a_descontar += c.no_paga ? 0 : c.importe;
    meses.set(k, row);
  }
  for (const v of varios) {
    const row = meses.get(v.periodo) ?? { periodo: v.periodo, consumos: 0, importe: 0, a_descontar: 0 };
    row.consumos += 1;
    row.importe += v.importe;
    row.a_descontar += v.importe;
    meses.set(v.periodo, row);
  }

  const porMes = Array.from(meses.values())
    .map((m) => ({ ...m, importe: r2(m.importe), a_descontar: r2(m.a_descontar) }))
    .sort((a, b) => b.periodo.localeCompare(a.periodo));

  const porServicio = new Map<string, number>();
  for (const c of consumos) porServicio.set(c.servicio, r2((porServicio.get(c.servicio) ?? 0) + c.importe_afiliado));
  if (comidas.length) {
    porServicio.set(
      "Comida a Dto.",
      r2(comidas.reduce((a, b) => a + (b.no_paga ? 0 : b.importe), 0)),
    );
  }
  for (const v of varios) porServicio.set(v.subservicio, r2((porServicio.get(v.subservicio) ?? 0) + v.importe));

  const variosTotal = r2(varios.reduce((a, b) => a + b.importe, 0));

  // Refinanciaciones ya aplicadas a este legajo (para marcar el detalle).
  const { data: refItems } = await supabaseAdmin
    .from("refinanciacion_items" as any)
    .select("source_key, refinanciaciones!inner(legajo)")
    .eq("refinanciaciones.legajo", legajo);
  const refinanciados = new Set((refItems ?? []).map((r: any) => String(r.source_key)));

  // Períodos ya liquidados (cerrados): sus consumos pasan a "Históricos" y no se refinancian.
  const { data: periodosCerrados } = await supabaseAdmin
    .from("payroll_periods")
    .select("hasta, estado")
    .eq("estado", "cerrado");
  const { periodMonth } = await import("./payroll.server");
  const cerrados = new Set(
    (periodosCerrados ?? []).map((p: any) => {
      const { mes, anio } = periodMonth(p.hasta);
      return periodo(anio, mes);
    }),
  );

  // Detalle unificado: todos los servicios y subservicios en una sola grilla.
  const detalleTodo = [

    ...consumos.map((c) => ({
      id: `srv:${c.id}`,
      source_key: `submission_item:${c.id}`,
      servicio: c.servicio,
      origen: c.proveedor,
      periodo: c.periodo !== "—" ? c.periodo : String(c.fecha ?? "").slice(0, 7) || "—",
      fecha: c.fecha ?? null,
      detalle: c.detalle ?? c.comprobante ?? "—",
      importe: c.importe,
      subsidio: c.subsidio,
      a_descontar: c.importe_afiliado,
      estado: c.estado,
      refinanciado: refinanciados.has(`submission_item:${c.id}`),
    })),
    ...comidas.map((c) => ({
      id: `comida:${c.id}`,
      source_key: `daily_consumption:${c.id}`,
      servicio: "Comida a Dto.",
      origen: "AGOEC",
      periodo: String(c.fecha ?? "").slice(0, 7) || "—",
      fecha: c.fecha ?? null,
      detalle: [c.descripcion, c.desayuno ? "Desayuno" : null, c.almuerzo ? "Almuerzo" : null]
        .filter(Boolean)
        .join(" · ") || "—",
      importe: c.importe,
      subsidio: 0,
      a_descontar: c.no_paga ? 0 : c.importe,
      estado: c.no_paga ? "no paga" : "—",
      refinanciado: refinanciados.has(`daily_consumption:${c.id}`),
    })),
    ...varios.map((v) => ({
      id: `varios:${v.id}`,
      source_key: v.source_key,
      servicio: v.subservicio,
      origen: "AGOEC",
      periodo: v.periodo,
      fecha: null,
      detalle: v.cuota ? `${v.detalle} (cuota ${v.cuota})` : v.detalle,
      importe: v.importe,
      subsidio: 0,
      a_descontar: v.importe,
      estado: "—",
      refinanciado: refinanciados.has(v.source_key),
    })),
  ]
    .map((d) => ({ ...d, periodo_cerrado: cerrados.has(String(d.periodo)) }))
    .sort((a, b) => String(b.periodo).localeCompare(String(a.periodo)));

  const detalle = detalleTodo.filter((d) => !d.periodo_cerrado);
  const historico = detalleTodo.filter((d) => d.periodo_cerrado);

  return {
    legajo,
    afiliado: aff ?? null,
    consumos,
    comidas,
    varios: serviciosVarios,
    adelantos: adelantosCrm,
    detalle,
    historico,
    porMes,

    porServicio: Array.from(porServicio, ([servicio, total]) => ({ servicio, total })).sort(
      (a, b) => b.total - a.total,
    ),
    totales: {
      items: consumos.length + comidas.length + varios.length,
      importe: r2(
        consumos.reduce((a, b) => a + b.importe, 0) +
          comidas.reduce((a, b) => a + b.importe, 0) +
          variosTotal,
      ),
      subsidio: r2(consumos.reduce((a, b) => a + b.subsidio, 0)),
      a_descontar: r2(
        consumos.reduce((a, b) => a + b.importe_afiliado, 0) +
          comidas.reduce((a, b) => a + (b.no_paga ? 0 : b.importe), 0) +
          variosTotal,
      ),
    },

  };
}

export async function providerHistory(providerId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const [{ data: prov }, { data: subs }] = await Promise.all([
    supabaseAdmin.from("providers").select("*, services(nombre, codigo)").eq("id", providerId).maybeSingle(),
    supabaseAdmin
      .from("provider_submissions")
      .select("*")
      .eq("provider_id", providerId)
      .order("periodo_anio", { ascending: false })
      .order("periodo_mes", { ascending: false })
      .limit(500),
  ]);
  if (!prov) throw new Error("Proveedor no encontrado");

  const liquidaciones = (subs ?? []).map((s: any) => ({
    id: s.id,
    nombre: s.nombre,
    periodo: periodo(s.periodo_anio, s.periodo_mes),
    estado: s.estado,
    total_items: s.total_items,
    total_afiliados: s.total_afiliados,
    total_importe: Number(s.total_importe ?? 0),
    total_subsidio: Number(s.total_subsidio ?? 0),
    total_a_pagar: Number(s.total_a_pagar ?? 0),
    created_at: s.created_at,
  }));

  const pagos = liquidaciones.filter((l) => l.estado === "pagada");
  const pendientes = liquidaciones.filter((l) => l.estado !== "pagada" && l.estado !== "rechazada");

  return {
    proveedor: {
      id: prov.id,
      nombre: prov.nombre,
      cuenta_contable: prov.cuenta_contable ?? null,
      cuit: prov.cuit ?? null,
      email: prov.email ?? null,
      tipo: prov.tipo ?? null,
      habilitado: !!prov.habilitado,
      banco: prov.banco ?? null,
      cbu: prov.cbu ?? null,
      alias: prov.alias ?? null,
      titular: prov.titular ?? null,
      servicio: (prov as any).services?.nombre ?? null,
    },
    liquidaciones,
    totales: {
      liquidaciones: liquidaciones.length,
      facturado: r2(liquidaciones.reduce((a, b) => a + b.total_importe, 0)),
      pagado: r2(pagos.reduce((a, b) => a + b.total_a_pagar, 0)),
      pendiente: r2(pendientes.reduce((a, b) => a + b.total_a_pagar, 0)),
      subsidios: r2(liquidaciones.reduce((a, b) => a + b.total_subsidio, 0)),
    },
  };
}

// Buscador de consumos por rubro: solo ítems de proveedores habilitados.
export async function farmaciaConsumos(q: string, rubro: "farmacia" | "indumentaria" | "supermercado" = "farmacia") {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const term = q.trim();
  if (!term) return { affiliates: [] as CrmAffiliateHit[], items: [] as any[], totales: null };

  const like = `%${term}%`;
  const { data: affs } = await supabaseAdmin
    .from("affiliates")
    .select("legajo, apellido_nombre, sector")
    .or(`legajo.ilike.${like},apellido_nombre.ilike.${like}`)
    .limit(25);

  const legajos = (affs ?? []).map((a: any) => a.legajo);
  if (!legajos.length) return { affiliates: [] as CrmAffiliateHit[], items: [] as any[], totales: null };

  // Servicio Farmacia (por código contable o nombre).
  const rubroOr =
    rubro === "indumentaria"
      ? "codigo.eq.1130203,nombre.ilike.%indumentaria%"
      : rubro === "supermercado"
        ? "codigo.eq.1130201,nombre.ilike.%supermercado%"
        : "codigo.eq.1130205,nombre.ilike.%farmacia%";
  const { data: svcs } = await supabaseAdmin
    .from("services")
    .select("id, nombre, codigo")
    .or(rubroOr);
  const serviceIds = (svcs ?? []).map((s: any) => s.id);
  if (!serviceIds.length) return { affiliates: affs as CrmAffiliateHit[], items: [] as any[], totales: null };

  // Solo farmacias habilitadas.
  const { data: provs } = await supabaseAdmin
    .from("providers")
    .select("id, nombre")
    .in("service_id", serviceIds)
    .eq("habilitado", true);
  const provIds = (provs ?? []).map((p: any) => p.id);
  const provNombre = new Map((provs ?? []).map((p: any) => [p.id, p.nombre]));
  if (!provIds.length) return { affiliates: affs as CrmAffiliateHit[], items: [] as any[], totales: null };

  // En Supermercado solo se muestran los consumos del período vigente.
  let vigente: { mes: number; anio: number } | null = null;
  if (rubro === "supermercado") {
    const { periodoVigente } = await import("./periodo-vigente.server");
    vigente = await periodoVigente();
  }

  const { data: items } = await supabaseAdmin
    .from("submission_items")
    .select("id, legajo, fecha, detalle, comprobante, importe, cuotas, con_receta, subsidio, importe_afiliado, prestacion, provider_id, provider_submissions(periodo_mes, periodo_anio, estado, nombre)")
    .in("provider_id", provIds)
    .in("legajo", legajos)
    .order("fecha", { ascending: false })
    .limit(500);

  const itemsFiltrados = vigente
    ? (items ?? []).filter(
        (it: any) =>
          it.provider_submissions?.periodo_mes === vigente!.mes &&
          it.provider_submissions?.periodo_anio === vigente!.anio,
      )
    : (items ?? []);

  const rows = itemsFiltrados.map((it: any) => ({
    id: it.id,
    legajo: it.legajo,
    fecha: it.fecha,
    detalle: it.detalle,
    comprobante: it.comprobante,
    importe: Number(it.importe ?? 0),
    cuotas: it.cuotas,
    con_receta: !!it.con_receta,
    subsidio: Number(it.subsidio ?? 0),
    a_descontar: Number(it.importe_afiliado ?? 0),
    prestacion: it.prestacion ?? null,
    farmacia: provNombre.get(it.provider_id) ?? "—",
    periodo: it.provider_submissions
      ? periodo(it.provider_submissions.periodo_anio, it.provider_submissions.periodo_mes)
      : "—",
    estado: it.provider_submissions?.estado ?? "—",
  }));

  const totales = {
    items: rows.length,
    importe: r2(rows.reduce((a, b) => a + b.importe, 0)),
    subsidio: r2(rows.reduce((a, b) => a + b.subsidio, 0)),
    a_descontar: r2(rows.reduce((a, b) => a + b.a_descontar, 0)),
  };

  return { affiliates: (affs ?? []) as CrmAffiliateHit[], items: rows, totales };
}

// Buscador de consumos de Automotores: solo proveedores habilitados y período vigente.
export async function automotoresConsumosVigente(q: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { periodoVigente } = await import("./periodo-vigente.server");
  const term = q.trim();
  const vigente = await periodoVigente();
  if (!term) return { affiliates: [] as CrmAffiliateHit[], items: [] as any[], totales: null, vigente };

  const like = `%${term}%`;
  const { data: affs } = await supabaseAdmin
    .from("affiliates")
    .select("legajo, apellido_nombre, sector")
    .or(`legajo.ilike.${like},apellido_nombre.ilike.${like}`)
    .limit(25);

  const legajos = (affs ?? []).map((a: any) => a.legajo);
  if (!legajos.length)
    return { affiliates: [] as CrmAffiliateHit[], items: [] as any[], totales: null, vigente };

  // Servicio Automotores (por código contable o nombre).
  const { data: svcs } = await supabaseAdmin
    .from("services")
    .select("id, nombre, codigo")
    .or("codigo.eq.1130202,nombre.ilike.%automot%");
  const serviceIds = (svcs ?? []).map((s: any) => s.id);
  if (!serviceIds.length)
    return { affiliates: affs as CrmAffiliateHit[], items: [] as any[], totales: null, vigente };

  // Solo proveedores habilitados del servicio.
  const { data: provs } = await supabaseAdmin
    .from("providers")
    .select("id, nombre")
    .in("service_id", serviceIds)
    .eq("habilitado", true);
  const provIds = (provs ?? []).map((p: any) => p.id);
  const provNombre = new Map((provs ?? []).map((p: any) => [p.id, p.nombre]));
  if (!provIds.length)
    return { affiliates: affs as CrmAffiliateHit[], items: [] as any[], totales: null, vigente };

  // Liquidaciones del período vigente de esos proveedores.
  const { data: subs } = await supabaseAdmin
    .from("provider_submissions")
    .select("id, provider_id, estado, nombre")
    .in("provider_id", provIds)
    .eq("periodo_mes", vigente.mes)
    .eq("periodo_anio", vigente.anio);
  const subIds = (subs ?? []).map((s: any) => s.id);
  const subMap = new Map((subs ?? []).map((s: any) => [s.id, s]));
  if (!subIds.length)
    return { affiliates: affs as CrmAffiliateHit[], items: [] as any[], totales: null, vigente };

  const { data: items } = await supabaseAdmin
    .from("submission_items")
    .select("id, submission_id, provider_id, legajo, fecha, detalle, comprobante, importe, cuotas, subsidio, importe_afiliado, prestacion, comision_pct, comision_monto, neto_proveedor")
    .in("submission_id", subIds)
    .in("legajo", legajos)
    .order("fecha", { ascending: false })
    .limit(500);

  const rows = (items ?? []).map((it: any) => {
    const sub = subMap.get(it.submission_id);
    return {
      id: it.id,
      legajo: it.legajo,
      fecha: it.fecha,
      detalle: it.detalle,
      comprobante: it.comprobante,
      importe: Number(it.importe ?? 0),
      cuotas: it.cuotas,
      subsidio: Number(it.subsidio ?? 0),
      a_descontar: Number(it.importe_afiliado ?? 0),
      prestacion: it.prestacion ?? null,
      comision_pct: Number(it.comision_pct ?? 0),
      comision_monto: Number(it.comision_monto ?? 0),
      neto_proveedor: it.neto_proveedor != null ? Number(it.neto_proveedor) : null,
      proveedor: provNombre.get(it.provider_id) ?? "—",
      estado: sub?.estado ?? "—",
    };
  });

  const totales = {
    items: rows.length,
    importe: r2(rows.reduce((a, b) => a + b.importe, 0)),
    comision: r2(rows.reduce((a, b) => a + b.comision_monto, 0)),
    a_descontar: r2(rows.reduce((a, b) => a + b.a_descontar, 0)),
  };

  return { affiliates: (affs ?? []) as CrmAffiliateHit[], items: rows, totales, vigente };
}

// Buscador de consumos de Servicios Varios (Comida a Dto., Círculos, Cumpleaños, Colectas)
// acotado al período vigente: por legajo o nombre del afiliado.
export async function variosConsumosVigente(q: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { periodoVigente } = await import("./periodo-vigente.server");
  const term = q.trim();
  const vigente = await periodoVigente();
  const empty = { affiliates: [] as CrmAffiliateHit[], items: [] as any[], totales: null as any, vigente };
  if (!term) return empty;

  const like = `%${term}%`;
  const { data: affs } = await supabaseAdmin
    .from("affiliates")
    .select("legajo, apellido_nombre, sector")
    .or(`legajo.ilike.${like},apellido_nombre.ilike.${like}`)
    .limit(25);

  const legajos = (affs ?? []).map((a: any) => String(a.legajo));
  if (!legajos.length) return empty;
  const nombreDe = new Map((affs ?? []).map((a: any) => [String(a.legajo), a.apellido_nombre]));

  const { mes, anio } = vigente;
  const desde = `${anio}-${String(mes).padStart(2, "0")}-01`;
  const hastaMes = mes === 12 ? `${anio + 1}-01-01` : `${anio}-${String(mes + 1).padStart(2, "0")}-01`;

  const { circleActivo } = await import("./circles.server");
  const { cuotaIndex: cuotaCumple } = await import("./birthdays.server");
  const { cuotaIndex: cuotaColecta } = await import("./collections.server");

  const [
    { data: comida },
    { data: circleMembers },
    { data: planMembers },
    { data: colectaMembers },
  ] = await Promise.all([
    supabaseAdmin
      .from("daily_consumptions")
      .select("id, legajo, importe, no_paga, desayuno, almuerzo, daily_forms!inner(fecha, descripcion_comida, es_cumpleanos)")
      .in("legajo", legajos)
      .gte("daily_forms.fecha", desde)
      .lt("daily_forms.fecha", hastaMes)
      .limit(3000),
    supabaseAdmin
      .from("circle_members")
      .select("*, circles(nombre, numero, periodo_inicio, periodo_fin)")
      .in("legajo", legajos),
    supabaseAdmin
      .from("birthday_members")
      .select("*, birthday_plans(nombre, periodo_inicio)")
      .in("legajo", legajos),
    supabaseAdmin
      .from("collection_members")
      .select("*, collections(nombre, cuotas, mes_inicio, anio_inicio, cerrada, motivo)")
      .in("legajo", legajos),
  ]);

  const rows: {
    id: string;
    legajo: string;
    afiliado: string;
    subservicio: string;
    detalle: string;
    fecha: string | null;
    cuota: string | null;
    importe: number;
    a_descontar: number;
    estado: string;
  }[] = [];

  const push = (r: Omit<(typeof rows)[number], "afiliado">) =>
    rows.push({ ...r, afiliado: nombreDe.get(r.legajo) ?? "—" });

  for (const c of (comida ?? []) as any[]) {
    const noPaga = !!c.no_paga || !!c.daily_forms?.es_cumpleanos;
    const importe = Number(c.importe ?? 0);
    push({
      id: `comida:${c.id}`,
      legajo: String(c.legajo),
      subservicio: "Comida a Dto.",
      detalle:
        [c.daily_forms?.descripcion_comida, c.desayuno ? "Desayuno" : null, c.almuerzo ? "Almuerzo" : null]
          .filter(Boolean)
          .join(" · ") || "—",
      fecha: c.daily_forms?.fecha ?? null,
      cuota: null,
      importe,
      a_descontar: noPaga ? 0 : importe,
      estado: noPaga ? "no paga" : "—",
    });
  }

  for (const m of (circleMembers ?? []) as any[]) {
    const c: any = m.circles;
    if (!c) continue;
    if (!circleActivo(c.periodo_inicio, c.periodo_fin, mes, anio)) continue;
    const importe = r2(Number(m.importe_mensual ?? 0));
    if (!importe) continue;
    push({
      id: `circle:${m.id}`,
      legajo: String(m.legajo),
      subservicio: "Círculos",
      detalle: c.numero ? `Círculo ${c.numero} - ${c.nombre}` : c.nombre,
      fecha: null,
      cuota: null,
      importe,
      a_descontar: importe,
      estado: "—",
    });
  }

  for (const m of (planMembers ?? []) as any[]) {
    const p: any = m.birthday_plans;
    if (!p) continue;
    const cuotas: number[] = Array.isArray(m.cuotas) ? m.cuotas.map((x: any) => Number(x) || 0) : [];
    const idx = cuotaCumple(p.periodo_inicio, cuotas.length, mes, anio);
    if (!idx) continue;
    const importe = r2(cuotas[idx - 1] ?? 0);
    if (!importe) continue;
    push({
      id: `birthday:${m.id}`,
      legajo: String(m.legajo),
      subservicio: "Cumpleaños",
      detalle: p.nombre,
      fecha: null,
      cuota: `${idx}/${cuotas.length}`,
      importe,
      a_descontar: importe,
      estado: "—",
    });
  }

  for (const m of (colectaMembers ?? []) as any[]) {
    const c: any = m.collections;
    if (!c || c.cerrada) continue;
    const idx = cuotaColecta(c, mes, anio);
    if (!idx) continue;
    const cuotasTotales = Math.max(1, Number(c.cuotas) || 1);
    const importe = r2(Number(m.importe_cuota ?? 0) || Number(m.importe_total ?? 0) / cuotasTotales);
    if (!importe) continue;
    push({
      id: `collection:${m.id}`,
      legajo: String(m.legajo),
      subservicio: "Colectas",
      detalle: c.motivo ? `${c.nombre} (${c.motivo})` : c.nombre,
      fecha: null,
      cuota: `${idx}/${cuotasTotales}`,
      importe,
      a_descontar: importe,
      estado: "—",
    });
  }

  rows.sort(
    (a, b) =>
      a.legajo.localeCompare(b.legajo) ||
      a.subservicio.localeCompare(b.subservicio) ||
      String(a.fecha ?? "").localeCompare(String(b.fecha ?? "")),
  );

  const porSubservicio = new Map<string, { subservicio: string; consumos: number; a_descontar: number }>();
  for (const r of rows) {
    const s = porSubservicio.get(r.subservicio) ?? { subservicio: r.subservicio, consumos: 0, a_descontar: 0 };
    s.consumos += 1;
    s.a_descontar = r2(s.a_descontar + r.a_descontar);
    porSubservicio.set(r.subservicio, s);
  }

  const totales = {
    items: rows.length,
    importe: r2(rows.reduce((a, b) => a + b.importe, 0)),
    a_descontar: r2(rows.reduce((a, b) => a + b.a_descontar, 0)),
  };

  return {
    affiliates: (affs ?? []) as CrmAffiliateHit[],
    items: rows,
    totales,
    porSubservicio: [...porSubservicio.values()],
    vigente,
  };
}
