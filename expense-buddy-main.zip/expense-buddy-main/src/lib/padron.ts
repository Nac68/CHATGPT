// Modelo de Excel del padrón de afiliados (formato AGOEC/CEAMSE).
// Se usa tanto para importar como para exportar, así el archivo que baja
// tiene exactamente las mismas columnas que el que se sube.

export type PadronRow = {
  legajo: string;
  apellido_nombre: string;
  sector?: string | null;
  sexo?: string | null;
  fecha_nac?: string | null;
  tipo_doc?: string | null;
  doc_nro?: string | null;
  cuil?: string | null;
  estado_civil?: string | null;
  calle?: string | null;
  numero?: string | null;
  piso?: string | null;
  depto?: string | null;
  cp?: string | null;
  localidad?: string | null;
  telefono?: string | null;
  celular?: string | null;
  fecha_afiliacion?: string | null;
  fecha_ingreso?: string | null;
  observaciones?: string | null;
  lugar_trabajo?: string | null;
  codigo_lugar_trabajo?: string | null;
};

/** Columna del Excel modelo -> campo del padrón */
export const PADRON_COLUMNS: { header: string; field: keyof PadronRow; date?: boolean }[] = [
  { header: "LEGAJO", field: "legajo" },
  { header: "APELLIDO_Y_NOMBRE", field: "apellido_nombre" },
  { header: "SECTOR", field: "sector" },
  { header: "SEXO", field: "sexo" },
  { header: "FECHA_NAC", field: "fecha_nac", date: true },
  { header: "TIPO_DOC", field: "tipo_doc" },
  { header: "DOC_Nº", field: "doc_nro" },
  { header: "CUIL", field: "cuil" },
  { header: "ESTADO_CIVIL", field: "estado_civil" },
  { header: "CALLE", field: "calle" },
  { header: "NUMERO", field: "numero" },
  { header: "PISO", field: "piso" },
  { header: "DEPTO", field: "depto" },
  { header: "CP", field: "cp" },
  { header: "LOCALIDAD", field: "localidad" },
  { header: "TELEFONO", field: "telefono" },
  { header: "CELULAR", field: "celular" },
  { header: "FECHA_DE_AFILIACION", field: "fecha_afiliacion", date: true },
  { header: "FECHA_INGRESO", field: "fecha_ingreso", date: true },
  { header: "OBSERVACIONES", field: "observaciones" },
  { header: "DESCRIPCION_DE_LUGAR_DE_TRABAJO", field: "lugar_trabajo" },
  { header: "CODIGO_LUGAR_DE_TRABAJO", field: "codigo_lugar_trabajo" },
];

const clean = (h: unknown) =>
  String(h ?? "")
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "");

/** Alias aceptados al importar, por si el archivo trae variantes de encabezado. */
const ALIASES: Record<string, keyof PadronRow> = {
  LEGAJO: "legajo",
  NROLEGAJO: "legajo",
  APELLIDOYNOMBRE: "apellido_nombre",
  APELLIDOYNOMBRES: "apellido_nombre",
  APELLIDONOMBRE: "apellido_nombre",
  NOMBREYAPELLIDO: "apellido_nombre",
  SECTOR: "sector",
  SEXO: "sexo",
  FECHANAC: "fecha_nac",
  FECHADENACIMIENTO: "fecha_nac",
  TIPODOC: "tipo_doc",
  DOCN: "doc_nro",
  DOCNRO: "doc_nro",
  NRODOC: "doc_nro",
  DNI: "doc_nro",
  CUIL: "cuil",
  CUIT: "cuil",
  ESTADOCIVIL: "estado_civil",
  CALLE: "calle",
  NUMERO: "numero",
  PISO: "piso",
  DEPTO: "depto",
  CP: "cp",
  LOCALIDAD: "localidad",
  TELEFONO: "telefono",
  CELULAR: "celular",
  FECHADEAFILIACION: "fecha_afiliacion",
  FECHAAFILIACION: "fecha_afiliacion",
  FECHAINGRESO: "fecha_ingreso",
  OBSERVACIONES: "observaciones",
  DESCRIPCIONDELUGARDETRABAJO: "lugar_trabajo",
  LUGARDETRABAJO: "lugar_trabajo",
  CODIGOLUGARDETRABAJO: "codigo_lugar_trabajo",
};

export function fieldForHeader(header: unknown): keyof PadronRow | null {
  return ALIASES[clean(header)] ?? null;
}

const DATE_FIELDS = new Set<keyof PadronRow>(["fecha_nac", "fecha_afiliacion", "fecha_ingreso"]);

export function toISODate(value: unknown): string | null {
  if (value == null || value === "") return null;
  if (value instanceof Date && !isNaN(value.getTime())) {
    const y = value.getFullYear();
    const m = String(value.getMonth() + 1).padStart(2, "0");
    const d = String(value.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }
  const s = String(value).trim();
  let m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  m = s.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})$/);
  if (m) {
    const yy = m[3].length === 2 ? `20${m[3]}` : m[3];
    return `${yy}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}`;
  }
  const n = Number(s);
  if (Number.isFinite(n) && n > 20000 && n < 60000) {
    // serial de fecha de Excel
    const ms = Math.round((n - 25569) * 86400 * 1000);
    return toISODate(new Date(ms));
  }
  return null;
}

export function normalizeCell(field: keyof PadronRow, value: unknown): string | null {
  if (DATE_FIELDS.has(field)) return toISODate(value);
  if (value == null) return null;
  const s = String(value).trim();
  return s ? s : null;
}

/** Fila de la base -> objeto plano listo para escribir en el Excel modelo */
export function toExcelRow(a: any): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const c of PADRON_COLUMNS) out[c.header] = a?.[c.field] ?? "";
  return out;
}
