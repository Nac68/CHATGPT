// Ordena legajos alfanuméricos de menor a mayor:
// los numéricos van primero en orden numérico, luego los alfanuméricos alfabéticamente.
export function compareLegajo(a: string, b: string): number {
  const sa = String(a ?? "");
  const sb = String(b ?? "");
  const na = /^\d+$/.test(sa) ? Number(sa) : null;
  const nb = /^\d+$/.test(sb) ? Number(sb) : null;
  if (na != null && nb != null) return na - nb;
  if (na != null) return -1;
  if (nb != null) return 1;
  return sa.localeCompare(sb, "es", { numeric: true, sensitivity: "base" });
}

/** Normaliza legajos provenientes de Excel o carga manual. */
export function normalizeLegajo(value: unknown): string {
  return String(value ?? "")
    .replace(/[\u00a0\u2007\u202f]/g, " ")
    .trim()
    .replace(/\.0+$/, "")
    .replace(/\s+/g, "")
    .toUpperCase();
}
