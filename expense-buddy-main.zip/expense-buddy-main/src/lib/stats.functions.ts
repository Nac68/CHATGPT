import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const getAdminStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Sólo administradores");

    const today = new Date();
    const y = today.getFullYear();

    const { data: forms } = await context.supabase
      .from("daily_forms")
      .select("id, fecha, importe");
    const { data: consumos } = await context.supabase
      .from("daily_consumptions")
      .select("legajo, desayuno, almuerzo, importe, daily_form_id");

    const fechaMap = new Map((forms ?? []).map((f: any) => [f.id, f.fecha as string]));
    const importeFormMap = new Map((forms ?? []).map((f: any) => [f.id, Number(f.importe ?? 0)]));

    const byMonth = new Map<
      string,
      { desayunos: number; almuerzos: number; consumos: number; importe: number }
    >();

    for (const c of consumos ?? []) {
      const fecha = fechaMap.get(c.daily_form_id);
      if (!fecha) continue;
      const key = fecha.slice(0, 7);
      const cur = byMonth.get(key) ?? { desayunos: 0, almuerzos: 0, consumos: 0, importe: 0 };
      if (c.desayuno) { cur.desayunos++; cur.consumos++; }
      if (c.almuerzo) { cur.almuerzos++; cur.consumos++; }
      cur.importe += Number(c.importe ?? 0);
      byMonth.set(key, cur);
    }
    // Also account for daily form importe when no consumption rows exist (rare)
    for (const [id, fecha] of fechaMap) {
      const key = (fecha as string).slice(0, 7);
      if (!byMonth.has(key)) {
        byMonth.set(key, {
          desayunos: 0,
          almuerzos: 0,
          consumos: 0,
          importe: importeFormMap.get(id) ?? 0,
        });
      }
    }

    // Top affiliates by count of consumos
    const byLegajo = new Map<string, number>();
    for (const c of consumos ?? []) {
      let n = byLegajo.get(c.legajo) ?? 0;
      if (c.desayuno) n++;
      if (c.almuerzo) n++;
      byLegajo.set(c.legajo, n);
    }
    const topLegajos = Array.from(byLegajo.entries()).sort((a, b) => b[1] - a[1]).slice(0, 10);
    const legajoIds = topLegajos.map(([l]) => l);
    const { data: affs } = await context.supabase
      .from("affiliates")
      .select("legajo, apellido_nombre")
      .in("legajo", legajoIds.length ? legajoIds : ["__none__"]);
    const nameMap = new Map((affs ?? []).map((a: any) => [a.legajo as string, a.apellido_nombre as string]));
    const topAffiliates = topLegajos.map(([legajo, n]) => ({
      legajo,
      apellido_nombre: nameMap.get(legajo) ?? legajo,
      consumos: n,
    }));

    const monthsArr = Array.from(byMonth.entries())
      .map(([mes, v]) => ({
        mes,
        desayunos: v.desayunos,
        almuerzos: v.almuerzos,
        consumos: v.consumos,
        importe_total: Math.round(v.importe * 100) / 100,
      }))
      .sort((a, b) => a.mes.localeCompare(b.mes));

    const currentMonthKey = `${y}-${String(today.getMonth() + 1).padStart(2, "0")}`;
    const currentMonth = byMonth.get(currentMonthKey);
    const currentYearMonths = monthsArr.filter((m) => m.mes.startsWith(String(y)));
    const yearlyConsumos = currentYearMonths.reduce((a, b) => a + b.consumos, 0);
    const yearlyImporte = currentYearMonths.reduce((a, b) => a + (b.importe_total ?? 0), 0);

    return {
      months: monthsArr,
      currentMonth: currentMonth ?? { desayunos: 0, almuerzos: 0, consumos: 0, importe: 0 },
      currentMonthImporte: currentMonth ? Math.round(currentMonth.importe * 100) / 100 : 0,
      yearlyConsumos,
      yearlyImporte: Math.round(yearlyImporte * 100) / 100,
      topAffiliates,
      totalForms: (forms ?? []).length,
      totalAffiliatesActive: byLegajo.size,
    };
  });

export const getMyStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => {
    const r = (raw ?? {}) as any;
    const l = typeof r?.legajo === "string" ? r.legajo.trim().toUpperCase() : null;
    return { legajo: l && l.length <= 32 ? l : null };
  })
  .handler(async ({ data, context }) => {
    const { data: legajoData } = await context.supabase.rpc("current_legajo");
    let legajo = (legajoData as string | null) ?? null;
    if (!legajo) {
      // Un administrador puede ver la cuenta de cualquier afiliado.
      const { data: adminRole } = await context.supabase.rpc("has_role", {
        _user_id: context.userId,
        _role: "admin",
      });
      if (adminRole) legajo = data.legajo;
    }
    if (!legajo) throw new Error("No sos afiliado");


    const { data: cons } = await context.supabase
      .from("daily_consumptions")
      .select("desayuno, almuerzo, importe, observacion, daily_form_id")
      .eq("legajo", legajo);
    const { data: forms } = await context.supabase
      .from("daily_forms")
      .select("id, fecha, descripcion_comida");
    const fechaMap = new Map((forms ?? []).map((f: any) => [f.id, f]));

    const byMonth = new Map<
      string,
      { desayunos: number; almuerzos: number; consumos: number; importe: number }
    >();
    const days: {
      fecha: string;
      desayuno: boolean;
      almuerzo: boolean;
      descripcion: string | null;
      observacion: string | null;
      importe: number;
    }[] = [];
    for (const c of cons ?? []) {
      const f: any = fechaMap.get(c.daily_form_id);
      if (!f) continue;
      const key = (f.fecha as string).slice(0, 7);
      const cur = byMonth.get(key) ?? { desayunos: 0, almuerzos: 0, consumos: 0, importe: 0 };
      if (c.desayuno) { cur.desayunos++; cur.consumos++; }
      if (c.almuerzo) { cur.almuerzos++; cur.consumos++; }
      cur.importe += Number(c.importe ?? 0);
      byMonth.set(key, cur);
      days.push({
        fecha: f.fecha,
        desayuno: c.desayuno,
        almuerzo: c.almuerzo,
        descripcion: f.descripcion_comida,
        observacion: c.observacion,
        importe: Number(c.importe ?? 0),
      });
    }
    days.sort((a, b) => b.fecha.localeCompare(a.fecha));

    const months = Array.from(byMonth.entries())
      .map(([mes, v]) => ({
        mes,
        desayunos: v.desayunos,
        almuerzos: v.almuerzos,
        consumos: v.consumos,
        importe_a_pagar: Math.round(v.importe * 100) / 100,
      }))
      .sort((a, b) => b.mes.localeCompare(a.mes));

    return { legajo, months, days };
  });
