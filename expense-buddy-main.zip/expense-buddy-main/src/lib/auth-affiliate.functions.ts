import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const AFFILIATE_EMAIL_DOMAIN = "afiliado.interno.local";

export function normalizeLegajo(raw: string): string {
  return raw.trim().toUpperCase().replace(/\s+/g, "");
}

export const affiliateEmail = (legajo: string) =>
  `legajo-${legajo.toLowerCase().replace(/[^a-z0-9]/g, "-")}@${AFFILIATE_EMAIL_DOMAIN}`;

export const defaultPinFor = (legajo: string) => {
  const s = legajo.replace(/[^a-zA-Z0-9]/g, "");
  return (s.length >= 4 ? s.slice(-4) : s.padStart(4, "0")).toLowerCase();
};

const LegajoSchema = z.string().min(1).max(32).transform(normalizeLegajo);

export const loginAffiliate = createServerFn({ method: "POST" })
  .inputValidator((raw: unknown) =>
    z.object({ legajo: LegajoSchema, pin: z.string().min(3).max(24) }).parse(raw),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: aff, error: affErr } = await supabaseAdmin
      .from("affiliates")
      .select("legajo, apellido_nombre, user_id")
      .eq("legajo", data.legajo)
      .maybeSingle();
    if (affErr) throw new Error(affErr.message);
    if (!aff) throw new Error("Legajo no encontrado");

    const email = affiliateEmail(data.legajo);

    if (!aff.user_id) {
      if (data.pin.toLowerCase() !== defaultPinFor(data.legajo)) {
        throw new Error(
          "Esta es la primera vez que ingresás. Tu PIN inicial son los últimos 4 caracteres de tu legajo.",
        );
      }
      const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
        email,
        password: data.pin,
        email_confirm: true,
        user_metadata: { legajo: data.legajo, apellido_nombre: aff.apellido_nombre },
      });
      if (createErr || !created.user) throw new Error(createErr?.message || "No se pudo crear la cuenta");

      await supabaseAdmin.from("affiliates").update({ user_id: created.user.id }).eq("legajo", data.legajo);
      await supabaseAdmin
        .from("user_roles")
        .insert({ user_id: created.user.id, role: "afiliado", legajo: data.legajo });

      // Primer ingreso con el PIN inicial predecible: hay que cambiarlo.
      await supabaseAdmin.from("affiliate_pin_status" as any).upsert(
        { user_id: created.user.id, legajo: data.legajo, must_change_pin: true } as any,
        { onConflict: "user_id" },
      );
      return { email, must_change_pin: true };
    }

    // Cuentas existentes: sólo se fuerza el cambio si el PIN usado es el inicial
    // derivado del legajo (o si un admin lo reseteó y quedó la marca).
    let must = false;
    if (data.pin.toLowerCase() === defaultPinFor(data.legajo)) {
      await supabaseAdmin.from("affiliate_pin_status" as any).upsert(
        { user_id: aff.user_id, legajo: data.legajo, must_change_pin: true } as any,
        { onConflict: "user_id" },
      );
      must = true;
    } else {
      const { data: st } = await supabaseAdmin
        .from("affiliate_pin_status" as any)
        .select("must_change_pin")
        .eq("user_id", aff.user_id)
        .maybeSingle();
      must = Boolean((st as any)?.must_change_pin);
    }

    return { email, must_change_pin: must };
  });

export const resetAffiliatePin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ legajo: LegajoSchema, newPin: z.string().min(4).max(24) }).parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Sólo el administrador puede resetear PINs");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: aff } = await supabaseAdmin
      .from("affiliates")
      .select("user_id")
      .eq("legajo", data.legajo)
      .maybeSingle();
    if (!aff?.user_id) throw new Error("El afiliado aún no tiene cuenta creada");

    const { error } = await supabaseAdmin.auth.admin.updateUserById(aff.user_id, { password: data.newPin });
    if (error) throw new Error(error.message);
    // Reset administrativo: el afiliado debe cambiarlo en su próximo ingreso.
    await supabaseAdmin.from("affiliate_pin_status" as any).upsert(
      { user_id: aff.user_id, legajo: data.legajo, must_change_pin: true } as any,
      { onConflict: "user_id" },
    );
    return { ok: true };
  });

export const changeMyPin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ currentPin: z.string().min(3), newPin: z.string().min(4).max(24) }).parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { createClient } = await import("@supabase/supabase-js");
    const email = context.claims.email as string | undefined;
    if (!email) throw new Error("Sesión inválida");
    const tmp = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_PUBLISHABLE_KEY!, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { error: signErr } = await tmp.auth.signInWithPassword({ email, password: data.currentPin });
    if (signErr) throw new Error("El PIN actual es incorrecto");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Validación del lado del servidor: el nuevo PIN no puede ser el inicial
    // predecible del legajo, ni repetir el actual.
    const legajo = await legajoOf(supabaseAdmin, context.userId);
    if (legajo && data.newPin.toLowerCase() === defaultPinFor(legajo))
      throw new Error("El nuevo PIN no puede ser el PIN inicial de tu legajo. Elegí otro.");
    if (data.newPin === data.currentPin)
      throw new Error("El nuevo PIN debe ser distinto al actual");

    const { error } = await supabaseAdmin.auth.admin.updateUserById(context.userId, { password: data.newPin });
    if (error) throw new Error(error.message);

    await supabaseAdmin.from("affiliate_pin_status" as any).upsert(
      {
        user_id: context.userId,
        legajo,
        must_change_pin: false,
        pin_changed_at: new Date().toISOString(),
      } as any,
      { onConflict: "user_id" },
    );
    return { ok: true };
  });

/** Legajo del afiliado según sus roles (nunca se leen ni guardan PINs). */
async function legajoOf(supabaseAdmin: any, userId: string): Promise<string | null> {
  const { data } = await supabaseAdmin
    .from("user_roles")
    .select("legajo")
    .eq("user_id", userId)
    .eq("role", "afiliado")
    .maybeSingle();
  const l = (data as any)?.legajo;
  return l ? normalizeLegajo(String(l)) : null;
}

/** ¿Este afiliado tiene pendiente el cambio obligatorio de PIN? */
export const myPinStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: st } = await supabaseAdmin
      .from("affiliate_pin_status" as any)
      .select("must_change_pin")
      .eq("user_id", context.userId)
      .maybeSingle();
    return { must_change_pin: Boolean((st as any)?.must_change_pin) };
  });
