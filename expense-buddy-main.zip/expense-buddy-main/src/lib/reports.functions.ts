import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

/**
 * Informes contables del período:
 *  - Liquidación a proveedores (lo que se transfiere a cada proveedor externo).
 *  - Liquidación de descuentos afiliado por afiliado (lo que se le descuenta a cada legajo).
 * Cada servicio / producto / proveedor lleva su número contable (manual y editable).
 */
export const accountingReport = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        mes: z.number().int().min(1).max(12),
        anio: z.number().int().min(2000).max(2100),
        service_id: z.string().uuid().nullable().optional(),
        incluir_comida: z.boolean().default(true),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { buildProviderReport, buildAffiliateReport, monthRange, periodoLabel } = await import(
      "./reports.server"
    );
    const { from, to } = monthRange({ mes: data.mes, anio: data.anio });

    const [{ data: services }, { data: providers }, { data: subs }] = await Promise.all([
      context.supabase.from("services").select("*").order("nombre"),
      context.supabase.from("providers").select("*").order("nombre"),
      context.supabase
        .from("provider_submissions")
        .select("*")
        .eq("periodo_mes", data.mes)
        .eq("periodo_anio", data.anio)
        .neq("estado", "rechazado"),
    ]);

    const subsList = (subs ?? []).filter(
      (s: any) => !data.service_id || s.service_id === data.service_id,
    );
    const subIds = subsList.map((s: any) => s.id);

    let items: any[] = [];
    if (subIds.length) {
      const { data: it, error } = await context.supabase
        .from("submission_items")
        .select(
          "legajo, fecha, detalle, comprobante, importe, importe_afiliado, subsidio, cuotas, con_receta, es_cumpleanos, provider_id, service_id, submission_id",
        )
        .in("submission_id", subIds);
      if (error) throw new Error(error.message);
      items = it ?? [];
    }

    // Comida a Dto. (servicio interno de AGOEC) del mismo período.
    let comida: { legajo: string; importe: number }[] = [];
    let comidaTotal = 0;
    if (data.incluir_comida && !data.service_id) {
      const { data: forms } = await context.supabase
        .from("daily_forms")
        .select("id, fecha, importe, es_cumpleanos")
        .gte("fecha", from)
        .lt("fecha", to);
      const formIds = (forms ?? []).map((f: any) => f.id);
      if (formIds.length) {
        const { data: cons } = await context.supabase
          .from("daily_consumptions")
          .select("legajo, importe, no_paga, daily_form_id")
          .in("daily_form_id", formIds);
        const exentos = new Set(
          (forms ?? []).filter((f: any) => f.es_cumpleanos).map((f: any) => f.id),
        );
        comida = (cons ?? [])
          .filter((c: any) => !c.no_paga && !exentos.has(c.daily_form_id))
          .map((c: any) => ({ legajo: String(c.legajo), importe: Number(c.importe ?? 0) }))
          .filter((c) => c.importe > 0);
        comidaTotal = comida.reduce((a, c) => a + c.importe, 0);
      }
    }

    const legajos = [...new Set([...items.map((i) => String(i.legajo)), ...comida.map((c) => c.legajo)])];
    const nombres = new Map<string, string>();
    for (let i = 0; i < legajos.length; i += 500) {
      const chunk = legajos.slice(i, i + 500);
      const { data: affs } = await context.supabase
        .from("affiliates")
        .select("legajo, apellido_nombre")
        .in("legajo", chunk);
      for (const a of affs ?? []) nombres.set(String(a.legajo), a.apellido_nombre);
    }

    const svcList = (services ?? []).filter(
      (s: any) => !data.service_id || s.id === data.service_id,
    );
    const provReport = buildProviderReport({
      services: services ?? [],
      providers: (providers ?? []).filter(
        (p: any) => !data.service_id || p.service_id === data.service_id,
      ),
      items,
    });
    const affReport = buildAffiliateReport({
      services: services ?? [],
      items,
      comida,
      nombres,
    });

    const { compareLegajo } = await import("./legajo");
    affReport.sort((a, b) => compareLegajo(a.legajo, b.legajo));

    const columnasServicio = [
      ...new Set([
        ...svcList.map((s: any) => s.nombre),
        ...(comida.length ? ["Comida a Dto."] : []),
      ]),
    ].filter((n) => affReport.some((r) => (r.por_servicio[n] ?? 0) !== 0));

    return {
      periodo: periodoLabel({ mes: data.mes, anio: data.anio }),
      services: (services ?? []).map((s: any) => ({
        id: s.id,
        nombre: s.nombre,
        codigo: s.codigo,
        cuenta_contable: s.cuenta_contable ?? null,
      })),
      proveedores: provReport,
      afiliados: affReport,
      columnasServicio,
      kpis: {
        a_transferir: Math.round(provReport.reduce((a, p) => a + p.a_transferir, 0) * 100) / 100,
        subsidio_agoec: Math.round(provReport.reduce((a, p) => a + p.subsidio_agoec, 0) * 100) / 100,
        descuento_afiliados:
          Math.round(affReport.reduce((a, r) => a + r.total_descuento, 0) * 100) / 100,
        comida_total: Math.round(comidaTotal * 100) / 100,
        proveedores: provReport.length,
        afiliados: affReport.length,
        items: items.length + comida.length,
      },
    };
  });

/** Números contables de servicios y productos: se cargan a mano y se pueden editar. */
export const listAccountingCodes = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const [{ data: services }, { data: products }, { data: providers }] = await Promise.all([
      context.supabase.from("services").select("id, nombre, codigo, cuenta_contable").order("nombre"),
      context.supabase
        .from("service_products")
        .select("id, nombre, codigo, tipo, service_id, cuenta_contable")
        .order("nombre"),
      context.supabase
        .from("providers")
        .select("id, nombre, service_id, tipo, cuenta_contable")
        .order("nombre"),
    ]);
    return { services: services ?? [], products: products ?? [], providers: providers ?? [] };
  });

export const setCuentaContable = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        tipo: z.enum(["service", "product", "provider"]),
        id: z.string().uuid(),
        cuenta_contable: z.string().trim().max(40).nullable(),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const table =
      data.tipo === "service" ? "services" : data.tipo === "product" ? "service_products" : "providers";
    const { error } = await context.supabase
      .from(table)
      .update({ cuenta_contable: data.cuenta_contable || null })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
