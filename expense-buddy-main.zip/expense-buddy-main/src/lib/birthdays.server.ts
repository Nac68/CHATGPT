// Helpers server-only para Cumpleaños: cuotas mensuales y liquidación.

export const r2 = (n: number) => Math.round((Number(n) || 0) * 100) / 100;

/** YYYYMM -> índice absoluto de mes. */
export const periodToIndex = (p: number) => {
  const anio = Math.floor(Number(p) / 100);
  const mes = Number(p) % 100;
  return anio * 12 + (mes - 1);
};

/** Índice de cuota (1..n) que corresponde a mes/anio, o null. */
export function cuotaIndex(periodo_inicio: number | null, cuotas: number, mes: number, anio: number) {
  if (!periodo_inicio) return null;
  const diff = anio * 12 + (mes - 1) - periodToIndex(periodo_inicio);
  if (diff < 0) return null;
  return diff < cuotas ? diff + 1 : null;
}

export type BirthdayPlan = {
  id: string;
  nombre: string;
  importe_total: number;
  periodo_inicio: number | null;
  periodo_fin: number | null;
  members: any[];
};

export type BirthdaySettlementRow = {
  legajo: string;
  apellido_nombre: string | null;
  planes: { nombre: string; cuota: string; importe: number }[];
  importe: number;
};

export function buildBirthdaySettlement(plans: BirthdayPlan[], mes: number, anio: number) {
  const map = new Map<string, BirthdaySettlementRow>();
  let planesActivos = 0;
  const agasajados: { legajo: string; apellido_nombre: string | null; importe: number; plan: string; plan_id: string }[] = [];

  for (const p of plans) {
    let activo = false;
    for (const m of p.members ?? []) {
      const cuotas: number[] = Array.isArray(m.cuotas) ? m.cuotas.map((x: any) => Number(x) || 0) : [];
      const idx = cuotaIndex(p.periodo_inicio, cuotas.length, mes, anio);
      if (!idx) continue;
      activo = true;
      const importe = r2(cuotas[idx - 1] ?? 0);
      if (importe) {
        const legajo = String(m.legajo);
        let row = map.get(legajo);
        if (!row) {
          row = { legajo, apellido_nombre: m.apellido_nombre ?? null, planes: [], importe: 0 };
          map.set(legajo, row);
        }
        row.planes.push({ nombre: p.nombre, cuota: `${idx}/${cuotas.length}`, importe });
        row.importe = r2(row.importe + importe);
      }
      // Agasajados del mes: cumplen años en este mes
      if (m.fecha_cobro) {
        const d = new Date(String(m.fecha_cobro));
        if (d.getUTCMonth() + 1 === mes) {
          agasajados.push({
            legajo: String(m.legajo),
            apellido_nombre: m.apellido_nombre ?? null,
            importe: r2(Number(p.importe_total) || 0),
            plan: p.nombre,
            plan_id: p.id,
          });
        }
      }
    }
    if (activo) planesActivos += 1;
  }

  const rows = [...map.values()];
  return {
    rows,
    agasajados,
    total: r2(rows.reduce((a, r) => a + r.importe, 0)),
    total_a_pagar: r2(agasajados.reduce((a, r) => a + r.importe, 0)),
    aportantes: rows.length,
    planes: planesActivos,
  };
}
