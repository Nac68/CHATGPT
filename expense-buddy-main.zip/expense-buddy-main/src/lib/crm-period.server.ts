// Consulta consolidada del CRM: LEGAJO + PERÍODO -> movimientos por servicio.
// Reutiliza las mismas reglas que la liquidación (payroll.server) para que la
// pantalla, el Excel y la impresión salgan del MISMO dataset.

import { cuotaPlan, r2 } from "./refinance-plan";

export type CrmMovimiento = {
  id: string;
  source_key: string;
  servicio: string;
  origen: string;
  detalle: string;
  fecha: string | null;
  referencia: string | null;
  cuota: number | null;
  cuotas: number;
  importe: number;
  /** Sólo Refinanciación: consumos/deudas originales que formaron el plan. */
  origenes?: { servicio: string | null; detalle: string | null; periodo: string | null; importe: number }[];
  /** true si el movimiento ya quedó liquidado (payroll_consumed) en este período. */
  liquidado: boolean;
};

const pad = (n: number) => String(n).padStart(2, "0");
const ymd = (anio: number, mes: number, dia: number) => `${anio}-${pad(mes)}-${pad(dia)}`;
const idxOf = (mes: number, anio: number) => anio * 12 + (mes - 1);

/** Período administrativo AGOEC: día 21 del mes anterior -> día 20 del mes del período. */
export function periodRange(mes: number, anio: number) {
  const prev = idxOf(mes, anio) - 1;
  return {
    desde: ymd(Math.floor(prev / 12), (prev % 12) + 1, 21),
    hasta: ymd(anio, mes, 20),
  };
}

/** Período vigente según la fecha de hoy (el que todavía no cerró el día 20). */
export function currentPeriod(hoy = new Date()) {
  const mes = hoy.getUTCMonth() + 1;
  const anio = hoy.getUTCFullYear();
  if (hoy.getUTCDate() <= 20) return { mes, anio };
  const n = idxOf(mes, anio) + 1;
  return { mes: (n % 12) + 1, anio: Math.floor(n / 12) };
}

export async function affiliatePeriod(args: { legajo: string; mes: number; anio: number }) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const legajo = String(args.legajo).trim().toUpperCase();
  const { mes, anio } = args;
  const { desde, hasta } = periodRange(mes, anio);
  const ym = `${anio}${pad(mes)}`;
  const hoyISO = new Date().toISOString().slice(0, 10);
  const periodoLabel = `${pad(mes)}/${anio}`;

  const [
    { data: aff },
    { data: periodos },
    { data: consumed },
    { data: refinItems },
    { data: circleMembers },
    { data: planMembers },
    { data: colectaMembers },
    { data: adelantos },
    { data: refis },
    { data: forms },
  ] = await Promise.all([
    supabaseAdmin.from("affiliates").select("*").eq("legajo", legajo).maybeSingle(),
    supabaseAdmin.from("payroll_periods").select("id, nombre, desde, hasta, estado, concepto_nombre"),
    supabaseAdmin.from("payroll_consumed").select("source_key, period_id"),
    supabaseAdmin.from("refinanciacion_items" as any).select("*, refinanciaciones!inner(id, legajo)"),
    supabaseAdmin
      .from("circle_members")
      .select("*, circles(nombre, numero, periodo_inicio, periodo_fin)")
      .eq("legajo", legajo),
    supabaseAdmin.from("birthday_members").select("*, birthday_plans(nombre, periodo_inicio)").eq("legajo", legajo),
    supabaseAdmin
      .from("collection_members")
      .select("*, collections(nombre, motivo, cuotas, mes_inicio, anio_inicio, cerrada)")
      .eq("legajo", legajo),
    supabaseAdmin.from("adelantos" as any).select("*").eq("legajo", legajo),
    supabaseAdmin.from("refinanciaciones" as any).select("*").eq("legajo", legajo),
    supabaseAdmin
      .from("daily_forms")
      .select("id, fecha, descripcion_comida, es_cumpleanos")
      .gte("fecha", desde)
      .lte("fecha", hasta > hoyISO ? hoyISO : hasta),

  ]);

  // Períodos ya liquidados: mapa source_key -> período (mes/año) que lo consumió.
  const { periodMonth } = await import("./payroll.server");
  const periodoDeId = new Map<string, string>();
  for (const p of (periodos ?? []) as any[]) {
    const pm = periodMonth(p.hasta);
    periodoDeId.set(p.id, `${pm.anio}${pad(pm.mes)}`);
  }
  const consumidoEn = new Map<string, string>();
  for (const c of (consumed ?? []) as any[]) {
    const ymC = periodoDeId.get(c.period_id);
    if (ymC) consumidoEn.set(String(c.source_key), ymC);
  }
  /** El movimiento pertenece al período pedido salvo que otro período ya lo haya liquidado. */
  const perteneceAlPeriodo = (key: string) => {
    const en = consumidoEn.get(key);
    return !en || en === ym;
  };
  const yaLiquidado = (key: string) => consumidoEn.get(key) === ym;

  // Todo lo refinanciado se cobra por cuotas del plan: no se cuenta el original.
  const refinanciados = new Set(
    ((refinItems ?? []) as any[])
      .filter((r) => String(r.refinanciaciones?.legajo ?? "").toUpperCase() === legajo)
      .map((r) => String(r.source_key)),
  );
  const itemsPorRefi = new Map<string, any[]>();
  for (const r of (refinItems ?? []) as any[]) {
    const id = String(r.refinanciaciones?.id ?? r.refinanciacion_id);
    (itemsPorRefi.get(id) ?? itemsPorRefi.set(id, []).get(id)!).push(r);
  }

  const movs: CrmMovimiento[] = [];
  const push = (m: Omit<CrmMovimiento, "liquidado">) => {
    if (!r2(m.importe)) return;
    if (refinanciados.has(m.source_key)) return;
    if (!perteneceAlPeriodo(m.source_key)) return;
    movs.push({ ...m, importe: r2(m.importe), liquidado: yaLiquidado(m.source_key) });
  };

  // 1) Consumos cargados por proveedores (Automotores, Farmacia, Supermercado, Indumentaria...).
  const { data: items } = await supabaseAdmin
    .from("submission_items")
    .select(
      "*, providers(nombre, cuenta_contable), services(nombre, codigo), provider_submissions(nombre, estado, periodo_mes, periodo_anio, factura)",
    )
    .eq("legajo", legajo)
    .limit(5000);
  for (const it of (items ?? []) as any[]) {
    const sub = it.provider_submissions;
    if (!sub || String(sub.estado) === "rechazado" || !sub.periodo_mes || !sub.periodo_anio) continue;
    const cuotas = Math.max(1, Number(it.cuotas) || 1);
    const k = idxOf(mes, anio) - idxOf(Number(sub.periodo_mes), Number(sub.periodo_anio));
    if (k < 0 || k >= cuotas) continue;
    const explicitas: number[] = Array.isArray(it.cuotas_importes)
      ? (it.cuotas_importes as any[]).map((x) => Number(x) || 0)
      : [];
    const importe =
      explicitas.length === cuotas ? explicitas[k] : Number(it.importe_afiliado ?? 0) / cuotas;
    const base = `submission_item:${it.id}`;
    push({
      id: `srv:${it.id}:${k}`,
      source_key: cuotas > 1 ? `${base}:${ym}` : base,
      servicio: it.services?.nombre ?? "Servicio",
      origen: it.providers?.nombre ?? "—",
      detalle: [it.prestacion, it.detalle].filter(Boolean).join(" · ") || "—",
      fecha: it.fecha ?? null,
      referencia: it.comprobante ?? sub.factura ?? null,
      cuota: k + 1,
      cuotas,
      importe,
    });
  }

  // 2) Comida a Dto.: un movimiento por consumo del rango 21 -> 20 (o hasta hoy si está abierto).
  const formById = new Map(((forms ?? []) as any[]).map((f) => [f.id, f]));
  const formIds = ((forms ?? []) as any[]).filter((f) => !f.es_cumpleanos).map((f) => f.id);
  if (formIds.length) {
    const { data: cons } = await supabaseAdmin
      .from("daily_consumptions")
      .select("*")
      .eq("legajo", legajo)
      .in("daily_form_id", formIds);
    for (const c of (cons ?? []) as any[]) {
      if (c.no_paga) continue;
      const f: any = formById.get(c.daily_form_id);
      push({
        id: `comida:${c.id}`,
        source_key: `daily_consumption:${c.id}`,
        servicio: "Comida a Dto.",
        origen: "AGOEC",
        detalle:
          [f?.descripcion_comida, c.desayuno ? "Desayuno" : null, c.almuerzo ? "Almuerzo" : null]
            .filter(Boolean)
            .join(" · ") || "Comida",
        fecha: f?.fecha ?? null,
        referencia: null,
        cuota: null,
        cuotas: 1,
        importe: Number(c.importe ?? 0),
      });
    }
  }

  // 3) Círculos (aporte del mes del período).
  {
    const { circleActivo } = await import("./circles.server");
    for (const m of (circleMembers ?? []) as any[]) {
      const c = m.circles;
      if (!c || !circleActivo(c.periodo_inicio, c.periodo_fin, mes, anio)) continue;
      push({
        id: `circle:${m.id}`,
        source_key: `circle_member:${m.id}:${ym}`,
        servicio: "Servicios Varios",
        origen: "Círculo",
        detalle: c.numero ? `Círculo ${c.numero} - ${c.nombre}` : c.nombre,
        fecha: m.fecha_cobro ?? null,
        referencia: c.numero ?? null,
        cuota: null,
        cuotas: 1,
        importe: Number(m.importe_mensual ?? 0),
      });
    }
  }

  // 4) Cumpleaños.
  {
    const { cuotaIndex } = await import("./birthdays.server");
    for (const m of (planMembers ?? []) as any[]) {
      const p = m.birthday_plans;
      if (!p) continue;
      const cuotas: number[] = Array.isArray(m.cuotas) ? (m.cuotas as any[]).map((x) => Number(x) || 0) : [];
      const idx = cuotaIndex(p.periodo_inicio, cuotas.length, mes, anio);
      if (!idx) continue;
      push({
        id: `birthday:${m.id}`,
        source_key: `birthday_member:${m.id}:${ym}`,
        servicio: "Servicios Varios",
        origen: "Cumpleaños",
        detalle: p.nombre,
        fecha: m.fecha_cobro ?? null,
        referencia: null,
        cuota: idx,
        cuotas: cuotas.length || 1,
        importe: cuotas[idx - 1] ?? 0,
      });
    }
  }

  // 5) Colectas.
  {
    const { cuotaIndex } = await import("./collections.server");
    for (const m of (colectaMembers ?? []) as any[]) {
      const c = m.collections;
      if (!c) continue;
      const idx = cuotaIndex(c, mes, anio);
      if (!idx) continue;
      const cuotasTotales = Math.max(1, Number(c.cuotas) || 1);
      push({
        id: `colecta:${m.id}`,
        source_key: `collection_member:${m.id}:${ym}`,
        servicio: "Servicios Varios",
        origen: "Colecta",
        detalle: c.motivo ? `${c.nombre} (${c.motivo})` : c.nombre,
        fecha: null,
        referencia: null,
        cuota: idx,
        cuotas: cuotasTotales,
        importe: Number(m.importe_cuota ?? 0) || Number(m.importe_total ?? 0) / cuotasTotales,
      });
    }
  }

  // 6) Adelantos (cuota del período).
  for (const a of (adelantos ?? []) as any[]) {
    const cuotas = Math.max(1, Number(a.cuotas) || 1);
    const k = idxOf(mes, anio) - idxOf(Number(a.periodo_mes), Number(a.periodo_anio));
    if (k < 0 || k >= cuotas) continue;
    push({
      id: `adelanto:${a.id}`,
      source_key: `adelanto:${a.id}:${ym}`,
      servicio: "Adelantos",
      origen: "AGOEC",
      detalle: a.concepto || "ADELANTO",
      fecha: a.fecha ?? null,
      referencia: a.ref_id ?? null,
      cuota: k + 1,
      cuotas,
      importe: cuotaPlan(Number(a.monto_pedido ?? 0), cuotas)[k],
    });
  }

  // 7) Refinanciación (cuota del período + orígenes reales del plan).
  for (const rf of (refis ?? []) as any[]) {
    const cuotas = Math.max(1, Number(rf.cuotas) || 1);
    const tope = rf.cuotas_efectivas == null ? cuotas : Math.max(0, Number(rf.cuotas_efectivas));
    const k = idxOf(mes, anio) - idxOf(Number(rf.periodo_mes), Number(rf.periodo_anio));
    if (k < 0 || k >= cuotas || k >= tope) continue;
    push({
      id: `refi:${rf.id}`,
      source_key: `refinanciacion:${rf.id}:${ym}`,
      servicio: "Refinanciación",
      origen: rf.origen === "adelanto" ? "Adelanto refinanciado" : "AGOEC",
      detalle: `Plan ${pad(Number(rf.periodo_mes))}/${rf.periodo_anio} · ${cuotas} cuotas${
        rf.observacion ? ` · ${rf.observacion}` : ""
      }`,
      fecha: rf.created_at ? String(rf.created_at).slice(0, 10) : null,
      referencia: String(rf.id).slice(0, 8),
      cuota: k + 1,
      cuotas,
      importe: cuotaPlan(Number(rf.total ?? 0), cuotas)[k],
      origenes: (itemsPorRefi.get(String(rf.id)) ?? []).map((i: any) => ({
        servicio: i.servicio ?? null,
        detalle: i.detalle ?? null,
        periodo: i.periodo ?? null,
        importe: r2(Number(i.importe ?? 0)),
      })),
    });
  }

  movs.sort(
    (a, b) =>
      a.servicio.localeCompare(b.servicio) ||
      String(a.fecha ?? "").localeCompare(String(b.fecha ?? "")) ||
      a.origen.localeCompare(b.origen),
  );

  // Resumen por servicio (sólo servicios con movimientos) y total general.
  const porServicioMap = new Map<string, { servicio: string; movimientos: number; total: number }>();
  for (const m of movs) {
    const row = porServicioMap.get(m.servicio) ?? { servicio: m.servicio, movimientos: 0, total: 0 };
    row.movimientos += 1;
    row.total = r2(row.total + m.importe);
    porServicioMap.set(m.servicio, row);
  }
  const por_servicio = [...porServicioMap.values()].sort((a, b) => b.total - a.total);
  const total = r2(por_servicio.reduce((a, b) => a + b.total, 0));

  // Estado del período y fotografía histórica ya liquidada (no se recalcula).
  const cerrados = ((periodos ?? []) as any[]).filter((p) => {
    const pm = periodMonth(p.hasta);
    return pm.mes === mes && pm.anio === anio && String(p.estado) === "cerrado";
  });
  let liquidado: { servicio: string; importe: number }[] = [];
  let liquidado_total = 0;
  if (cerrados.length) {
    const { data: pitems } = await supabaseAdmin
      .from("payroll_period_items")
      .select("servicio, importe, period_id")
      .eq("legajo", legajo)
      .in("period_id", cerrados.map((p) => p.id));
    const map = new Map<string, number>();
    for (const i of (pitems ?? []) as any[])
      map.set(String(i.servicio), r2((map.get(String(i.servicio)) ?? 0) + Number(i.importe ?? 0)));
    liquidado = [...map, ].map(([servicio, importe]) => ({ servicio, importe })).sort((a, b) => b.importe - a.importe);
    liquidado_total = r2(liquidado.reduce((a, b) => a + b.importe, 0));
  }

  return {
    legajo,
    afiliado: aff
      ? {
          apellido_nombre: aff.apellido_nombre ?? null,
          cuil: aff.cuil ?? null,
          lugar_trabajo: aff.lugar_trabajo ?? null,
          sector: aff.sector ?? null,
        }
      : null,
    periodo: { mes, anio, label: periodoLabel },
    desde,
    hasta,
    corte: hasta > hoyISO ? hoyISO : hasta,
    estado: cerrados.length ? ("CERRADO" as const) : ("ABIERTO" as const),
    cierres: cerrados.map((p) => ({ nombre: p.nombre, concepto: p.concepto_nombre ?? null })),
    movimientos: movs,
    por_servicio,
    total,
    liquidado,
    liquidado_total,
  };
}

/** Períodos ofrecidos en el selector: el vigente + los últimos meses, con su estado. */
export async function affiliatePeriodList(meses = 24) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: periodos } = await supabaseAdmin.from("payroll_periods").select("hasta, estado");
  const { periodMonth } = await import("./payroll.server");
  const cerrados = new Set(
    ((periodos ?? []) as any[])
      .filter((p) => String(p.estado) === "cerrado")
      .map((p) => {
        const pm = periodMonth(p.hasta);
        return `${pm.anio}${pad(pm.mes)}`;
      }),
  );
  const cur = currentPeriod();
  const base = idxOf(cur.mes, cur.anio);
  return Array.from({ length: meses }, (_, i) => {
    const idx = base - i;
    const mes = (idx % 12) + 1;
    const anio = Math.floor(idx / 12);
    const { desde, hasta } = periodRange(mes, anio);
    return {
      mes,
      anio,
      label: `${pad(mes)}/${anio}`,
      desde,
      hasta,
      estado: cerrados.has(`${anio}${pad(mes)}`) ? ("CERRADO" as const) : ("ABIERTO" as const),
    };
  });
}
