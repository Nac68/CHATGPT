// Tablero operativo del período (portada de Administración).
// SÓLO agrega/reutiliza lecturas existentes: no cambia lógica de negocio de los módulos.

import { cuotaDelPeriodo } from "./refinance-plan";

const r2 = (n: number) => Math.round((Number(n) || 0) * 100) / 100;

const ymd = (d: Date) =>
  `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(
    d.getUTCDate(),
  ).padStart(2, "0")}`;

export type PayoutRow = {
  tipo: "Cumpleaños" | "Círculo" | "Colecta";
  detalle: string;
  legajo: string | null;
  beneficiario: string | null;
  importe: number;
  cuil: string | null;
  titular: string | null;
  cbu: string | null;
  alias: string | null;
  falta_bancario: boolean;
  ref_key: string;
  adelantado: boolean;
  adelantado_info: string | null;
};

export async function buildAdminDashboard() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { defaultPeriod, periodMonth, buildCircleBirthdayPayout, buildPayroll } = await import(
    "./payroll.server"
  );

  const { desde, hasta } = defaultPeriod();
  // El tablero se rige por el PERÍODO vigente (mensual y transversal a todos los servicios).
  const { periodoVigente } = await import("./periodo-vigente.server");
  const { mes, anio } = await periodoVigente();

  // "Hoy" en hora de Argentina (el servidor corre en UTC; a las 21 hs AR ya sería mañana).
  const hoy = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Argentina/Buenos_Aires",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
  void ymd;
  const diasRestantes = Math.ceil(
    (new Date(`${hasta}T00:00:00Z`).getTime() - new Date(`${hoy}T00:00:00Z`).getTime()) / 86400000,
  );

  const [payout, payroll] = await Promise.all([
    buildCircleBirthdayPayout({ desde, hasta }),
    buildPayroll({ desde, hasta }),
  ]);

  const [
    { data: colectas },
    { data: providers },
    { data: subs },
    { data: refis },
    { data: settlements },
    { data: formsPeriodo },
    { data: formHoy },
  ] = await Promise.all([
    supabaseAdmin.from("collections").select("*"),
    supabaseAdmin.from("providers").select("id, nombre, interno, habilitado, cbu, alias, titular, cuit"),
    supabaseAdmin
      .from("provider_submissions")
      .select("id, provider_id, estado, periodo_mes, periodo_anio, total_a_pagar")
      .neq("estado", "rechazado"),
    supabaseAdmin.from("refinanciaciones" as any).select("*").eq("estado", "activa"),
    supabaseAdmin
      .from("settlements")
      .select("id, nombre, estado, periodo_mes, periodo_anio, importe_total, total_consumos"),
    supabaseAdmin.from("daily_forms").select("id, fecha, importe").gte("fecha", desde).lte("fecha", hasta),
    supabaseAdmin.from("daily_forms").select("id, fecha, importe, descripcion_comida").eq("fecha", hoy),
  ]);

  // ---- Pagos de Servicios Varios del período -------------------------------
  const rows: PayoutRow[] = (payout.rows ?? []).map((r: any) => ({
    tipo: r.tipo === "Círculo" ? "Círculo" : "Cumpleaños",
    detalle: r.detalle,
    legajo: r.legajo ?? null,
    beneficiario: r.apellido_nombre ?? null,
    importe: r2(r.importe),
    cuil: null,
    titular: null,
    cbu: null,
    alias: null,
    falta_bancario: true,
    ref_key: String(r.ref_key ?? ""),
    adelantado: false,
    adelantado_info: null,
  }));

  // Colectas: activas según el PERÍODO (cuota del mes), no por fecha calendario.
  // Importe a transferir: el objetivo si está cargado; si no, lo recaudado a los integrantes ese mes.
  let colectasSinFecha = 0;
  {
    const { cuotaIndex } = await import("./collections.server");
    const { data: colMembers } = await supabaseAdmin.from("collection_members").select("*");
    for (const c of (colectas ?? []) as any[]) {
      if (c.cerrada) continue;
      const idx = cuotaIndex(c as any, mes, anio);
      if (!idx) continue;
      const tieneBenef = !!(c.beneficiario_legajo || c.beneficiario_nombre);
      if (!tieneBenef) {
        colectasSinFecha += 1;
        continue;
      }
      const cuotasTotales = Math.max(1, Number(c.cuotas) || 1);
      const recaudado = ((colMembers ?? []) as any[])
        .filter((m) => String(m.collection_id) === String(c.id))
        .reduce(
          (a, m) =>
            a + (Number(m.importe_cuota ?? 0) || Number(m.importe_total ?? 0) / cuotasTotales),
          0,
        );
      const objetivo = Number(c.importe_objetivo ?? 0);
      rows.push({
        tipo: "Colecta",
        detalle: `${c.nombre} (cuota ${idx}/${cuotasTotales})`,
        legajo: c.beneficiario_legajo ?? null,
        beneficiario: c.beneficiario_nombre ?? null,
        importe: r2(objetivo > 0 ? objetivo : recaudado),
        cuil: null,
        titular: null,
        cbu: null,
        alias: null,
        falta_bancario: true,
        ref_key: `colecta:${c.id}`,
        adelantado: false,
        adelantado_info: null,
      });
    }
  }


  // Datos disponibles del afiliado beneficiario: sólo CUIL (el padrón no tiene banco).
  const legajos = [...new Set(rows.map((r) => r.legajo).filter(Boolean) as string[])];
  if (legajos.length) {
    const { data: affs } = await supabaseAdmin
      .from("affiliates")
      .select("legajo, apellido_nombre, cuil")
      .in("legajo", legajos);
    const map = new Map((affs ?? []).map((a: any) => [String(a.legajo), a]));
    for (const r of rows) {
      const a: any = r.legajo ? map.get(r.legajo) : null;
      if (!a) continue;
      r.beneficiario = r.beneficiario ?? a.apellido_nombre ?? null;
      r.cuil = a.cuil ?? null;
    }
  }

  // Pagos adelantados: no se vuelven a transferir (el descuento a integrantes sigue intacto).
  const { data: adel } = await supabaseAdmin.from("pagos_adelantados" as any).select("*");
  const adelMap = new Map(((adel ?? []) as any[]).map((a) => [String(a.ref_key), a]));
  for (const r of rows) {
    const a: any = adelMap.get(r.ref_key);
    if (!a) continue;
    r.adelantado = true;
    const per = a.pagado_mes ? `${String(a.pagado_mes).padStart(2, "0")}/${a.pagado_anio}` : "";
    r.adelantado_info = `Pagado por adelantado${per ? ` en ${per}` : ""}${a.pagado_por_email ? ` · ${a.pagado_por_email}` : ""}`;
  }
  const totalAdelantado = r2(rows.filter((r) => r.adelantado).reduce((a, r) => a + r.importe, 0));
  const totalTransferir = r2(rows.filter((r) => !r.adelantado).reduce((a, r) => a + r.importe, 0));

  // ---- Proveedores sin presentación del período ----------------------------
  const subsPeriodo = ((subs ?? []) as any[]).filter(
    (s) => Number(s.periodo_mes) === mes && Number(s.periodo_anio) === anio,
  );
  const conCarga = new Set(subsPeriodo.map((s) => String(s.provider_id)));
  const proveedoresSinCarga = ((providers ?? []) as any[])
    .filter((p) => p.habilitado && !p.interno && !conCarga.has(String(p.id)))
    .map((p) => ({ id: p.id, nombre: p.nombre }));

  const totalProveedores = r2(
    subsPeriodo.reduce((a, s) => a + Number(s.total_a_pagar ?? 0), 0),
  );

  // ---- Refinanciación: cuotas del período ---------------------------------
  let refiCuotas = 0;
  let refiTotal = 0;
  for (const r of (refis ?? []) as any[]) {
    const c = cuotaDelPeriodo(r, mes, anio);
    if (!c) continue;
    refiCuotas += 1;
    refiTotal = r2(refiTotal + c.importe);
  }

  // ---- Comida a Dto. ------------------------------------------------------
  const { getLockedFormIds } = await import("./settlement.server");
  const locked = await getLockedFormIds(supabaseAdmin as any);
  const formsP = (formsPeriodo ?? []) as any[];
  const diasPendientes = formsP.filter((f) => !locked.has(String(f.id)));
  const diasSinImporte = formsP.filter((f) => f.importe == null).length;
  const liquidacionesAbiertas = ((settlements ?? []) as any[]).filter(
    (s) =>
      !["cerrada", "exportada"].includes(String(s.estado)) &&
      (s.periodo_mes == null || (Number(s.periodo_mes) === mes && Number(s.periodo_anio) === anio)),
  );

  const hoyForm = ((formHoy ?? []) as any[])[0] ?? null;
  let consumosHoy = 0;
  if (hoyForm) {
    const { count } = await supabaseAdmin
      .from("daily_consumptions")
      .select("id", { count: "exact", head: true })
      .eq("daily_form_id", hoyForm.id);
    consumosHoy = count ?? 0;
  }

  // ---- Resumen: mismos totales que Cargas para el mes del período vigente ----
  const { cargasPanel } = await import("./cargas-panel.server");
  const panel = await cargasPanel({ mes, anio });
  const provPagar = r2(panel.proveedores.reduce((a, p) => a + Number(p.a_pagar ?? 0), 0));
  const cuotasTotal = r2(panel.cuotas.reduce((a, c) => a + Number(c.total ?? 0), 0));
  const legSet = new Set<string>();
  for (const c of panel.cuotas) for (const d of c.detalle) legSet.add(String(d.legajo).trim().toUpperCase());
  const subIds = panel.proveedores.flatMap((p) => p.submission_ids);
  if (subIds.length) {
    const { data: its } = await supabaseAdmin
      .from("submission_items")
      .select("legajo")
      .in("submission_id", subIds);
    for (const i of (its ?? []) as any[]) if (i.legajo) legSet.add(String(i.legajo).trim().toUpperCase());
  }
  void payroll;

  return {
    periodo: { desde, hasta, mes, anio, hoy, dias_restantes: diasRestantes, dia_cierre: 20 },
    pagos: {
      rows,
      total: totalTransferir,
      total_adelantado: totalAdelantado,
      total_circulos: r2(payout.total_circulos),
      total_cumpleanos: r2(payout.total_cumpleanos),
      colectas_sin_fecha: colectasSinFecha,
      sin_datos_bancarios: rows.filter((r) => r.falta_bancario && !r.adelantado).length,
    },
    proveedores: { sin_carga: proveedoresSinCarga, presentaciones: subsPeriodo.length },
    refinanciacion: { cuotas: refiCuotas, total: refiTotal },
    comida: {
      hoy_cargado: !!hoyForm,
      hoy_importe: hoyForm?.importe == null ? null : Number(hoyForm.importe),
      hoy_descripcion: hoyForm?.descripcion_comida ?? null,
      consumos_hoy: consumosHoy,
      dias_pendientes: diasPendientes.length,
      dias_sin_importe: diasSinImporte,
      liquidaciones_abiertas: liquidacionesAbiertas.map((s) => ({
        id: s.id,
        nombre: s.nombre,
        estado: s.estado,
      })),
    },
    resumen: {
      total_a_descontar: r2(provPagar + cuotasTotal),
      afiliados_a_descontar: legSet.size,
      total_a_pagar_proveedores: provPagar || totalProveedores,
      total_a_transferir_servicios: totalTransferir,
    },
  };
}
