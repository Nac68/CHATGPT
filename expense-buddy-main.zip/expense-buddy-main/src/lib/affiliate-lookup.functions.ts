import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

// Resuelve legajo -> apellido y nombre.
// Admin y proveedores pueden resolver cualquier legajo (lo necesitan para cargar
// liquidaciones). Un afiliado sólo puede resolver su propio legajo.
export const lookupAffiliateNames = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({ legajos: z.array(z.string().trim().min(1).max(32)).max(2000) })
      .parse(raw ?? { legajos: [] }),
  )
  .handler(async ({ data, context }) => {
    let legajos = Array.from(
      new Set(data.legajos.map((l) => l.trim().toUpperCase()).filter(Boolean)),
    );
    if (!legajos.length) return { names: {} as Record<string, string> };

    const [{ data: isAdmin }, { data: isProveedor }] = await Promise.all([
      context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" }),
      context.supabase.rpc("has_role", { _user_id: context.userId, _role: "proveedor" }),
    ]);

    if (!isAdmin && !isProveedor) {
      // Afiliado: se limita a su propio legajo.
      const { data: propio } = await context.supabase.rpc("current_legajo");
      const mio = propio ? String(propio).trim().toUpperCase() : null;
      legajos = mio && legajos.includes(mio) ? [mio] : [];
      if (!legajos.length) return { names: {} as Record<string, string> };
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: rows, error } = await supabaseAdmin
      .from("affiliates")
      .select("legajo, apellido_nombre")
      .in("legajo", legajos);
    if (error) throw new Error(error.message);
    const names: Record<string, string> = {};
    for (const r of rows ?? []) names[r.legajo as string] = r.apellido_nombre as string;
    return { names };
  });

