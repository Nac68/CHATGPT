import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { zMes, zAnio } from "./periodo";

/** Consulta consolidada: afiliado + período -> movimientos, subtotales y total. */
export const crmAffiliatePeriod = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({ legajo: z.string().trim().min(1).max(32), mes: zMes, anio: zAnio })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { affiliatePeriod } = await import("./crm-period.server");
    return await affiliatePeriod(data);
  });

/** Períodos disponibles en el selector (vigente + históricos, con estado). */
export const crmPeriodList = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { affiliatePeriodList } = await import("./crm-period.server");
    const { periodoVigente } = await import("./periodo-vigente.server");
    return { periodos: await affiliatePeriodList(24), vigente: await periodoVigente() };
  });
