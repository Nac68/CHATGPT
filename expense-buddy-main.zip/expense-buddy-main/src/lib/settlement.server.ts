import { lockedFormIdsFrom } from "./settlement-eligibility";

type Agg = { desayunos: number; almuerzos: number; consumos: number; importe: number };

export async function assertAdmin(context: { supabase: any; userId: string }) {
  const { data } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  if (!data) throw new Error("Sólo administradores");
}

/**
 * Ids de daily_forms ya liquidados de forma definitiva (liquidación cerrada o exportada).
 * Se resuelve por el vínculo real settlement_days → settlements, nunca por mes/fechas.
 */
export async function getLockedFormIds(supabase: any): Promise<Set<string>> {
  const { data: sets, error: sErr } = await supabase.from("settlements").select("id, estado");
  if (sErr) throw new Error(sErr.message);
  const bloqueadas = (sets ?? []).filter((s: any) => s.estado === "cerrada" || s.estado === "exportada");
  if (!bloqueadas.length) return new Set<string>();
  const { data: links, error: lErr } = await supabase
    .from("settlement_days")
    .select("settlement_id, daily_form_id")
    .in(
      "settlement_id",
      bloqueadas.map((s: any) => s.id),
    );
  if (lErr) throw new Error(lErr.message);
  return lockedFormIdsFrom(sets ?? [], links ?? []);
}

/** Guarda/actualiza el vínculo real entre una liquidación y los formularios de sus fechas. */
export async function syncSettlementDays(
  supabaseAdmin: any,
  settlementId: string,
  fechas: string[],
) {
  const list = [...new Set(fechas)];
  const { data: forms } = await supabaseAdmin
    .from("daily_forms")
    .select("id, fecha")
    .in("fecha", list.length ? list : ["1900-01-01"]);
  await supabaseAdmin.from("settlement_days").delete().eq("settlement_id", settlementId);
  const rows = (forms ?? []).map((f: any) => ({
    settlement_id: settlementId,
    daily_form_id: f.id,
    fecha: f.fecha,
  }));
  if (rows.length) {
    const { error } = await supabaseAdmin.from("settlement_days").insert(rows);
    if (error) throw new Error(error.message);
  }
  return rows.length;
}


export async function aggregateByDates(supabase: any, fechas: string[]) {
  const { data: forms, error: fErr } = await supabase
    .from("daily_forms")
    .select("id, fecha, importe, es_cumpleanos, descripcion_comida")
    .in("fecha", fechas.length ? fechas : ["1900-01-01"]);
  if (fErr) throw new Error(fErr.message);

  const formIds = (forms ?? []).map((f: any) => f.id);
  if (!formIds.length) {
    return { forms: forms ?? [], rows: [] as any[], total_consumos: 0, importe_total: 0 };
  }

  const { data: cons, error: cErr } = await supabase
    .from("daily_consumptions")
    .select("legajo, desayuno, almuerzo, importe, no_paga, daily_form_id")
    .in("daily_form_id", formIds);
  if (cErr) throw new Error(cErr.message);

  const byLegajo = new Map<string, Agg>();
  let total = 0;
  for (const c of cons ?? []) {
    const cur = byLegajo.get(c.legajo) ?? { desayunos: 0, almuerzos: 0, consumos: 0, importe: 0 };
    if (c.desayuno) {
      cur.desayunos++;
      cur.consumos++;
      total++;
    }
    if (c.almuerzo) {
      cur.almuerzos++;
      cur.consumos++;
      total++;
    }
    cur.importe += c.no_paga ? 0 : Number(c.importe ?? 0);
    byLegajo.set(c.legajo, cur);
  }

  const legajos = Array.from(byLegajo.keys());
  const { data: affs } = await supabase
    .from("affiliates")
    .select("legajo, apellido_nombre")
    .in("legajo", legajos.length ? legajos : ["__none__"]);
  const nameMap = new Map(
    (affs ?? []).map((a: any) => [a.legajo as string, a.apellido_nombre as string]),
  );

  const rows = Array.from(byLegajo.entries()).map(([legajo, v]) => ({
    legajo,
    apellido_nombre: (nameMap.get(legajo) as string) ?? legajo,
    desayunos: v.desayunos,
    almuerzos: v.almuerzos,
    consumos: v.consumos,
    importe: Math.round(v.importe * 100) / 100,
  }));

  const importe_total = Math.round(rows.reduce((a, b) => a + b.importe, 0) * 100) / 100;
  return { forms: forms ?? [], rows, total_consumos: total, importe_total };
}

export async function dayStats(supabase: any, forms: any[]) {
  const ids = forms.map((f) => f.id);
  const counts = new Map<string, { comensales: number; importe: number }>();
  if (ids.length) {
    const { data: cons } = await supabase
      .from("daily_consumptions")
      .select("daily_form_id, desayuno, almuerzo, importe, no_paga")
      .in("daily_form_id", ids);
    for (const c of cons ?? []) {
      const cur = counts.get(c.daily_form_id) ?? { comensales: 0, importe: 0 };
      if (c.desayuno || c.almuerzo) cur.comensales++;
      cur.importe += c.no_paga ? 0 : Number(c.importe ?? 0);
      counts.set(c.daily_form_id, cur);
    }
  }
  return forms.map((f) => ({
    id: f.id,
    fecha: f.fecha,
    descripcion_comida: f.descripcion_comida,
    importe: f.importe,
    es_cumpleanos: f.es_cumpleanos,
    comensales: counts.get(f.id)?.comensales ?? 0,
    a_cobrar: Math.round((counts.get(f.id)?.importe ?? 0) * 100) / 100,
  }));
}

/* ─────────────────────────────────────────────────────────────
   Snapshot de liquidación por período (Comida a Dto.)
   Congela días, consumos fila por fila (sin deduplicar) y totales.
   ───────────────────────────────────────────────────────────── */

export type SettlementSnapshot = {
  generado_at: string;
  fechas: string[];
  dias: Array<{
    fecha: string;
    descripcion: string | null;
    es_cumpleanos: boolean;
    importe: number | null;
    comensales: number;
    pagan: number;
    no_paga: number;
    a_descontar: number;
    /** Importe del día que absorbe AGOEC (consumos "no paga" + cumpleaños). */
    a_cargo_agoec: number;
  }>;

  consumos: Array<{
    fecha: string;
    legajo: string;
    apellido_nombre: string;
    desayuno: boolean;
    almuerzo: boolean;
    no_paga: boolean;
    importe: number;
    observacion: string | null;
  }>;
  rows: Array<{
    legajo: string;
    apellido_nombre: string;
    desayunos: number;
    almuerzos: number;
    consumos: number;
    importe: number;
  }>;
  totales: {
    dias: number;
    dias_sin_importe: number;
    dias_cumpleanos: number;
    consumos: number;
    afiliados: number;
    importe_cargado: number;
    total_a_descontar: number;
    diferencia: number;
    /** Consumos marcados "no paga" (no se redistribuyen: los absorbe AGOEC). */
    consumos_no_paga: number;
    /** Importe a cargo de AGOEC por consumos "no paga". */
    a_cargo_agoec_no_paga: number;
    /** Importe a cargo de AGOEC por días de cumpleaños (sin cargo a afiliados). */
    a_cargo_agoec_cumpleanos: number;
    /** Total absorbido por AGOEC. */
    a_cargo_agoec: number;
    /** Diferencia real que no explica el "no paga" (redondeos u otros desvíos). */
    diferencia_no_explicada: number;
  };

  advertencias: string[];
  errores: string[];
};

const r2 = (v: number) => Math.round((Number(v) || 0) * 100) / 100;

/**
 * Devuelve las fechas cuyo formulario ya quedó liquidado en una liquidación cerrada/exportada.
 * Con throwOnLocked lanza error (usado al crear/actualizar), si no sólo informa.
 */
export async function assertFechasElegibles(
  supabase: any,
  fechas: string[],
  opts: { throwOnLocked?: boolean; ignoreSettlementId?: string } = {},
): Promise<string[]> {
  const list = [...new Set(fechas)];
  if (!list.length) return [];
  const { data: forms } = await supabase
    .from("daily_forms")
    .select("id, fecha")
    .in("fecha", list);
  let locked = await getLockedFormIds(supabase);
  if (opts.ignoreSettlementId) {
    const { data: own } = await supabase
      .from("settlement_days")
      .select("daily_form_id")
      .eq("settlement_id", opts.ignoreSettlementId);
    for (const l of own ?? []) locked.delete(String(l.daily_form_id));
  }
  const bloqueadas = (forms ?? [])
    .filter((f: any) => locked.has(String(f.id)))
    .map((f: any) => String(f.fecha))
    .sort();
  if (bloqueadas.length && opts.throwOnLocked)
    throw new Error(
      `Estos días ya fueron liquidados en una liquidación cerrada o exportada: ${bloqueadas.join(", ")}. Reabrí esa liquidación si necesitás volver a usarlos.`,
    );
  return bloqueadas;
}

export async function buildSnapshot(supabase: any, fechas: string[]): Promise<SettlementSnapshot> {

  const list = [...new Set(fechas)].sort();
  const { data: forms, error: fErr } = await supabase
    .from("daily_forms")
    .select("id, fecha, importe, es_cumpleanos, descripcion_comida")
    .in("fecha", list.length ? list : ["1900-01-01"])
    .order("fecha");
  if (fErr) throw new Error(fErr.message);

  const formIds = (forms ?? []).map((f: any) => f.id);
  let cons: any[] = [];
  if (formIds.length) {
    const { data, error } = await supabase
      .from("daily_consumptions")
      .select("daily_form_id, legajo, desayuno, almuerzo, importe, no_paga, observacion")
      .in("daily_form_id", formIds)
      .limit(50000);
    if (error) throw new Error(error.message);
    cons = data ?? [];
  }

  const legajos = [...new Set(cons.map((c: any) => String(c.legajo)))];
  const { data: affs } = await supabase
    .from("affiliates")
    .select("legajo, apellido_nombre")
    .in("legajo", legajos.length ? legajos : ["__none__"]);
  const nameMap = new Map<string, string>(
    (affs ?? []).map((a: any) => [String(a.legajo), String(a.apellido_nombre)]),
  );

  const formMap = new Map((forms ?? []).map((f: any) => [f.id, f]));

  // Cada fila es un consumo real: NO se deduplica por (día, legajo).
  const consumos = cons.map((c: any) => {
    const f: any = formMap.get(c.daily_form_id);
    return {
      fecha: String(f?.fecha ?? ""),
      legajo: String(c.legajo),
      apellido_nombre: nameMap.get(String(c.legajo)) ?? String(c.legajo),
      desayuno: !!c.desayuno,
      almuerzo: !!c.almuerzo,
      no_paga: !!c.no_paga,
      importe: c.no_paga ? 0 : r2(Number(c.importe ?? 0)),
      observacion: c.observacion ?? null,
    };
  });
  consumos.sort(
    (a, b) => a.fecha.localeCompare(b.fecha) || a.legajo.localeCompare(b.legajo),
  );

  const dias: SettlementSnapshot["dias"] = ((forms ?? []) as any[]).map((f: any) => {
    const rows = consumos.filter((c) => c.fecha === String(f.fecha));
    const comensales = rows.filter((c) => c.desayuno || c.almuerzo).length;
    const noPaga = rows.filter((c) => (c.desayuno || c.almuerzo) && c.no_paga).length;
    const importe = f.importe == null ? null : r2(Number(f.importe));
    const a_descontar = r2(rows.reduce((a, c) => a + c.importe, 0));
    // El "no paga" NO se redistribuye: la parte proporcional la absorbe AGOEC.
    const unitario = importe != null && comensales > 0 ? Number(importe) / comensales : 0;
    const a_cargo_agoec = f.es_cumpleanos
      ? r2(Number(importe ?? 0))
      : r2(unitario * noPaga);
    return {
      fecha: String(f.fecha),
      descripcion: f.descripcion_comida ?? null,
      es_cumpleanos: !!f.es_cumpleanos,
      importe,
      comensales,
      pagan: comensales - noPaga,
      no_paga: noPaga,
      a_descontar,
      a_cargo_agoec,
    };
  });


  const agg = new Map<string, Agg>();
  let total_consumos = 0;
  for (const c of consumos) {
    const cur = agg.get(c.legajo) ?? { desayunos: 0, almuerzos: 0, consumos: 0, importe: 0 };
    if (c.desayuno) {
      cur.desayunos++;
      cur.consumos++;
      total_consumos++;
    }
    if (c.almuerzo) {
      cur.almuerzos++;
      cur.consumos++;
      total_consumos++;
    }
    cur.importe += c.importe;
    agg.set(c.legajo, cur);
  }
  const rows = Array.from(agg.entries())
    .map(([legajo, v]) => ({
      legajo,
      apellido_nombre: nameMap.get(legajo) ?? legajo,
      desayunos: v.desayunos,
      almuerzos: v.almuerzos,
      consumos: v.consumos,
      importe: r2(v.importe),
    }))
    .sort((a, b) => a.legajo.localeCompare(b.legajo));

  const total_a_descontar = r2(rows.reduce((a, b) => a + b.importe, 0));
  const importe_cargado = r2(
    dias.reduce((a, d) => a + (d.es_cumpleanos ? 0 : Number(d.importe ?? 0)), 0),
  );
  const sinImporte = dias.filter((d) => !d.es_cumpleanos && d.importe == null);
  const sinConsumos = dias.filter((d) => d.comensales === 0);

  const errores: string[] = [];
  const advertencias: string[] = [];
  if (!list.length) errores.push("No seleccionaste ningún día.");
  if (!dias.length) errores.push("Los días seleccionados no tienen formulario cargado.");
  if (sinImporte.length)
    errores.push(
      `${sinImporte.length} día(s) sin importe cargado: ${sinImporte.map((d) => d.fecha).join(", ")}. Cargá el importe antes de cerrar.`,
    );
  if (!rows.length) errores.push("No hay consumos en los días seleccionados.");
  if (sinConsumos.length)
    advertencias.push(
      `${sinConsumos.length} día(s) sin comensales: ${sinConsumos.map((d) => d.fecha).join(", ")}.`,
    );
  const dif = r2(importe_cargado - total_a_descontar);
  const a_cargo_no_paga = r2(
    dias.filter((d) => !d.es_cumpleanos).reduce((a, d) => a + d.a_cargo_agoec, 0),
  );
  const cumple = dias.filter((d) => d.es_cumpleanos);
  const a_cargo_cumple = r2(cumple.reduce((a, d) => a + d.a_cargo_agoec, 0));
  const consumos_no_paga = dias.reduce((a, d) => a + d.no_paga, 0);
  const dif_real = r2(dif - a_cargo_no_paga);
  if (a_cargo_no_paga > 0)
    advertencias.push(
      `A cargo de AGOEC (No paga): ${a_cargo_no_paga.toFixed(2)} en ${consumos_no_paga} consumo(s). No se redistribuye entre los afiliados.`,
    );
  if (Math.abs(dif_real) >= 0.5)
    advertencias.push(
      `Diferencia sin explicar de ${dif_real.toFixed(2)}: importe cargado − total a descontar − a cargo de AGOEC (No paga). Revisá importes o redondeos.`,
    );
  if (cumple.length)
    advertencias.push(
      `${cumple.length} día(s) de cumpleaños sin cargo a los afiliados: ${a_cargo_cumple.toFixed(2)} a cargo de AGOEC.`,
    );

  return {
    generado_at: new Date().toISOString(),
    fechas: list,
    dias,
    consumos,
    rows,
    totales: {
      dias: dias.length,
      dias_sin_importe: sinImporte.length,
      dias_cumpleanos: cumple.length,
      consumos: total_consumos,
      afiliados: rows.length,
      importe_cargado,
      total_a_descontar,
      diferencia: dif,
      consumos_no_paga,
      a_cargo_agoec_no_paga: a_cargo_no_paga,
      a_cargo_agoec_cumpleanos: a_cargo_cumple,
      a_cargo_agoec: r2(a_cargo_no_paga + a_cargo_cumple),
      diferencia_no_explicada: dif_real,
    },

    advertencias,
    errores,
  };
}

export async function logSettlementEvent(
  supabaseAdmin: any,
  settlementId: string,
  accion: string,
  userId: string,
  nota?: string,
  extra?: { valor_anterior?: unknown; valor_nuevo?: unknown },
) {
  // Guardamos el email para que la auditoría sea legible (nunca PIN/tokens).
  let email: string | null = null;
  try {
    const { data } = await supabaseAdmin.auth.admin.getUserById(userId);
    email = data?.user?.email ?? null;
  } catch {
    email = null;
  }
  try {
    await supabaseAdmin.from("settlement_events").insert({
      settlement_id: settlementId,
      accion,
      user_id: userId,
      user_email: email,
      nota: nota ?? null,
    });
  } catch (e) {
    console.error("[audit] settlement_events", (e as Error)?.message);
  }
  // Espejo en la auditoría económica general (única escritura, sin duplicados).
  const { logAudit } = await import("./audit.server");
  await logAudit(supabaseAdmin, {
    entidad: "liquidacion_comida",
    entidad_id: settlementId,
    accion,
    userId,
    nota: nota ?? null,
    valor_anterior: extra?.valor_anterior ?? null,
    valor_nuevo: extra?.valor_nuevo ?? null,
  });
}

