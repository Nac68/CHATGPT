// Generador del Excel con el formato oficial de intercambio (CEAMSE).
// Las columnas "Inf." llevan lo que AGOEC informa a descontar; las columnas de
// descuento efectivo y "NO DESC" viajan vacías para que las complete CEAMSE.
import * as XLSX from "xlsx";

export const CEAMSE_HEADERS = [
  "ID_EMPLEADO",
  "APELLIDO_NOMBRE",
  "7102 Inf. Refinanc. AGOEC",
  "7103 Refinanc AGOEC",
  "NO DESC Refinanc. AGOEC",
  "7112 Inf. Adelanto AGOEC",
  "7113 Adelanto AGOEC",
  "NO DESC Adelanto",
  "7122 Inf. Serv. Automot",
  "7123 Servicio Automotor AGOEC",
  "NO DESC Serv. Automot.",
  "7132 Inf. Farmacia AGOEC",
  "7133 Farmacia AGOEC",
  "NO DESC Farmacia",
  "7132 Inf. Indument. AGOEC",
  "7143 Indumentaria AGOEC",
  "NO DESC Indumentaria",
  "7152 Inf. Serv. AGOEC",
  "7153 Servicio AGOEC",
  "NO DESC Servicio",
  "7162 Inf. Supermerc. AGOEC",
  "7163 Servicio Supermercado AGOEC",
  "NO DESC Supermercado",
  "Cuota Sindical",
  "Cuota Sindical SAC",
  "Fondo Solidario",
  "Fondo Solidario SAC",
  "Banco",
  "Sucursal",
  "Nro de Cuenta",
  "N_CATEGORIA",
  "CUIL",
] as const;

type Grupo =
  | "refinanciacion"
  | "adelanto"
  | "automotores"
  | "farmacia"
  | "indumentaria"
  | "servicio"
  | "supermercado";

/** Columna "Inf." de cada grupo del archivo CEAMSE. */
const COL_INF: Record<Grupo, string> = {
  refinanciacion: "7102 Inf. Refinanc. AGOEC",
  adelanto: "7112 Inf. Adelanto AGOEC",
  automotores: "7122 Inf. Serv. Automot",
  farmacia: "7132 Inf. Farmacia AGOEC",
  indumentaria: "7132 Inf. Indument. AGOEC",
  servicio: "7152 Inf. Serv. AGOEC",
  supermercado: "7162 Inf. Supermerc. AGOEC",
};

const sinAcentos = (s: string) =>
  String(s ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();

/**
 * Clasifica un concepto de la liquidación en su grupo CEAMSE.
 * Todo lo que no tiene columna propia (Comida a Dto., Círculos, Cumpleaños,
 * Colectas y subservicios) se informa en "Servicio AGOEC".
 */
export function grupoCeamse(nombre: string): Grupo {
  const n = sinAcentos(nombre);
  if (n.includes("refinanc")) return "refinanciacion";
  if (n.includes("adelanto")) return "adelanto";
  if (n.includes("automot")) return "automotores";
  if (n.includes("farmacia")) return "farmacia";
  if (n.includes("indument")) return "indumentaria";
  if (n.includes("supermerc")) return "supermercado";
  return "servicio";
}

const r2 = (v: number) => Math.round((Number(v) || 0) * 100) / 100;

export type CeamseConcepto = { key: string; nombre: string };
export type CeamseRow = {
  legajo: string;
  apellido_nombre?: string | null;
  por_concepto: Record<string, number>;
};

/** Ordena por legajo numérico cuando es posible, alfabético si es alfanumérico. */
function ordenarLegajos(a: string, b: string) {
  const na = Number(a);
  const nb = Number(b);
  if (Number.isFinite(na) && Number.isFinite(nb) && na !== nb) return na - nb;
  if (Number.isFinite(na) && !Number.isFinite(nb)) return -1;
  if (!Number.isFinite(na) && Number.isFinite(nb)) return 1;
  return a.localeCompare(b, "es");
}

/** Arma las filas del archivo CEAMSE a partir de la liquidación del período. */
export function buildCeamseRows(args: {
  conceptos: CeamseConcepto[];
  rows: CeamseRow[];
  padron?: Record<string, { apellido_nombre?: string | null; cuil?: string | null }>;
}) {
  const { conceptos, rows, padron = {} } = args;
  const grupoPorKey = new Map(conceptos.map((c) => [c.key, grupoCeamse(c.nombre)]));

  const salida = rows
    .map((r) => {
      const acum: Partial<Record<Grupo, number>> = {};
      for (const [key, val] of Object.entries(r.por_concepto ?? {})) {
        const imp = Number(val) || 0;
        if (!imp) continue;
        const g = grupoPorKey.get(key) ?? grupoCeamse(key);
        acum[g] = r2((acum[g] ?? 0) + imp);
      }
      return { legajo: String(r.legajo), apellido_nombre: r.apellido_nombre, acum };
    })
    .filter((r) => Object.values(r.acum).some((v) => Number(v) !== 0))
    .sort((a, b) => ordenarLegajos(a.legajo, b.legajo));

  const data = salida.map((r) => {
    const ficha = padron[r.legajo];
    const o: Record<string, any> = {};
    for (const h of CEAMSE_HEADERS) o[h] = "";
    o["ID_EMPLEADO"] = r.legajo;
    o["APELLIDO_NOMBRE"] = ficha?.apellido_nombre ?? r.apellido_nombre ?? "";
    o["CUIL"] = ficha?.cuil ?? "";
    for (const [g, v] of Object.entries(r.acum)) {
      if (Number(v)) o[COL_INF[g as Grupo]] = r2(Number(v));
    }
    return o;
  });

  const totales: Record<string, any> = {};
  for (const h of CEAMSE_HEADERS) totales[h] = "";
  totales["APELLIDO_NOMBRE"] = "TOTAL";
  for (const g of Object.keys(COL_INF) as Grupo[]) {
    const col = COL_INF[g];
    const t = r2(data.reduce((a, row) => a + (Number(row[col]) || 0), 0));
    if (t) totales[col] = t;
  }

  return { data, totales, afiliados: data.length };
}

/** Descarga el Excel del período con el formato exacto de CEAMSE. */
export function downloadCeamseXlsx(args: {
  conceptos: CeamseConcepto[];
  rows: CeamseRow[];
  padron?: Record<string, { apellido_nombre?: string | null; cuil?: string | null }>;
  desde?: string | null;
  hasta?: string | null;
  periodo?: string | null;
}) {
  const { data, totales, afiliados } = buildCeamseRows(args);
  if (!afiliados) throw new Error("El período no tiene importes para informar");

  const ws = XLSX.utils.json_to_sheet([...data, totales], {
    header: CEAMSE_HEADERS as unknown as string[],
  });
  ws["!cols"] = CEAMSE_HEADERS.map((h, i) => ({ wch: i === 1 ? 38 : Math.max(12, h.length + 2) }));

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Resultado");
  const rango = args.periodo
    ? args.periodo.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^\w]+/g, "_")
    : args.desde && args.hasta
      ? `${args.desde}_al_${args.hasta}`
      : "periodo";
  XLSX.writeFile(wb, `NoDescontado_${rango}.xlsx`);
  return afiliados;
}
