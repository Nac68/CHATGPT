import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const memberSchema = z.object({
  legajo: z.string().trim().min(1).max(32),
  importe_mensual: z.number().nonnegative().default(0),
  fecha_cobro: z.string().nullable().optional(),
  mes_cobro: z.number().int().min(1).max(12).nullable().optional(),
  anio_cobro: z.number().int().min(2000).max(2100).nullable().optional(),
  observacion: z.string().max(300).nullable().optional(),
});

export const listCircles = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ product_id: z.string().uuid().optional() }).parse(raw ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);

    let q = context.supabase
      .from("circles")
      .select("*")
      .order("created_at", { ascending: false });
    if (data.product_id) q = q.eq("product_id", data.product_id);
    const { data: circles, error } = await q;
    if (error) throw new Error(error.message);

    const ids = (circles ?? []).map((c: any) => c.id);
    let members: any[] = [];
    if (ids.length) {
      const { data: ms, error: e2 } = await context.supabase
        .from("circle_members")
        .select("*")
        .in("circle_id", ids)
        .order("legajo");
      if (e2) throw new Error(e2.message);
      members = ms ?? [];
    }

    return {
      circles: (circles ?? []).map((c: any) => {
        const ms = members.filter((m) => m.circle_id === c.id);
        return {
          ...c,
          members: ms,
          total_mensual: ms.reduce((a, m) => a + Number(m.importe_mensual ?? 0), 0),
          integrantes: new Set(ms.map((m) => m.legajo)).size,
          cuotas: ms.length,
        };
      }),
    };
  });

export const saveCircle = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        id: z.string().uuid().optional(),
        service_id: z.string().uuid().nullable().optional(),
        product_id: z.string().uuid().nullable().optional(),
        numero: z.string().trim().max(32).nullable().optional(),
        nombre: z.string().trim().min(2).max(300),
        fecha_inicio: z.string().nullable().optional(),
        fecha_fin: z.string().nullable().optional(),
        periodo_inicio: z.number().int().min(200001).max(210012, "Período inicial inválido"),
        periodo_fin: z.number().int().min(200001).max(210012).nullable().optional(),
        importe: z.number().nonnegative().default(0),
        observacion: z.string().max(500).nullable().optional(),
        members: z.array(memberSchema).default([]),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);

    const header = {
      ...(data.id ? { id: data.id } : {}),
      service_id: data.service_id ?? null,
      product_id: data.product_id ?? null,
      numero: data.numero || null,
      nombre: data.nombre,
      fecha_inicio: data.fecha_inicio || null,
      fecha_fin: data.fecha_fin || null,
      periodo_inicio: data.periodo_inicio ?? null,
      periodo_fin: data.periodo_fin ?? null,
      importe: data.importe,
      observacion: data.observacion ?? null,
    };

    const { data: saved, error } = await context.supabase
      .from("circles")
      .upsert(header as any, { onConflict: "id" })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    const circleId = saved.id as string;

    await context.supabase.from("circle_members").delete().eq("circle_id", circleId);

    const legajos = data.members.map((m) => m.legajo.trim().toUpperCase());
    let nombres: Record<string, string | null> = {};
    if (legajos.length) {
      const { data: afs } = await context.supabase
        .from("affiliates")
        .select("legajo, apellido_nombre")
        .in("legajo", legajos);
      nombres = Object.fromEntries((afs ?? []).map((a: any) => [a.legajo, a.apellido_nombre]));
    }

    if (data.members.length) {
      const rows = data.members.map((m) => {
        const legajo = m.legajo.trim().toUpperCase();
        const f = m.fecha_cobro ? new Date(m.fecha_cobro) : null;
        return {
          circle_id: circleId,
          legajo,
          apellido_nombre: nombres[legajo] ?? null,
          importe_mensual: m.importe_mensual,
          fecha_cobro: m.fecha_cobro || null,
          mes_cobro: m.mes_cobro ?? (f ? f.getUTCMonth() + 1 : null),
          anio_cobro: m.anio_cobro ?? (f ? f.getUTCFullYear() : null),
          observacion: m.observacion ?? null,
        };
      });
      const { error: e3 } = await context.supabase.from("circle_members").insert(rows as any);
      if (e3) throw new Error(e3.message);
    }

    return { ok: true, id: circleId };
  });

export const deleteCircle = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { error } = await context.supabase.from("circles").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Liquidación mensual de círculos: descuento por afiliado y pozo a pagar a quien cobra. */
export const circlesSettlement = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        mes: z.number().int().min(1).max(12),
        anio: z.number().int().min(2000).max(2100),
        product_id: z.string().uuid().optional(),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { buildCircleSettlement } = await import("./circles.server");

    let q = context.supabase.from("circles").select("*");
    if (data.product_id) q = q.eq("product_id", data.product_id);
    const { data: circles, error } = await q;
    if (error) throw new Error(error.message);

    const ids = (circles ?? []).map((c: any) => c.id);
    let members: any[] = [];
    if (ids.length) {
      const { data: ms, error: e2 } = await context.supabase
        .from("circle_members")
        .select("*")
        .in("circle_id", ids);
      if (e2) throw new Error(e2.message);
      members = ms ?? [];
    }

    const full = (circles ?? []).map((c: any) => ({
      ...c,
      members: members.filter((m) => m.circle_id === c.id),
    }));

    return {
      mes: data.mes,
      anio: data.anio,
      ...buildCircleSettlement(full as any, data.mes, data.anio),
    };
  });
