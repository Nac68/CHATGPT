import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

// Vista rápida completa de "Comida a Dto." para armar la liquidación:
// días cargados, KPIs y el detalle legajo por legajo (lo mismo que ve el afiliado).
export const comidaOverview = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({ mes: z.string().max(7).nullable().optional() })
      .parse(raw ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    const { getLockedFormIds } = await import("./settlement.server");
    await assertAdmin(context);
    const locked = await getLockedFormIds(context.supabase);


    const [{ data: forms }, { data: cons }] = await Promise.all([
      context.supabase
        .from("daily_forms")
        .select("id, fecha, importe, descripcion_comida, es_cumpleanos")
        .order("fecha", { ascending: false }),
      context.supabase
        .from("daily_consumptions")
        .select("legajo, desayuno, almuerzo, importe, no_paga, observacion, daily_form_id")
        .limit(50000),
    ]);

    const mes = data.mes || null;

    // "actual" = período administrativo vigente de Comida a Dto.:
    // todos los días posteriores al último día ya liquidado en una liquidación
    // cerrada/exportada (corte real de cierre, no corte calendario).
    let ultimoCerrado: string | null = null;
    if (mes === "actual") {
      for (const f of forms ?? []) {
        const fe = String(f.fecha);
        if (locked.has(String(f.id)) && (!ultimoCerrado || fe > ultimoCerrado)) ultimoCerrado = fe;
      }
    }

    const allForms = (forms ?? []).filter((f: any) => {
      const fe = String(f.fecha);
      if (mes === "actual") return !locked.has(String(f.id)) && (!ultimoCerrado || fe > ultimoCerrado);
      return !mes || fe.startsWith(mes);
    });
    const formMap = new Map(allForms.map((f: any) => [f.id, f]));
    const consList = (cons ?? []).filter((c: any) => formMap.has(c.daily_form_id));


    const meses = Array.from(
      new Set((forms ?? []).map((f: any) => String(f.fecha).slice(0, 7))),
    ).sort((a, b) => b.localeCompare(a));

    // Días
    const dias = allForms.map((f: any) => {
      const rows = consList.filter((c: any) => c.daily_form_id === f.id);
      const comensales = rows.filter((c: any) => c.desayuno || c.almuerzo).length;
      const pagan = rows.filter((c: any) => (c.desayuno || c.almuerzo) && !c.no_paga).length;
      const noPaga = comensales - pagan;
      const importe = f.importe == null ? null : Number(f.importe);
      // El "no paga" no se redistribuye: esa parte la absorbe AGOEC.
      const unitario = importe != null && comensales > 0 ? importe / comensales : 0;
      const aCargoAgoec = f.es_cumpleanos
        ? Math.round(Number(importe ?? 0) * 100) / 100
        : Math.round(unitario * noPaga * 100) / 100;
      return {
        id: f.id,
        fecha: f.fecha,
        descripcion: f.descripcion_comida,
        es_cumpleanos: !!f.es_cumpleanos,
        importe,
        comensales,
        pagan,
        no_paga: noPaga,
        a_cargo_agoec: aCargoAgoec,
        // true si el día ya quedó en una liquidación cerrada/exportada (no vuelve a liquidarse)
        liquidado: locked.has(String(f.id)),
        a_cobrar: rows.reduce((a: number, c: any) => a + Number(c.importe ?? 0), 0),
      };
    });



    // Legajo por legajo
    const byLegajo = new Map<string, any>();
    for (const c of consList) {
      const f: any = formMap.get(c.daily_form_id);
      const cur =
        byLegajo.get(c.legajo) ??
        ({
          legajo: c.legajo,
          desayunos: 0,
          almuerzos: 0,
          consumos: 0,
          dias: 0,
          no_paga: 0,
          importe: 0,
          ultimo_dia: null as string | null,
          detalle: [] as any[],
        } as any);
      if (c.desayuno) {
        cur.desayunos++;
        cur.consumos++;
      }
      if (c.almuerzo) {
        cur.almuerzos++;
        cur.consumos++;
      }
      if (c.desayuno || c.almuerzo) cur.dias++;
      if (c.no_paga) cur.no_paga++;
      cur.importe += Number(c.importe ?? 0);
      if (!cur.ultimo_dia || f.fecha > cur.ultimo_dia) cur.ultimo_dia = f.fecha;
      cur.detalle.push({
        fecha: f.fecha,
        descripcion: f.descripcion_comida,
        es_cumpleanos: !!f.es_cumpleanos,
        desayuno: c.desayuno,
        almuerzo: c.almuerzo,
        no_paga: c.no_paga,
        observacion: c.observacion,
        importe: Number(c.importe ?? 0),
      });
      byLegajo.set(c.legajo, cur);
    }

    const legajos = Array.from(byLegajo.keys());
    const names = new Map<string, string>();
    for (let i = 0; i < legajos.length; i += 300) {
      const { data: affs } = await context.supabase
        .from("affiliates")
        .select("legajo, apellido_nombre")
        .in("legajo", legajos.slice(i, i + 300));
      (affs ?? []).forEach((a: any) => names.set(a.legajo, a.apellido_nombre));
    }

    const porLegajo = Array.from(byLegajo.values()).map((r: any) => ({
      ...r,
      apellido_nombre: names.get(r.legajo) ?? null,
      importe: Math.round(r.importe * 100) / 100,
      detalle: r.detalle.sort((a: any, b: any) => b.fecha.localeCompare(a.fecha)),
    }));

    const total_pagado = allForms.reduce((a: number, f: any) => a + Number(f.importe ?? 0), 0);
    const total_a_descontar = porLegajo.reduce((a, r) => a + r.importe, 0);
    const r2 = (v: number) => Math.round(v * 100) / 100;
    const a_cargo_agoec_no_paga = r2(
      dias.filter((d: any) => !d.es_cumpleanos).reduce((a: number, d: any) => a + d.a_cargo_agoec, 0),
    );
    const a_cargo_agoec_cumpleanos = r2(
      dias.filter((d: any) => d.es_cumpleanos).reduce((a: number, d: any) => a + d.a_cargo_agoec, 0),
    );

    return {
      meses,
      mes,
      dias,
      porLegajo,
      kpis: {
        dias: allForms.length,
        sin_importe: allForms.filter((f: any) => f.importe == null).length,
        cumpleanos: allForms.filter((f: any) => f.es_cumpleanos).length,
        consumos: consList.filter((c: any) => c.desayuno || c.almuerzo).length,
        afiliados: porLegajo.length,
        total_pagado: r2(total_pagado),
        total_a_descontar: r2(total_a_descontar),
        consumos_no_paga: consList.filter((c: any) => (c.desayuno || c.almuerzo) && c.no_paga).length,
        a_cargo_agoec_no_paga,
        a_cargo_agoec_cumpleanos,
        a_cargo_agoec: r2(a_cargo_agoec_no_paga + a_cargo_agoec_cumpleanos),
        diferencia_no_explicada: r2(total_pagado - total_a_descontar - a_cargo_agoec_no_paga - a_cargo_agoec_cumpleanos),
        dias_liquidados: dias.filter((d: any) => d.liquidado).length,
        dias_pendientes: dias.filter((d: any) => !d.liquidado).length,
        ultimo_dia: allForms[0]?.fecha ?? null,
      },
    };

  });
