// Helpers server-only para Colectas: cálculo de cuotas y liquidación mensual.

export const r2 = (n: number) => Math.round((Number(n) || 0) * 100) / 100;

export type CollectionRow = {
  id: string;
  nombre: string;
  cuotas: number;
  mes_inicio: number | null;
  anio_inicio: number | null;
  cerrada: boolean;
  beneficiario_legajo: string | null;
  beneficiario_nombre: string | null;
  members: any[];
};

/** Índice de cuota (1..cuotas) que corresponde descontar en mes/anio, o null si no corresponde. */
export function cuotaIndex(
  c: { mes_inicio: number | null; anio_inicio: number | null; cuotas: number },
  mes: number,
  anio: number,
) {
  if (!c.mes_inicio || !c.anio_inicio) return null;
  const diff = (anio - c.anio_inicio) * 12 + (mes - c.mes_inicio);
  if (diff < 0) return null;
  const total = Math.max(1, Number(c.cuotas) || 1);
  return diff < total ? diff + 1 : null;
}

export type CollectionSettlementRow = {
  legajo: string;
  apellido_nombre: string | null;
  colectas: { nombre: string; cuota: string; importe: number }[];
  importe: number;
};

export function buildCollectionSettlement(
  collections: CollectionRow[],
  mes: number,
  anio: number,
): { rows: CollectionSettlementRow[]; total: number; aportantes: number; colectas: number } {
  const map = new Map<string, CollectionSettlementRow>();
  let colectasActivas = 0;

  for (const c of collections) {
    if (c.cerrada) continue;
    const idx = cuotaIndex(c, mes, anio);
    if (!idx) continue;
    colectasActivas += 1;
    const cuotasTotales = Math.max(1, Number(c.cuotas) || 1);
    for (const m of c.members ?? []) {
      const importe = r2(
        Number(m.importe_cuota ?? 0) || Number(m.importe_total ?? 0) / cuotasTotales,
      );
      if (!importe) continue;
      const legajo = String(m.legajo);
      let row = map.get(legajo);
      if (!row) {
        row = { legajo, apellido_nombre: m.apellido_nombre ?? null, colectas: [], importe: 0 };
        map.set(legajo, row);
      }
      row.colectas.push({ nombre: c.nombre, cuota: `${idx}/${cuotasTotales}`, importe });
      row.importe = r2(row.importe + importe);
    }
  }

  const rows = [...map.values()];
  return {
    rows,
    total: r2(rows.reduce((a, r) => a + r.importe, 0)),
    aportantes: rows.length,
    colectas: colectasActivas,
  };
}
