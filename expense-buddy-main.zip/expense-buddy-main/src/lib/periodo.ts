import { z } from "zod";

export const MESES = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre",
];

export type Periodo = { mes: number; anio: number };

export const ANIO_MIN = 2000;
export const ANIO_MAX = 2100;

export function periodoValido(mes: any, anio: any): boolean {
  const m = Number(mes);
  const a = Number(anio);
  return Number.isInteger(m) && m >= 1 && m <= 12 && Number.isInteger(a) && a >= ANIO_MIN && a <= ANIO_MAX;
}

/** Mensaje de error legible, o null si el período es válido. */
export function periodoError(mes: any, anio: any): string | null {
  const m = Number(mes);
  const a = Number(anio);
  if (!m) return "Falta el mes del período";
  if (!Number.isInteger(m) || m < 1 || m > 12) return "El mes debe estar entre 1 y 12";
  if (!a) return "Falta el año del período";
  if (!Number.isInteger(a) || a < ANIO_MIN || a > ANIO_MAX) return `El año debe estar entre ${ANIO_MIN} y ${ANIO_MAX}`;
  return null;
}

/**
 * Acepta 202401 / 2024-01 / 01-2024 / 01/2024 / "Enero 2024".
 * Devuelve null si no se puede interpretar un período válido.
 */
export function parsePeriodo(v: any): Periodo | null {
  if (v == null) return null;
  if (typeof v === "object" && "mes" in v && "anio" in v) {
    return periodoValido((v as any).mes, (v as any).anio) ? { mes: Number((v as any).mes), anio: Number((v as any).anio) } : null;
  }
  const raw = String(v).trim();
  if (!raw) return null;

  const nombreMes = MESES.findIndex((m) => raw.toLowerCase().startsWith(m.toLowerCase().slice(0, 3)));
  const anioSuelto = raw.match(/(20\d{2})/);
  if (nombreMes >= 0 && anioSuelto) {
    const p = { mes: nombreMes + 1, anio: Number(anioSuelto[1]) };
    if (periodoValido(p.mes, p.anio)) return p;
  }

  const sep = raw.match(/^(\d{1,4})\s*[-/.]\s*(\d{1,4})$/);
  if (sep) {
    const a = Number(sep[1]);
    const b = Number(sep[2]);
    // YYYY-MM
    if (a >= ANIO_MIN && periodoValido(b, a)) return { mes: b, anio: a };
    // MM-YYYY
    if (b >= ANIO_MIN && periodoValido(a, b)) return { mes: a, anio: b };
    return null;
  }

  const digits = raw.replace(/\D/g, "");
  if (digits.length === 6) {
    const anio = Number(digits.slice(0, 4));
    const mes = Number(digits.slice(4, 6));
    if (periodoValido(mes, anio)) return { mes, anio };
    const mes2 = Number(digits.slice(0, 2));
    const anio2 = Number(digits.slice(2, 6));
    if (periodoValido(mes2, anio2)) return { mes: mes2, anio: anio2 };
  }
  return null;
}

/** 202401 numérico, el formato que usan los Excel oficiales. */
export function periodoNumero(mes: number, anio: number): number {
  return anio * 100 + mes;
}

export function formatPeriodo(mes: any, anio: any): string {
  const m = Number(mes);
  const a = Number(anio);
  if (!periodoValido(m, a)) return "—";
  return `${MESES[m - 1]} ${a}`;
}

export function formatPeriodoCorto(mes: any, anio: any): string {
  const m = Number(mes);
  const a = Number(anio);
  if (!periodoValido(m, a)) return "—";
  return `${String(m).padStart(2, "0")}/${a}`;
}

/** Suma meses a un período (para calcular el período final de un plan de cuotas). */
export function sumarMeses(mes: number, anio: number, meses: number): Periodo {
  const total = (anio * 12 + (mes - 1)) + meses;
  return { mes: (total % 12) + 1, anio: Math.floor(total / 12) };
}

export const zMes = z.coerce.number().int().min(1, "Mes inválido").max(12, "Mes inválido");
export const zAnio = z.coerce.number().int().min(ANIO_MIN, "Año inválido").max(ANIO_MAX, "Año inválido");
export const zPeriodo = z.object({ periodo_mes: zMes, periodo_anio: zAnio });
