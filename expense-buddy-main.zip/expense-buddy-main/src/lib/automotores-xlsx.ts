// Lectura del Excel real de proveedores de Automotores (modelo "SEFER SERVICIOS FC 1526").
// Cabecera: Proveedor / FC B N° / Fecha / Periodo (202609).
// Detalle: Fecha_Compra | Legajo | Apellido_y_Nombre | Ticket | Tipo_Compra | Importe_Total |
//          Observacion | Cuotas | Cuota_1 ... Cuota_12
import * as XLSX from "xlsx";
import { normalizeLegajo } from "@/lib/legajo";
import { parsePeriodo } from "@/lib/periodo";

export type AutoParsedRow = {
  fecha: string | null;
  legajo: string;
  apellido_nombre: string | null;
  ticket: string | null;
  prestacion: string;
  importe: number;
  observacion: string | null;
  cuotas: number;
  cuotas_importes: number[];
  fila: number;
};

export type AutoParsedFile = {
  archivo: string;
  proveedor_ref: string | null;
  factura: string | null;
  fecha_factura: string | null;
  periodo_mes: number | null;
  periodo_anio: number | null;
  filas: AutoParsedRow[];
  invalidas: { fila: number; legajo: string; motivo: string }[];
};

const norm = (s: unknown) =>
  String(s ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[\s._]+/g, "")
    .trim()
    .toLowerCase();

const excelDate = (v: unknown): string | null => {
  if (v == null || v === "") return null;
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  if (typeof v === "number") {
    const d = XLSX.SSF.parse_date_code(v);
    if (!d) return null;
    return `${d.y}-${String(d.m).padStart(2, "0")}-${String(d.d).padStart(2, "0")}`;
  }
  const s = String(v).trim();
  const dmy = s.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})$/);
  if (dmy) {
    const y = Number(dmy[3]) < 100 ? 2000 + Number(dmy[3]) : Number(dmy[3]);
    return `${y}-${dmy[2].padStart(2, "0")}-${dmy[1].padStart(2, "0")}`;
  }
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
  return null;
};

const num = (v: unknown): number => {
  if (typeof v === "number") return v;
  const s = String(v ?? "")
    .replace(/[^\d,.-]/g, "")
    .trim();
  if (!s) return 0;
  // 1.234,56 (es-AR) vs 1234.56
  const esAr = /,\d{1,2}$/.test(s);
  const clean = esAr ? s.replace(/\./g, "").replace(",", ".") : s.replace(/,/g, "");
  const n = Number(clean);
  return Number.isFinite(n) ? n : 0;
};

export function parseAutomotoresWorkbook(file: string, buf: ArrayBuffer): AutoParsedFile {
  const wb = XLSX.read(buf, { cellDates: true });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const grid = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, raw: true, defval: null }) as any[][];

  const out: AutoParsedFile = {
    archivo: file,
    proveedor_ref: null,
    factura: null,
    fecha_factura: null,
    periodo_mes: null,
    periodo_anio: null,
    filas: [],
    invalidas: [],
  };

  // --- Cabecera: se leen etiquetas y su valor a la derecha, en cualquier posición.
  let headerRow = -1;
  for (let r = 0; r < grid.length; r++) {
    const row = grid[r] ?? [];
    for (let c = 0; c < row.length; c++) {
      const label = norm(row[c]);
      const next = row[c + 1] ?? row[c + 2];
      if (label === "proveedor" && out.proveedor_ref == null && next != null)
        out.proveedor_ref = String(next).trim();
      if ((label.startsWith("fcb") || label === "factura" || label.startsWith("fcbn")) && next != null)
        out.factura = String(next).replace(/\.0+$/, "").trim();
      if (label === "fecha" && out.fecha_factura == null) out.fecha_factura = excelDate(next);
      if (label === "periodo" && out.periodo_mes == null) {
        const p = parsePeriodo(next instanceof Date ? null : next);
        if (p) {
          out.periodo_mes = p.mes;
          out.periodo_anio = p.anio;
        }
      }
      if (label === "fechacompra") headerRow = r;
    }
    if (headerRow >= 0) break;
  }
  if (headerRow < 0) throw new Error("No se encontró la fila de encabezados (Fecha_Compra, Legajo, …)");

  const cols = new Map<string, number>();
  (grid[headerRow] ?? []).forEach((h, i) => {
    const k = norm(h);
    if (k && !cols.has(k)) cols.set(k, i);
  });
  const col = (...names: string[]) => {
    for (const n of names) {
      const i = cols.get(norm(n));
      if (i != null) return i;
    }
    return -1;
  };
  const iFecha = col("Fecha_Compra");
  const iLegajo = col("Legajo");
  const iNombre = col("Apellido_y_Nombre", "Apellido y Nombre");
  const iTicket = col("Ticket");
  const iTipo = col("Tipo_Compra");
  const iImporte = col("Importe_Total", "Importe");
  const iObs = col("Observacion", "Observación");
  const iCuotas = col("Cuotas");
  const iCuota = Array.from({ length: 12 }, (_, k) => col(`Cuota_${k + 1}`));

  for (let r = headerRow + 1; r < grid.length; r++) {
    const row = grid[r] ?? [];
    const vacia = row.every((v) => v == null || String(v).trim() === "");
    if (vacia) continue;
    const fila = r + 1;
    const legajo = normalizeLegajo(iLegajo >= 0 ? row[iLegajo] : "");
    const prestacion = String((iTipo >= 0 ? row[iTipo] : "") ?? "").trim();
    const importe = Math.round(num(iImporte >= 0 ? row[iImporte] : 0) * 100) / 100;
    const cuotasRaw = Math.floor(num(iCuotas >= 0 ? row[iCuotas] : 1)) || 1;
    const cuotas_importes = iCuota
      .map((i) => (i >= 0 ? Math.round(num(row[i]) * 100) / 100 : 0))
      .filter((x) => x > 0);

    const motivos: string[] = [];
    if (!legajo) motivos.push("falta el legajo");
    if (!prestacion) motivos.push("falta Tipo_Compra (servicio/prestación)");
    if (!(importe > 0)) motivos.push("Importe_Total inválido");
    if (cuotasRaw < 1 || cuotasRaw > 12) motivos.push("cantidad de cuotas inválida (1 a 12)");
    if (cuotas_importes.length && cuotas_importes.length !== cuotasRaw)
      motivos.push(`informa ${cuotas_importes.length} importe(s) de cuota pero declara ${cuotasRaw} cuotas`);
    if (cuotas_importes.length === cuotasRaw) {
      const suma = Math.round(cuotas_importes.reduce((a, b) => a + b, 0) * 100) / 100;
      if (Math.abs(suma - importe) > 0.05)
        motivos.push(`la suma de cuotas (${suma}) no coincide con Importe_Total (${importe})`);
    }

    if (motivos.length) {
      out.invalidas.push({ fila, legajo, motivo: motivos.join("; ") });
      continue;
    }

    out.filas.push({
      fecha: excelDate(iFecha >= 0 ? row[iFecha] : null),
      legajo,
      apellido_nombre: iNombre >= 0 ? (String(row[iNombre] ?? "").trim() || null) : null,
      ticket: iTicket >= 0 ? (String(row[iTicket] ?? "").replace(/\.0+$/, "").trim() || null) : null,
      prestacion,
      importe,
      observacion: iObs >= 0 ? (String(row[iObs] ?? "").trim() || null) : null,
      cuotas: cuotasRaw,
      cuotas_importes,
      fila,
    });
  }

  return out;
}
