// Estadísticas generales de los subservicios de Servicios Varios.
const r2 = (n: number) => Math.round(n * 100) / 100;
const sum = (rows: any[], k: string) => r2(rows.reduce((a, x) => a + Number(x?.[k] ?? 0), 0));

export async function subserviceStats() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const [
    { data: circles },
    { data: circleMembers },
    { data: plans },
    { data: planMembers },
    { data: colectas },
    { data: colectaMembers },
    { data: forms },
    { data: cons },
  ] = await Promise.all([
    supabaseAdmin.from("circles").select("id, importe"),
    supabaseAdmin.from("circle_members").select("legajo, importe_mensual"),
    supabaseAdmin.from("birthday_plans").select("id, importe_total"),
    supabaseAdmin.from("birthday_members").select("legajo, total"),
    supabaseAdmin.from("collections").select("id, cerrada, importe_objetivo"),
    supabaseAdmin.from("collection_members").select("legajo, importe_total"),
    supabaseAdmin.from("daily_forms").select("fecha, importe, es_cumpleanos"),
    supabaseAdmin.from("daily_consumptions").select("legajo, importe, no_paga"),
  ]);

  const c = circles ?? [];
  const cm = circleMembers ?? [];
  const p = plans ?? [];
  const pm = planMembers ?? [];
  const co = colectas ?? [];
  const com = colectaMembers ?? [];
  const f = forms ?? [];
  const dc = cons ?? [];

  return [
    {
      key: "circulo",
      nombre: "Círculos",
      to: "/admin/circulo",
      kpis: [
        { l: "Círculos", v: c.length },
        { l: "Participantes", v: new Set(cm.map((x: any) => x.legajo)).size },
        { l: "Aporte mensual", v: sum(cm, "importe_mensual"), money: true },
        { l: "Pozo total", v: sum(c, "importe"), money: true },
      ],
    },
    {
      key: "cumpleanos",
      nombre: "Cumpleaños",
      to: "/admin/cumpleanos",
      kpis: [
        { l: "Planes", v: p.length },
        { l: "Participantes", v: new Set(pm.map((x: any) => x.legajo)).size },
        { l: "A descontar", v: sum(pm, "total"), money: true },
        { l: "Importe planes", v: sum(p, "importe_total"), money: true },
      ],
    },
    {
      key: "colecta",
      nombre: "Colectas",
      to: "/admin/colecta",
      kpis: [
        { l: "Colectas", v: co.length },
        { l: "Abiertas", v: co.filter((x: any) => !x.cerrada).length },
        { l: "Participantes", v: new Set(com.map((x: any) => x.legajo)).size },
        { l: "Recaudado", v: sum(com, "importe_total"), money: true },
      ],
    },
    {
      key: "comida-dto",
      nombre: "Comida a Dto.",
      to: "/admin/comida-dto",
      kpis: [
        { l: "Días cargados", v: f.length },
        { l: "Consumos", v: dc.length },
        { l: "Total pagado", v: sum(f, "importe"), money: true },
        {
          l: "A descontar",
          v: r2(dc.reduce((a: number, x: any) => a + (x.no_paga ? 0 : Number(x.importe ?? 0)), 0)),
          money: true,
        },
      ],
    },
  ];
}
