// Panel consolidado de servicios y proveedores del período vigente + histórico.
import { periodoVigente } from "./periodo-vigente.server";
import { buildCircleSettlement } from "./circles.server";
import { buildBirthdaySettlement } from "./birthdays.server";
import { buildCollectionSettlement } from "./collections.server";

const r2 = (n: number) => Math.round((Number(n) || 0) * 100) / 100;

export type ProveedorDetalle = {
  legajo: string;
  apellido_nombre: string | null;
  carga: string;
  fecha: string | null;
  detalle: string | null;
  cuota: string;
  importe: number;
  subsidio: number;
  a_descontar: number;
};

export type ProveedorFila = {
  tipo: "proveedor";
  key: string;
  servicio: string;
  proveedor: string;
  submission_id: string | null;
  submission_ids: string[];
  cargas: number;
  estado: string | null;
  estados: string[];
  items: number;
  afiliados: number;
  importe: number;
  subsidio: number;
  a_pagar: number;
  /** Lo que se descuenta a los afiliados en ESTE período (cuotas vigentes incluidas). */
  a_descontar: number;
  /** Cuotas de cargas de meses anteriores que impactan este período. */
  cuotas_de_otros_periodos: number;
  /** Es un plan en cuotas (refinanciación), no un consumo de pago único. */
  refinanciacion: boolean;
  detalle: ProveedorDetalle[];
  sin_consumo: boolean;
};


export type CuotaDetalle = {
  grupo: string;
  legajo: string;
  apellido_nombre: string | null;
  cuota: string;
  importe: number;
  /** Beneficiario del grupo (colectas). */
  beneficiario?: string | null;
  /** Le corresponde cobrar/ser agasajado en este período: se resalta en el Excel. */
  destacado?: boolean;
  nota?: string | null;
};


export type CuotaFila = {
  tipo: "cuota";
  key: string;
  servicio: string;
  concepto: string;
  afiliados: number;
  total: number;
  sin_consumo: boolean;
  detalle: CuotaDetalle[];
};

/** Todo lo que se liquida en el período (mes/anio); si no se pasa, usa el vigente. */
export async function cargasPanel(args?: { mes?: number | null; anio?: number | null }) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const vig = await periodoVigente();
  const mes = args?.mes ?? vig.mes;
  const anio = args?.anio ?? vig.anio;

  const [
    { data: providers },
    { data: subs },
    { data: circles },
    { data: circleMembers },
    { data: plans },
    { data: planMembers },
    { data: colectas },
    { data: colectaMembers },
    { data: forms },
  ] = await Promise.all([
    supabaseAdmin.from("providers").select("id, nombre, habilitado, service_id, services(nombre, codigo)"),
    supabaseAdmin
      .from("provider_submissions")
      .select("id, nombre, provider_id, service_id, estado, periodo_mes, periodo_anio, total_items, total_afiliados, total_importe, total_subsidio, total_a_pagar")
      .neq("estado", "rechazado"),

    supabaseAdmin.from("circles").select("*"),
    supabaseAdmin.from("circle_members").select("*"),
    supabaseAdmin.from("birthday_plans").select("*"),
    supabaseAdmin.from("birthday_members").select("*"),
    supabaseAdmin.from("collections").select("*"),
    supabaseAdmin.from("collection_members").select("*"),
    supabaseAdmin.from("daily_forms").select("id, fecha, es_cumpleanos"),
  ]);

  // -------- proveedores habilitados --------
  // Las cargas del período se pagan al proveedor; los DESCUENTOS del período son
  // las cuotas que caen en este mes, sin importar en qué mes se cargó la planilla.
  const periodoIdx = anio * 12 + (mes - 1);
  const subById = new Map((subs ?? []).map((s: any) => [String(s.id), s]));

  // Cargas del período (para el pago al proveedor y el estado de la carga).
  const byProv = new Map<string, any[]>();
  for (const s of subs ?? []) {
    if (Number(s.periodo_mes) !== mes || Number(s.periodo_anio) !== anio) continue;
    const arr = byProv.get(String(s.provider_id)) ?? [];
    arr.push(s);
    byProv.set(String(s.provider_id), arr);
  }

  // Cuotas vigentes en el período, tomadas de TODAS las cargas.
  const nombrePorLegajo = new Map<string, string>();
  {
    const { data: afiliados } = await supabaseAdmin.from("affiliates").select("legajo, apellido_nombre");
    for (const a of afiliados ?? []) nombrePorLegajo.set(String(a.legajo), String(a.apellido_nombre ?? ""));
  }

  type Activa = ProveedorDetalle & { provider_id: string; refi: boolean; submission_id: string; otro_periodo: boolean };
  const activas: Activa[] = [];
  const allSubIds = (subs ?? []).map((s: any) => String(s.id));
  for (let i = 0; i < allSubIds.length; i += 200) {
    const { data: items } = await supabaseAdmin
      .from("submission_items")
      .select("id, submission_id, provider_id, legajo, fecha, detalle, importe, subsidio, importe_afiliado, cuotas, cuotas_importes")
      .in("submission_id", allSubIds.slice(i, i + 200));
    for (const it of items ?? []) {
      const sub: any = subById.get(String(it.submission_id));
      if (!sub?.periodo_mes || !sub?.periodo_anio) continue;
      const n = Math.max(1, Number(it.cuotas) || 1);
      const idx = periodoIdx - (Number(sub.periodo_anio) * 12 + (Number(sub.periodo_mes) - 1));
      if (idx < 0 || idx >= n) continue;
      const explic: number[] = Array.isArray((it as any).cuotas_importes)
        ? ((it as any).cuotas_importes as any[]).map((x) => Number(x) || 0)
        : [];
      const aDescontar =
        explic.length === n ? r2(explic[idx] ?? 0) : r2(Number(it.importe_afiliado ?? 0) / n);
      if (!aDescontar) continue;
      activas.push({
        provider_id: String(it.provider_id),
        submission_id: String(it.submission_id),
        refi: n > 1,
        otro_periodo: idx > 0,
        legajo: String(it.legajo),
        apellido_nombre: nombrePorLegajo.get(String(it.legajo)) ?? null,
        carga: String(sub.nombre ?? ""),
        fecha: it.fecha ?? null,
        detalle: it.detalle ?? null,
        cuota: n > 1 ? `${idx + 1}/${n}` : "única",
        importe: r2(Number(it.importe ?? 0) / n),
        subsidio: r2(Number(it.subsidio ?? 0) / n),
        a_descontar: aDescontar,
      });
    }
  }

  const proveedores: ProveedorFila[] = [];
  for (const p of (providers ?? []).filter((x: any) => x.habilitado)) {
    const svc = (p as any).services?.nombre ?? "—";
    const list = byProv.get(String(p.id)) ?? [];
    const misActivas = activas.filter((a) => a.provider_id === String(p.id));
    const ids = list.map((s: any) => String(s.id));
    const estados = [...new Set(list.map((s: any) => String(s.estado)))];
    const aPagar = r2(list.reduce((a: number, s: any) => a + Number(s.total_a_pagar ?? 0), 0));

    // Un consumo en 1 cuota es pago único; en más de 1 cuota es una refinanciación.
    const grupos: { refi: boolean; det: Activa[] }[] = [
      { refi: false, det: misActivas.filter((a) => !a.refi) },
      { refi: true, det: misActivas.filter((a) => a.refi) },
    ];

    for (const g of grupos) {
      if (g.refi && !g.det.length) continue;
      if (!g.refi && !g.det.length && !list.length && misActivas.length) continue;
      const det = g.det;
      proveedores.push({
        tipo: "proveedor",
        key: g.refi ? `prov:${p.id}:refi` : `prov:${p.id}`,
        servicio: g.refi ? "Refinanciación" : svc,
        proveedor: p.nombre,
        submission_id: ids[0] ?? null,
        submission_ids: g.refi ? [...new Set(det.map((d) => d.submission_id))] : ids,
        cargas: g.refi ? new Set(det.map((d) => d.submission_id)).size : list.length,
        estado: estados.length === 1 ? estados[0]! : estados.length ? "varios" : null,
        estados,
        items: det.length,
        afiliados: new Set(det.map((d) => d.legajo)).size,
        importe: r2(det.reduce((a, d) => a + d.importe, 0)),
        subsidio: r2(det.reduce((a, d) => a + d.subsidio, 0)),
        a_pagar: g.refi ? 0 : aPagar,
        a_descontar: r2(det.reduce((a, d) => a + d.a_descontar, 0)),
        cuotas_de_otros_periodos: det.filter((d) => d.otro_periodo).length,
        refinanciacion: g.refi,
        detalle: det.map(({ provider_id: _p, refi: _r, submission_id: _s, otro_periodo: _o, ...rest }) => rest),
        sin_consumo: !det.length && !list.length,
      });
    }
  }
  proveedores.sort((a, b) => a.servicio.localeCompare(b.servicio) || a.proveedor.localeCompare(b.proveedor));


  // -------- servicios con cuotas --------
  const cuotas: CuotaFila[] = [];

  const cMembers = new Map<string, any[]>();
  for (const m of circleMembers ?? []) {
    const arr = cMembers.get(String(m.circle_id)) ?? [];
    arr.push(m);
    cMembers.set(String(m.circle_id), arr);
  }
  const circ = buildCircleSettlement(
    (circles ?? []).map((c: any) => ({ ...c, members: cMembers.get(String(c.id)) ?? [] })) as any,
    mes,
    anio,
  );
  cuotas.push({
    tipo: "cuota",
    key: "circulos",
    servicio: "Servicios Varios",
    concepto: "Círculos",
    afiliados: circ.rows.length,
    total: r2(circ.total),
    sin_consumo: !circ.rows.length,
    detalle: circ.rows.flatMap((r) =>
      r.circulos.map((c) => {
        const cobra = circ.cobradores.some((x) => x.legajo === r.legajo && x.circulo === c.nombre);
        return {
          grupo: `${c.numero ? `N° ${c.numero} · ` : ""}${c.nombre}`,
          legajo: r.legajo,
          apellido_nombre: r.apellido_nombre,
          cuota: "mensual",
          importe: r2(c.importe),
          destacado: cobra,
          nota: cobra ? "Le corresponde el cobro de este mes" : null,
        };
      }),
    ),

  });

  const pMembers = new Map<string, any[]>();
  for (const m of planMembers ?? []) {
    const arr = pMembers.get(String(m.plan_id)) ?? [];
    arr.push(m);
    pMembers.set(String(m.plan_id), arr);
  }
  const bd = buildBirthdaySettlement(
    (plans ?? []).map((p: any) => ({ ...p, members: pMembers.get(String(p.id)) ?? [] })) as any,
    mes,
    anio,
  );
  cuotas.push({
    tipo: "cuota",
    key: "cumpleanos",
    servicio: "Servicios Varios",
    concepto: "Cumpleaños",
    afiliados: bd.rows.length,
    total: r2(bd.total),
    sin_consumo: !bd.rows.length,
    detalle: bd.rows.flatMap((r) =>
      r.planes.map((p) => {
        const agasajado = bd.agasajados.some((a) => a.legajo === r.legajo && a.plan === p.nombre);
        return {
          grupo: p.nombre,
          legajo: r.legajo,
          apellido_nombre: r.apellido_nombre,
          cuota: p.cuota,
          importe: r2(p.importe),
          destacado: agasajado,
          nota: agasajado ? "Cumple años este mes" : null,
        };
      }),
    ),

  });

  const coMembers = new Map<string, any[]>();
  for (const m of colectaMembers ?? []) {
    const arr = coMembers.get(String(m.collection_id)) ?? [];
    arr.push(m);
    coMembers.set(String(m.collection_id), arr);
  }
  const colList = (colectas ?? []).map((c: any) => ({ ...c, members: coMembers.get(String(c.id)) ?? [] }));
  const benefPorColecta = new Map<string, string>();
  for (const c of colList as any[]) {
    const nom = String(c.beneficiario_nombre ?? "").trim();
    const leg = String(c.beneficiario_legajo ?? "").trim();
    const txt = [leg, nom].filter(Boolean).join(" · ");
    if (txt) benefPorColecta.set(String(c.nombre), txt);
  }
  const col = buildCollectionSettlement(colList as any, mes, anio);

  cuotas.push({
    tipo: "cuota",
    key: "colectas",
    servicio: "Servicios Varios",
    concepto: "Colectas",
    afiliados: col.rows.length,
    total: r2(col.total),
    sin_consumo: !col.rows.length,
    detalle: col.rows.flatMap((r) =>
      r.colectas.map((c) => ({
        grupo: c.nombre,
        legajo: r.legajo,
        apellido_nombre: r.apellido_nombre,
        cuota: c.cuota,
        importe: r2(c.importe),
        beneficiario: benefPorColecta.get(c.nombre) ?? null,
      })),
    ),

  });

  // -------- Comida a Dto. del período --------
  const ym = `${anio}-${String(mes).padStart(2, "0")}`;
  const formIds = (forms ?? []).filter((f: any) => String(f.fecha ?? "").startsWith(ym)).map((f: any) => f.id);
  let comidaRows: CuotaDetalle[] = [];
  let comidaTotal = 0;
  const legajosComida = new Set<string>();
  if (formIds.length) {
    const { data: cons } = await supabaseAdmin
      .from("daily_consumptions")
      .select("legajo, importe, no_paga, daily_form_id, daily_forms!inner(fecha)")
      .in("daily_form_id", formIds);
    for (const c of cons ?? []) {
      const imp = c.no_paga ? 0 : r2(Number(c.importe ?? 0));
      if (!imp) continue;
      legajosComida.add(String(c.legajo));
      comidaTotal = r2(comidaTotal + imp);
      comidaRows.push({
        grupo: "Comida a Dto.",
        legajo: String(c.legajo),
        apellido_nombre: null,
        cuota: String((c as any).daily_forms?.fecha ?? ""),
        importe: imp,
      });
    }
  }
  cuotas.push({
    tipo: "cuota",
    key: "comida",
    servicio: "Servicios Varios",
    concepto: "Comida a Dto.",
    afiliados: legajosComida.size,
    total: comidaTotal,
    sin_consumo: !comidaRows.length,
    detalle: comidaRows,
  });

  // -------- adelantos y refinanciaciones del período --------
  const [{ data: adelantos }, { data: refis }] = await Promise.all([
    supabaseAdmin.from("adelantos" as any).select("*"),
    supabaseAdmin.from("refinanciaciones" as any).select("*"),
  ]);
  const idx = anio * 12 + (mes - 1);
  const adeDet: CuotaDetalle[] = [];
  for (const a of (adelantos ?? []) as any[]) {
    const cuotas_n = Math.max(1, Number(a.cuotas) || 1);
    // Un adelanto se descuenta en UNA cuota; en más de una es refinanciación
    // y ya se refleja con su plan en la fila de Refinanciación.
    if (cuotas_n > 1) continue;
    const start = Number(a.periodo_anio) * 12 + (Number(a.periodo_mes) - 1);
    const d = idx - start;
    if (d !== 0) continue;
    const importe = r2(Number(a.monto_pedido) || 0);
    if (!importe) continue;

    adeDet.push({
      grupo: String(a.concepto ?? "Adelanto"),
      legajo: String(a.legajo),
      apellido_nombre: a.apellido_nombre ?? null,
      cuota: "única",
      importe,
    });
  }
  cuotas.push({
    tipo: "cuota",
    key: "adelantos",
    servicio: "Adelantos",
    concepto: "Adelantos a descontar (1 cuota)",

    afiliados: new Set(adeDet.map((x) => x.legajo)).size,
    total: r2(adeDet.reduce((a, x) => a + x.importe, 0)),
    sin_consumo: !adeDet.length,
    detalle: adeDet,
  });

  const refDet: CuotaDetalle[] = [];
  for (const r of (refis ?? []) as any[]) {
    if (r.reemplazada_por) continue;
    const cuotas_n = Math.max(1, Number(r.cuotas_efectivas ?? r.cuotas) || 1);
    const start = Number(r.periodo_anio) * 12 + (Number(r.periodo_mes) - 1);
    const d = idx - start;
    if (d < 0 || d >= cuotas_n) continue;
    const importe = r2((Number(r.total) || 0) / cuotas_n);
    if (!importe) continue;
    refDet.push({
      grupo: "Refinanciación",
      legajo: String(r.legajo),
      apellido_nombre: r.apellido_nombre ?? null,
      cuota: `${d + 1}/${cuotas_n}`,
      importe,
    });
  }
  cuotas.push({
    tipo: "cuota",
    key: "refinanciacion",
    servicio: "Refinanciación",
    concepto: "Cuotas refinanciadas",
    afiliados: new Set(refDet.map((x) => x.legajo)).size,
    total: r2(refDet.reduce((a, x) => a + x.importe, 0)),
    sin_consumo: !refDet.length,
    detalle: refDet,
  });

  return { vigente: vig, mes, anio, proveedores, cuotas };
}

/** Períodos (mes/anio) con cargas de proveedores, del más nuevo al más viejo. */
export async function cargasPeriodos() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin.from("provider_submissions").select("periodo_mes, periodo_anio");
  const set = new Set<string>();
  for (const s of data ?? []) set.add(`${s.periodo_anio}-${s.periodo_mes}`);
  return [...set]
    .map((k) => {
      const [a, m] = k.split("-").map(Number);
      return { mes: m, anio: a };
    })
    .sort((x, y) => y.anio * 12 + y.mes - (x.anio * 12 + x.mes));
}
