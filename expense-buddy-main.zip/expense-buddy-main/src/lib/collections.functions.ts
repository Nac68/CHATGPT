import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const memberSchema = z.object({
  legajo: z.string().trim().min(1).max(32),
  importe_total: z.number().nonnegative().default(0),
  cuotas: z.number().int().min(1).max(60).default(1),
  observacion: z.string().max(300).nullable().optional(),
});

export const listCollections = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ product_id: z.string().uuid().optional() }).parse(raw ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);

    let q = context.supabase
      .from("collections")
      .select("*")
      .order("created_at", { ascending: false });
    if (data.product_id) q = q.eq("product_id", data.product_id);
    const { data: cols, error } = await q;
    if (error) throw new Error(error.message);

    const ids = (cols ?? []).map((c: any) => c.id);
    let members: any[] = [];
    if (ids.length) {
      const { data: ms, error: e2 } = await context.supabase
        .from("collection_members")
        .select("*")
        .in("collection_id", ids)
        .order("legajo");
      if (e2) throw new Error(e2.message);
      members = ms ?? [];
    }

    return {
      collections: (cols ?? []).map((c: any) => {
        const ms = members.filter((m) => m.collection_id === c.id);
        return {
          ...c,
          members: ms,
          aportantes: ms.length,
          total_aportes: ms.reduce((a, m) => a + Number(m.importe_total ?? 0), 0),
          total_cuota_mes: ms.reduce((a, m) => a + Number(m.importe_cuota ?? 0), 0),
        };
      }),
    };
  });

export const saveCollection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        id: z.string().uuid().optional(),
        service_id: z.string().uuid().nullable().optional(),
        product_id: z.string().uuid().nullable().optional(),
        nombre: z.string().trim().min(2).max(160),
        motivo: z.string().max(300).nullable().optional(),
        beneficiario_legajo: z.string().trim().max(32).nullable().optional(),
        beneficiario_nombre: z.string().trim().max(160).nullable().optional(),
        fecha: z.string().nullable().optional(),
        importe_objetivo: z.number().nonnegative().default(0),
        cuotas: z.number().int().min(1).max(60).default(1),
        mes_inicio: z.number().int().min(1, "Mes del período inválido").max(12, "Mes del período inválido"),
        anio_inicio: z.number().int().min(2000, "Año del período inválido").max(2100, "Año del período inválido"),
        cerrada: z.boolean().default(false),
        observacion: z.string().max(500).nullable().optional(),
        members: z.array(memberSchema).default([]),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { r2 } = await import("./collections.server");

    const benLegajo = data.beneficiario_legajo?.trim().toUpperCase() || null;
    let benNombre = data.beneficiario_nombre?.trim() || null;
    if (benLegajo && !benNombre) {
      const { data: ben } = await context.supabase
        .from("affiliates")
        .select("apellido_nombre")
        .eq("legajo", benLegajo)
        .maybeSingle();
      benNombre = (ben as any)?.apellido_nombre ?? null;
    }

    const header = {
      ...(data.id ? { id: data.id } : {}),
      service_id: data.service_id ?? null,
      product_id: data.product_id ?? null,
      nombre: data.nombre,
      motivo: data.motivo ?? null,
      beneficiario_legajo: benLegajo,
      beneficiario_nombre: benNombre,
      fecha: data.fecha || null,
      importe_objetivo: data.importe_objetivo,
      cuotas: data.cuotas,
      mes_inicio: data.mes_inicio ?? null,
      anio_inicio: data.anio_inicio ?? null,
      cerrada: data.cerrada,
      observacion: data.observacion ?? null,
    };

    const { data: saved, error } = await context.supabase
      .from("collections")
      .upsert(header as any, { onConflict: "id" })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    const collectionId = saved.id as string;

    await context.supabase.from("collection_members").delete().eq("collection_id", collectionId);

    const legajos = data.members.map((m) => m.legajo.trim().toUpperCase());
    let nombres: Record<string, string | null> = {};
    if (legajos.length) {
      const { data: afs } = await context.supabase
        .from("affiliates")
        .select("legajo, apellido_nombre")
        .in("legajo", legajos);
      nombres = Object.fromEntries((afs ?? []).map((a: any) => [a.legajo, a.apellido_nombre]));
    }

    if (data.members.length) {
      const rows = data.members.map((m) => {
        const legajo = m.legajo.trim().toUpperCase();
        const cuotas = Math.max(1, m.cuotas || data.cuotas || 1);
        return {
          collection_id: collectionId,
          legajo,
          apellido_nombre: nombres[legajo] ?? null,
          importe_total: m.importe_total,
          cuotas,
          importe_cuota: r2(m.importe_total / cuotas),
          observacion: m.observacion ?? null,
        };
      });
      const { error: e3 } = await context.supabase
        .from("collection_members")
        .insert(rows as any);
      if (e3) throw new Error(e3.message);
    }

    return { ok: true, id: collectionId };
  });

export const deleteCollection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { error } = await context.supabase.from("collections").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Liquidación mensual de colectas: descuento por afiliado y total. */
export const collectionsSettlement = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        mes: z.number().int().min(1).max(12),
        anio: z.number().int().min(2000).max(2100),
        product_id: z.string().uuid().optional(),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { buildCollectionSettlement } = await import("./collections.server");

    let q = context.supabase.from("collections").select("*");
    if (data.product_id) q = q.eq("product_id", data.product_id);
    const { data: cols, error } = await q;
    if (error) throw new Error(error.message);

    const ids = (cols ?? []).map((c: any) => c.id);
    let members: any[] = [];
    if (ids.length) {
      const { data: ms, error: e2 } = await context.supabase
        .from("collection_members")
        .select("*")
        .in("collection_id", ids);
      if (e2) throw new Error(e2.message);
      members = ms ?? [];
    }

    const full = (cols ?? []).map((c: any) => ({
      ...c,
      members: members.filter((m) => m.collection_id === c.id),
    }));

    return { mes: data.mes, anio: data.anio, ...buildCollectionSettlement(full, data.mes, data.anio) };
  });
