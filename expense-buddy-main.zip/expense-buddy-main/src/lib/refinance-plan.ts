// Lógica pura del plan de cuotas y de la consolidación de refinanciaciones.
// Sin dependencias: se usa igual en el navegador, en el servidor y en verificaciones.

export const r2 = (n: number) => Math.round((Number(n) || 0) * 100) / 100;

export const periodIndex = (mes: number, anio: number) =>
  Number(anio) * 12 + (Number(mes) - 1);

export const periodFromIndex = (idx: number) => ({
  mes: (((idx % 12) + 12) % 12) + 1,
  anio: Math.floor(idx / 12),
});

export const periodLabel = (mes: number, anio: number) =>
  `${String(mes).padStart(2, "0")}/${anio}`;

/**
 * Cuotas iguales a 2 decimales; la última absorbe la diferencia para que la
 * suma sea exactamente el capital.
 */
export function cuotaPlan(capital: number, cuotas: number): number[] {
  const n = Math.max(1, Math.floor(Number(cuotas) || 1));
  const total = r2(capital);
  const base = Math.floor((total / n) * 100) / 100;
  const plan = Array.from({ length: n }, () => base);
  plan[n - 1] = r2(total - base * (n - 1));
  return plan;
}

export type RefiLike = {
  total: number | string;
  cuotas: number | string;
  periodo_mes: number | string;
  periodo_anio: number | string;
  cuotas_efectivas?: number | null;
};

/** Cuotas ya devengadas de un plan al llegar a (mes/año): nunca se reescriben. */
export function cuotasCobradas(r: RefiLike, mes: number, anio: number) {
  const cuotas = Math.max(1, Number(r.cuotas) || 1);
  const tope = r.cuotas_efectivas == null ? cuotas : Math.max(0, Number(r.cuotas_efectivas));
  const transcurridas =
    periodIndex(mes, anio) - periodIndex(Number(r.periodo_mes), Number(r.periodo_anio));
  return Math.min(tope, cuotas, Math.max(0, transcurridas));
}

/** Importe de la cuota que corresponde al período, o null si no se descuenta. */
export function cuotaDelPeriodo(r: RefiLike, mes: number, anio: number) {
  const cuotas = Math.max(1, Number(r.cuotas) || 1);
  const tope = r.cuotas_efectivas == null ? cuotas : Math.max(0, Number(r.cuotas_efectivas));
  const idx =
    periodIndex(mes, anio) - periodIndex(Number(r.periodo_mes), Number(r.periodo_anio));
  if (idx < 0 || idx >= cuotas || idx >= tope) return null;
  return { n: idx + 1, importe: cuotaPlan(Number(r.total), cuotas)[idx] };
}

/** Saldo real pendiente (capital de las cuotas futuras) a partir de (mes/año). */
export function saldoPendiente(r: RefiLike, mes: number, anio: number) {
  const cuotas = Math.max(1, Number(r.cuotas) || 1);
  const plan = cuotaPlan(Number(r.total), cuotas);
  const cobradas = cuotasCobradas(r, mes, anio);
  return r2(plan.slice(cobradas).reduce((a, b) => a + b, 0));
}

export type ConsolidationPreview = {
  saldo_anterior: number;
  nuevos_importes: number;
  capital: number;
  cuotas: number;
  importe_cuota: number;
  cuotas_conservadas: number;
  plan: { n: number; periodo: string; importe: number; saldo: number }[];
  periodo_label: string;
  periodo_fin_label: string;
};

/**
 * Vista previa del plan consolidado: saldo pendiente del plan anterior + los
 * nuevos importes, repartidos en la nueva cantidad de cuotas.
 */
export function consolidationPreview(args: {
  anterior?: RefiLike | null;
  nuevos: number;
  cuotas: number;
  mes: number;
  anio: number;
}): ConsolidationPreview {
  const { anterior, mes, anio } = args;
  const cuotas = Math.max(1, Math.floor(Number(args.cuotas) || 1));
  const saldo_anterior = anterior ? saldoPendiente(anterior, mes, anio) : 0;
  const nuevos_importes = r2(args.nuevos);
  const capital = r2(saldo_anterior + nuevos_importes);
  const importes = cuotaPlan(capital, cuotas);
  const base = periodIndex(mes, anio);
  let acumulado = 0;
  const plan = importes.map((importe, i) => {
    acumulado = r2(acumulado + importe);
    const p = periodFromIndex(base + i);
    return {
      n: i + 1,
      periodo: periodLabel(p.mes, p.anio),
      importe,
      saldo: r2(capital - acumulado),
    };
  });
  const fin = periodFromIndex(base + cuotas - 1);
  return {
    saldo_anterior,
    nuevos_importes,
    capital,
    cuotas,
    importe_cuota: importes[0],
    cuotas_conservadas: anterior ? cuotasCobradas(anterior, mes, anio) : 0,
    plan,
    periodo_label: periodLabel(mes, anio),
    periodo_fin_label: periodLabel(fin.mes, fin.anio),
  };
}

/** Estados que ocupan el lugar de "refinanciación activa" de un legajo. */
export const ESTADOS_ACTIVOS = ["activa"];
