// Helpers server-only de Refinanciación: plan de cuotas por período.
// El cálculo puro vive en ./refinance-plan (compartido con la UI y las pruebas).

import {
  cuotaDelPeriodo as cuotaPeriodo,
  cuotaPlan,
  cuotasCobradas,
  periodFromIndex,
  periodIndex,
  periodLabel,
  r2,
  saldoPendiente,
  type RefiLike,
} from "./refinance-plan";

export { r2 };

/** Cuota (1..n) que corresponde al período, o null si no se descuenta ese mes. */
export function cuotaDelPeriodo(r: RefiLike, mes: number, anio: number) {
  return cuotaPeriodo(r, mes, anio)?.n ?? null;
}

/** Agrega importe de cuota, plan, cuota actual y saldo pendiente. */
export function withPlan(rows: any[], hoy = new Date()) {
  const mesActual = hoy.getUTCMonth() + 1;
  const anioActual = hoy.getUTCFullYear();
  return rows.map((r) => {
    const cuotas = Math.max(1, Number(r.cuotas) || 1);
    const importes = cuotaPlan(Number(r.total ?? 0), cuotas);
    const base = periodIndex(Number(r.periodo_mes), Number(r.periodo_anio));
    const fin = periodFromIndex(base + cuotas - 1);
    const cobradas = cuotasCobradas(r, mesActual, anioActual);
    const cuota = cuotaPeriodo(r, mesActual, anioActual);
    const consolidada = String(r.estado ?? "activa") === "consolidada";
    return {
      ...r,
      importe_cuota: importes[0],
      importe_ultima_cuota: importes[cuotas - 1],
      cuota_actual: cuota?.n ?? null,
      importe_cuota_periodo: cuota?.importe ?? 0,
      cuotas_cobradas: cobradas,
      cuotas_restantes: consolidada ? 0 : Math.max(0, cuotas - cobradas),
      saldo: consolidada ? 0 : saldoPendiente(r, mesActual, anioActual),
      periodo_label: periodLabel(Number(r.periodo_mes), Number(r.periodo_anio)),
      periodo_fin_label: periodLabel(fin.mes, fin.anio),
      consolidada,
      finalizada: consolidada || cuotas - cobradas <= 0,
    };
  });
}

/**
 * Refinanciación activa consolidada del legajo. Si hay más de una (datos
 * históricos), no se toca nada: se informa el conflicto.
 */
export async function activeRefinance(
  db: any,
  legajo: string,
): Promise<{ activa: any | null; conflicto: any[] }> {
  const { data } = await db
    .from("refinanciaciones")
    .select("*")
    .eq("legajo", legajo)
    .eq("estado", "activa")
    .order("created_at", { ascending: false });
  const hoy = new Date();
  const vigentes = withPlan((data ?? []) as any[], hoy).filter((r: any) => !r.finalizada);
  if (vigentes.length > 1) return { activa: null, conflicto: vigentes };
  return { activa: vigentes[0] ?? null, conflicto: [] };
}
