import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { normalizeLegajo } from "./auth-affiliate.functions";

async function assertAdmin(context: { supabase: any; userId: string }) {
  const { data } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  if (!data) throw new Error("Sólo administradores");
}

const LegajoSchema = z.string().min(1).max(32).transform(normalizeLegajo);
const NombreSchema = z.string().trim().min(2).max(200);

// Campos opcionales del padrón (mismo modelo que el Excel de AGOEC/CEAMSE).
const opt = (max = 200) =>
  z
    .union([z.string(), z.number(), z.null()])
    .optional()
    .transform((v) => {
      if (v === null || v === undefined) return null;
      const s = String(v).trim();
      return s ? s.slice(0, max) : null;
    });
const optDate = z
  .union([z.string(), z.null()])
  .optional()
  .transform((v) => {
    if (!v) return null;
    const s = String(v).slice(0, 10);
    return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : null;
  });

export const PadronFields = {
  sector: opt(120),
  sexo: opt(20),
  fecha_nac: optDate,
  tipo_doc: opt(20),
  doc_nro: opt(30),
  cuil: opt(30),
  estado_civil: opt(40),
  calle: opt(160),
  numero: opt(20),
  piso: opt(20),
  depto: opt(20),
  cp: opt(20),
  localidad: opt(120),
  telefono: opt(40),
  celular: opt(40),
  fecha_afiliacion: optDate,
  fecha_ingreso: optDate,
  observaciones: opt(500),
  lugar_trabajo: opt(160),
  codigo_lugar_trabajo: opt(20),
};

export const listAffiliates = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    // Padrón completo: sólo administradores (contiene datos personales).
    await assertAdmin(context);

    const PAGE = 1000;
    const all: any[] = [];
    for (let i = 0; i < 60; i++) {
      const { data, error } = await context.supabase
        .from("affiliates")
        .select("*")
        .order("legajo")
        .range(i * PAGE, i * PAGE + PAGE - 1);
      if (error) throw new Error(error.message);
      all.push(...(data ?? []));
      if (!data || data.length < PAGE) break;
    }
    return all;
  });


export const createAffiliate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({ legajo: LegajoSchema, apellido_nombre: NombreSchema, ...PadronFields })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Upsert: si el legajo ya existe, se sobrescriben los datos cargados.
    const { error } = await supabaseAdmin
      .from("affiliates")
      .upsert(data as any, { onConflict: "legajo" });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const updateAffiliate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({ legajo: LegajoSchema, apellido_nombre: NombreSchema, ...PadronFields })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { legajo, ...rest } = data as any;
    const { error } = await supabaseAdmin
      .from("affiliates")
      .update(rest)
      .eq("legajo", legajo);
    if (error) throw new Error(error.message);
    return { ok: true };
  });


export const deleteAffiliate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ legajo: LegajoSchema }).parse(raw))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: aff } = await supabaseAdmin
      .from("affiliates")
      .select("user_id")
      .eq("legajo", data.legajo)
      .maybeSingle();
    if (aff?.user_id) {
      await supabaseAdmin.auth.admin.deleteUser(aff.user_id).catch(() => null);
    }
    const { error } = await supabaseAdmin.from("affiliates").delete().eq("legajo", data.legajo);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const bulkImportAffiliates = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        rows: z
          .array(
            z.object({ legajo: LegajoSchema, apellido_nombre: NombreSchema, ...PadronFields }),
          )
          .min(1)
          .max(10000),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Deduplica por legajo (gana la última fila del archivo)
    const map = new Map<string, any>();
    for (const r of data.rows) map.set(r.legajo, r);
    const rows = Array.from(map.values());
    // Upsert in chunks
    const CHUNK = 500;
    let inserted = 0;
    for (let i = 0; i < rows.length; i += CHUNK) {
      const slice = rows.slice(i, i + CHUNK);
      const { error, count } = await supabaseAdmin
        .from("affiliates")
        .upsert(slice, { onConflict: "legajo", ignoreDuplicates: false, count: "exact" });
      if (error) throw new Error(error.message);
      inserted += count ?? slice.length;
    }
    return { ok: true, procesados: rows.length, escritos: inserted };
  });
