import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

// Búsqueda unificada del CRM: legajo/nombre de afiliado o número contable/nombre de proveedor.
export const crmSearch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ q: z.string().trim().max(120) }).parse(raw ?? { q: "" }))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { searchAll } = await import("./crm-search.server");
    return await searchAll(data.q);
  });

export const crmAffiliateHistory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ legajo: z.string().trim().min(1).max(32) }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { affiliateHistory } = await import("./crm-search.server");
    return await affiliateHistory(data.legajo);
  });

export const crmProviderHistory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ provider_id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { providerHistory } = await import("./crm-search.server");
    return await providerHistory(data.provider_id);
  });

// Buscador de consumos de Farmacia (solo farmacias habilitadas), por legajo o nombre.
export const farmaciaConsumosSearch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ q: z.string().trim().min(1).max(120), rubro: z.enum(["farmacia", "indumentaria", "supermercado"]).optional() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { farmaciaConsumos } = await import("./crm-search.server");
    return await farmaciaConsumos(data.q, data.rubro ?? "farmacia");
  });

// Buscador de consumos de Automotores: solo proveedores habilitados y período vigente.
export const automotoresConsumosSearch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ q: z.string().trim().min(1).max(120) }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { automotoresConsumosVigente } = await import("./crm-search.server");
    return await automotoresConsumosVigente(data.q);
  });

// Buscador de consumos de Servicios Varios del período vigente.
export const variosConsumosSearch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ q: z.string().trim().min(1).max(120) }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { variosConsumosVigente } = await import("./crm-search.server");
    return await variosConsumosVigente(data.q);
  });
