import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Tablero operativo del período para la portada de Administración. */
export const getAdminDashboard = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { buildAdminDashboard } = await import("./dashboard.server");
    return buildAdminDashboard();
  });
