import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { adelantoSchema } from "./advances.schema";

/** Listado de adelantos con el plan de cuotas calculado y el vínculo con refinanciación. */
export const listAdvances = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const [{ data, error }, { data: refis }, { data: refiItems }] = await Promise.all([
      context.supabase
        .from("adelantos" as any)
        .select("*")
        .order("periodo_anio", { ascending: false })
        .order("periodo_mes", { ascending: false })
        .order("legajo"),
      context.supabase.from("refinanciaciones" as any).select("*"),
      context.supabase.from("refinanciacion_items" as any).select("refinanciacion_id, source_key"),
    ]);
    if (error) throw new Error(error.message);
    const { withPlan } = await import("./advances.server");
    const { withPlan: withRefiPlan } = await import("./refinance.server");

    const refiById = new Map(
      withRefiPlan((refis ?? []) as any[]).map((r: any) => [r.id, r]),
    );
    // adelanto -> refinanciación que absorbió sus cuotas
    const porAdelanto = new Map<string, any>();
    for (const it of ((refiItems ?? []) as any[])) {
      const m = String(it.source_key ?? "").match(/^adelanto:([0-9a-f-]+):/i);
      if (!m) continue;
      const r = refiById.get(it.refinanciacion_id);
      if (r) porAdelanto.set(m[1], r);
    }

    const adelantos = withPlan((data ?? []) as any[]).map((a: any) => {
      const r = porAdelanto.get(String(a.id));
      return {
        ...a,
        refinanciacion: r
          ? {
              id: r.id,
              estado: r.estado ?? "activa",
              total: r.total,
              cuotas: r.cuotas,
              importe_cuota: r.importe_cuota,
              periodo_label: r.periodo_label,
              saldo: r.saldo,
            }
          : null,
        estado_operacion: r
          ? "Refinanciado"
          : a.cuota_actual
            ? `En curso ${a.cuota_actual}/${a.cuotas}`
            : a.cuotas_restantes
              ? "Pendiente"
              : "Finalizado",
      };
    });
    return { adelantos };
  });


/** Alta / edición de adelantos (uno o varios, para la importación de Excel). */
export const saveAdvances = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ items: z.array(adelantoSchema).min(1).max(2000) }).parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    const { normalizeLegajo } = await import("./legajo");
    await assertAdmin(context);

    const legajos = [...new Set(data.items.map((i) => normalizeLegajo(i.legajo)).filter(Boolean))];
    const nombres = new Map<string, string | null>();
    for (let i = 0; i < legajos.length; i += 500) {
      const { data: afs } = await context.supabase
        .from("affiliates")
        .select("legajo, apellido_nombre")
        .in("legajo", legajos.slice(i, i + 500));
      for (const a of afs ?? []) nombres.set(normalizeLegajo(a.legajo), a.apellido_nombre ?? null);
    }
    const faltantes = legajos.filter((l) => !nombres.has(l));

    const rows = data.items.filter((i) => nombres.has(normalizeLegajo(i.legajo))).map((i) => {
      const legajo = normalizeLegajo(i.legajo);
      return {
        ...(i.id ? { id: i.id } : {}),
        legajo,
        apellido_nombre: nombres.get(legajo) ?? null,
        fecha: i.fecha || null,
        monto_pedido: i.monto_pedido,
        cuotas: i.cuotas,
        periodo_mes: i.periodo_mes,
        periodo_anio: i.periodo_anio,
        concepto: i.concepto || "ADELANTO",
        responsable: i.responsable || null,
        ref_id: i.ref_id || null,
        cuil: i.cuil || null,
        banco: i.banco || null,
        cuenta: i.cuenta || null,
        cbu: i.cbu || null,
        cbu2: i.cbu2 || null,
        observacion: i.observacion || null,
      };
    });

    if (!rows.length) {
      throw new Error(`Ningún legajo coincide con el padrón: ${faltantes.slice(0, 12).join(", ")}`);
    }
    const guardados: any[] = [];
    for (let i = 0; i < rows.length; i += 500) {
      const { data: saved, error } = await context.supabase
        .from("adelantos" as any)
        .upsert(rows.slice(i, i + 500) as any, { onConflict: "id" })
        .select("*");
      if (error) throw new Error(error.message);
      guardados.push(...((saved ?? []) as any[]));
    }

    // Cada fila es un adelanto independiente: se cobra en cuotas por el concepto
    // "Adelantos". La refinanciación es siempre una decisión explícita (una sola
    // activa consolidada por legajo), así que no se genera plan automático.
    return {
      ok: true,
      guardados: rows.length,
      refinanciaciones: 0,
      omitidos: faltantes.map((legajo) => ({ legajo, motivo: "No está en el padrón de afiliados" })),
    };

  });

export const deleteAdvance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Se quita también el plan de refinanciación generado por este adelanto.
    const { data: its } = await supabaseAdmin
      .from("refinanciacion_items" as any)
      .select("refinanciacion_id")
      .like("source_key", `adelanto:${data.id}:%`);
    const refIds = [...new Set(((its ?? []) as any[]).map((i) => i.refinanciacion_id))];
    if (refIds.length)
      await supabaseAdmin.from("refinanciaciones" as any).delete().in("id", refIds);

    const { error } = await context.supabase.from("adelantos" as any).delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
