/**
 * Reglas puras de elegibilidad de días para liquidar (Comida a Dto.).
 *
 * Un día/formulario deja de ser elegible SÓLO cuando está vinculado
 * (por su id real de formulario, no por mes ni por aproximación de fechas)
 * a una liquidación cuyo estado es CERRADA o EXPORTADA.
 * Si esa liquidación se reabre (vuelve a borrador/revisada), el día vuelve a ser elegible.
 *
 * No deduplica ni altera consumos: varias filas del mismo legajo en un día
 * (por ejemplo el legajo 232323 de Tesorería AGOEC) siguen siendo válidas.
 */

export const ESTADOS_BLOQUEANTES = ["cerrada", "exportada"] as const;

export type EstadoLiquidacion = string | null | undefined;

export function esEstadoBloqueante(estado: EstadoLiquidacion): boolean {
  return (ESTADOS_BLOQUEANTES as readonly string[]).includes(String(estado ?? ""));
}

export type SettlementLike = { id: string; estado: EstadoLiquidacion };
export type SettlementDayLink = { settlement_id: string; daily_form_id: string };

/** Ids de formularios bloqueados por liquidaciones cerradas/exportadas. */
export function lockedFormIdsFrom(
  settlements: SettlementLike[],
  links: SettlementDayLink[],
): Set<string> {
  const bloqueadas = new Set(
    settlements.filter((s) => esEstadoBloqueante(s.estado)).map((s) => String(s.id)),
  );
  const out = new Set<string>();
  for (const l of links) {
    if (bloqueadas.has(String(l.settlement_id))) out.add(String(l.daily_form_id));
  }
  return out;
}

/** Deja sólo los días elegibles (no incluidos en liquidaciones cerradas/exportadas). */
export function filterEligibleForms<T extends { id: string }>(
  forms: T[],
  lockedFormIds: Iterable<string>,
): T[] {
  const locked = lockedFormIds instanceof Set ? lockedFormIds : new Set(lockedFormIds);
  return forms.filter((f) => !locked.has(String(f.id)));
}
