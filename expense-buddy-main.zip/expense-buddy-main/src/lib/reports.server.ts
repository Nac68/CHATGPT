// Helpers server-only para armar los informes contables (transferencias a proveedores
// y descuentos afiliado por afiliado).

const r2 = (n: number) => Math.round((Number(n) || 0) * 100) / 100;

export type Periodo = { mes: number; anio: number };

export function periodoLabel(p: Periodo) {
  return `${String(p.mes).padStart(2, "0")}/${p.anio}`;
}

export function monthRange({ mes, anio }: Periodo) {
  const from = `${anio}-${String(mes).padStart(2, "0")}-01`;
  const nextMes = mes === 12 ? 1 : mes + 1;
  const nextAnio = mes === 12 ? anio + 1 : anio;
  const to = `${nextAnio}-${String(nextMes).padStart(2, "0")}-01`;
  return { from, to };
}

export type ProviderReportRow = {
  service_id: string;
  servicio: string;
  cuenta_contable_servicio: string | null;
  provider_id: string;
  proveedor: string;
  tipo: string;
  cuenta_contable: string | null;
  cuit: string | null;
  banco: string | null;
  cbu: string | null;
  alias: string | null;
  titular: string | null;
  items: number;
  afiliados: number;
  total_importe: number;
  con_receta: number;
  sin_receta: number;
  subsidio_agoec: number;
  descuento_afiliados: number;
  a_transferir: number;
};

export type AffiliateReportRow = {
  legajo: string;
  apellido_nombre: string | null;
  items: number;
  por_servicio: Record<string, number>;
  total_descuento: number;
};

export function buildProviderReport(args: {
  services: any[];
  providers: any[];
  items: any[];
}): ProviderReportRow[] {
  const svcById = new Map(args.services.map((s) => [s.id, s]));
  return args.providers
    .map((p) => {
      const pi = args.items.filter((i) => i.provider_id === p.id);
      const svc: any = svcById.get(p.service_id) ?? {};
      const importe = r2(pi.reduce((a, i) => a + Number(i.importe ?? 0), 0));
      return {
        service_id: p.service_id,
        servicio: svc.nombre ?? "",
        cuenta_contable_servicio: svc.cuenta_contable ?? null,
        provider_id: p.id,
        proveedor: p.nombre,
        tipo: p.tipo ?? (p.interno ? "interno" : "externo"),
        cuenta_contable: p.cuenta_contable ?? null,
        cuit: p.cuit ?? null,
        banco: p.banco ?? null,
        cbu: p.cbu ?? null,
        alias: p.alias ?? null,
        titular: p.titular ?? null,
        items: pi.length,
        afiliados: new Set(pi.map((i) => i.legajo)).size,
        total_importe: importe,
        con_receta: r2(
          pi.filter((i) => i.con_receta).reduce((a, i) => a + Number(i.importe ?? 0), 0),
        ),
        sin_receta: r2(
          pi.filter((i) => !i.con_receta).reduce((a, i) => a + Number(i.importe ?? 0), 0),
        ),
        subsidio_agoec: r2(pi.reduce((a, i) => a + Number(i.subsidio ?? 0), 0)),
        descuento_afiliados: r2(pi.reduce((a, i) => a + Number(i.importe_afiliado ?? 0), 0)),
        // Al proveedor externo se le transfiere el total facturado: el subsidio lo absorbe AGOEC.
        a_transferir: importe,
      };
    })
    .filter((r) => r.items > 0)
    .sort((a, b) => a.servicio.localeCompare(b.servicio) || a.proveedor.localeCompare(b.proveedor));
}

export function buildAffiliateReport(args: {
  services: any[];
  items: any[];
  comida: { legajo: string; importe: number }[];
  nombres: Map<string, string>;
}): AffiliateReportRow[] {
  const svcById = new Map(args.services.map((s) => [s.id, s]));
  const map = new Map<string, AffiliateReportRow>();
  const get = (legajo: string) => {
    let row = map.get(legajo);
    if (!row) {
      row = {
        legajo,
        apellido_nombre: args.nombres.get(legajo) ?? null,
        items: 0,
        por_servicio: {},
        total_descuento: 0,
      };
      map.set(legajo, row);
    }
    return row;
  };

  for (const it of args.items) {
    const row = get(String(it.legajo));
    const svc: any = svcById.get(it.service_id) ?? {};
    const key = svc.nombre ?? "Otros";
    const monto = r2(Number(it.importe_afiliado ?? 0));
    row.por_servicio[key] = r2((row.por_servicio[key] ?? 0) + monto);
    row.total_descuento = r2(row.total_descuento + monto);
    row.items += 1;
  }
  for (const c of args.comida) {
    const row = get(String(c.legajo));
    const monto = r2(c.importe);
    row.por_servicio["Comida a Dto."] = r2((row.por_servicio["Comida a Dto."] ?? 0) + monto);
    row.total_descuento = r2(row.total_descuento + monto);
    row.items += 1;
  }
  return [...map.values()].filter((r) => r.items > 0);
}
