import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { normalizeLegajo } from "./auth-affiliate.functions";

async function assertAdmin(context: { supabase: any; userId: string }) {
  const { data } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  if (!data) throw new Error("Sólo administradores");
}

const ConsumptionSchema = z.object({
  legajo: z.string().min(1).max(32).transform(normalizeLegajo),
  desayuno: z.boolean(),
  almuerzo: z.boolean(),
  no_paga: z.boolean().optional(),
  observacion: z.string().max(500).nullable().optional(),
});

export const saveDailyForm = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        id: z.string().uuid().optional(),
        fecha: z.string(),
        descripcion_comida: z.string().max(500).nullable().optional(),
        observacion: z.string().max(500).nullable().optional(),
        importe: z.number().nullable().optional(),
        foto_url: z.string().nullable().optional(),
        es_cumpleanos: z.boolean().optional(),
        consumos: z.array(ConsumptionSchema),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const esCumple =
      data.es_cumpleanos ??
      /cumplea/i.test((data.descripcion_comida ?? "") + " " + (data.observacion ?? ""));

    const { data: existing } = await supabaseAdmin
      .from("daily_forms")
      .select("id, importe, es_cumpleanos, descripcion_comida")
      .eq("fecha", data.fecha)
      .maybeSingle();

    // Estado económico previo (para valor anterior en la auditoría)
    let prevConsumos = { filas: 0, importe: 0 };
    if (existing?.id) {
      const { data: pc } = await supabaseAdmin
        .from("daily_consumptions")
        .select("importe, no_paga")
        .eq("daily_form_id", existing.id);
      prevConsumos = {
        filas: (pc ?? []).length,
        importe:
          Math.round(
            (pc ?? []).reduce(
              (a: number, c: any) => a + (c.no_paga ? 0 : Number(c.importe ?? 0)),
              0,
            ) * 100,
          ) / 100,
      };
    }

    let formId = existing?.id;

    if (formId) {
      const { error } = await supabaseAdmin
        .from("daily_forms")
        .update({
          descripcion_comida: data.descripcion_comida,
          observacion: data.observacion,
          importe: data.importe,
          foto_url: data.foto_url,
          es_cumpleanos: esCumple,
        })
        .eq("id", formId);
      if (error) throw new Error(error.message);
    } else {
      const { data: created, error } = await supabaseAdmin
        .from("daily_forms")
        .insert({
          fecha: data.fecha,
          descripcion_comida: data.descripcion_comida,
          observacion: data.observacion,
          importe: data.importe,
          foto_url: data.foto_url,
          es_cumpleanos: esCumple,
          created_by: context.userId,
        })
        .select("id")
        .single();
      if (error) throw new Error(error.message);
      formId = created.id;
    }

    // Keep rows with at least one tick OR a non-empty observation
    const kept = data.consumos.filter(
      (c) => c.desayuno || c.almuerzo || (c.observacion && c.observacion.trim() !== ""),
    );

    // Divide daily amount by comensales (only rows with at least one tick count as comensales)
    const comensales = kept.filter((c) => c.desayuno || c.almuerzo).length;
    const importePorAfiliado =
      data.importe != null && comensales > 0
        ? Math.round(((data.importe as number) / comensales) * 100) / 100
        : null;

    const rows = kept.map((c) => ({
      daily_form_id: formId!,
      legajo: c.legajo,
      desayuno: c.desayuno,
      almuerzo: c.almuerzo,
      no_paga: c.no_paga ?? false,
      observacion: c.observacion ?? null,
      // Cumpleaños o "no paga" ⇒ no se le cobra al afiliado
      importe:
        esCumple || c.no_paga || !(c.desayuno || c.almuerzo) ? 0 : importePorAfiliado,
    }));

    await supabaseAdmin.from("daily_consumptions").delete().eq("daily_form_id", formId!);
    if (rows.length) {
      const { error } = await supabaseAdmin.from("daily_consumptions").insert(rows);
      if (error) throw new Error(error.message);
    }

    // ── Auditoría económica (no bloquea el guardado) ─────────────────
    const { logAudit } = await import("./audit.server");
    const totalNuevo =
      Math.round(rows.reduce((a, r) => a + Number(r.importe ?? 0), 0) * 100) / 100;
    await logAudit(supabaseAdmin, {
      entidad: "formulario_diario",
      entidad_id: formId!,
      accion: existing?.id ? "modificado" : "creado",
      userId: context.userId,
      nota: `Fecha ${data.fecha}`,
      valor_anterior: existing?.id
        ? {
            importe: existing.importe == null ? null : Number(existing.importe),
            es_cumpleanos: !!existing.es_cumpleanos,
          }
        : null,
      valor_nuevo: {
        importe: data.importe ?? null,
        es_cumpleanos: esCumple,
        comensales,
        importe_por_afiliado: importePorAfiliado,
      },
    });
    await logAudit(supabaseAdmin, {
      entidad: "consumos_diarios",
      entidad_id: formId!,
      accion: existing?.id ? "reemplazados" : "cargados",
      userId: context.userId,
      nota: `Fecha ${data.fecha} · ${rows.length} fila(s) (se preservan legajos repetidos)`,
      valor_anterior: existing?.id ? prevConsumos : null,
      valor_nuevo: { filas: rows.length, importe: totalNuevo },
    });

    return { id: formId!, ok: true, comensales, importePorAfiliado };

  });

export const listDailyForms = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ from: z.string().optional(), to: z.string().optional() }).parse(raw ?? {}),
  )
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("daily_forms")
      .select("id, fecha, descripcion_comida, importe, foto_url")
      .order("fecha", { ascending: false });
    if (data.from) q = q.gte("fecha", data.from);
    if (data.to) q = q.lte("fecha", data.to);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows;
  });

export const getDailyFormByDate = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ fecha: z.string() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { data: form } = await context.supabase
      .from("daily_forms")
      .select("*")
      .eq("fecha", data.fecha)
      .maybeSingle();
    if (!form) return { form: null, consumos: [] as any[] };
    const { data: consumos } = await context.supabase
      .from("daily_consumptions")
      .select("legajo, desayuno, almuerzo, observacion, importe, no_paga")
      .eq("daily_form_id", form.id);
    return { form, consumos: consumos ?? [] };
  });

export const uploadDailyPhoto = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ fecha: z.string(), base64: z.string() }).parse(raw),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const match = data.base64.match(/^data:(.+?);base64,(.+)$/);
    if (!match) throw new Error("Foto inválida");
    const mime = match[1];
    const buffer = Buffer.from(match[2], "base64");
    const ext = mime.split("/")[1] || "jpg";
    const path = `${data.fecha}/${Date.now()}.${ext}`;
    const { error } = await supabaseAdmin.storage
      .from("daily-photos")
      .upload(path, buffer, { contentType: mime, upsert: false });
    if (error) throw new Error(error.message);
    return { path };
  });

export const getPhotoSignedUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ path: z.string() }).parse(raw))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: signed, error } = await supabaseAdmin.storage
      .from("daily-photos")
      .createSignedUrl(data.path, 60 * 60);
    if (error) throw new Error(error.message);
    return { url: signed.signedUrl };
  });
