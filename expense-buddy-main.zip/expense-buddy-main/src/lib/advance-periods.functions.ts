import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const periodoSchema = z.object({
  periodo_mes: z.number().int().min(1).max(12),
  periodo_anio: z.number().int().min(2000).max(2100),
});

/** Períodos de adelantos + el vigente abierto + control del período abierto. */
export const listAdvancePeriods = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { data, error } = await context.supabase
      .from("advance_periods" as any)
      .select("*")
      .order("periodo_anio", { ascending: false })
      .order("periodo_mes", { ascending: false });
    if (error) throw new Error(error.message);
    const periodos = (data ?? []) as any[];
    const abierto = periodos.find((p) => p.estado !== "cerrado") ?? null;
    let control = null;
    if (abierto) {
      const { buildPeriodControl } = await import("./advance-periods.server");
      const { detalle, ...resto } = await buildPeriodControl(
        context.supabase,
        Number(abierto.periodo_mes),
        Number(abierto.periodo_anio),
      );
      control = resto;
    }
    return { periodos, abierto, control };
  });

/** Abre (o reutiliza) el período de adelantos. Una sola apertura a la vez. */
export const openAdvancePeriod = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    periodoSchema.extend({ descripcion: z.string().trim().max(120).optional() }).parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: existente } = await supabaseAdmin
      .from("advance_periods" as any)
      .select("*")
      .eq("periodo_mes", data.periodo_mes)
      .eq("periodo_anio", data.periodo_anio)
      .maybeSingle();
    if (existente && (existente as any).estado !== "cerrado")
      return { ok: true, id: (existente as any).id, reutilizado: true };
    if (existente)
      throw new Error("Ese período ya está cerrado: reabrilo desde el histórico si hace falta");

    const { data: abierto } = await supabaseAdmin
      .from("advance_periods" as any)
      .select("periodo_mes, periodo_anio")
      .neq("estado", "cerrado")
      .maybeSingle();
    if (abierto)
      throw new Error(
        `Ya hay un período abierto (${String((abierto as any).periodo_mes).padStart(2, "0")}/${
          (abierto as any).periodo_anio
        }). Cerralo antes de abrir otro.`,
      );

    const { data: nuevo, error } = await supabaseAdmin
      .from("advance_periods" as any)
      .insert({
        periodo_mes: data.periodo_mes,
        periodo_anio: data.periodo_anio,
        descripcion: data.descripcion || "ADELANTOS",
        estado: "abierto",
        created_by: context.userId,
      } as any)
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { ok: true, id: (nuevo as any).id, reutilizado: false };
  });

/** Marca el período como revisado (control previo al cierre). */
export const reviewAdvancePeriod = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("advance_periods" as any)
      .update({ estado: "revisado" } as any)
      .eq("id", data.id)
      .neq("estado", "cerrado");
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Cierra el período guardando un snapshot inmutable y abre el siguiente. */
export const closeAdvancePeriod = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ id: z.string().uuid(), abrir_siguiente: z.boolean().default(true) }).parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { buildPeriodControl } = await import("./advance-periods.server");

    const { data: p } = await supabaseAdmin
      .from("advance_periods" as any)
      .select("*")
      .eq("id", data.id)
      .maybeSingle();
    if (!p) throw new Error("El período no existe");
    if ((p as any).estado === "cerrado") throw new Error("El período ya está cerrado");

    const mes = Number((p as any).periodo_mes);
    const anio = Number((p as any).periodo_anio);
    const control = await buildPeriodControl(supabaseAdmin, mes, anio);
    if (control.errores.length)
      throw new Error(
        `No se puede cerrar: ${control.errores.length} error(es). ${control.errores[0].detalle}`,
      );

    const { error } = await supabaseAdmin
      .from("advance_periods" as any)
      .update({
        estado: "cerrado",
        snapshot: {
          generado_at: new Date().toISOString(),
          periodo: { mes, anio },
          totales: {
            total_solicitado: control.total_solicitado,
            cuotas_adelantos: control.cuotas_adelantos,
            cuotas_refinanciacion: control.cuotas_refinanciacion,
            refinanciado_en_periodo: control.refinanciado_en_periodo,
            total_general: control.total_general,
          },
          adelantos: control.detalle.map((a: any) => ({
            id: a.id,
            legajo: a.legajo,
            apellido_nombre: a.apellido_nombre,
            fecha: a.fecha,
            monto_pedido: a.monto_pedido,
            cuotas: a.cuotas,
            importe_cuota: a.importe_cuota,
            cuota_periodo: a.importe_cuota_periodo,
            concepto: a.concepto,
            cuil: a.cuil,
            banco: a.banco,
            cuenta: a.cuenta,
            cbu: a.cbu,
            cbu2: a.cbu2,
            responsable: a.responsable,
            ref_id: a.ref_id,
          })),
        },
        total_solicitado: control.total_solicitado,
        total_cuotas_adelantos: control.cuotas_adelantos,
        total_cuotas_refinanciacion: control.cuotas_refinanciacion,
        total_general: control.total_general,
        total_adelantos: control.adelantos,
        total_legajos: control.legajos,
        cerrado_at: new Date().toISOString(),
        cerrado_por: context.userId,
      } as any)
      .eq("id", data.id);
    if (error) throw new Error(error.message);

    let siguiente: string | null = null;
    if (data.abrir_siguiente) {
      const idx = anio * 12 + (mes - 1) + 1;
      const sm = (idx % 12) + 1;
      const sa = Math.floor(idx / 12);
      const { data: ya } = await supabaseAdmin
        .from("advance_periods" as any)
        .select("id")
        .eq("periodo_mes", sm)
        .eq("periodo_anio", sa)
        .maybeSingle();
      if (ya) siguiente = (ya as any).id;
      else {
        const { data: nuevo } = await supabaseAdmin
          .from("advance_periods" as any)
          .insert({
            periodo_mes: sm,
            periodo_anio: sa,
            descripcion: (p as any).descripcion ?? "ADELANTOS",
            estado: "abierto",
            created_by: context.userId,
          } as any)
          .select("id")
          .single();
        siguiente = (nuevo as any)?.id ?? null;
      }
    }
    return { ok: true, siguiente, control };
  });

/** Reapertura auditada (solo admin): el snapshot queda como quedó. */
export const reopenAdvancePeriod = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: abierto } = await supabaseAdmin
      .from("advance_periods" as any)
      .select("id")
      .neq("estado", "cerrado")
      .maybeSingle();
    if (abierto && (abierto as any).id !== data.id)
      throw new Error("Cerrá el período abierto antes de reabrir otro");

    const { data: p } = await supabaseAdmin
      .from("advance_periods" as any)
      .select("reaperturas")
      .eq("id", data.id)
      .maybeSingle();

    const { error } = await supabaseAdmin
      .from("advance_periods" as any)
      .update({
        estado: "revisado",
        reabierto_at: new Date().toISOString(),
        reabierto_por: context.userId,
        reaperturas: Number((p as any)?.reaperturas ?? 0) + 1,
      } as any)
      .eq("id", data.id);
    if (error) throw new Error(error.message);

    await supabaseAdmin.from("audit_events").insert({
      entidad: "advance_period",
      entidad_id: data.id,
      accion: "reapertura",
      user_id: context.userId,
      nota: "Reapertura del período de adelantos",
    } as any);
    return { ok: true };
  });
