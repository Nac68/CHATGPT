// Helpers server-only para Círculos: períodos y liquidación mensual.

export const r2 = (n: number) => Math.round((Number(n) || 0) * 100) / 100;

/** AAAAMM -> índice absoluto de mes. */
export const periodToIndex = (p: number) => {
  const anio = Math.floor(Number(p) / 100);
  const mes = Number(p) % 100;
  return anio * 12 + (mes - 1);
};

export const monthIndex = (mes: number, anio: number) => anio * 12 + (mes - 1);

/** ¿El círculo está vigente en mes/anio según sus períodos? */
export function circleActivo(
  periodo_inicio: number | null,
  periodo_fin: number | null,
  mes: number,
  anio: number,
) {
  const idx = monthIndex(mes, anio);
  if (periodo_inicio && idx < periodToIndex(periodo_inicio)) return false;
  if (periodo_fin && idx > periodToIndex(periodo_fin)) return false;
  return true;
}

export type CircleRecord = {
  id: string;
  numero: string | null;
  nombre: string;
  importe: number;
  periodo_inicio: number | null;
  periodo_fin: number | null;
  members: any[];
};

export type CircleSettlementRow = {
  legajo: string;
  apellido_nombre: string | null;
  circulos: { numero: string | null; nombre: string; importe: number }[];
  importe: number;
};

export function buildCircleSettlement(circles: CircleRecord[], mes: number, anio: number) {
  const map = new Map<string, CircleSettlementRow>();
  const cobradores: {
    legajo: string;
    apellido_nombre: string | null;
    importe: number;
    circulo: string;
    numero: string | null;
    circle_id: string;
  }[] = [];
  let activos = 0;

  for (const c of circles) {
    if (!circleActivo(c.periodo_inicio, c.periodo_fin, mes, anio)) continue;
    activos += 1;

    const totalMensual = r2(
      (c.members ?? []).reduce((a: number, m: any) => a + (Number(m.importe_mensual) || 0), 0),
    );

    for (const m of c.members ?? []) {
      const importe = r2(Number(m.importe_mensual) || 0);
      const legajo = String(m.legajo);
      if (importe) {
        let row = map.get(legajo);
        if (!row) {
          row = { legajo, apellido_nombre: m.apellido_nombre ?? null, circulos: [], importe: 0 };
          map.set(legajo, row);
        }
        row.circulos.push({ numero: c.numero ?? null, nombre: c.nombre, importe });
        row.importe = r2(row.importe + importe);
      }

      // ¿Le corresponde cobrar el pozo este mes?
      const f = m.fecha_cobro ? new Date(String(m.fecha_cobro)) : null;
      const mesCobro = f ? f.getUTCMonth() + 1 : Number(m.mes_cobro) || null;
      const anioCobro = f ? f.getUTCFullYear() : Number(m.anio_cobro) || null;
      if (mesCobro === mes && (!anioCobro || anioCobro === anio)) {
        const ya = cobradores.find((x) => x.legajo === legajo && x.circulo === c.nombre);
        if (!ya) {
          cobradores.push({
            legajo,
            apellido_nombre: m.apellido_nombre ?? null,
            importe: totalMensual,
            circulo: c.nombre,
            numero: c.numero ?? null,
            circle_id: c.id,
          });
        }
      }
    }
  }

  const rows = [...map.values()];
  return {
    rows,
    cobradores,
    total: r2(rows.reduce((a, r) => a + r.importe, 0)),
    total_a_pagar: r2(cobradores.reduce((a, r) => a + r.importe, 0)),
    aportantes: rows.length,
    circulos: activos,
  };
}
