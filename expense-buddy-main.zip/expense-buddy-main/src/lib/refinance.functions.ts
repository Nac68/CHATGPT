import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const itemSchema = z.object({
  source_key: z.string().trim().min(3).max(200),
  servicio: z.string().trim().max(200).nullable().optional(),
  detalle: z.string().trim().max(400).nullable().optional(),
  periodo: z.string().trim().max(20).nullable().optional(),
  importe: z.number().nonnegative(),
});

/** Vista previa de la consolidación: saldo anterior + nuevos importes. */
export const previewRefinance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        legajo: z.string().trim().min(1).max(32),
        nuevos: z.number().nonnegative().default(0),
        cuotas: z.number().int().min(1).max(60),
        periodo_mes: z.number().int().min(1).max(12),
        periodo_anio: z.number().int().min(2000).max(2100),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { activeRefinance } = await import("./refinance.server");
    const { consolidationPreview } = await import("./refinance-plan");
    const legajo = data.legajo.trim().toUpperCase();
    const { activa, conflicto } = await activeRefinance(context.supabase, legajo);
    if (conflicto.length)
      return {
        conflicto: conflicto.map((r: any) => ({ id: r.id, total: r.total, saldo: r.saldo })),
        anterior: null,
        preview: null,
      };
    return {
      conflicto: [],
      anterior: activa
        ? {
            id: activa.id,
            total: activa.total,
            cuotas: activa.cuotas,
            cuotas_cobradas: activa.cuotas_cobradas,
            saldo: activa.saldo,
            periodo_label: activa.periodo_label,
          }
        : null,
      preview: consolidationPreview({
        anterior: activa,
        nuevos: data.nuevos,
        cuotas: data.cuotas,
        mes: data.periodo_mes,
        anio: data.periodo_anio,
      }),
    };
  });

/**
 * Crea la refinanciación: bloquea el cobro original y deja las cuotas nuevas.
 * Si el legajo ya tiene una refinanciación activa, consolida: capital nuevo =
 * saldo pendiente real de la anterior + nuevos importes. La anterior conserva
 * para siempre sus cuotas ya devengadas y deja de cobrar las futuras.
 */
export const createRefinance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        legajo: z.string().trim().min(1).max(32),
        cuotas: z.number().int().min(1).max(60),
        periodo_mes: z.number().int().min(1).max(12),
        periodo_anio: z.number().int().min(2000).max(2100),
        observacion: z.string().trim().max(300).nullable().optional(),
        items: z.array(itemSchema).min(1).max(2000),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const legajo = data.legajo.trim().toUpperCase();
    const nuevos = Math.round(data.items.reduce((a, i) => a + Number(i.importe || 0), 0) * 100) / 100;
    if (nuevos <= 0) throw new Error("El total a refinanciar debe ser mayor a cero");

    const keys = [...new Set(data.items.map((i) => i.source_key))];
    const { data: yaRef } = await supabaseAdmin
      .from("refinanciacion_items" as any)
      .select("source_key")
      .in("source_key", keys);
    if ((yaRef ?? []).length)
      throw new Error(
        `Hay consumos ya refinanciados: ${(yaRef ?? [])
          .slice(0, 5)
          .map((r: any) => r.source_key)
          .join(", ")}`,
      );

    // No se puede refinanciar un consumo de un período ya liquidado (cerrado).
    const { data: cerradosRaw } = await supabaseAdmin
      .from("payroll_periods")
      .select("hasta")
      .eq("estado", "cerrado");
    const { periodMonth } = await import("./payroll.server");
    const cerrados = new Set(
      (cerradosRaw ?? []).map((p: any) => {
        const { mes, anio } = periodMonth(p.hasta);
        return `${anio}-${String(mes).padStart(2, "0")}`;
      }),
    );
    const enCerrado = data.items.filter((i) => i.periodo && cerrados.has(String(i.periodo)));
    if (enCerrado.length)
      throw new Error(
        `Hay consumos de períodos ya liquidados: ${[...new Set(enCerrado.map((i) => i.periodo))]
          .slice(0, 5)
          .join(", ")}. Solo se pueden refinanciar períodos abiertos.`,
      );

    const { data: aff } = await supabaseAdmin
      .from("affiliates")
      .select("apellido_nombre")
      .eq("legajo", legajo)
      .maybeSingle();

    const { activeRefinance } = await import("./refinance.server");
    const { consolidationPreview } = await import("./refinance-plan");
    const { activa, conflicto } = await activeRefinance(supabaseAdmin, legajo);
    if (conflicto.length)
      throw new Error(
        `El legajo ${legajo} tiene ${conflicto.length} refinanciaciones activas (datos históricos). ` +
          "No se consolida automáticamente para no perder información: anulá o unificá esos planes primero.",
      );

    const preview = consolidationPreview({
      anterior: activa,
      nuevos,
      cuotas: data.cuotas,
      mes: data.periodo_mes,
      anio: data.periodo_anio,
    });

    const { data: ref, error } = await supabaseAdmin
      .from("refinanciaciones" as any)
      .insert({
        legajo,
        apellido_nombre: aff?.apellido_nombre ?? null,
        total: preview.capital,
        cuotas: data.cuotas,
        periodo_mes: data.periodo_mes,
        periodo_anio: data.periodo_anio,
        observacion: data.observacion || null,
        estado: "activa",
        saldo_incorporado: preview.saldo_anterior,
        reemplaza_a: activa?.id ?? null,
        created_by: context.userId,
      } as any)
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    const refId = (ref as any).id as string;

    const rows = data.items.map((i) => ({
      refinanciacion_id: refId,
      source_key: i.source_key,
      servicio: i.servicio || null,
      detalle: i.detalle || null,
      periodo: i.periodo || null,
      importe: Number(i.importe || 0),
    }));
    for (let i = 0; i < rows.length; i += 500) {
      const { error: e } = await supabaseAdmin
        .from("refinanciacion_items" as any)
        .insert(rows.slice(i, i + 500) as any);
      if (e) throw new Error(e.message);
    }

    // La anterior queda consolidada: conserva las cuotas devengadas y no cobra
    // las futuras (evita el doble descuento).
    if (activa) {
      await supabaseAdmin
        .from("refinanciaciones" as any)
        .update({
          estado: "consolidada",
          cuotas_efectivas: preview.cuotas_conservadas,
          cuotas_cobradas: preview.cuotas_conservadas,
          reemplazada_por: refId,
          consolidada_at: new Date().toISOString(),
          consolidada_por: context.userId,
        } as any)
        .eq("id", activa.id);
    }

    // Los consumos originales dejan de descontarse: la liquidación saltea
    // cualquier source_key que esté en refinanciacion_items.
    return {
      ok: true,
      id: refId,
      total: preview.capital,
      cuotas: data.cuotas,
      consolidada_de: activa?.id ?? null,
      saldo_incorporado: preview.saldo_anterior,
      importe_cuota: preview.importe_cuota,
    };
  });

/**
 * Reprograma una refinanciación activa cambiando la cantidad de cuotas: sólo
 * sobre el saldo futuro. Las cuotas de períodos ya pasados no se reescriben.
 */
export const rescheduleRefinance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        cuotas: z.number().int().min(1).max(60),
        periodo_mes: z.number().int().min(1).max(12),
        periodo_anio: z.number().int().min(2000).max(2100),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { withPlan } = await import("./refinance.server");
    const { consolidationPreview } = await import("./refinance-plan");

    const { data: prevRaw, error: e0 } = await supabaseAdmin
      .from("refinanciaciones" as any)
      .select("*")
      .eq("id", data.id)
      .maybeSingle();
    if (e0) throw new Error(e0.message);
    if (!prevRaw) throw new Error("La refinanciación no existe");
    const [prev] = withPlan([prevRaw]);
    if (prev.estado !== "activa") throw new Error("Sólo se reprograma un plan activo");

    const preview = consolidationPreview({
      anterior: prev,
      nuevos: 0,
      cuotas: data.cuotas,
      mes: data.periodo_mes,
      anio: data.periodo_anio,
    });
    if (preview.capital <= 0) throw new Error("El plan no tiene saldo futuro para reprogramar");

    const { data: nuevo, error } = await supabaseAdmin
      .from("refinanciaciones" as any)
      .insert({
        legajo: prev.legajo,
        apellido_nombre: prev.apellido_nombre ?? null,
        total: preview.capital,
        cuotas: data.cuotas,
        periodo_mes: data.periodo_mes,
        periodo_anio: data.periodo_anio,
        observacion: `Reprogramación de plan ${String(prev.id).slice(0, 8)}`,
        estado: "activa",
        origen: prev.origen ?? "consumo",
        saldo_incorporado: preview.saldo_anterior,
        reemplaza_a: prev.id,
        created_by: context.userId,
      } as any)
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    const refId = (nuevo as any).id as string;

    await supabaseAdmin
      .from("refinanciaciones" as any)
      .update({
        estado: "consolidada",
        cuotas_efectivas: preview.cuotas_conservadas,
        cuotas_cobradas: preview.cuotas_conservadas,
        reemplazada_por: refId,
        consolidada_at: new Date().toISOString(),
        consolidada_por: context.userId,
      } as any)
      .eq("id", prev.id);

    return { ok: true, id: refId, capital: preview.capital, importe_cuota: preview.importe_cuota };
  });



/** Listado de refinanciaciones con plan de cuotas, saldo y consumos incluidos. */
export const listRefinances = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);

    const { data: refs, error } = await context.supabase
      .from("refinanciaciones" as any)
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);

    const ids = (refs ?? []).map((r: any) => r.id);
    let items: any[] = [];
    if (ids.length) {
      const { data: its, error: e2 } = await context.supabase
        .from("refinanciacion_items" as any)
        .select("*")
        .in("refinanciacion_id", ids);
      if (e2) throw new Error(e2.message);
      items = its ?? [];
    }

    const { withPlan } = await import("./refinance.server");
    const refinanciaciones = withPlan(
      (refs ?? []).map((r: any) => ({
        ...r,
        items: items.filter((i) => i.refinanciacion_id === r.id),
      })),
    );

    return {
      refinanciaciones,
      resumen: {
        legajos: new Set(refinanciaciones.map((r: any) => r.legajo)).size,
        activas: refinanciaciones.filter((r: any) => !r.finalizada).length,
        total: Math.round(refinanciaciones.reduce((a: number, r: any) => a + Number(r.total), 0) * 100) / 100,
        saldo: Math.round(refinanciaciones.reduce((a: number, r: any) => a + Number(r.saldo), 0) * 100) / 100,
        cuota_periodo:
          Math.round(
            refinanciaciones
              .filter((r: any) => r.cuota_actual)
              .reduce((a: number, r: any) => a + Number(r.importe_cuota), 0) * 100,
          ) / 100,
      },
    };
  });

/** Historial de refinanciaciones de un legajo, con plan, saldo y consumos. */
export const refinanceHistoryByLegajo = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ legajo: z.string().trim().min(1).max(32) }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const legajo = data.legajo.trim().toUpperCase();

    const { data: refs, error } = await context.supabase
      .from("refinanciaciones" as any)
      .select("*")
      .eq("legajo", legajo)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);

    const ids = (refs ?? []).map((r: any) => r.id);
    let items: any[] = [];
    if (ids.length) {
      const { data: its, error: e2 } = await context.supabase
        .from("refinanciacion_items" as any)
        .select("*")
        .in("refinanciacion_id", ids);
      if (e2) throw new Error(e2.message);
      items = its ?? [];
    }

    const { withPlan } = await import("./refinance.server");
    const planes = withPlan(
      (refs ?? []).map((r: any) => ({ ...r, items: items.filter((i) => i.refinanciacion_id === r.id) })),
    );
    return {
      legajo,
      planes,
      resumen: {
        planes: planes.length,
        en_curso: planes.filter((p: any) => !p.finalizada).length,
        total: Math.round(planes.reduce((a: number, p: any) => a + Number(p.total), 0) * 100) / 100,
        saldo: Math.round(planes.reduce((a: number, p: any) => a + Number(p.saldo), 0) * 100) / 100,
      },
    };
  });

/** Historial agregado por servicio de origen de los consumos refinanciados. */
export const refinanceByService = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);

    const { data: refs, error } = await context.supabase
      .from("refinanciaciones" as any)
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    const ids = (refs ?? []).map((r: any) => r.id);
    let items: any[] = [];
    if (ids.length) {
      const { data: its, error: e2 } = await context.supabase
        .from("refinanciacion_items" as any)
        .select("*")
        .in("refinanciacion_id", ids);
      if (e2) throw new Error(e2.message);
      items = its ?? [];
    }

    const { withPlan } = await import("./refinance.server");
    const planes = withPlan(refs ?? []);
    const byId = new Map(planes.map((p: any) => [p.id, p]));

    const map = new Map<string, any>();
    const detalle: any[] = [];
    for (const it of items) {
      const p: any = byId.get(it.refinanciacion_id);
      if (!p) continue;
      const servicio = (it.servicio || "Sin servicio").toString();
      const prop = Number(p.total) > 0 ? Number(it.importe) / Number(p.total) : 0;
      const saldoItem = Math.round(Number(p.saldo) * prop * 100) / 100;
      const g =
        map.get(servicio) ??
        { servicio, planes: new Set<string>(), legajos: new Set<string>(), consumos: 0, total: 0, saldo: 0 };
      g.planes.add(p.id);
      g.legajos.add(p.legajo);
      g.consumos += 1;
      g.total += Number(it.importe) || 0;
      g.saldo += saldoItem;
      map.set(servicio, g);

      detalle.push({
        id: it.id,
        servicio,
        origen: p.origen ?? "consumo",
        detalle: it.detalle,
        periodo_original: it.periodo,

        importe: Number(it.importe) || 0,
        saldo: saldoItem,
        legajo: p.legajo,
        apellido_nombre: p.apellido_nombre,
        refinanciacion_id: p.id,
        cuotas: p.cuotas,
        importe_cuota: p.importe_cuota,
        periodo_label: p.periodo_label,
        periodo_fin_label: p.periodo_fin_label,
        periodo_mes: p.periodo_mes,
        periodo_anio: p.periodo_anio,
        fecha: p.created_at,
        finalizada: p.finalizada,
      });
    }

    const servicios = Array.from(map.values())
      .map((g) => ({
        servicio: g.servicio,
        planes: g.planes.size,
        legajos: g.legajos.size,
        consumos: g.consumos,
        total: Math.round(g.total * 100) / 100,
        saldo: Math.round(g.saldo * 100) / 100,
      }))
      .sort((a, b) => b.total - a.total);

    return { servicios, detalle };
  });

/** Planes de refinanciación del afiliado logueado (solo lectura). */
export const myRefinances = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: refs, error } = await context.supabase
      .from("refinanciaciones" as any)
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    const ids = (refs ?? []).map((r: any) => r.id);
    let items: any[] = [];
    if (ids.length) {
      const { data: its } = await context.supabase
        .from("refinanciacion_items" as any)
        .select("*")
        .in("refinanciacion_id", ids);
      items = its ?? [];
    }
    const { withPlan } = await import("./refinance.server");
    return {
      planes: withPlan(
        (refs ?? []).map((r: any) => ({ ...r, items: items.filter((i) => i.refinanciacion_id === r.id) })),
      ),
    };
  });

/** Anula una refinanciación: los consumos originales vuelven a su cobro normal. */

export const cancelRefinance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Las cuotas ya liquidadas quedan registradas en payroll_consumed y no se tocan.
    const { error } = await supabaseAdmin
      .from("refinanciaciones" as any)
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

