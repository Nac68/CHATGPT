import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const rangoSchema = z.object({
  desde: z.string().min(10).max(10),
  hasta: z.string().min(10).max(10),
});

/** Vista previa de la liquidación del período (excluye lo ya liquidado antes). */
export const previewPayroll = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => rangoSchema.parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { buildPayroll } = await import("./payroll.server");
    const res = await buildPayroll(data);
    return {
      ...res,
      rows: res.rows.map(({ keys: _k, keys_por_concepto: _kc, ...r }) => r),
    };
  });

/**
 * Cierra el período. Si se pasan `conceptos`, cierra sólo esos servicios
 * (cierre parcial); el resto queda pendiente dentro del mismo período.
 */
export const closePayroll = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    rangoSchema
      .extend({
        nombre: z.string().trim().min(2).max(200),
        conceptos: z.array(z.string()).optional(),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { buildPayroll } = await import("./payroll.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const res = await buildPayroll({ desde: data.desde, hasta: data.hasta });
    const sel = data.conceptos?.length ? new Set(data.conceptos) : null;

    const conceptoById = new Map(res.conceptos.map((c) => [c.key, c]));

    // Filas/ítems limitados a los conceptos elegidos.
    const items = res.rows.flatMap((r) =>
      Object.entries(r.por_concepto)
        .filter(([k, v]) => Number(v) !== 0 && (!sel || sel.has(k)))
        .map(([k, v]) => ({
          legajo: r.legajo,
          apellido_nombre: r.apellido_nombre,
          concepto_key: k,
          servicio: conceptoById.get(k)?.nombre ?? k,
          cuenta_contable: conceptoById.get(k)?.cuenta_contable ?? null,
          importe: Number(v),
        })),
    );
    if (!items.length) throw new Error("No hay importes para liquidar en esta selección");

    const total = Math.round(items.reduce((a, i) => a + i.importe, 0) * 100) / 100;
    const afiliados = new Set(items.map((i) => i.legajo)).size;
    const conceptoKeys = [...new Set(items.map((i) => i.concepto_key))];

    const { data: period, error } = await supabaseAdmin
      .from("payroll_periods")
      .insert({
        nombre: data.nombre,
        desde: data.desde,
        hasta: data.hasta,
        estado: "cerrado",
        total_descuento: total,
        total_afiliados: afiliados,
        cerrado_at: new Date().toISOString(),
        created_by: context.userId,
        concepto_key: sel ? conceptoKeys.join(",") : null,
        concepto_nombre: sel
          ? conceptoKeys.map((k) => conceptoById.get(k)?.nombre ?? k).join(", ")
          : null,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);

    const dbItems = items.map(({ concepto_key: _ck, ...i }) => ({
      ...i,
      period_id: period.id,
    }));
    for (let i = 0; i < dbItems.length; i += 500) {
      const { error: e } = await supabaseAdmin
        .from("payroll_period_items")
        .insert(dbItems.slice(i, i + 500));
      if (e) throw new Error(e.message);
    }

    const keys = [
      ...new Set(
        res.rows.flatMap((r) =>
          Object.entries(r.keys_por_concepto)
            .filter(([k]) => !sel || sel.has(k))
            .flatMap(([, ks]) => ks),
        ),
      ),
    ].map((source_key) => ({ period_id: period.id, source_key }));
    for (let i = 0; i < keys.length; i += 500) {
      const { error: e } = await supabaseAdmin
        .from("payroll_consumed")
        .upsert(keys.slice(i, i + 500), { onConflict: "source_key", ignoreDuplicates: true });
      if (e) throw new Error(e.message);
    }

    return { id: period.id, total, afiliados, items: dbItems.length };
  });

/** Historial de períodos liquidados (incluye cierres parciales por servicio). */
export const listPayrollPeriods = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { data, error } = await context.supabase
      .from("payroll_periods")
      .select("*")
      .order("hasta", { ascending: false });
    if (error) throw new Error(error.message);
    return { periodos: data ?? [] };
  });

/** Datos de padrón (nombre oficial y CUIL) para armar el archivo de CEAMSE. */
export const payrollPadron = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ legajos: z.array(z.string()).max(5000) }).parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const out: Record<string, { apellido_nombre: string | null; cuil: string | null }> = {};
    const legajos = [...new Set(data.legajos.map((l) => String(l)))];
    for (let i = 0; i < legajos.length; i += 500) {
      const { data: affs, error } = await context.supabase
        .from("affiliates")
        .select("legajo, apellido_nombre, cuil")
        .in("legajo", legajos.slice(i, i + 500));
      if (error) throw new Error(error.message);
      for (const a of affs ?? [])
        out[String(a.legajo)] = { apellido_nombre: a.apellido_nombre, cuil: a.cuil };
    }
    return { padron: out };
  });




/** Reabre un período: borra su detalle y libera los consumos para volver a liquidarlos. */
export const reopenPayroll = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("payroll_periods").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Detalle guardado de un período liquidado. */
export const getPayrollPeriod = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const [{ data: period }, { data: items }] = await Promise.all([
      context.supabase.from("payroll_periods").select("*").eq("id", data.id).maybeSingle(),
      context.supabase.from("payroll_period_items").select("*").eq("period_id", data.id),
    ]);
    if (!period) throw new Error("Período no encontrado");
    const { buildSavedPayroll } = await import("./payroll-saved");
    return { period, ...buildSavedPayroll(items ?? []) };
  });

/** Liquidación de pagos: legajos que cobran círculo o cumpleaños en el período. */
export const circleBirthdayPayout = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => rangoSchema.parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { buildCircleBirthdayPayout } = await import("./payroll.server");
    return buildCircleBirthdayPayout(data);
  });

/** Período mensual abierto, compartido por todos los servicios. */
export const getPeriodoVigente = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    const { periodoVigente } = await import("./periodo-vigente.server");
    return await periodoVigente();
  });
