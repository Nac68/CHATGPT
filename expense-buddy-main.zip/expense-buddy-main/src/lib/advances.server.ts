// Helpers server-only para Adelantos: plan de cuotas por período (mes/año).

import { cuotaPlan, periodFromIndex, periodIndex, periodLabel, r2 } from "./refinance-plan";

export { r2 };

/** Cuota que corresponde a un período, o null si el adelanto no se descuenta ese mes. */
export function cuotaDelPeriodo(
  a: { periodo_mes: number; periodo_anio: number; cuotas: number },
  mes: number,
  anio: number,
) {
  const cuotas = Math.max(1, Number(a.cuotas) || 1);
  const idx =
    periodIndex(mes, anio) - periodIndex(Number(a.periodo_mes), Number(a.periodo_anio));
  return idx >= 0 && idx < cuotas ? idx + 1 : null;
}

/** Agrega a cada adelanto el importe de cuota, el plan y lo que queda por descontar. */
export function withPlan(rows: any[], hoy = new Date()) {
  const mesActual = hoy.getUTCMonth() + 1;
  const anioActual = hoy.getUTCFullYear();
  return rows.map((a) => {
    const cuotas = Math.max(1, Number(a.cuotas) || 1);
    const importes = cuotaPlan(Number(a.monto_pedido ?? 0), cuotas);
    const base = periodIndex(Number(a.periodo_mes), Number(a.periodo_anio));
    const plan = importes.map((importe, i) => {
      const p = periodFromIndex(base + i);
      return { cuota: `${i + 1}/${cuotas}`, periodo: periodLabel(p.mes, p.anio), importe };
    });
    const cuotaActual = cuotaDelPeriodo(a, mesActual, anioActual);
    const pagadas = Math.min(
      cuotas,
      Math.max(0, periodIndex(mesActual, anioActual) - base),
    );
    return {
      ...a,
      importe_cuota: importes[0],
      importe_ultima_cuota: importes[cuotas - 1],
      plan,
      cuota_actual: cuotaActual,
      importe_cuota_periodo: cuotaActual ? importes[cuotaActual - 1] : 0,
      cuotas_restantes: Math.max(0, cuotas - pagadas),
      saldo: r2(importes.slice(pagadas).reduce((s, v) => s + v, 0)),
      periodo_label: periodLabel(Number(a.periodo_mes), Number(a.periodo_anio)),
    };
  });
}


/**
 * Un adelanto en más de una cuota es, en la práctica, un préstamo: se refleja
 * como plan de refinanciación para verlo junto al resto de los servicios.
 */
export async function syncAdvanceRefinances(supabaseAdmin: any, adelantos: any[]) {
  const enCuotas = adelantos.filter((a) => Math.max(1, Number(a.cuotas) || 1) > 1);
  if (!enCuotas.length) return { planes: 0 };

  const keys = enCuotas.map((a) => `adelanto:${a.id}:`);
  const { data: existentes } = await supabaseAdmin
    .from("refinanciacion_items")
    .select("source_key")
    .or(keys.map((k) => `source_key.like.${k}%`).join(","));
  const yaHay = new Set(
    ((existentes ?? []) as any[]).map((r) => String(r.source_key).split(":").slice(0, 2).join(":")),
  );

  let planes = 0;
  for (const a of enCuotas) {
    if (yaHay.has(`adelanto:${a.id}`)) continue;
    const cuotas = Math.max(1, Number(a.cuotas) || 1);
    const total = r2(Number(a.monto_pedido ?? 0));
    if (total <= 0) continue;
    const concepto = a.concepto || "ADELANTO";

    const { data: ref, error } = await supabaseAdmin
      .from("refinanciaciones")
      .insert({
        legajo: a.legajo,
        apellido_nombre: a.apellido_nombre ?? null,
        total,
        cuotas,
        periodo_mes: Number(a.periodo_mes),
        periodo_anio: Number(a.periodo_anio),
        observacion: `${concepto} · adelanto en cuotas`,
        estado: "activa",
        origen: "adelanto",
      })
      .select("id")
      .single();
    if (error) continue;

    const base = Number(a.periodo_anio) * 12 + (Number(a.periodo_mes) - 1);
    const items = Array.from({ length: cuotas }, (_, i) => {
      const idx = base + i;
      const mes = (idx % 12) + 1;
      const anio = Math.floor(idx / 12);
      return {
        refinanciacion_id: (ref as any).id,
        source_key: `adelanto:${a.id}:${anio}${String(mes).padStart(2, "0")}`,
        servicio: "Adelantos",
        detalle: `${concepto} (cuota ${i + 1}/${cuotas})`,
        periodo: `${anio}-${String(mes).padStart(2, "0")}`,
        importe: r2(total / cuotas),
      };
    });
    await supabaseAdmin.from("refinanciacion_items").insert(items);
    planes += 1;
  }
  return { planes };
}
