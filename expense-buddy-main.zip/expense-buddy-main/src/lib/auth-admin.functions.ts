import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

// Called after a successful email/password sign-up. If no admin exists yet in
// the system, the caller becomes admin. Otherwise noop.
export const claimAdminIfFirst = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { count, error: countErr } = await supabaseAdmin
      .from("user_roles")
      .select("id", { count: "exact", head: true })
      .eq("role", "admin");
    if (countErr) throw new Error(countErr.message);

    if ((count ?? 0) === 0) {
      const { error } = await supabaseAdmin
        .from("user_roles")
        .insert({ user_id: context.userId, role: "admin" });
      if (error && !error.message.includes("duplicate")) throw new Error(error.message);
      return { promoted: true };
    }
    return { promoted: false };
  });

export const grantAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ email: z.string().email() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Sólo administradores");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: users, error } = await supabaseAdmin.auth.admin.listUsers();
    if (error) throw new Error(error.message);
    const user = users.users.find((u) => u.email === data.email);
    if (!user) throw new Error("Usuario no encontrado");
    const { error: insErr } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: user.id, role: "admin" });
    if (insErr && !insErr.message.includes("duplicate")) throw new Error(insErr.message);
    return { ok: true };
  });

// Returns the current user's role info (admin/afiliado + legajo).
export const getMyRole = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("user_roles")
      .select("role, legajo")
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    const isAdmin = data.some((r) => r.role === "admin");
    const afiliado = data.find((r) => r.role === "afiliado");
    return {
      isAdmin,
      isAfiliado: !!afiliado,
      legajo: afiliado?.legajo ?? null,
    };
  });
