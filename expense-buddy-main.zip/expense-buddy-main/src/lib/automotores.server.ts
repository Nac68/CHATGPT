// Helpers server-only del servicio AUTOMOTORES.
// Modelo: proveedor -> prestación (Tipo_Compra) -> consumo del afiliado -> cuotas -> liquidación
// del período -> comisión AGOEC -> neto a pagar al proveedor.
// La comisión se configura por PROVEEDOR + PRESTACIÓN y se congela en cada ítem al cargarlo.

export const AUTOMOTORES_CODIGO = "1130202";

export const r2 = (n: number) => Math.round((Number(n) || 0) * 100) / 100;

export const normNombre = (s: unknown) =>
  String(s ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();

export type AutoRawItem = {
  fecha: string | null;
  legajo: string;
  apellido_nombre?: string | null;
  ticket?: string | null;
  prestacion: string;
  importe: number;
  observacion?: string | null;
  cuotas: number;
  cuotas_importes?: number[] | null;
};

export type AutoComputedItem = AutoRawItem & {
  cuotas_importes: number[];
  comision_pct: number;
  comision_monto: number;
  neto_proveedor: number;
};

/** Reparte el importe en N cuotas cuando el Excel no informa los importes explícitos. */
export function distribuirCuotas(importe: number, cuotas: number): number[] {
  const n = Math.max(1, Math.floor(cuotas) || 1);
  const base = Math.floor((r2(importe) * 100) / n) / 100;
  const arr = Array.from({ length: n }, () => base);
  arr[n - 1] = r2(r2(importe) - base * (n - 1));
  return arr;
}

export async function getAutomotoresService(context: { supabase: any }) {
  const { data, error } = await context.supabase
    .from("services")
    .select("*")
    .eq("codigo", AUTOMOTORES_CODIGO)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("El servicio Automotores no está configurado");
  return data;
}

/** Comisión vigente por prestación de un proveedor, indexada por nombre normalizado. */
export async function comisionMap(context: { supabase: any }, provider_id: string) {
  const { data, error } = await context.supabase
    .from("provider_prestaciones")
    .select("*")
    .eq("provider_id", provider_id);
  if (error) throw new Error(error.message);
  const map = new Map<string, { nombre: string; comision_pct: number; activo: boolean }>();
  for (const p of data ?? [])
    map.set(normNombre(p.nombre), {
      nombre: p.nombre,
      comision_pct: Number(p.comision_pct) || 0,
      activo: !!p.activo,
    });
  return map;
}

export function computeAutoItems(
  items: AutoRawItem[],
  comisiones: Map<string, { nombre: string; comision_pct: number; activo: boolean }>,
): AutoComputedItem[] {
  return items.map((it) => {
    const importe = r2(it.importe);
    const cuotas = Math.max(1, Math.floor(Number(it.cuotas) || 1));
    const informadas = (it.cuotas_importes ?? []).map((x) => r2(x)).filter((x) => x > 0);
    // Se respetan los importes de cuota informados por el proveedor; sólo se distribuye
    // automáticamente cuando el archivo/carga no los trae.
    const cuotas_importes =
      informadas.length === cuotas ? informadas : distribuirCuotas(importe, cuotas);
    const pct = comisiones.get(normNombre(it.prestacion))?.comision_pct ?? 0;
    const comision_monto = r2((importe * pct) / 100);
    return {
      ...it,
      cuotas,
      cuotas_importes,
      comision_pct: pct,
      comision_monto,
      neto_proveedor: r2(importe - comision_monto),
    };
  });
}

export function autoTotals(items: AutoComputedItem[]) {
  const total_importe = r2(items.reduce((a, b) => a + b.importe, 0));
  const total_comision = r2(items.reduce((a, b) => a + b.comision_monto, 0));
  return {
    total_importe,
    total_comision,
    total_neto: r2(total_importe - total_comision),
    total_items: items.length,
    total_afiliados: new Set(items.map((i) => i.legajo)).size,
  };
}

/** Subtotales por prestación, para mostrar la liquidación abierta por servicio. */
export function subtotalesPorPrestacion(
  items: { prestacion?: string | null; importe: number; comision_monto: number; comision_pct: number }[],
) {
  const map = new Map<
    string,
    { prestacion: string; comision_pct: number; bruto: number; comision: number; neto: number; items: number }
  >();
  for (const it of items) {
    const nombre = it.prestacion?.trim() || "(sin prestación)";
    const k = normNombre(nombre);
    const row =
      map.get(k) ??
      { prestacion: nombre, comision_pct: Number(it.comision_pct) || 0, bruto: 0, comision: 0, neto: 0, items: 0 };
    row.bruto = r2(row.bruto + Number(it.importe || 0));
    row.comision = r2(row.comision + Number(it.comision_monto || 0));
    row.neto = r2(row.bruto - row.comision);
    row.items += 1;
    map.set(k, row);
  }
  return Array.from(map.values()).sort((a, b) => b.bruto - a.bruto);
}
