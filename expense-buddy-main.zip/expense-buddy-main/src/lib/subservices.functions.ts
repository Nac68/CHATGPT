import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// Estadísticas generales de los subservicios de Servicios Varios.
export const getSubserviceStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { subserviceStats } = await import("./subservices.server");
    return { subservicios: await subserviceStats() };
  });
