import { MESES } from "./periodo";

/** Mes/año del período abierto: el siguiente al último "Período <Mes> <aa>" cerrado en total; si no hay, el mes actual. */
export async function periodoVigente(): Promise<{ mes: number; anio: number }> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin.from("payroll_periods").select("nombre, concepto_key");
  let ult: { mes: number; anio: number } | null = null;
  for (const p of data ?? []) {
    if (p.concepto_key) continue;
    const m = String(p.nombre ?? "").match(/per[ií]odo\s+([a-záéíóú]+)\s+(\d{2,4})/i);
    if (!m) continue;
    const i = MESES.findIndex((x) => x.toLowerCase() === m[1].toLowerCase());
    if (i < 0) continue;
    const y = Number(m[2]);
    const pm = { mes: i + 1, anio: y < 100 ? 2000 + y : y };
    if (!ult || pm.anio * 12 + pm.mes > ult.anio * 12 + ult.mes) ult = pm;
  }
  const now = new Date();
  if (!ult) return { mes: now.getUTCMonth() + 1, anio: now.getUTCFullYear() };
  return ult.mes === 12 ? { mes: 1, anio: ult.anio + 1 } : { mes: ult.mes + 1, anio: ult.anio };
}
