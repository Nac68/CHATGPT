import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const ESTADOS = ["borrador", "revisada", "cerrada", "exportada"] as const;

// Días disponibles para liquidar: excluye los ya incluidos en liquidaciones CERRADAS/EXPORTADAS
export const listSettlementDays = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ from: z.string().optional(), to: z.string().optional() }).parse(raw ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin, dayStats, getLockedFormIds } = await import("./settlement.server");
    const { filterEligibleForms } = await import("./settlement-eligibility");
    await assertAdmin(context);
    let q = context.supabase
      .from("daily_forms")
      .select("id, fecha, descripcion_comida, importe, es_cumpleanos")
      .order("fecha", { ascending: false });
    if (data.from) q = q.gte("fecha", data.from);
    if (data.to) q = q.lte("fecha", data.to);
    const { data: forms, error } = await q;
    if (error) throw new Error(error.message);
    const locked = await getLockedFormIds(context.supabase);
    return dayStats(context.supabase, filterEligibleForms(forms ?? [], locked));
  });

// Vista previa + controles de consistencia para los días tildados
export const previewSettlement = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ fechas: z.array(z.string()).min(1).max(400) }).parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin, buildSnapshot, assertFechasElegibles } = await import(
      "./settlement.server"
    );
    await assertAdmin(context);
    const snap = await buildSnapshot(context.supabase, data.fechas);
    const bloqueadas = await assertFechasElegibles(context.supabase, data.fechas, {
      throwOnLocked: false,
    });
    if (bloqueadas.length)
      snap.errores.push(
        `${bloqueadas.length} día(s) ya liquidados en una liquidación cerrada o exportada: ${bloqueadas.join(", ")}.`,
      );
    return snap;
  });

// Fechas ya incluidas en liquidaciones cerradas/exportadas (para avisar solapamientos)
export const listUsedSettlementDates = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./settlement.server");
    const { esEstadoBloqueante } = await import("./settlement-eligibility");
    await assertAdmin(context);
    const { data, error } = await context.supabase
      .from("settlements")
      .select("id, nombre, estado, fechas");
    if (error) throw new Error(error.message);
    const map: Record<string, string> = {};
    for (const s of data ?? []) {
      if (!esEstadoBloqueante(s.estado)) continue;
      for (const f of s.fechas ?? []) map[f] = s.nombre;
    }
    return map;
  });


// Crea la liquidación del período en estado BORRADOR
export const createSettlement = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        nombre: z.string().trim().min(2).max(200),
        fechas: z.array(z.string()).min(1).max(400),
        periodo_mes: z.number().int().min(1).max(12),
        periodo_anio: z.number().int().min(2000).max(2100),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin, buildSnapshot, logSettlementEvent, assertFechasElegibles, syncSettlementDays } =
      await import("./settlement.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await assertFechasElegibles(supabaseAdmin, data.fechas, { throwOnLocked: true });
    const snap = await buildSnapshot(supabaseAdmin, data.fechas);
    const fechas = snap.fechas;


    const { data: created, error } = await supabaseAdmin
      .from("settlements")
      .insert({
        nombre: data.nombre,
        fechas,
        desde: fechas[0],
        hasta: fechas[fechas.length - 1],
        periodo_mes: data.periodo_mes,
        periodo_anio: data.periodo_anio,
        estado: "borrador",
        total_consumos: snap.totales.consumos,
        total_afiliados: snap.totales.afiliados,
        importe_total: snap.totales.total_a_descontar,
        importe_cargado: snap.totales.importe_cargado,
        diferencia: snap.totales.diferencia,
        dias_sin_importe: snap.totales.dias_sin_importe,
        snapshot: snap as any,
        created_by: context.userId,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);

    if (snap.rows.length) {
      const items = snap.rows.map((r) => ({ settlement_id: created.id, ...r }));
      const CHUNK = 500;
      for (let i = 0; i < items.length; i += CHUNK) {
        const { error: iErr } = await supabaseAdmin
          .from("settlement_items")
          .insert(items.slice(i, i + CHUNK));
        if (iErr) throw new Error(iErr.message);
      }
    }
    // Vínculo real día ↔ liquidación (base de la exclusión de días ya liquidados)
    await syncSettlementDays(supabaseAdmin, created.id as string, fechas);

    await logSettlementEvent(
      supabaseAdmin,
      created.id as string,
      "creada",
      context.userId,
      `Borrador ${String(data.periodo_mes).padStart(2, "0")}/${data.periodo_anio} · ${fechas.length} día(s)`,
      { valor_nuevo: { estado: "borrador", ...snap.totales, dias: fechas.length } },
    );

    return { id: created.id as string };
  });

// Recalcula un BORRADOR contra los datos diarios actuales
export const recalcSettlement = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin, buildSnapshot, logSettlementEvent, assertFechasElegibles, syncSettlementDays } =
      await import("./settlement.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: s, error: sErr } = await supabaseAdmin
      .from("settlements")
      .select("id, estado, fechas")
      .eq("id", data.id)
      .maybeSingle();
    if (sErr) throw new Error(sErr.message);
    if (!s) throw new Error("Liquidación no encontrada");
    if (s.estado === "cerrada" || s.estado === "exportada")
      throw new Error("Una liquidación cerrada o exportada no se puede recalcular. Reabrila primero.");

    await assertFechasElegibles(supabaseAdmin, s.fechas ?? [], {
      throwOnLocked: true,
      ignoreSettlementId: String(s.id),
    });
    const snap = await buildSnapshot(supabaseAdmin, s.fechas ?? []);
    await syncSettlementDays(supabaseAdmin, String(s.id), s.fechas ?? []);
    await supabaseAdmin.from("settlement_items").delete().eq("settlement_id", s.id);

    if (snap.rows.length) {
      const items = snap.rows.map((r) => ({ settlement_id: s.id, ...r }));
      const CHUNK = 500;
      for (let i = 0; i < items.length; i += CHUNK) {
        const { error: iErr } = await supabaseAdmin
          .from("settlement_items")
          .insert(items.slice(i, i + CHUNK));
        if (iErr) throw new Error(iErr.message);
      }
    }
    const { error: uErr } = await supabaseAdmin
      .from("settlements")
      .update({
        total_consumos: snap.totales.consumos,
        total_afiliados: snap.totales.afiliados,
        importe_total: snap.totales.total_a_descontar,
        importe_cargado: snap.totales.importe_cargado,
        diferencia: snap.totales.diferencia,
        dias_sin_importe: snap.totales.dias_sin_importe,
        snapshot: snap as any,
      })
      .eq("id", s.id);
    if (uErr) throw new Error(uErr.message);
    await logSettlementEvent(
      supabaseAdmin,
      s.id as string,
      "recalculada",
      context.userId,
      undefined,
      { valor_nuevo: snap.totales },
    );

    return { ok: true, totales: snap.totales, errores: snap.errores, advertencias: snap.advertencias };
  });

// Controles de consistencia (desde datos actuales si es borrador, del snapshot si está congelada)
export const settlementControls = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin, buildSnapshot } = await import("./settlement.server");
    await assertAdmin(context);
    const { data: s, error } = await context.supabase
      .from("settlements")
      .select("id, estado, fechas, snapshot")
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!s) throw new Error("Liquidación no encontrada");
    if (s.estado === "cerrada" || s.estado === "exportada") {
      const snap: any = s.snapshot;
      return { congelado: true, totales: snap?.totales ?? null, errores: [], advertencias: snap?.advertencias ?? [] };
    }
    const snap = await buildSnapshot(context.supabase, s.fechas ?? []);
    return {
      congelado: false,
      totales: snap.totales,
      errores: snap.errores,
      advertencias: snap.advertencias,
    };
  });

// Cambio de estado: borrador → revisada → cerrada → exportada, y reapertura
export const setSettlementEstado = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        estado: z.enum(ESTADOS),
        nota: z.string().max(500).optional(),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin, buildSnapshot, logSettlementEvent, assertFechasElegibles, syncSettlementDays } =
      await import("./settlement.server");

    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: s, error } = await supabaseAdmin
      .from("settlements")
      .select("id, estado, fechas, snapshot, reaperturas")
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!s) throw new Error("Liquidación no encontrada");

    const from = String(s.estado);
    const to = data.estado;
    const now = new Date().toISOString();
    const patch: Record<string, any> = { estado: to };
    let accion: string = to;

    if (from === to) throw new Error(`La liquidación ya está en estado ${to}.`);

    if (to === "revisada") {
      if (from !== "borrador")
        throw new Error("Sólo un borrador puede marcarse como revisada.");
      patch.revisada_at = now;
      patch.revisada_por = context.userId;
    } else if (to === "cerrada") {
      if (from !== "revisada" && from !== "borrador")
        throw new Error("Sólo un borrador o una liquidación revisada puede cerrarse.");
      await assertFechasElegibles(supabaseAdmin, s.fechas ?? [], {
        throwOnLocked: true,
        ignoreSettlementId: String(s.id),
      });
      const snap = await buildSnapshot(supabaseAdmin, s.fechas ?? []);
      if (snap.errores.length)
        throw new Error(`No se puede cerrar: ${snap.errores.join(" ")}`);
      // Vínculo real día ↔ liquidación, para que esos días dejen de ser elegibles
      await syncSettlementDays(supabaseAdmin, String(s.id), s.fechas ?? []);
      // Congela el snapshot definitivo y el detalle por legajo
      await supabaseAdmin.from("settlement_items").delete().eq("settlement_id", s.id);
      if (snap.rows.length) {

        const items = snap.rows.map((r) => ({ settlement_id: s.id, ...r }));
        const CHUNK = 500;
        for (let i = 0; i < items.length; i += CHUNK) {
          const { error: iErr } = await supabaseAdmin
            .from("settlement_items")
            .insert(items.slice(i, i + CHUNK));
          if (iErr) throw new Error(iErr.message);
        }
      }
      patch.snapshot = snap as any;
      patch.total_consumos = snap.totales.consumos;
      patch.total_afiliados = snap.totales.afiliados;
      patch.importe_total = snap.totales.total_a_descontar;
      patch.importe_cargado = snap.totales.importe_cargado;
      patch.diferencia = snap.totales.diferencia;
      patch.dias_sin_importe = snap.totales.dias_sin_importe;
      patch.cerrada_at = now;
      patch.cerrada_por = context.userId;
    } else if (to === "exportada") {
      if (from !== "cerrada")
        throw new Error("Sólo una liquidación cerrada puede exportarse a Tesorería.");
      if (!s.snapshot) throw new Error("La liquidación no tiene snapshot congelado.");
      patch.exportada_at = now;
      patch.exportada_por = context.userId;
    } else if (to === "borrador") {
      if (from === "borrador") throw new Error("Ya es un borrador.");
      patch.reabierta_at = now;
      patch.reabierta_por = context.userId;
      patch.reaperturas = Number(s.reaperturas ?? 0) + 1;
      patch.cerrada_at = null;
      patch.cerrada_por = null;
      patch.exportada_at = null;
      patch.exportada_por = null;
      patch.revisada_at = null;
      patch.revisada_por = null;
      accion = from === "exportada" ? "reapertura_de_exportada" : "reapertura";
    }

    const { error: uErr } = await supabaseAdmin
      .from("settlements")
      .update(patch as never)
      .eq("id", s.id);
    if (uErr) throw new Error(uErr.message);
    await logSettlementEvent(
      supabaseAdmin,
      s.id as string,
      accion,
      context.userId,
      data.nota ?? `${from} → ${to}`,
      {
        valor_anterior: { estado: from },
        valor_nuevo: {
          estado: to,
          ...(patch.importe_total != null ? { importe_total: patch.importe_total } : {}),
          ...(patch.reaperturas != null ? { reaperturas: patch.reaperturas } : {}),
        },
      },
    );

    return { ok: true, estado: to, desde: from };
  });

export const listSettlementEvents = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./settlement.server");
    await assertAdmin(context);
    const { data: rows, error } = await context.supabase
      .from("settlement_events")
      .select("id, accion, user_id, nota, created_at")
      .eq("settlement_id", data.id)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const listSettlements = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./settlement.server");
    await assertAdmin(context);
    const { data, error } = await context.supabase
      .from("settlements")
      .select(
        "id, nombre, estado, fechas, desde, hasta, periodo_mes, periodo_anio, total_consumos, total_afiliados, importe_total, importe_cargado, diferencia, dias_sin_importe, reaperturas, cerrada_at, exportada_at, revisada_at, reabierta_at, created_at",
      )
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data;
  });

export const getSettlement = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./settlement.server");
    await assertAdmin(context);
    const { data: settlement, error } = await context.supabase
      .from("settlements")
      .select("*")
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!settlement) throw new Error("Liquidación no encontrada");
    const { data: items } = await context.supabase
      .from("settlement_items")
      .select("*")
      .eq("settlement_id", data.id)
      .range(0, 9999);

    const snap: any = settlement.snapshot ?? null;
    // Los históricos leen SIEMPRE del snapshot congelado, no de los datos diarios.
    let dias: any[] = snap?.dias ?? [];
    const consumos: any[] = snap?.consumos ?? [];
    if (!dias.length) {
      const fechas: string[] = settlement.fechas ?? [];
      const { data: forms } = await context.supabase
        .from("daily_forms")
        .select("fecha, descripcion_comida, importe, es_cumpleanos")
        .in("fecha", fechas.length ? fechas : ["1900-01-01"])
        .order("fecha");
      dias = (forms ?? []).map((f: any) => ({
        fecha: f.fecha,
        descripcion: f.descripcion_comida,
        es_cumpleanos: f.es_cumpleanos,
        importe: f.importe,
        comensales: null,
        pagan: null,
        a_descontar: null,
      }));
    }
    return { settlement, items: items ?? [], dias, consumos, snapshot: snap };
  });

export const deleteSettlement = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./settlement.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: s } = await supabaseAdmin
      .from("settlements")
      .select("estado")
      .eq("id", data.id)
      .maybeSingle();
    if (s && (s.estado === "cerrada" || s.estado === "exportada"))
      throw new Error("No se puede eliminar una liquidación cerrada o exportada. Reabrila primero.");
    const { error } = await supabaseAdmin.from("settlements").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// Reporte mensual (se mantiene para la vista por mes)
export const getMonthReport = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ anio: z.number().int(), mes: z.number().int().min(1).max(12) }).parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin, aggregateByDates } = await import("./settlement.server");
    await assertAdmin(context);
    const from = `${data.anio}-${String(data.mes).padStart(2, "0")}-01`;
    const lastDay = new Date(data.anio, data.mes, 0).getDate();
    const to = `${data.anio}-${String(data.mes).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`;

    const { data: forms } = await context.supabase
      .from("daily_forms")
      .select("fecha")
      .gte("fecha", from)
      .lte("fecha", to);
    const fechas = (forms ?? []).map((f: any) => f.fecha);
    if (!fechas.length) {
      return { from, to, rows: [] as any[], total_consumos: 0, importe_total_mes: 0 };
    }
    const agg = await aggregateByDates(context.supabase, fechas);
    return {
      from,
      to,
      rows: agg.rows as any[],
      total_consumos: agg.total_consumos,
      importe_total_mes: agg.importe_total,
    };
  });

// Registra la descarga del Excel de Tesorería (auditoría de exportación)
export const logSettlementExport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ id: z.string().uuid(), filas: z.number().int().min(0) }).parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./settlement.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { logAudit } = await import("./audit.server");
    const { data: s } = await supabaseAdmin
      .from("settlements")
      .select("estado, importe_total")
      .eq("id", data.id)
      .maybeSingle();
    await logAudit(supabaseAdmin, {
      entidad: "liquidacion_comida",
      entidad_id: data.id,
      accion: "excel_descargado",
      userId: context.userId,
      nota: `Estado ${s?.estado ?? "?"} · ${data.filas} fila(s)`,
      valor_nuevo: { importe_total: s?.importe_total ?? null, filas: data.filas },
    });
    return { ok: true };
  });
