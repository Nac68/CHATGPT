import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

// Lista todos los usuarios registrados con sus roles, autorización y clave temporal
// asignada por el administrador (si existe).
export const listAppUsers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const users: any[] = [];
    for (let page = 1; page <= 20; page++) {
      const { data, error } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 200 });
      if (error) throw new Error(error.message);
      users.push(...(data?.users ?? []));
      if (!data?.users?.length || data.users.length < 200) break;
    }

    const [{ data: roles }, { data: accounts }, { data: provs }] = await Promise.all([
      supabaseAdmin.from("user_roles").select("user_id, role, legajo"),
      supabaseAdmin.from("user_accounts").select("*"),
      supabaseAdmin.from("providers").select("user_id, nombre, habilitado"),
    ]);

    const roleMap = new Map<string, any[]>();
    (roles ?? []).forEach((r: any) => {
      roleMap.set(r.user_id, [...(roleMap.get(r.user_id) ?? []), r]);
    });
    const accMap = new Map((accounts ?? []).map((a: any) => [a.user_id, a]));
    const provMap = new Map((provs ?? []).map((p: any) => [p.user_id, p]));

    return users
      .map((u) => {
        const rs = roleMap.get(u.id) ?? [];
        const acc: any = accMap.get(u.id);
        const prov: any = provMap.get(u.id);
        return {
          id: u.id,
          email: u.email ?? "",
          created_at: u.created_at,
          last_sign_in_at: u.last_sign_in_at ?? null,
          roles: rs.map((r: any) => r.role as string),
          legajo: rs.find((r: any) => r.legajo)?.legajo ?? null,
          proveedor: prov?.nombre ?? null,
          autorizado: acc?.autorizado ?? rs.length > 0,
          clave_temporal: acc?.clave_temporal ?? null,
          nota: acc?.nota ?? null,
        };
      })
      .sort((a, b) => (a.email > b.email ? 1 : -1));
  });

// Blanquea la clave de un usuario y la deja visible para el administrador.
export const resetUserPassword = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        user_id: z.string().uuid(),
        email: z.string().email().optional(),
        password: z.string().min(6).max(72),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.updateUserById(data.user_id, {
      password: data.password,
      email_confirm: true,
    });
    if (error) throw new Error(error.message);
    const { error: accErr } = await supabaseAdmin.from("user_accounts").upsert(
      {
        user_id: data.user_id,
        email: data.email ?? null,
        clave_temporal: data.password,
        updated_at: new Date().toISOString(),
      } as any,
      { onConflict: "user_id" },
    );
    if (accErr) throw new Error(accErr.message);
    return { ok: true };
  });

// Blanquea TODAS las claves de todos los usuarios registrados con una clave temporal.
export const resetAllPasswords = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ password: z.string().min(6).max(72) }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const users: any[] = [];
    for (let page = 1; page <= 20; page++) {
      const { data: list, error } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 200 });
      if (error) throw new Error(error.message);
      users.push(...(list?.users ?? []));
      if (!list?.users?.length || list.users.length < 200) break;
    }

    let ok = 0;
    for (const u of users) {
      const { error } = await supabaseAdmin.auth.admin.updateUserById(u.id, {
        password: data.password,
        email_confirm: true,
      });
      if (error) continue;
      ok++;
      await supabaseAdmin.from("user_accounts").upsert(
        {
          user_id: u.id,
          email: u.email ?? null,
          clave_temporal: data.password,
          updated_at: new Date().toISOString(),
        } as any,
        { onConflict: "user_id" },
      );
    }
    return { total: users.length, actualizados: ok };
  });

// Autoriza o bloquea manualmente el acceso de un usuario registrado.
export const setUserAuthorized = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        user_id: z.string().uuid(),
        email: z.string().email().nullable().optional(),
        autorizado: z.boolean(),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("user_accounts").upsert(
      {
        user_id: data.user_id,
        email: data.email ?? null,
        autorizado: data.autorizado,
        updated_at: new Date().toISOString(),
      } as any,
      { onConflict: "user_id" },
    );
    if (error) throw new Error(error.message);
    if (!data.autorizado) {
      await supabaseAdmin.from("providers").update({ habilitado: false }).eq("user_id", data.user_id);
    }
    return { ok: true };
  });

// Asigna o quita un rol (admin / afiliado / proveedor) a un usuario.
export const setUserRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        user_id: z.string().uuid(),
        role: z.enum(["admin", "afiliado", "proveedor"]),
        enabled: z.boolean(),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    if (data.enabled) {
      const { error } = await supabaseAdmin
        .from("user_roles")
        .upsert({ user_id: data.user_id, role: data.role } as any, { onConflict: "user_id,role" });
      if (error) throw new Error(error.message);
    } else {
      if (data.role === "admin" && data.user_id === context.userId) {
        throw new Error("No podés quitarte el rol de administrador a vos mismo");
      }
      const { error } = await supabaseAdmin
        .from("user_roles")
        .delete()
        .eq("user_id", data.user_id)
        .eq("role", data.role);
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });

// Elimina definitivamente un usuario registrado.
export const deleteAppUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ user_id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    if (data.user_id === context.userId) throw new Error("No podés eliminar tu propio usuario");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.deleteUser(data.user_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// Otorga acceso total (admin + afiliado + proveedor + autorizado) a un email.
// Si el usuario no existe, lo crea con la clave indicada.
export const grantFullAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        email: z.string().email(),
        password: z.string().min(6).max(72).optional(),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    let userId: string | null = null;
    for (let page = 1; page <= 20 && !userId; page++) {
      const { data: list, error } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 200 });
      if (error) throw new Error(error.message);
      userId =
        list.users.find((u) => u.email?.toLowerCase() === data.email.toLowerCase())?.id ?? null;
      if (!list.users.length || list.users.length < 200) break;
    }

    let creado = false;
    if (!userId) {
      if (!data.password) throw new Error("El usuario no existe: indicá una clave para crearlo");
      const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
        email: data.email,
        password: data.password,
        email_confirm: true,
      });
      if (error || !created.user) throw new Error(error?.message ?? "No se pudo crear el usuario");
      userId = created.user.id;
      creado = true;
    } else if (data.password) {
      const { error } = await supabaseAdmin.auth.admin.updateUserById(userId, {
        password: data.password,
        email_confirm: true,
      });
      if (error) throw new Error(error.message);
    }

    for (const role of ["admin", "afiliado", "proveedor"] as const) {
      const { error } = await supabaseAdmin
        .from("user_roles")
        .upsert({ user_id: userId, role } as any, { onConflict: "user_id,role" });
      if (error && !error.message.includes("duplicate")) throw new Error(error.message);
    }

    const { error: accErr } = await supabaseAdmin.from("user_accounts").upsert(
      {
        user_id: userId,
        email: data.email,
        autorizado: true,
        ...(data.password ? { clave_temporal: data.password } : {}),
        updated_at: new Date().toISOString(),
      } as any,
      { onConflict: "user_id" },
    );
    if (accErr) throw new Error(accErr.message);

    return { ok: true, creado, user_id: userId };
  });

