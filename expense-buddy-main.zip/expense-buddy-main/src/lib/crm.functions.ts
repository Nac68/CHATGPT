import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const ItemSchema = z.object({
  legajo: z.string().min(1).max(32),
  fecha: z.string().nullable().optional(),
  detalle: z.string().max(500).nullable().optional(),
  comprobante: z.string().max(80).nullable().optional(),
  importe: z.number(),
  // Importe a cargo del afiliado ya con el descuento de obra social (columna "A/C Afiliado").
  // Si no viene, se asume el 100%.
  base_afiliado: z.number().nullable().optional(),
  cuotas: z.number().int().min(1).max(60).default(1),
  con_receta: z.boolean().default(false),
  es_cumpleanos: z.boolean().default(false),

});

/* ------------------------------ SERVICIOS ------------------------------ */

export const listServices = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("services")
      .select("*")
      .order("nombre", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const upsertService = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        id: z.string().uuid().optional(),
        nombre: z.string().trim().min(2).max(80),
        codigo: z
          .string()
          .trim()
          .min(2)
          .max(40)
          .transform((s) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-")),
        descripcion: z.string().max(500).nullable().optional(),
        cuenta_contable: z.string().trim().max(40).nullable().optional(),
        activo: z.boolean().default(true),

        usa_receta: z.boolean().default(false),
        subsidio_receta_pct: z.number().min(0).max(100).default(0),
        permite_cuotas: z.boolean().default(true),
        permite_cumpleanos: z.boolean().default(false),
        campos_requeridos: z.array(z.string()).default(["fecha", "legajo", "detalle", "importe"]),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const payload = { ...data, campos_requeridos: data.campos_requeridos };
    const { data: row, error } = await context.supabase
      .from("services")
      .upsert(payload as any, { onConflict: "id" })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

/* ------------------------------ PROVEEDORES ---------------------------- */

export const listProviders = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { data, error } = await context.supabase
      .from("providers")
      .select("*, services(*)")
      .order("nombre", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const createProvider = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        nombre: z.string().trim().min(2).max(120),
        service_id: z.string().uuid(),
        email: z.string().email(),
        password: z.string().min(6).max(72),
        cuit: z.string().max(20).nullable().optional(),
        cuenta_contable: z.string().max(40).nullable().optional(),
        tipo: z.enum(["externo", "interno", "agoec"]).default("externo"),


      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    let userId: string | null = null;
    const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
      user_metadata: { proveedor: data.nombre },
    });
    if (createErr) {
      const { data: list } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 1000 });
      const found = list?.users?.find((u: any) => u.email?.toLowerCase() === data.email.toLowerCase());
      if (!found) throw new Error(createErr.message);
      userId = found.id;
      await supabaseAdmin.auth.admin.updateUserById(userId, { password: data.password });
    } else {
      userId = created.user!.id;
    }

    await supabaseAdmin
      .from("user_roles")
      .upsert({ user_id: userId!, role: "proveedor" as any }, { onConflict: "user_id,role" });

    const { data: row, error } = await supabaseAdmin
      .from("providers")
      .insert({
        user_id: userId,
        nombre: data.nombre,
        service_id: data.service_id,
        email: data.email,
        cuit: data.cuit ?? null,
        cuenta_contable: data.cuenta_contable ?? null,

        tipo: data.tipo,
        interno: data.tipo !== "externo",
      })
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const updateProvider = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        nombre: z.string().trim().min(2).max(120).optional(),
        service_id: z.string().uuid().optional(),
        cuit: z.string().max(20).nullable().optional(),
        cuenta_contable: z.string().max(40).nullable().optional(),

        tipo: z.enum(["externo", "interno", "agoec"]).optional(),
        habilitado: z.boolean().optional(),
        newPassword: z.string().min(6).max(72).optional(),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { id, newPassword, ...rest } = data;
    const patch: Record<string, any> = { ...rest };
    if (rest.tipo) patch.interno = rest.tipo !== "externo";
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    if (Object.keys(patch).length) {
      const { error } = await supabaseAdmin.from("providers").update(patch as any).eq("id", id);
      if (error) throw new Error(error.message);
    }
    if (newPassword) {
      const { data: p } = await supabaseAdmin.from("providers").select("user_id").eq("id", id).single();
      if (p?.user_id) await supabaseAdmin.auth.admin.updateUserById(p.user_id, { password: newPassword });
    }
    return { ok: true };
  });

export const deleteProvider = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { error } = await context.supabase.from("providers").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* --------------------------- PANEL DEL PROVEEDOR ----------------------- */

export const getMyProvider = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { myProviderRow } = await import("./crm.server");
    return await myProviderRow(context);
  });

export const updateMyBankDetails = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        banco: z.string().max(120).nullable(),
        cbu: z.string().max(40).nullable(),
        alias: z.string().max(60).nullable(),
        titular: z.string().max(120).nullable(),
        cuit: z.string().max(20).nullable(),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { myProviderRow } = await import("./crm.server");
    const prov = await myProviderRow(context);
    const { error } = await context.supabase.from("providers").update(data).eq("id", prov.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const previewLiquidation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ items: z.array(ItemSchema) }).parse(raw))
  .handler(async ({ data, context }) => {
    const { myProviderRow, computeItems, totals } = await import("./crm.server");
    const prov = await myProviderRow(context);
    const items = computeItems(data.items as any, prov.services);

    const legajos = Array.from(new Set(items.map((i) => i.legajo)));
    const { data: affs } = await context.supabase
      .from("affiliates")
      .select("legajo, apellido_nombre")
      .in("legajo", legajos.length ? legajos : ["__none__"]);
    const map = new Map((affs ?? []).map((a: any) => [a.legajo, a.apellido_nombre]));
    const rows = items.map((i) => ({
      ...i,
      apellido_nombre: (map.get(i.legajo) as string) ?? null,
      valido: map.has(i.legajo),
    }));
    return { rows, ...totals(items), servicio: prov.services.nombre };
  });

export const submitLiquidation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        nombre: z.string().trim().min(2).max(120),
        periodo_mes: z.number().int().min(1).max(12),
        periodo_anio: z.number().int().min(2020).max(2100),
        observacion: z.string().max(1000).nullable().optional(),
        items: z.array(ItemSchema).min(1),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { myProviderRow, computeItems, totals } = await import("./crm.server");
    const prov = await myProviderRow(context);
    const items = computeItems(data.items as any, prov.services);
    const t = totals(items);

    const { data: sub, error } = await context.supabase
      .from("provider_submissions")
      .insert({
        provider_id: prov.id,
        service_id: prov.service_id,
        nombre: data.nombre,
        periodo_mes: data.periodo_mes,
        periodo_anio: data.periodo_anio,
        observacion: data.observacion ?? null,
        total_importe: t.total_importe,
        total_subsidio: t.total_subsidio,
        total_a_pagar: t.total_a_pagar,
        total_items: t.total_items,
        total_afiliados: t.total_afiliados,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);

    const payload = items.map((i) => ({
      submission_id: sub.id,
      provider_id: prov.id,
      service_id: prov.service_id,
      legajo: i.legajo,
      fecha: i.fecha || null,
      detalle: i.detalle ?? null,
      comprobante: i.comprobante ?? null,
      importe: i.importe,
      cuotas: i.cuotas,
      con_receta: i.con_receta,
      es_cumpleanos: i.es_cumpleanos,
      subsidio: i.subsidio,
      importe_afiliado: i.importe_afiliado,
    }));
    for (let i = 0; i < payload.length; i += 500) {
      const { error: e } = await context.supabase
        .from("submission_items")
        .insert(payload.slice(i, i + 500));
      if (e) throw new Error(e.message);
    }
    return { id: sub.id, ...t };
  });

export const listMySubmissions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { myProviderRow } = await import("./crm.server");
    const prov = await myProviderRow(context);
    const { data, error } = await context.supabase
      .from("provider_submissions")
      .select("*")
      .eq("provider_id", prov.id)
      .order("periodo_anio", { ascending: false })
      .order("periodo_mes", { ascending: false });
    if (error) throw new Error(error.message);
    return { provider: prov, submissions: data ?? [] };
  });

export const getSubmission = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { data: sub, error } = await context.supabase
      .from("provider_submissions")
      .select("*, providers(nombre, email, interno), services(nombre, codigo)")
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!sub) throw new Error("Liquidación no encontrada");
    const { data: items } = await context.supabase
      .from("submission_items")
      .select("*")
      .eq("submission_id", data.id)
      .order("fecha", { ascending: true });

    const legajos = Array.from(new Set((items ?? []).map((i: any) => i.legajo)));
    const { data: affs } = await context.supabase
      .from("affiliates")
      .select("legajo, apellido_nombre")
      .in("legajo", legajos.length ? legajos : ["__none__"]);
    const map = new Map((affs ?? []).map((a: any) => [a.legajo, a.apellido_nombre]));
    return {
      submission: sub,
      items: (items ?? []).map((i: any) => ({
        ...i,
        apellido_nombre: (map.get(i.legajo) as string) ?? null,
      })),
    };
  });

export const deleteMySubmission = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("provider_submissions")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const parseProviderPhoto = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ base64: z.string() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { myProviderRow } = await import("./crm.server");
    const prov = await myProviderRow(context);
    const { callLovableAI } = await import("./ai-gateway.server");

    const system = `Analizás fotos de listados de consumos de afiliados del servicio "${prov.services.nombre}" en Argentina.
Columnas típicas: fecha | legajo | detalle | comprobante | importe | cuotas${prov.services.usa_receta ? " | con receta (sí/no)" : ""}.
Los legajos pueden ser alfanuméricos. Los importes son en pesos, usá punto decimal y sin separador de miles.
Devolvé ÚNICAMENTE JSON con la clave "items" (array). Cada item:
{ "legajo": string, "fecha": "YYYY-MM-DD" | null, "detalle": string | null, "comprobante": string | null, "importe": number, "cuotas": number, "con_receta": boolean, "es_cumpleanos": boolean }`;

    const res = await callLovableAI({
      model: "google/gemini-3.6-flash",
      messages: [
        { role: "system", content: system },
        {
          role: "user",
          content: [
            { type: "text", text: "Extraé el listado de consumos de esta imagen." },
            { type: "image_url", image_url: { url: data.base64 } },
          ],
        },
      ],
      response_format: { type: "json_object" },
    });
    if (!res.ok) {
      if (res.status === 429) throw new Error("La IA está sobrecargada. Probá en un rato.");
      if (res.status === 402) throw new Error("Sin créditos de IA.");
      throw new Error(`Error IA (${res.status})`);
    }
    const json = (await res.json()) as any;
    const raw = json.choices?.[0]?.message?.content ?? "{}";
    let parsed: any;
    try {
      parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
    } catch {
      throw new Error("La IA no devolvió JSON válido");
    }
    const list = Array.isArray(parsed?.items) ? parsed.items : [];
    return {
      items: list
        .map((i: any) => ({
          legajo: String(i.legajo ?? "").trim().toUpperCase(),
          fecha: i.fecha ? String(i.fecha).slice(0, 10) : null,
          detalle: i.detalle ? String(i.detalle).slice(0, 500) : null,
          comprobante: i.comprobante ? String(i.comprobante).slice(0, 80) : null,
          importe: Number(i.importe) || 0,
          cuotas: Math.max(1, Number(i.cuotas) || 1),
          con_receta: Boolean(i.con_receta),
          es_cumpleanos: Boolean(i.es_cumpleanos),
        }))
        .filter((i: any) => i.legajo.length > 0),
    };
  });

/* ------------------------------- MENSAJES ------------------------------ */

export const listMyMessages = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { myProviderRow } = await import("./crm.server");
    const prov = await myProviderRow(context);
    const { data, error } = await context.supabase
      .from("provider_messages")
      .select("*")
      .eq("provider_id", prov.id)
      .order("created_at", { ascending: true });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const sendProviderMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({ asunto: z.string().max(160).nullable(), mensaje: z.string().trim().min(2).max(4000) })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { myProviderRow } = await import("./crm.server");
    const prov = await myProviderRow(context);
    const { error } = await context.supabase.from("provider_messages").insert({
      provider_id: prov.id,
      autor_user_id: context.userId,
      desde_admin: false,
      asunto: data.asunto,
      mensaje: data.mensaje,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const listAllMessages = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { data, error } = await context.supabase
      .from("provider_messages")
      .select("*, providers(nombre, email, services(nombre))")
      .order("created_at", { ascending: false })
      .limit(500);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const replyProviderMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        provider_id: z.string().uuid(),
        asunto: z.string().max(160).nullable(),
        mensaje: z.string().trim().min(1).max(4000),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { error } = await context.supabase.from("provider_messages").insert({
      provider_id: data.provider_id,
      autor_user_id: context.userId,
      desde_admin: true,
      asunto: data.asunto,
      mensaje: data.mensaje,
      leido: true,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* --------------------------------- CRM --------------------------------- */

export const listSubmissionsAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { data, error } = await context.supabase
      .from("provider_submissions")
      .select("*, providers(nombre, interno), services(nombre, codigo)")
      .order("created_at", { ascending: false })
      .limit(1000);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const setSubmissionEstado = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        estado: z.enum(["enviada", "revisada", "aprobada", "pagada", "rechazada"]),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { error } = await context.supabase
      .from("provider_submissions")
      .update({ estado: data.estado })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const crmConsumptions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        service_id: z.string().uuid().nullable().optional(),
        anio: z.number().int().nullable().optional(),
        mes: z.number().int().min(1).max(12).nullable().optional(),
        legajo: z.string().max(32).nullable().optional(),
      })
      .parse(raw ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);

    let q = context.supabase
      .from("submission_items")
      .select(
        "*, provider_submissions!inner(periodo_mes, periodo_anio, estado, nombre), providers(nombre), services(nombre, codigo)",
      )
      .limit(5000);
    if (data.service_id) q = q.eq("service_id", data.service_id);
    if (data.anio) q = q.eq("provider_submissions.periodo_anio", data.anio);
    if (data.mes) q = q.eq("provider_submissions.periodo_mes", data.mes);
    if (data.legajo) q = q.eq("legajo", data.legajo.trim().toUpperCase());

    const { data: items, error } = await q;
    if (error) throw new Error(error.message);

    const legajos = Array.from(new Set((items ?? []).map((i: any) => i.legajo)));
    const { data: affs } = await context.supabase
      .from("affiliates")
      .select("legajo, apellido_nombre")
      .in("legajo", legajos.length ? legajos : ["__none__"]);
    const map = new Map((affs ?? []).map((a: any) => [a.legajo, a.apellido_nombre]));

    return (items ?? []).map((i: any) => ({
      ...i,
      apellido_nombre: (map.get(i.legajo) as string) ?? null,
      periodo: `${i.provider_submissions.periodo_anio}-${String(i.provider_submissions.periodo_mes).padStart(2, "0")}`,
    }));
  });

export const getMyServiceConsumptions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ legajo: z.string().max(32).nullable().optional() }).parse(raw ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { isAdmin } = await import("./crm.server");
    const { data: own } = await context.supabase.rpc("current_legajo");
    let legajo = (own as string | null) ?? null;
    // Un administrador puede consultar la vista del afiliado que quiera.
    if (!legajo && (await isAdmin(context))) legajo = data.legajo?.trim().toUpperCase() ?? null;
    if (!legajo) return { legajo: null, items: [] as any[] };

    const { data: rows, error } = await context.supabase
      .from("submission_items")
      .select("*, services(nombre, codigo), provider_submissions(periodo_mes, periodo_anio, estado)")
      .eq("legajo", legajo)
      .order("fecha", { ascending: false })
      .limit(2000);
    if (error) throw new Error(error.message);
    return {
      legajo,
      items: (rows ?? []).map((i: any) => ({

        ...i,
        servicio: i.services?.nombre ?? "—",
        periodo: i.provider_submissions
          ? `${i.provider_submissions.periodo_anio}-${String(i.provider_submissions.periodo_mes).padStart(2, "0")}`
          : "—",
      })),
    };
  });

/* ------------- CARGA POR EL ADMINISTRADOR (servicios de AGOEC) ---------- */

export const adminPreviewLiquidation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ provider_id: z.string().uuid(), items: z.array(ItemSchema) }).parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin, providerRowById, computeItems, totals } = await import("./crm.server");
    await assertAdmin(context);
    const prov = await providerRowById(context, data.provider_id);
    const items = computeItems(data.items as any, prov.services);

    const legajos = Array.from(new Set(items.map((i) => i.legajo)));
    const { data: affs } = await context.supabase
      .from("affiliates")
      .select("legajo, apellido_nombre")
      .in("legajo", legajos.length ? legajos : ["__none__"]);
    const map = new Map((affs ?? []).map((a: any) => [a.legajo, a.apellido_nombre]));
    return {
      rows: items.map((i) => ({
        ...i,
        apellido_nombre: (map.get(i.legajo) as string) ?? null,
        valido: map.has(i.legajo),
      })),
      ...totals(items),
      servicio: prov.services.nombre,
      proveedor: prov.nombre,
    };
  });

export const adminSubmitLiquidation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        provider_id: z.string().uuid(),
        nombre: z.string().trim().min(2).max(120),
        periodo_mes: z.number().int().min(1).max(12),
        periodo_anio: z.number().int().min(2020).max(2100),
        observacion: z.string().max(1000).nullable().optional(),
        items: z.array(ItemSchema).min(1),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin, providerRowById, computeItems, totals } = await import("./crm.server");
    await assertAdmin(context);
    const prov = await providerRowById(context, data.provider_id);
    const items = computeItems(data.items as any, prov.services);
    const t = totals(items);

    const { data: sub, error } = await context.supabase
      .from("provider_submissions")
      .insert({
        provider_id: prov.id,
        service_id: prov.service_id,
        nombre: data.nombre,
        periodo_mes: data.periodo_mes,
        periodo_anio: data.periodo_anio,
        observacion: data.observacion ?? null,
        estado: "aprobada",
        total_importe: t.total_importe,
        total_subsidio: t.total_subsidio,
        total_a_pagar: t.total_a_pagar,
        total_items: t.total_items,
        total_afiliados: t.total_afiliados,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);

    const payload = items.map((i) => ({
      submission_id: sub.id,
      provider_id: prov.id,
      service_id: prov.service_id,
      legajo: i.legajo,
      fecha: i.fecha || null,
      detalle: i.detalle ?? null,
      comprobante: i.comprobante ?? null,
      importe: i.importe,
      cuotas: i.cuotas,
      con_receta: i.con_receta,
      es_cumpleanos: i.es_cumpleanos,
      subsidio: i.subsidio,
      importe_afiliado: i.importe_afiliado,
    }));
    const { error: itErr } = await context.supabase.from("submission_items").insert(payload);
    if (itErr) throw new Error(itErr.message);
    return { id: sub.id, ...t };
  });

/* --------- LIQUIDACIONES DE UN PROVEEDOR VISTAS DESDE EL ADMIN ---------- */

// Ficha del proveedor + su histórico de liquidaciones (para la vista por farmacia/proveedor).
export const adminProviderLiquidations = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        provider_id: z.string().uuid(),
        periodo_mes: z.coerce.number().int().min(1).max(12).optional(),
        periodo_anio: z.coerce.number().int().min(2000).max(2100).optional(),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin, providerRowById } = await import("./crm.server");
    await assertAdmin(context);
    const prov = await providerRowById(context, data.provider_id);

    const [{ data: subs }, { data: items }] = await Promise.all([
      context.supabase
        .from("provider_submissions")
        .select("*")
        .eq("provider_id", prov.id)
        .order("periodo_anio", { ascending: false })
        .order("periodo_mes", { ascending: false }),
      context.supabase
        .from("submission_items")
        .select("*")
        .eq("provider_id", prov.id)
        .order("fecha", { ascending: false })
        .limit(5000),
    ]);

    const allSubs = (subs ?? []) as any[];
    const allItems = (items ?? []) as any[];

    // Períodos disponibles (los que tienen cargas) más el período elegido.
    const periodos = Array.from(
      new Set(allSubs.map((s: any) => `${s.periodo_anio}-${String(s.periodo_mes).padStart(2, "0")}`)),
    )
      .sort()
      .reverse()
      .map((k) => ({ anio: Number(k.slice(0, 4)), mes: Number(k.slice(5, 7)) }));

    const hoy = new Date();
    const mes = data.periodo_mes ?? hoy.getMonth() + 1;
    const anio = data.periodo_anio ?? hoy.getFullYear();

    const esRechazada = (s: any) => String(s.estado) === "rechazada" || String(s.estado) === "rechazado";
    const delPeriodo = allSubs.filter(
      (s: any) => Number(s.periodo_mes) === mes && Number(s.periodo_anio) === anio,
    );
    const subsPeriodo = delPeriodo.filter((s) => !esRechazada(s));
    const subsRechazadas = delPeriodo.filter(esRechazada);

    const okIds = new Set(subsPeriodo.map((s) => s.id));
    const rechIds = new Set(subsRechazadas.map((s) => s.id));
    const subById = new Map(allSubs.map((s: any) => [s.id, s]));

    const legajos = Array.from(new Set(allItems.map((i: any) => i.legajo)));
    const names = new Map<string, string>();
    for (let i = 0; i < legajos.length; i += 300) {
      const { data: affs } = await context.supabase
        .from("affiliates")
        .select("legajo, apellido_nombre")
        .in("legajo", legajos.slice(i, i + 300) as string[]);
      (affs ?? []).forEach((a: any) => names.set(a.legajo, a.apellido_nombre));
    }

    const withMeta = (list: any[]) =>
      list.map((i: any) => {
        const s = subById.get(i.submission_id);
        return {
          ...i,
          apellido_nombre: names.get(i.legajo) ?? null,
          submission_nombre: s?.nombre ?? null,
          submission_estado: s?.estado ?? null,
          periodo: s ? `${String(s.periodo_mes).padStart(2, "0")}/${s.periodo_anio}` : null,
        };
      });

    const itemsPeriodo = withMeta(allItems.filter((i: any) => okIds.has(i.submission_id)));
    const itemsRechazados = withMeta(allItems.filter((i: any) => rechIds.has(i.submission_id)));

    const sum = (l: any[], k: string) => l.reduce((a: number, i: any) => a + Number(i[k] ?? 0), 0);

    return {
      provider: prov,
      periodo: { mes, anio },
      periodos,
      // Vigente / seleccionado
      submissions: subsPeriodo,
      submissionsRechazadas: subsRechazadas,
      items: itemsPeriodo,
      itemsRechazados,
      // Histórico completo (para consulta y Excel histórico)
      submissionsTodas: allSubs,
      itemsTodos: withMeta(allItems),
      totales: {
        cargas: subsPeriodo.length,
        rechazadas: subsRechazadas.length,
        pendientes: subsPeriodo.filter(
          (s: any) => s.estado === "pendiente" || s.estado === "enviada" || s.estado === "revisada",
        ).length,
        aprobadas: subsPeriodo.filter((s: any) => s.estado === "aprobada" || s.estado === "pagada")
          .length,
        afiliados: new Set(itemsPeriodo.map((i: any) => i.legajo)).size,
        total_importe: sum(itemsPeriodo, "importe"),
        total_subsidio: sum(itemsPeriodo, "subsidio"),
        total_afiliado: sum(itemsPeriodo, "importe_afiliado"),
        total_rechazado: sum(itemsRechazados, "importe"),
      },
    };
  });

/** Borra un consumo cargado por error. No toca movimientos ya liquidados ni cargas pagadas. */
export const adminDeleteSubmissionItem = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ item_id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);

    const { data: item, error: e1 } = await context.supabase
      .from("submission_items")
      .select("*, provider_submissions(id, estado)")
      .eq("id", data.item_id)
      .maybeSingle();
    if (e1) throw new Error(e1.message);
    if (!item) throw new Error("El consumo ya no existe");

    const estado = String((item as any).provider_submissions?.estado ?? "");
    if (estado === "pagada") throw new Error("La carga ya está pagada: no se puede borrar el consumo");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: consumed } = await supabaseAdmin
      .from("payroll_consumed")
      .select("source_key")
      .like("source_key", `submission_item:${data.item_id}%`);
    if ((consumed ?? []).length)
      throw new Error("El consumo ya fue liquidado en un período cerrado: no se puede borrar");

    const { data: refin } = await supabaseAdmin
      .from("refinanciacion_items" as any)
      .select("source_key")
      .like("source_key", `submission_item:${data.item_id}%`);
    if ((refin ?? []).length)
      throw new Error("El consumo está incluido en una refinanciación: no se puede borrar");

    const { error: e2 } = await context.supabase
      .from("submission_items")
      .delete()
      .eq("id", data.item_id);
    if (e2) throw new Error(e2.message);

    // Recalcular los totales de la carga con los ítems que quedan.
    const subId = (item as any).submission_id;
    const { data: rest } = await context.supabase
      .from("submission_items")
      .select("legajo, importe, subsidio, importe_afiliado, comision_monto, neto_proveedor")
      .eq("submission_id", subId);
    const l = (rest ?? []) as any[];
    const s = (k: string) =>
      Math.round(l.reduce((a: number, i: any) => a + Number(i[k] ?? 0), 0) * 100) / 100;
    await context.supabase
      .from("provider_submissions")
      .update({
        total_importe: s("importe"),
        total_subsidio: s("subsidio"),
        total_a_pagar: s("importe"),
        total_comision: s("comision_monto"),
        total_neto: s("neto_proveedor"),
        total_items: l.length,
        total_afiliados: new Set(l.map((i: any) => i.legajo)).size,
      })
      .eq("id", subId);

    const { logAudit } = await import("./audit.server");
    await logAudit(supabaseAdmin, {
      entidad: "submission_item",
      entidad_id: data.item_id,
      accion: "borrado",
      userId: context.userId,
      legajo: (item as any).legajo,
      valor_anterior: item as any,
      nota: "Borrado manual de consumo cargado por error",
    });

    return { ok: true };
  });


// OCR de la foto de un listado, con la configuración del servicio del proveedor elegido.
export const adminParseProviderPhoto = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ provider_id: z.string().uuid(), base64: z.string() }).parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin, providerRowById, parsePhotoItems } = await import("./crm.server");
    await assertAdmin(context);
    const prov = await providerRowById(context, data.provider_id);
    return { items: await parsePhotoItems(prov.services, data.base64) };
  });

/** Alta masiva/manual de prestadores (sin crear acceso al portal). Ideal para importar un archivo. */
export const importProviders = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        service_id: z.string().uuid(),
        product_id: z.string().uuid().nullable().optional(),
        providers: z
          .array(
            z.object({
              nombre: z.string().trim().min(2).max(160),
              cuit: z.string().max(20).nullable().optional(),
              cuenta_contable: z.string().max(40).nullable().optional(),
              email: z.string().max(160).nullable().optional(),
              banco: z.string().max(120).nullable().optional(),
              cbu: z.string().max(40).nullable().optional(),
              alias: z.string().max(80).nullable().optional(),
              titular: z.string().max(160).nullable().optional(),
              tipo: z.enum(["externo", "interno", "agoec"]).default("externo"),
            }),
          )
          .min(1)
          .max(2000),
      })
      .parse(raw),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);

    const rows = data.providers.map((p) => ({
      service_id: data.service_id,
      product_id: data.product_id ?? null,
      nombre: p.nombre,
      cuit: p.cuit || null,
      cuenta_contable: p.cuenta_contable || null,
      email: p.email || null,
      banco: p.banco || null,
      cbu: p.cbu || null,
      alias: p.alias || null,
      titular: p.titular || null,
      tipo: p.tipo,
      interno: p.tipo !== "externo",
      habilitado: true,
    }));

    const { data: inserted, error } = await context.supabase
      .from("providers")
      .insert(rows as any)
      .select("id");
    if (error) throw new Error(error.message);
    return { ok: true, insertados: inserted?.length ?? 0 };
  });
