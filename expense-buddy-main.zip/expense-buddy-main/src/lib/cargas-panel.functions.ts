import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

export const getCargasPanel = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        mes: z.number().int().min(1).max(12).nullable().optional(),
        anio: z.number().int().min(2000).max(2100).nullable().optional(),
      })
      .parse(raw ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { cargasPanel } = await import("./cargas-panel.server");
    return cargasPanel({ mes: data.mes ?? null, anio: data.anio ?? null });
  });

export const getCargasPeriodos = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./crm.server");
    await assertAdmin(context);
    const { cargasPeriodos } = await import("./cargas-panel.server");
    return cargasPeriodos();
  });
