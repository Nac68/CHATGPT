// Helpers server-only del Período de Adelantos: control previo al cierre y snapshot.

import { cuotaDelPeriodo as cuotaRefi, periodIndex, r2 } from "./refinance-plan";
import { withPlan as withAdvancePlan } from "./advances.server";

export type PeriodControl = {
  periodo_mes: number;
  periodo_anio: number;
  adelantos: number;
  legajos: number;
  total_solicitado: number;
  cuotas_adelantos: number;
  refinanciado_en_periodo: number;
  cuotas_refinanciacion: number;
  total_general: number;
  errores: { tipo: string; detalle: string }[];
  detalle: any[];
};

/** Control completo del período: totales separados y errores detectados. */
export async function buildPeriodControl(
  db: any,
  mes: number,
  anio: number,
): Promise<PeriodControl> {
  const [{ data: adelantos }, { data: refis }, { data: refiItems }] = await Promise.all([
    db.from("adelantos").select("*"),
    db.from("refinanciaciones").select("*"),
    db.from("refinanciacion_items").select("refinanciacion_id, importe, source_key"),
  ]);

  const todos = withAdvancePlan((adelantos ?? []) as any[], new Date(Date.UTC(anio, mes - 1, 15)));
  const delPeriodo = todos.filter(
    (a: any) => Number(a.periodo_mes) === mes && Number(a.periodo_anio) === anio,
  );

  const total_solicitado = r2(delPeriodo.reduce((s: number, a: any) => s + Number(a.monto_pedido || 0), 0));
  const cuotas_adelantos = r2(
    todos.reduce((s: number, a: any) => s + Number(a.importe_cuota_periodo || 0), 0),
  );

  const refisArr = ((refis ?? []) as any[]).filter((r) => String(r.estado ?? "activa") !== "anulada");
  const cuotas_refinanciacion = r2(
    refisArr.reduce((s, r) => s + (cuotaRefi(r, mes, anio)?.importe ?? 0), 0),
  );
  const idsDelPeriodo = new Set(
    refisArr
      .filter((r) => periodIndex(Number(r.periodo_mes), Number(r.periodo_anio)) === periodIndex(mes, anio))
      .map((r) => r.id),
  );
  const refinanciado_en_periodo = r2(
    ((refiItems ?? []) as any[])
      .filter((i) => idsDelPeriodo.has(i.refinanciacion_id))
      .reduce((s, i) => s + Number(i.importe || 0), 0),
  );

  const errores: { tipo: string; detalle: string }[] = [];
  for (const a of delPeriodo) {
    if (!a.apellido_nombre)
      errores.push({ tipo: "padrón", detalle: `Legajo ${a.legajo} sin nombre en el padrón` });
    if (Number(a.monto_pedido) <= 0)
      errores.push({ tipo: "monto", detalle: `Legajo ${a.legajo} con monto inválido` });
  }
  const activasPorLegajo = new Map<string, number>();
  for (const r of refisArr) {
    if (String(r.estado ?? "activa") !== "activa") continue;
    const cuotas = Math.max(1, Number(r.cuotas) || 1);
    const transcurridas = periodIndex(mes, anio) - periodIndex(Number(r.periodo_mes), Number(r.periodo_anio));
    if (transcurridas >= cuotas) continue;
    activasPorLegajo.set(String(r.legajo), (activasPorLegajo.get(String(r.legajo)) ?? 0) + 1);
  }
  for (const [legajo, cant] of activasPorLegajo)
    if (cant > 1)
      errores.push({
        tipo: "refinanciación",
        detalle: `Legajo ${legajo} tiene ${cant} refinanciaciones activas: consolidación bloqueada`,
      });

  return {
    periodo_mes: mes,
    periodo_anio: anio,
    adelantos: delPeriodo.length,
    legajos: new Set(delPeriodo.map((a: any) => String(a.legajo))).size,
    total_solicitado,
    cuotas_adelantos,
    refinanciado_en_periodo,
    cuotas_refinanciacion,
    total_general: r2(cuotas_adelantos + cuotas_refinanciacion),
    errores,
    detalle: delPeriodo,
  };
}
