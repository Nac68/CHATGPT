# Expense Buddy

Quiero hacer un administrador de control de gastos que se hace diariamente en mi empresa ,  

quiero tener un formulario diario en el que tiene un encabezado donde dice Comida a dto que es la descripción del formulario, después hay un importe que es el total de la cuenta a pagar , este importe se llena los días 15 de cada mes , después hay otro espacio donde esta la fecha y otro es la descripción de la comida servida .

Por otro lado esta el listado donde yo pongo el numero de legajo  y automáticamente me aparece el nombre y apellido que aparece en el Excel que subiré , y desp hay una columna donde  pongo el tilde que ese día consumio , si consumio desayuno y si consumio almuerzo , posteriormente el día 15 le pondré el importe por que ahí tendré el importe que pagamos en total ese día .

Tengo que tener la posibilidad de subir el consumo del día por foto o el administrador me permita completar online el formulario .

Los días 15 de cada mes pondría el importe consumido los días anteriores y se relaciona con el formulario de ese día y se divide el importe total dividido la gente que consumio y me dejaras bajar un Excel que mandare para que se cobre el importe total del mes por cada persona .

Tambien quiero que cada persona pueda entrar a un sector de la aplicación para poder ver los gastos que ha hecho ese mes y también los meses anrteriores , también darme estadísticas de los últimos meses , ya sea lo que consumio  y  que consumio y para el administrador general darme todas las estadísticas posibles ,como ser , cuanto gastamos por mes año y día  y en que se consumio . En el archivo adjunto veras un listado donde estan los que nosotros llamamos afiliados ( datos nuevos ) y cada uno tiene un numero de legajo , despues veras el trabajo que se realiza todos los meses , en donde veras los consumos  diarios y en la columna  D aparece el gasto total de ese dia . y en el archivo ficha de comida a dto , es el formulario que hago todos los dias con las presencias de la gente que comio . con esto necesito armar la aplicacion con el administrador correspondiente .

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/85d7c65d-66e3-4793-8b5c-69d7a189a13b).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
